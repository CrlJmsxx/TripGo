<?php
require_once 'config/database.php';

echo "<h2>TripGO Database Migration</h2>";
echo "<p>Adding missing columns for enhanced features...</p>";

try {
    $pdo = getConnection();
    
    // Add accepted_time column if it doesn't exist
    try {
        $pdo->exec("ALTER TABLE bookings ADD COLUMN accepted_time TIMESTAMP NULL");
        echo "<p style='color: green;'>✅ Added 'accepted_time' column to bookings table</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ 'accepted_time' column already exists</p>";
    }
    
    // Add rating_requested column if it doesn't exist
    try {
        $pdo->exec("ALTER TABLE bookings ADD COLUMN rating_requested BOOLEAN DEFAULT FALSE");
        echo "<p style='color: green;'>✅ Added 'rating_requested' column to bookings table</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ 'rating_requested' column already exists</p>";
    }
    
    // Add rating_submitted column if it doesn't exist
    try {
        $pdo->exec("ALTER TABLE bookings ADD COLUMN rating_submitted BOOLEAN DEFAULT FALSE");
        echo "<p style='color: green;'>✅ Added 'rating_submitted' column to bookings table</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ 'rating_submitted' column already exists</p>";
    }
    
    // Add average_rating column to users table if it doesn't exist
    try {
        $pdo->exec("ALTER TABLE users ADD COLUMN average_rating DECIMAL(3, 2) DEFAULT NULL");
        echo "<p style='color: green;'>✅ Added 'average_rating' column to users table</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ 'average_rating' column already exists</p>";
    }
    
    // Add current_lat column to users table if it doesn't exist
    try {
        $pdo->exec("ALTER TABLE users ADD COLUMN current_lat DECIMAL(10, 8) NULL");
        echo "<p style='color: green;'>✅ Added 'current_lat' column to users table</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ 'current_lat' column already exists</p>";
    }
    
    // Add current_lng column to users table if it doesn't exist
    try {
        $pdo->exec("ALTER TABLE users ADD COLUMN current_lng DECIMAL(11, 8) NULL");
        echo "<p style='color: green;'>✅ Added 'current_lng' column to users table</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ 'current_lng' column already exists</p>";
    }
    
    // Add updated_at column to users table if it doesn't exist
    try {
        $pdo->exec("ALTER TABLE users ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
        echo "<p style='color: green;'>✅ Added 'updated_at' column to users table</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ 'updated_at' column already exists</p>";
    }
    
    // Add cancellation columns to bookings table if they don't exist
    try {
        $pdo->exec("ALTER TABLE bookings ADD COLUMN cancellation_reason TEXT NULL");
        echo "<p style='color: green;'>✅ Added 'cancellation_reason' column to bookings table</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ 'cancellation_reason' column already exists</p>";
    }
    
    try {
        $pdo->exec("ALTER TABLE bookings ADD COLUMN cancelled_by ENUM('passenger', 'driver', 'system') NULL");
        echo "<p style='color: green;'>✅ Added 'cancelled_by' column to bookings table</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ 'cancelled_by' column already exists</p>";
    }
    
    try {
        $pdo->exec("ALTER TABLE bookings ADD COLUMN cancelled_at TIMESTAMP NULL");
        echo "<p style='color: green;'>✅ Added 'cancelled_at' column to bookings table</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ 'cancelled_at' column already exists</p>";
    }
    
    try {
        $pdo->exec("ALTER TABLE bookings ADD COLUMN expires_at TIMESTAMP NULL");
        echo "<p style='color: green;'>✅ Added 'expires_at' column to bookings table</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ 'expires_at' column already exists</p>";
    }
    
    // Add vehicle_type column if it doesn't exist
    try {
        $pdo->exec("ALTER TABLE bookings ADD COLUMN vehicle_type ENUM('motorcycle', 'tricycle', 'car') NULL");
        echo "<p style='color: green;'>✅ Added 'vehicle_type' column to bookings table</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ 'vehicle_type' column already exists</p>";
    }
    
    // Add driver vehicle fields if they don't exist
    try {
        $pdo->exec("ALTER TABLE driver_profiles ADD COLUMN vehicle_type ENUM('motorcycle', 'tricycle', 'car') NULL");
        echo "<p style='color: green;'>✅ Added 'vehicle_type' column to driver_profiles table</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ 'vehicle_type' column already exists in driver_profiles</p>";
    }
    
    try {
        $pdo->exec("ALTER TABLE driver_profiles ADD COLUMN vehicle_capacity INT NULL");
        echo "<p style='color: green;'>✅ Added 'vehicle_capacity' column to driver_profiles table</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ 'vehicle_capacity' column already exists in driver_profiles</p>";
    }
    
    try {
        $pdo->exec("ALTER TABLE driver_profiles ADD COLUMN vehicle_brand VARCHAR(50) NULL");
        echo "<p style='color: green;'>✅ Added 'vehicle_brand' column to driver_profiles table</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ 'vehicle_brand' column already exists in driver_profiles</p>";
    }
    
    // Update status enum to include 'expired' if needed
    try {
        $pdo->exec("ALTER TABLE bookings MODIFY COLUMN status ENUM('pending', 'accepted', 'in_progress', 'completed', 'cancelled', 'expired') DEFAULT 'pending'");
        echo "<p style='color: green;'>✅ Updated status enum to include 'expired'</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ Status enum already includes 'expired'</p>";
    }
    
    // Create reviews table if it doesn't exist
    try {
        $sql = "CREATE TABLE IF NOT EXISTS reviews (
            id INT AUTO_INCREMENT PRIMARY KEY,
            booking_id INT NOT NULL UNIQUE,
            passenger_id INT NOT NULL,
            driver_id INT NOT NULL,
            rating INT CHECK (rating >= 1 AND rating <= 5),
            review TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
            FOREIGN KEY (passenger_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (driver_id) REFERENCES users(id) ON DELETE CASCADE
        )";
        $pdo->exec($sql);
        echo "<p style='color: green;'>✅ Reviews table is ready</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ Reviews table already exists</p>";
    }
    
    echo "<h3 style='color: green;'>✅ Migration completed successfully!</h3>";
    echo "<p><a href='index.php'>Go to TripGO Homepage</a></p>";
    echo "<p><a href='driver/'>Go to Driver Dashboard</a></p>";
    echo "<p><a href='passenger/'>Go to Passenger Dashboard</a></p>";
    
} catch (Exception $e) {
    echo "<h3 style='color: red;'>❌ Migration Error</h3>";
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
    echo "<p>Please check your database connection and try again.</p>";
}
?>
