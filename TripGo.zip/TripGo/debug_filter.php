<?php
// Debug script to test the filter functionality
session_start();
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/session.php';

echo "<h2>Driver Filter Debug</h2>";

// Check if driver is logged in
$currentUser = getCurrentUser();
if (!$currentUser || $currentUser['user_type'] !== 'driver') {
    echo "<p style='color: red;'>Error: Not logged in as driver</p>";
    echo "<p>Current user: " . ($currentUser ? $currentUser['user_type'] : 'None') . "</p>";
    exit();
}

echo "<p style='color: green;'>✓ Driver logged in: " . htmlspecialchars($currentUser['full_name']) . "</p>";

// Check driver location
try {
    $pdo = getConnection();
    $stmt = $pdo->prepare("SELECT current_latitude, current_longitude FROM driver_profiles WHERE user_id = ?");
    $stmt->execute([$currentUser['id']]);
    $driverProfile = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$driverProfile) {
        echo "<p style='color: red;'>✗ No driver profile found</p>";
    } else {
        echo "<p style='color: green;'>✓ Driver profile found</p>";
        if (!$driverProfile['current_latitude'] || !$driverProfile['current_longitude']) {
            echo "<p style='color: orange;'>⚠ Driver location not set</p>";
            echo "<p>Lat: " . ($driverProfile['current_latitude'] ?? 'NULL') . "</p>";
            echo "<p>Lng: " . ($driverProfile['current_longitude'] ?? 'NULL') . "</p>";
        } else {
            echo "<p style='color: green;'>✓ Driver location available</p>";
            echo "<p>Lat: " . $driverProfile['current_latitude'] . "</p>";
            echo "<p>Lng: " . $driverProfile['current_longitude'] . "</p>";
        }
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>✗ Database error: " . htmlspecialchars($e->getMessage()) . "</p>";
}

// Check for pending requests
try {
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count
        FROM bookings b
        WHERE b.status = 'pending'
        AND (b.expires_at IS NULL OR b.expires_at > NOW())
        AND b.pickup_latitude IS NOT NULL
        AND b.pickup_longitude IS NOT NULL
    ");
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<p style='color: green;'>✓ Found " . $result['count'] . " pending requests with valid coordinates</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>✗ Query error: " . htmlspecialchars($e->getMessage()) . "</p>";
}

// Test the API endpoint directly
echo "<h3>Testing API Endpoint</h3>";
$api_url = 'http://' . $_SERVER['HTTP_HOST'] . '/TripGo/api/get_all_requests.php?max_radius=50';
echo "<p>URL: <code>" . htmlspecialchars($api_url) . "</code></p>";

$context = stream_context_create([
    'http' => [
        'method' => 'GET',
        'header' => 'Cookie: ' . $_SERVER['HTTP_COOKIE']
    ]
]);

$response = @file_get_contents($api_url, false, $context);

if ($response === false) {
    echo "<p style='color: red;'>✗ Failed to call API endpoint</p>";
    $error = error_get_last();
    echo "<p>Error: " . htmlspecialchars($error['message']) . "</p>";
} else {
    echo "<p style='color: green;'>✓ API endpoint responded</p>";
    echo "<p>Response:</p>";
    echo "<pre style='background: #f0f0f0; padding: 10px; border-radius: 4px;'>";
    echo htmlspecialchars($response);
    echo "</pre>";
    
    $data = json_decode($response, true);
    if ($data && isset($data['success'])) {
        if ($data['success']) {
            echo "<p style='color: green;'>✓ API returned success</p>";
            echo "<p>Requests found: " . count($data['requests']) . "</p>";
        } else {
            echo "<p style='color: red;'>✗ API returned error: " . htmlspecialchars($data['error']) . "</p>";
        }
    } else {
        echo "<p style='color: red;'>✗ Invalid JSON response</p>";
    }
}

echo "<h3>JavaScript Console Test</h3>";
echo "<p>Open browser console and run:</p>";
echo "<pre style='background: #f0f0f0; padding: 10px; border-radius: 4px;'>
fetch('/TripGo/api/get_all_requests.php?max_radius=50')
  .then(response => response.json())
  .then(data => console.log('Success:', data))
  .catch(error => console.error('Error:', error));
</pre>";
?>
