<?php


require_once 'config/database.php';

echo "<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>TripGO Setup</title>
    <link rel='stylesheet' href='assets/css/style.css'>
    <link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css' rel='stylesheet'>
</head>
<body class='auth-body'>
    <div class='auth-container'>
        <div class='auth-card'>
            <div class='auth-header'>
                <h1><i class='fas fa-car'></i> TripGO Setup</h1>
                <p>Initializing your ride-sharing platform</p>
            </div>";

try {
    // Test database connection
    $pdo = getConnection();
    echo "<div class='alert alert-success'>
            <i class='fas fa-check-circle'></i> Database connection successful!
          </div>";
    
    // Check if database is already initialized
    $stmt = $pdo->prepare("SHOW TABLES LIKE 'users'");
    $stmt->execute();
    $tablesExist = $stmt->fetch();
    
    if ($tablesExist) {
        echo "<div class='alert alert-info'>
                <i class='fas fa-info-circle'></i> Database tables already exist. System is ready to use!
              </div>";
        
        // Check if admin user exists
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE user_type = 'admin'");
        $stmt->execute();
        $adminCount = $stmt->fetchColumn();
        
        if ($adminCount > 0) {
            echo "<div class='alert alert-success'>
                    <i class='fas fa-user-shield'></i> Admin user already exists.
                  </div>";
        } else {
            // Create admin user
            $adminPassword = password_hash('admin123', PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password, full_name, phone, user_type, is_verified) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute(['admin', 'admin@tripgo.com', $adminPassword, 'System Administrator', '0000000000', 'admin', true]);
            
            echo "<div class='alert alert-success'>
                    <i class='fas fa-user-plus'></i> Admin user created successfully!
                  </div>";
        }
    } else {
        // Initialize database
        echo "<div class='alert alert-info'>
                <i class='fas fa-cog'></i> Initializing database tables...
              </div>";
        
        // The database initialization is handled in config/database.php
        echo "<div class='alert alert-success'>
                <i class='fas fa-check-circle'></i> Database initialized successfully!
              </div>";
    }
    
    // Display system information
    echo "<div style='margin-top: 30px; padding: 20px; background: #f8f9fa; border-radius: 10px;'>
            <h3 style='margin-bottom: 20px; color: #333;'>
                <i class='fas fa-info-circle'></i> System Information
            </h3>
            <div style='display: grid; gap: 15px;'>
                <div style='display: flex; justify-content: space-between; padding: 10px; background: white; border-radius: 8px;'>
                    <span><strong>Database:</strong> " . DB_NAME . "</span>
                    <span style='color: #28a745;'><i class='fas fa-check'></i> Connected</span>
                </div>
                <div style='display: flex; justify-content: space-between; padding: 10px; background: white; border-radius: 8px;'>
                    <span><strong>Admin Username:</strong> admin</span>
                    <span style='color: #667eea;'><i class='fas fa-user'></i> Ready</span>
                </div>
                <div style='display: flex; justify-content: space-between; padding: 10px; background: white; border-radius: 8px;'>
                    <span><strong>Admin Password:</strong> admin123</span>
                    <span style='color: #ffc107;'><i class='fas fa-key'></i> Default</span>
                </div>
            </div>
          </div>";
    
    echo "<div style='margin-top: 50px; text-align: center;'>
            <a href='index.php' class='btn btn-primary' style='margin-right: px;'>
                <i class='fas fa-home'></i> Go to Homepage
            </a><br>
            <a href='auth/login.php' class='btn btn-secondary'>
                <i class='fas fa-sign-in-alt'></i> Login as Admin
            </a>
          </div>";
    
} catch (Exception $e) {
    echo "<div class='alert alert-error'>
            <i class='fas fa-exclamation-circle'></i> Setup failed: " . $e->getMessage() . "
          </div>";
    
    echo "<div style='margin-top: 20px; padding: 20px; background: #f8d7da; border-radius: 10px; color: #721c24;'>
            <h4>Setup Instructions:</h4>
            <ol style='margin-top: 10px; padding-left: 20px;'>
                <li>Make sure XAMPP is running</li>
                <li>Create a database named 'tripgo_booking' in phpMyAdmin</li>
                <li>Update database credentials in config/database.php if needed</li>
                <li>Refresh this page</li>
            </ol>
          </div>";
}

echo "        </div>
    </div>
</body>
</html>";
?>
