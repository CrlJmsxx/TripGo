<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/session.php';

header('Content-Type: text/plain');

try {
    $pdo = getConnection();
    
    // Get a test passenger
    $stmt = $pdo->query("SELECT id, full_name FROM users WHERE user_type = 'passenger' LIMIT 1");
    $passenger = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$passenger) {
        echo "No passenger found. Creating test passenger...\n";
        
        // Create test passenger
        $stmt = $pdo->prepare("
            INSERT INTO users (full_name, email, password, user_type, phone, created_at) 
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            'Test Passenger',
            'passenger@test.com',
            password_hash('password123', PASSWORD_DEFAULT),
            'passenger',
            '+63912345678'
        ]);
        $passengerId = $pdo->lastInsertId();
        echo "Created test passenger with ID: $passengerId\n";
    } else {
        $passengerId = $passenger['id'];
        echo "Using existing passenger: {$passenger['full_name']} (ID: $passengerId)\n";
    }
    
    // Create test booking request
    $testBookings = [
        [
            'pickup_address' => 'Makati City Hall, Makati',
            'pickup_latitude' => 14.5547,
            'pickup_longitude' => 120.0244,
            'dropoff_address' => 'Bonifacio Global City, Taguig',
            'dropoff_latitude' => 14.5425,
            'dropoff_longitude' => 121.0459,
            'estimated_fare' => 150.00
        ],
        [
            'pickup_address' => 'Quezon City Hall, Quezon City',
            'pickup_latitude' => 14.6760,
            'pickup_longitude' => 121.0437,
            'dropoff_address' => 'Manila City Hall, Manila',
            'dropoff_latitude' => 14.5995,
            'dropoff_longitude' => 120.9842,
            'estimated_fare' => 200.00
        ],
        [
            'pickup_address' => 'SM Mall of Asia, Pasay',
            'pickup_latitude' => 14.5356,
            'pickup_longitude' => 120.9834,
            'dropoff_address' => 'Airport Terminal 3, Pasay',
            'dropoff_latitude' => 14.5086,
            'dropoff_longitude' => 121.0194,
            'estimated_fare' => 180.00
        ]
    ];
    
    $createdCount = 0;
    foreach ($testBookings as $booking) {
        // Check if similar booking already exists
        $stmt = $pdo->prepare("
            SELECT id FROM bookings 
            WHERE passenger_id = ? 
            AND pickup_address = ? 
            AND status = 'pending'
            AND created_at > DATE_SUB(NOW(), INTERVAL 30 MINUTE)
        ");
        $stmt->execute([$passengerId, $booking['pickup_address']]);
        $existing = $stmt->fetch();
        
        if (!$existing) {
            $stmt = $pdo->prepare("
                INSERT INTO bookings (
                    passenger_id, pickup_address, pickup_latitude, pickup_longitude,
                    dropoff_address, dropoff_latitude, dropoff_longitude,
                    estimated_fare, status, booking_time, expires_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', NOW(), DATE_ADD(NOW(), INTERVAL 15 MINUTE))
            ");
            
            $stmt->execute([
                $passengerId,
                $booking['pickup_address'],
                $booking['pickup_latitude'],
                $booking['pickup_longitude'],
                $booking['dropoff_address'],
                $booking['dropoff_latitude'],
                $booking['dropoff_longitude'],
                $booking['estimated_fare']
            ]);
            
            $bookingId = $pdo->lastInsertId();
            echo "Created booking #{$bookingId}: {$booking['pickup_address']} → {$booking['dropoff_address']}\n";
            $createdCount++;
        } else {
            echo "Similar booking already exists: {$booking['pickup_address']}\n";
        }
    }
    
    echo "\n=== Summary ===\n";
    echo "Created $createdCount new booking requests\n";
    
    // Check total pending requests
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM bookings WHERE status = 'pending'");
    $totalPending = $stmt->fetch()['count'];
    echo "Total pending requests: $totalPending\n";
    
    // Check requests with coordinates
    $stmt = $pdo->query("
        SELECT COUNT(*) as count 
        FROM bookings 
        WHERE status = 'pending' 
        AND pickup_latitude IS NOT NULL 
        AND pickup_longitude IS NOT NULL
    ");
    $withCoords = $stmt->fetch()['count'];
    echo "Pending requests with coordinates: $withCoords\n";
    
    echo "\nTest booking creation completed!\n";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
