<?php
// Test environment setup script
require_once __DIR__ . '/config/database.php';

echo "<h2>Setting Up Test Environment</h2>";

try {
    $pdo = getConnection();
    echo "<p style='color: green;'>✓ Database connection successful</p>";
    
    // Get driver user
    $stmt = $pdo->prepare("SELECT id, full_name FROM users WHERE user_type = 'driver' LIMIT 1");
    $stmt->execute();
    $driver = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$driver) {
        echo "<p style='color: red;'>✗ No driver user found. Creating test driver...</p>";
        
        // Create test driver
        $stmt = $pdo->prepare("
            INSERT INTO users (full_name, email, phone, password, user_type, created_at) 
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            'Test Driver',
            'driver@test.com',
            '1234567890',
            password_hash('password123', PASSWORD_DEFAULT),
            'driver'
        ]);
        
        $driverId = $pdo->lastInsertId();
        
        // Create driver profile
        $stmt = $pdo->prepare("
            INSERT INTO driver_profiles (user_id, license_number, vehicle_type, vehicle_plate, current_latitude, current_longitude) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $driverId,
            'TEST-12345',
            'sedan',
            'TEST-123',
            14.5995,
            120.9842
        ]);
        
        echo "<p style='color: green;'>✓ Test driver created successfully</p>";
    } else {
        echo "<p style='color: green;'>✓ Found driver: " . htmlspecialchars($driver['full_name']) . "</p>";
        
        // Update driver location
        $stmt = $pdo->prepare("
            UPDATE driver_profiles 
            SET current_latitude = ?, current_longitude = ? 
            WHERE user_id = ?
        ");
        $stmt->execute([14.5995, 120.9842, $driver['id']]);
        
        echo "<p style='color: green;'>✓ Driver location updated to Manila area</p>";
    }
    
    // Get passenger user
    $stmt = $pdo->prepare("SELECT id, full_name FROM users WHERE user_type = 'passenger' LIMIT 1");
    $stmt->execute();
    $passenger = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$passenger) {
        echo "<p style='color: red;'>✗ No passenger user found. Creating test passenger...</p>";
        
        $stmt = $pdo->prepare("
            INSERT INTO users (full_name, email, phone, password, user_type, created_at) 
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            'Test Passenger',
            'passenger@test.com',
            '0987654321',
            password_hash('password123', PASSWORD_DEFAULT),
            'passenger'
        ]);
        
        echo "<p style='color: green;'>✓ Test passenger created successfully</p>";
    } else {
        echo "<p style='color: green;'>✓ Found passenger: " . htmlspecialchars($passenger['full_name']) . "</p>";
    }
    
    echo "<br><h3>Next Steps:</h3>";
    echo "<p>1. <a href='create_test_requests.php'>Create Test Requests</a></p>";
    echo "<p>2. <a href='driver/dashboard.php'>Go to Driver Dashboard</a></p>";
    echo "<p>3. Test the 'Filter All Requests' button</p>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>✗ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}
?>
