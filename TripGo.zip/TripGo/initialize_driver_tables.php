<?php
require_once 'config/database.php';

echo "<h2>Initialize Driver Tables</h2>";
echo "<p>Creating missing driver_profiles table and updating vehicle fields...</p>";

try {
    $pdo = getConnection();
    
    // Create driver_profiles table if it doesn't exist
    try {
        $sql = "CREATE TABLE IF NOT EXISTS driver_profiles (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            license_number VARCHAR(50) NOT NULL,
            vehicle_model VARCHAR(100) NOT NULL,
            vehicle_plate VARCHAR(20) NOT NULL,
            vehicle_color VARCHAR(30) NOT NULL,
            is_available BOOLEAN DEFAULT TRUE,
            current_latitude DECIMAL(10, 8),
            current_longitude DECIMAL(11, 8),
            rating DECIMAL(3, 2) DEFAULT 0.00,
            total_rides INT DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )";
        $pdo->exec($sql);
        echo "<p style='color: green;'>✅ driver_profiles table created successfully</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ driver_profiles table already exists</p>";
    }
    
    // Add vehicle type column if it doesn't exist
    try {
        $pdo->exec("ALTER TABLE driver_profiles ADD COLUMN vehicle_type ENUM('motorcycle', 'tricycle', 'car') NULL");
        echo "<p style='color: green;'>✅ Added 'vehicle_type' column to driver_profiles table</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ 'vehicle_type' column already exists in driver_profiles</p>";
    }
    
    // Add vehicle brand column if it doesn't exist
    try {
        $pdo->exec("ALTER TABLE driver_profiles ADD COLUMN vehicle_brand VARCHAR(50) NULL");
        echo "<p style='color: green;'>✅ Added 'vehicle_brand' column to driver_profiles table</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ 'vehicle_brand' column already exists in driver_profiles</p>";
    }
    
    // Add vehicle capacity column if it doesn't exist
    try {
        $pdo->exec("ALTER TABLE driver_profiles ADD COLUMN vehicle_capacity INT NULL");
        echo "<p style='color: green;'>✅ Added 'vehicle_capacity' column to driver_profiles table</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ 'vehicle_capacity' column already exists in driver_profiles</p>";
    }
    
    // Add updated_at column if it doesn't exist
    try {
        $pdo->exec("ALTER TABLE driver_profiles ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
        echo "<p style='color: green;'>✅ Added 'updated_at' column to driver_profiles table</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ 'updated_at' column already exists in driver_profiles</p>";
    }
    
    // Create driver_notifications table if it doesn't exist
    try {
        $sql = "CREATE TABLE IF NOT EXISTS driver_notifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            driver_id INT NOT NULL,
            booking_id INT NULL,
            notification_type ENUM('new_ride_request', 'booking_accepted', 'booking_cancelled', 'payment_received') DEFAULT 'new_ride_request',
            message TEXT NOT NULL,
            is_read BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (driver_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE SET NULL
        )";
        $pdo->exec($sql);
        echo "<p style='color: green;'>✅ driver_notifications table created successfully</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ driver_notifications table already exists</p>";
    }
    
    echo "<h3 style='color: green;'>✅ Driver table initialization completed successfully!</h3>";
    echo "<p><a href='driver/'>Go to Driver Dashboard</a></p>";
    echo "<p><a href='index.php'>Go to Homepage</a></p>";
    
} catch (Exception $e) {
    echo "<h3 style='color: red;'>❌ Initialization Error</h3>";
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
    echo "<p>Please check your database connection and try again.</p>";
}
?>
