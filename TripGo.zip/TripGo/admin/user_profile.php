<?php
require_once '../config/database.php';
require_once '../config/session.php';

requireAdmin();

$currentUser = getCurrentUser();
$pdo = getConnection();

// Get user details
$userId = $_GET['id'] ?? null;
if (!$userId) {
    header('Location: users.php');
    exit();
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    header('Location: users.php');
    exit();
}

// Get driver profile if applicable
$driverProfile = null;
if ($user['user_type'] === 'driver') {
    $stmt = $pdo->prepare("SELECT * FROM driver_profiles WHERE user_id = ?");
    $stmt->execute([$userId]);
    $driverProfile = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Get user's booking statistics
$bookingStats = [
    'total_bookings' => 0,
    'completed_bookings' => 0,
    'cancelled_bookings' => 0
];

if ($user['user_type'] === 'passenger') {
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
            SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled
        FROM bookings 
        WHERE passenger_id = ?
    ");
    $stmt->execute([$userId]);
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);
    $bookingStats = [
        'total_bookings' => $stats['total'],
        'completed_bookings' => $stats['completed'],
        'cancelled_bookings' => $stats['cancelled']
    ];
} elseif ($user['user_type'] === 'driver') {
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
            SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled
        FROM bookings 
        WHERE driver_id = ?
    ");
    $stmt->execute([$userId]);
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);
    $bookingStats = [
        'total_bookings' => $stats['total'],
        'completed_bookings' => $stats['completed'],
        'cancelled_bookings' => $stats['cancelled']
    ];
}

// Get recent bookings
$recentBookings = [];
if ($user['user_type'] === 'passenger') {
    $stmt = $pdo->prepare("
        SELECT b.*, d.full_name as driver_name
        FROM bookings b
        LEFT JOIN users d ON b.driver_id = d.id
        WHERE b.passenger_id = ?
        ORDER BY b.booking_time DESC
        LIMIT 5
    ");
    $stmt->execute([$userId]);
    $recentBookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
} elseif ($user['user_type'] === 'driver') {
    $stmt = $pdo->prepare("
        SELECT b.*, p.full_name as passenger_name
        FROM bookings b
        LEFT JOIN users p ON b.passenger_id = p.id
        WHERE b.driver_id = ?
        ORDER BY b.booking_time DESC
        LIMIT 5
    ");
    $stmt->execute([$userId]);
    $recentBookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile - TripGO</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="header-content">
                <a href="../index.php" class="logo">
                    <i class="fas fa-car"></i> TripGO
                </a>
                
                <nav class="nav">
                    <a href="../index.php">Home</a>
                    <a href="dashboard.php">Dashboard</a>
                    <a href="users.php">Users</a>
                    <a href="bookings.php">Bookings</a>
                    <a href="settings.php">Settings</a>
                </nav>
                
                <div class="user-menu">
                    <div class="user-info">
                        <div class="user-avatar">
                            <?php echo strtoupper(substr($currentUser['full_name'], 0, 1)); ?>
                        </div>
                        <span><?php echo htmlspecialchars($currentUser['full_name']); ?></span>
                    </div>
                    <a href="../auth/logout.php" class="btn btn-danger">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="container" style="padding: 40px 0;">
        <!-- Back Button -->
        <div style="margin-bottom: 20px;">
            <a href="users.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Users
            </a>
        </div>

        <!-- Profile Header -->
        <div class="card" style="margin-bottom: 30px;">
            <div style="display: flex; align-items: center; gap: 30px; padding: 30px;">
                <!-- Profile Image -->
                <div style="text-align: center;">
                    <?php if ($user['profile_image']): ?>
                        <img src="../<?php echo htmlspecialchars($user['profile_image']); ?>" 
                             alt="Profile Image" 
                             style="width: 150px; height: 150px; border-radius: 50%; object-fit: cover; border: 4px solid var(--primary-color); box-shadow: var(--shadow-medium);">
                    <?php else: ?>
                        <div style="width: 150px; height: 150px; border-radius: 50%; background: linear-gradient(135deg, var(--primary-color), var(--accent-color)); display: flex; align-items: center; justify-content: center; font-size: 3rem; color: white; font-weight: bold; box-shadow: var(--shadow-medium);">
                            <?php echo strtoupper(substr($user['full_name'], 0, 1)); ?>
                        </div>
                    <?php endif; ?>
                    
                    <div style="margin-top: 15px;">
                        <span class="badge badge-<?php echo $user['user_type'] === 'admin' ? 'danger' : ($user['user_type'] === 'driver' ? 'warning' : 'info'); ?>" style="font-size: 14px; padding: 8px 16px;">
                            <i class="fas fa-<?php echo $user['user_type'] === 'admin' ? 'user-shield' : ($user['user_type'] === 'driver' ? 'car' : 'user'); ?>"></i>
                            <?php echo ucfirst($user['user_type']); ?>
                        </span>
                    </div>
                </div>
                
                <!-- User Info -->
                <div style="flex: 1;">
                    <h1 style="font-size: 2.5rem; margin-bottom: 10px; color: var(--text-primary);">
                        <?php echo htmlspecialchars($user['full_name']); ?>
                    </h1>
                    
                    <div style="display: flex; gap: 20px; margin-bottom: 20px; flex-wrap: wrap;">
                        <div style="display: flex; align-items: center; gap: 8px; color: var(--text-secondary);">
                            <i class="fas fa-envelope"></i>
                            <?php echo htmlspecialchars($user['email']); ?>
                        </div>
                        <div style="display: flex; align-items: center; gap: 8px; color: var(--text-secondary);">
                            <i class="fas fa-phone"></i>
                            <?php echo htmlspecialchars($user['phone']); ?>
                        </div>
                        <div style="display: flex; align-items: center; gap: 8px; color: var(--text-secondary);">
                            <i class="fas fa-id-badge"></i>
                            ID: <?php echo $user['id']; ?>
                        </div>
                    </div>
                    
                    <div style="display: flex; align-items: center; gap: 15px;">
                        <span class="badge badge-<?php echo $user['is_verified'] ? 'success' : 'secondary'; ?>">
                            <i class="fas fa-<?php echo $user['is_verified'] ? 'check-circle' : 'clock'; ?>"></i>
                            <?php echo $user['is_verified'] ? 'Verified' : 'Pending Verification'; ?>
                        </span>
                        <span style="color: var(--text-muted); font-size: 14px;">
                            <i class="fas fa-calendar"></i>
                            Joined <?php echo date('F j, Y', strtotime($user['created_at'])); ?>
                        </span>
                    </div>
                </div>
                
                <!-- Actions -->
                <div style="display: flex; flex-direction: column; gap: 10px;">
                    <?php if (!$user['is_verified'] && $user['user_type'] !== 'admin'): ?>
                        <form method="POST" style="display: inline;">
                            <input type="hidden" name="verify_user" value="1">
                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                            <button type="submit" class="btn btn-success" onclick="return confirm('Verify this user?')">
                                <i class="fas fa-check"></i> Verify User
                            </button>
                        </form>
                    <?php endif; ?>
                    
                    <?php if ($user['user_type'] !== 'admin'): ?>
                        <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this user? This action cannot be undone.')">
                            <input type="hidden" name="delete_user" value="1">
                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                            <button type="submit" class="btn btn-danger">
                                <i class="fas fa-trash"></i> Delete User
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Driver Profile (if applicable) -->
        <?php if ($driverProfile): ?>
        <div class="card" style="margin-bottom: 30px;">
            <div class="card-header">
                <h2 class="card-title">
                    <i class="fas fa-car"></i> Driver Information
                </h2>
            </div>
            <div style="padding: 20px;">
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                    <div>
                        <strong style="color: var(--text-secondary);">License Number:</strong>
                        <p style="margin: 5px 0; color: var(--text-primary);"><?php echo htmlspecialchars($driverProfile['license_number']); ?></p>
                    </div>
                    <div>
                        <strong style="color: var(--text-secondary);">Vehicle Model:</strong>
                        <p style="margin: 5px 0; color: var(--text-primary);"><?php echo htmlspecialchars($driverProfile['vehicle_model']); ?></p>
                    </div>
                    <div>
                        <strong style="color: var(--text-secondary);">Vehicle Plate:</strong>
                        <p style="margin: 5px 0; color: var(--text-primary);"><?php echo htmlspecialchars($driverProfile['vehicle_plate']); ?></p>
                    </div>
                    <div>
                        <strong style="color: var(--text-secondary);">Vehicle Color:</strong>
                        <p style="margin: 5px 0; color: var(--text-primary);"><?php echo htmlspecialchars($driverProfile['vehicle_color']); ?></p>
                    </div>
                    <div>
                        <strong style="color: var(--text-secondary);">Rating:</strong>
                        <p style="margin: 5px 0; color: var(--text-primary);">
                            <?php if ($driverProfile['rating'] > 0): ?>
                                <?php echo number_format($driverProfile['rating'], 1); ?> ⭐
                            <?php else: ?>
                                No rating yet
                            <?php endif; ?>
                        </p>
                    </div>
                    <div>
                        <strong style="color: var(--text-secondary);">Total Rides:</strong>
                        <p style="margin: 5px 0; color: var(--text-primary);"><?php echo $driverProfile['total_rides']; ?></p>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Statistics -->
        <div class="card" style="margin-bottom: 30px;">
            <div class="card-header">
                <h2 class="card-title">
                    <i class="fas fa-chart-bar"></i> Booking Statistics
                </h2>
            </div>
            <div style="padding: 20px;">
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
                    <div style="text-align: center; padding: 20px; background: var(--bg-primary); border-radius: 12px; border-left: 4px solid var(--primary-color);">
                        <div style="font-size: 2rem; font-weight: bold; color: var(--primary-color);"><?php echo $bookingStats['total_bookings']; ?></div>
                        <div style="color: var(--text-secondary); margin-top: 5px;">Total Bookings</div>
                    </div>
                    <div style="text-align: center; padding: 20px; background: var(--bg-primary); border-radius: 12px; border-left: 4px solid var(--success-color);">
                        <div style="font-size: 2rem; font-weight: bold; color: var(--success-color);"><?php echo $bookingStats['completed_bookings']; ?></div>
                        <div style="color: var(--text-secondary); margin-top: 5px;">Completed</div>
                    </div>
                    <div style="text-align: center; padding: 20px; background: var(--bg-primary); border-radius: 12px; border-left: 4px solid var(--creative-accent);">
                        <div style="font-size: 2rem; font-weight: bold; color: var(--creative-accent);"><?php echo $bookingStats['cancelled_bookings']; ?></div>
                        <div style="color: var(--text-secondary); margin-top: 5px;">Cancelled</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Bookings -->
        <?php if (!empty($recentBookings)): ?>
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">
                    <i class="fas fa-history"></i> Recent Bookings
                </h2>
            </div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Booking ID</th>
                            <th><?php echo $user['user_type'] === 'driver' ? 'Passenger' : 'Driver'; ?></th>
                            <th>Pickup</th>
                            <th>Dropoff</th>
                            <th>Fare</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentBookings as $booking): ?>
                            <tr>
                                <td>#<?php echo $booking['id']; ?></td>
                                <td>
                                    <?php echo htmlspecialchars($user['user_type'] === 'driver' ? $booking['passenger_name'] : ($booking['driver_name'] ?: 'Not assigned')); ?>
                                </td>
                                <td><?php echo htmlspecialchars(substr($booking['pickup_address'], 0, 30)) . '...'; ?></td>
                                <td><?php echo htmlspecialchars(substr($booking['dropoff_address'], 0, 30)) . '...'; ?></td>
                                <td>₱<?php echo number_format($booking['estimated_fare'] ?? 0, 2); ?></td>
                                <td>
                                    <span class="badge badge-<?php echo $booking['status'] === 'completed' ? 'success' : ($booking['status'] === 'cancelled' ? 'danger' : 'warning'); ?>">
                                        <?php echo ucfirst($booking['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('M j, Y g:i A', strtotime($booking['booking_time'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>
