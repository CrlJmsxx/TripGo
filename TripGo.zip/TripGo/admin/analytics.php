<?php
require_once '../config/database.php';
require_once '../config/session.php';

requireAdmin();

$currentUser = getCurrentUser();
$pdo = getConnection();

// Get analytics data
$analytics = [];

// Revenue analytics
$stmt = $pdo->prepare("
    SELECT 
        DATE(booking_time) as date,
        COUNT(*) as total_bookings,
        SUM(CASE WHEN status = 'completed' THEN actual_fare ELSE 0 END) as revenue
    FROM bookings 
    WHERE booking_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    GROUP BY DATE(booking_time)
    ORDER BY date DESC
");
$stmt->execute();
$revenueData = $stmt->fetchAll(PDO::FETCH_ASSOC);

// User analytics
$stmt = $pdo->prepare("
    SELECT 
        user_type,
        COUNT(*) as count,
        AVG(CASE WHEN user_type = 'driver' THEN (
            SELECT AVG(rating) FROM driver_profiles WHERE user_id = users.id
        ) ELSE NULL END) as avg_rating
    FROM users 
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    GROUP BY user_type
");
$stmt->execute();
$userData = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Booking analytics
$stmt = $pdo->prepare("
    SELECT 
        status,
        COUNT(*) as count,
        AVG(estimated_fare) as avg_fare,
        AVG(distance_km) as avg_distance
    FROM bookings 
    WHERE booking_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    GROUP BY status
");
$stmt->execute();
$bookingData = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Peak hours analysis
$stmt = $pdo->prepare("
    SELECT 
        HOUR(booking_time) as hour,
        COUNT(*) as bookings
    FROM bookings 
    WHERE booking_time >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY HOUR(booking_time)
    ORDER BY hour
");
$stmt->execute();
$peakHours = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Top drivers
$stmt = $pdo->prepare("
    SELECT 
        u.full_name,
        dp.rating,
        dp.total_rides,
        SUM(CASE WHEN b.status = 'completed' THEN b.actual_fare ELSE 0 END) as total_earnings
    FROM users u
    JOIN driver_profiles dp ON u.id = dp.user_id
    LEFT JOIN bookings b ON u.id = b.driver_id
    WHERE u.user_type = 'driver' AND u.is_verified = 1
    GROUP BY u.id
    ORDER BY total_earnings DESC
    LIMIT 10
");
$stmt->execute();
$topDrivers = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Popular routes
$stmt = $pdo->prepare("
    SELECT 
        pickup_address,
        dropoff_address,
        COUNT(*) as frequency,
        AVG(estimated_fare) as avg_fare
    FROM bookings 
    WHERE booking_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    GROUP BY pickup_address, dropoff_address
    HAVING frequency > 1
    ORDER BY frequency DESC
    LIMIT 10
");
$stmt->execute();
$popularRoutes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// System performance
$stmt = $pdo->prepare("
    SELECT 
        COUNT(*) as total_users,
        (SELECT COUNT(*) FROM users WHERE user_type = 'passenger') as passengers,
        (SELECT COUNT(*) FROM users WHERE user_type = 'driver') as drivers,
        (SELECT COUNT(*) FROM bookings) as total_bookings,
        (SELECT COUNT(*) FROM bookings WHERE status = 'completed') as completed_bookings,
        (SELECT SUM(actual_fare) FROM bookings WHERE status = 'completed') as total_revenue
    FROM users
");
$stmt->execute();
$systemStats = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics Dashboard - TripGO</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <a href="../index.php" class="logo">
                    <i class="fas fa-car"></i> TripGO
                </a>
                
                <nav class="nav">
                    <a href="../index.php">Home</a>
                    <a href="dashboard.php">Dashboard</a>
                    <a href="analytics.php" style="font-weight: bold; color: #667eea;">Analytics</a>
                    <a href="users.php">Users</a>
                    <a href="settings.php">Settings</a>
                </nav>
                
                <div class="user-menu">
                    <div class="user-info">
                        <div class="user-avatar">
                            <?php echo strtoupper(substr($currentUser['full_name'], 0, 1)); ?>
                        </div>
                        <span><?php echo htmlspecialchars($currentUser['full_name']); ?></span>
                    </div>
                    <a href="../auth/logout.php" class="btn btn-danger">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="container" style="padding: 40px 0;">
        <!-- Analytics Overview -->
        <div class="card" style="margin-bottom: 30px;">
            <div class="card-header">
                <h1 class="card-title">
                    <i class="fas fa-chart-line"></i> Advanced Analytics Dashboard
                </h1>
            </div>
            <p style="color: #666; font-size: 1.1rem;">
                Comprehensive insights into your ride-sharing platform performance.
            </p>
        </div>

        <!-- System Statistics -->
        <div class="stats-grid" style="margin-bottom: 40px;">
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-number"><?php echo $systemStats['total_users']; ?></div>
                <div class="stat-label">Total Users</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, #28a745 0%, #20c997 100%);">
                    <i class="fas fa-route"></i>
                </div>
                <div class="stat-number"><?php echo $systemStats['total_bookings']; ?></div>
                <div class="stat-label">Total Bookings</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%);">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="stat-number"><?php echo $systemStats['completed_bookings']; ?></div>
                <div class="stat-label">Completed Rides</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, #dc3545 0%, #e83e8c 100%);">
                    <i class="fas fa-dollar-sign"></i>
                </div>
                <div class="stat-number">₱<?php echo number_format($systemStats['total_revenue'], 2); ?></div>
                <div class="stat-label">Total Revenue</div>
            </div>
        </div>

        <div class="dashboard-grid">
            <!-- Revenue Chart -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-chart-area" style="color: #667eea;"></i>
                        Revenue Trends (Last 30 Days)
                    </h3>
                </div>
                <div style="height: 300px; position: relative;">
                    <canvas id="revenueChart"></canvas>
                </div>
            </div>

            <!-- Booking Status Chart -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-chart-pie" style="color: #28a745;"></i>
                        Booking Status Distribution
                    </h3>
                </div>
                <div style="height: 300px; position: relative;">
                    <canvas id="statusChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Peak Hours Analysis -->
        <div class="card" style="margin-top: 30px;">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-clock" style="color: #ffc107;"></i>
                    Peak Hours Analysis (Last 7 Days)
                </h3>
            </div>
            <div style="height: 300px; position: relative;">
                <canvas id="peakHoursChart"></canvas>
            </div>
        </div>

        <div class="dashboard-grid" style="margin-top: 30px;">
            <!-- Top Drivers -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-trophy" style="color: #667eea;"></i>
                        Top Performing Drivers
                    </h3>
                </div>
                <div class="table-container">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Driver</th>
                                <th>Rating</th>
                                <th>Rides</th>
                                <th>Earnings</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($topDrivers as $driver): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($driver['full_name']); ?></td>
                                    <td>
                                        <span style="color: #ffc107;">
                                            <?php echo number_format($driver['rating'], 1); ?> ⭐
                                        </span>
                                    </td>
                                    <td><?php echo $driver['total_rides']; ?></td>
                                    <td>₱<?php echo number_format($driver['total_earnings'], 2); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Popular Routes -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-route" style="color: #28a745;"></i>
                        Popular Routes
                    </h3>
                </div>
                <div class="table-container">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Route</th>
                                <th>Frequency</th>
                                <th>Avg Fare</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($popularRoutes as $route): ?>
                                <tr>
                                    <td>
                                        <div style="font-size: 0.9rem;">
                                            <strong>From:</strong> <?php echo htmlspecialchars($route['pickup_address']); ?><br>
                                            <strong>To:</strong> <?php echo htmlspecialchars($route['dropoff_address']); ?>
                                        </div>
                                    </td>
                                    <td><?php echo $route['frequency']; ?></td>
                                    <td>₱<?php echo number_format($route['avg_fare'], 2); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Revenue Chart
        const revenueCtx = document.getElementById('revenueChart').getContext('2d');
        const revenueData = <?php echo json_encode($revenueData); ?>;
        
        new Chart(revenueCtx, {
            type: 'line',
            data: {
                labels: revenueData.map(item => item.date).reverse(),
                datasets: [{
                    label: 'Revenue (₱)',
                    data: revenueData.map(item => parseFloat(item.revenue)).reverse(),
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Status Chart
        const statusCtx = document.getElementById('statusChart').getContext('2d');
        const statusData = <?php echo json_encode($bookingData); ?>;
        
        new Chart(statusCtx, {
            type: 'doughnut',
            data: {
                labels: statusData.map(item => item.status),
                datasets: [{
                    data: statusData.map(item => item.count),
                    backgroundColor: [
                        '#667eea',
                        '#28a745',
                        '#ffc107',
                        '#dc3545',
                        '#17a2b8'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });

        // Peak Hours Chart
        const peakHoursCtx = document.getElementById('peakHoursChart').getContext('2d');
        const peakHoursData = <?php echo json_encode($peakHours); ?>;
        
        new Chart(peakHoursCtx, {
            type: 'bar',
            data: {
                labels: peakHoursData.map(item => item.hour + ':00'),
                datasets: [{
                    label: 'Bookings',
                    data: peakHoursData.map(item => item.bookings),
                    backgroundColor: '#ffc107',
                    borderColor: '#ffc107',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>
