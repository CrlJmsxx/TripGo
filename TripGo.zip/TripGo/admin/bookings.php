<?php
require_once '../config/database.php';
require_once '../config/session.php';

requireAdmin();

$currentUser = getCurrentUser();
$pdo = getConnection();

// Handle booking actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['cancel_booking'])) {
        $bookingId = $_POST['booking_id'];
        $stmt = $pdo->prepare("UPDATE bookings SET status = 'cancelled' WHERE id = ?");
        $stmt->execute([$bookingId]);
        header('Location: bookings.php');
        exit();
    }
}

// Handle booking search
$searchTerm = $_GET['search'] ?? '';

// Build the query
$query = "
    SELECT b.*, 
           p.full_name as passenger_name, 
           d.full_name as driver_name 
    FROM bookings b 
    LEFT JOIN users p ON b.passenger_id = p.id 
    LEFT JOIN users d ON b.driver_id = d.id 
    WHERE 1=1
";
$params = [];

// Search by booking ID
if (!empty($searchTerm)) {
    $query .= " AND b.id LIKE ?";
    $params[] = "%$searchTerm%";
}

$query .= " ORDER BY b.booking_time DESC";

// Get filtered bookings
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bookings Management - TripGO</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <a href="../index.php" class="logo">
                    <i class="fas fa-car"></i> TripGO
                </a>
                
                <nav class="nav">
                    <a href="../index.php">Home</a>
                    <a href="dashboard.php">Dashboard</a>
                    <a href="users.php">Users</a>
                    <a href="bookings.php">Bookings</a>
                    <a href="settings.php">Settings</a>
                </nav>
                
                <div class="user-menu">
                    <div class="user-info">
                        <div class="user-avatar">
                            <?php echo strtoupper(substr($currentUser['full_name'], 0, 1)); ?>
                        </div>
                        <span><?php echo htmlspecialchars($currentUser['full_name']); ?></span>
                    </div>
                    <a href="../auth/logout.php" class="btn btn-danger">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="container" style="padding: 40px 0;">
        <div class="card">
            <div class="card-header">
                <h1 class="card-title">
                    <i class="fas fa-route"></i> Bookings Management
                </h1>
            </div>
            
            <!-- Search Container -->
            <div style="padding: 20px; background: var(--bg-primary); border-radius: 12px; margin-bottom: 20px;">
                <div style="display: flex; gap: 20px; align-items: center; flex-wrap: wrap;">
                    <!-- Search Bar -->
                    <div style="flex: 1; min-width: 300px;">
                        <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--text-primary);">
                            <i class="fas fa-search"></i> Search by Booking ID
                        </label>
                        <div style="display: flex; gap: 10px;">
                            <input type="text" 
                                   id="searchInput" 
                                   placeholder="Enter booking ID..." 
                                   value="<?php echo htmlspecialchars($searchTerm); ?>"
                                   style="flex: 1; padding: 10px; border: 2px solid var(--border-color); border-radius: 8px; background: var(--bg-secondary); color: var(--text-primary); font-size: 14px;"
                                   onkeyup="handleSearch(event)">
                            <button type="button" 
                                    onclick="searchBookings()" 
                                    class="btn btn-primary"
                                    style="padding: 10px 20px;">
                                <i class="fas fa-search"></i> Search
                            </button>
                        </div>
                    </div>
                    
                    <!-- Clear Search -->
                    <div style="display: flex; align-items: flex-end;">
                        <button type="button" 
                                onclick="clearSearch()" 
                                class="btn btn-secondary"
                                style="padding: 10px 20px;">
                            <i class="fas fa-times"></i> Clear
                        </button>
                    </div>
                </div>
                
                <!-- Results Count -->
                <div style="margin-top: 15px; padding: 10px; background: var(--bg-secondary); border-radius: 8px; border-left: 4px solid var(--primary-color);">
                    <span style="color: var(--text-secondary); font-size: 14px;">
                        <i class="fas fa-info-circle"></i> 
                        Showing <strong><?php echo count($bookings); ?></strong> booking(s)
                        <?php if (!empty($searchTerm)): ?>
                            matching "<strong><?php echo htmlspecialchars($searchTerm); ?></strong>"
                        <?php endif; ?>
                    </span>
                </div>
            </div>
            
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Passenger</th>
                            <th>Driver</th>
                            <th>Pickup</th>
                            <th>Dropoff</th>
                            <th>Fare</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($bookings as $booking): ?>
                            <tr>
                                <td>#<?php echo $booking['id']; ?></td>
                                <td><?php echo htmlspecialchars($booking['passenger_name']); ?></td>
                                <td><?php echo $booking['driver_name'] ? htmlspecialchars($booking['driver_name']) : 'No driver'; ?></td>
                                <td><?php echo htmlspecialchars(substr($booking['pickup_address'], 0, 30)) . '...'; ?></td>
                                <td><?php echo htmlspecialchars(substr($booking['dropoff_address'], 0, 30)) . '...'; ?></td>
                                <td>₱<?php echo number_format($booking['estimated_fare'], 2); ?></td>
                                <td>
                                    <span class="badge badge-<?php 
                                        echo $booking['status'] === 'completed' ? 'success' : 
                                            ($booking['status'] === 'cancelled' ? 'danger' : 
                                            ($booking['status'] === 'in_progress' ? 'warning' : 'info')); 
                                    ?>">
                                        <?php echo ucfirst($booking['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('M j, Y g:i A', strtotime($booking['booking_time'])); ?></td>
                                <td>
                                    <?php if ($booking['status'] !== 'completed' && $booking['status'] !== 'cancelled'): ?>
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to cancel this booking?')">
                                            <input type="hidden" name="cancel_booking" value="1">
                                            <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                            <button type="submit" class="btn btn-danger btn-sm">
                                                <i class="fas fa-times"></i> Cancel
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        // Function to search bookings
        function searchBookings() {
            const searchTerm = document.getElementById('searchInput').value.trim();
            
            // Build URL with search parameter
            const url = searchTerm ? `bookings.php?search=${encodeURIComponent(searchTerm)}` : 'bookings.php';
            window.location.href = url;
        }
        
        // Function to handle search on Enter key
        function handleSearch(event) {
            if (event.key === 'Enter') {
                searchBookings();
            }
        }
        
        // Function to clear search
        function clearSearch() {
            document.getElementById('searchInput').value = '';
            window.location.href = 'bookings.php';
        }
        
        // Auto-focus search input when page loads with search term
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.getElementById('searchInput');
            const urlParams = new URLSearchParams(window.location.search);
            const searchParam = urlParams.get('search');
            
            if (searchParam && searchInput) {
                searchInput.focus();
                searchInput.select();
            }
        });
    </script>
</body>
</html>

