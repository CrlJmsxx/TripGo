<?php
require_once '../config/database.php';
require_once '../config/session.php';

requireAdmin();

$currentUser = getCurrentUser();
$pdo = getConnection();

$success = '';
$error = '';

// Handle settings update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_settings'])) {
        $baseFare = $_POST['base_fare'];
        $perKmRate = $_POST['per_km_rate'];
        $perMinuteRate = $_POST['per_minute_rate'];
        $minimumFare = $_POST['minimum_fare'];
        $maximumFare = $_POST['maximum_fare'];
        
        $settings = [
            'base_fare' => $baseFare,
            'per_km_rate' => $perKmRate,
            'per_minute_rate' => $perMinuteRate,
            'minimum_fare' => $MinimumFare,
            'maximum_fare' => $maximumFare
        ];
        
        try {
            foreach ($settings as $key => $value) {
                $stmt = $pdo->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = ?");
                $stmt->execute([$value, $key]);
            }
            $success = 'Settings updated successfully!';
        } catch (Exception $e) {
            $error = 'Failed to update settings. Please try again.';
        }
    }
}

// Get current system settings
$stmt = $pdo->prepare("SELECT setting_key, setting_value FROM system_settings");
$stmt->execute();
$systemSettings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Settings - TripGO</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <a href="../index.php" class="logo">
                    <i class="fas fa-car"></i> TripGO
                </a>
                
                <nav class="nav">
                    <a href="../index.php">Home</a>
                    <a href="dashboard.php">Dashboard</a>
                    <a href="users.php">Users</a>
                    <a href="bookings.php">Bookings</a>
                    <a href="settings.php">Settings</a>
                </nav>
                
                <div class="user-menu">
                    <div class="user-info">
                        <div class="user-avatar">
                            <?php echo strtoupper(substr($currentUser['full_name'], 0, 1)); ?>
                        </div>
                        <span><?php echo htmlspecialchars($currentUser['full_name']); ?></span>
                    </div>
                    <a href="../auth/logout.php" class="btn btn-danger">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="container" style="padding: 40px 0;">
        <div class="card">
            <div class="card-header">
                <h1 class="card-title">
                    <i class="fas fa-cog"></i> System Settings
                </h1>
            </div>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label for="base_fare">Base Fare (₱)</label>
                        <input type="number" step="0.01" id="base_fare" name="base_fare" 
                               value="<?php echo $systemSettings['base_fare']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="per_km_rate">Per KM Rate (₱)</label>
                        <input type="number" step="0.01" id="per_km_rate" name="per_km_rate" 
                               value="<?php echo $systemSettings['per_km_rate']; ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="per_minute_rate">Per Minute Rate (₱)</label>
                        <input type="number" step="0.01" id="per_minute_rate" name="per_minute_rate" 
                               value="<?php echo $systemSettings['per_minute_rate']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="minimum_fare">Minimum Fare (₱)</label>
                        <input type="number" step="0.01" id="minimum_fare" name="minimum_fare" 
                               value="<?php echo $systemSettings['minimum_fare']; ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="maximum_fare">Maximum Fare (₱)</label>
                        <input type="number" step="0.01" id="maximum_fare" name="maximum_fare" 
                               value="<?php echo $systemSettings['maximum_fare']; ?>" required>
                    </div>
                </div>
                <button type="submit" name="update_settings" class="btn btn-primary">
                    <i class="fas fa-save"></i> Update Settings
                </button>
            </form>
        </div>
    </div>
</body>
</html>

