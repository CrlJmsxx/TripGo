<?php
require_once '../config/database.php';
require_once '../config/session.php';

requireAdmin();

$currentUser = getCurrentUser();
$pdo = getConnection();

// Handle user actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['delete_user'])) {
        $userId = $_POST['user_id'];
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND user_type != 'admin'");
        $stmt->execute([$userId]);
        header('Location: users.php');
        exit();
    }
    
    if (isset($_POST['verify_user'])) {
        $userId = $_POST['user_id'];
        $stmt = $pdo->prepare("UPDATE users SET is_verified = 1 WHERE id = ?");
        $stmt->execute([$userId]);
        header('Location: users.php');
        exit();
    }
}

// Handle filtering and searching
$userType = $_GET['type'] ?? 'all';
$searchTerm = $_GET['search'] ?? '';

// Build the query
$query = "SELECT * FROM users WHERE 1=1";
$params = [];

// Filter by user type
if ($userType !== 'all') {
    $query .= " AND user_type = ?";
    $params[] = $userType;
}

// Search by ID or Email
if (!empty($searchTerm)) {
    $query .= " AND (id LIKE ? OR email LIKE ? OR full_name LIKE ?)";
    $searchParam = "%$searchTerm%";
    $params[] = $searchParam;
    $params[] = $searchParam;
    $params[] = $searchParam;
}

$query .= " ORDER BY created_at DESC";

// Get filtered users
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users Management - TripGO</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <a href="../index.php" class="logo">
                    <i class="fas fa-car"></i> TripGO
                </a>
                
                <nav class="nav">
                    <a href="../index.php">Home</a>
                    <a href="dashboard.php">Dashboard</a>
                    <a href="users.php">Users</a> <!-- Ensure this matches the filename -->
                    <a href="bookings.php">Bookings</a>
                    <a href="settings.php">Settings</a>
                </nav>
                
                <div class="user-menu">
                    <div class="user-info">
                        <div class="user-avatar">
                            <?php echo strtoupper(substr($currentUser['full_name'], 0, 1)); ?>
                        </div>
                        <span><?php echo htmlspecialchars($currentUser['full_name']); ?></span>
                    </div>
                    <a href="../auth/logout.php" class="btn btn-danger">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="container" style="padding: 40px 0;">
        <div class="card">
            <div class="card-header">
                <h1 class="card-title">
                    <i class="fas fa-users"></i> Users Management
                </h1>
            </div>
            
            <!-- Filter and Search Container -->
            <div style="padding: 20px; background: var(--bg-primary); border-radius: 12px; margin-bottom: 20px;">
                <div style="display: flex; gap: 20px; align-items: center; flex-wrap: wrap;">
                    <!-- User Type Filter -->
                    <div style="flex: 1; min-width: 200px;">
                        <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--text-primary);">
                            <i class="fas fa-filter"></i> Filter by Type
                        </label>
                        <select name="type" id="userTypeFilter" style="width: 100%; padding: 10px; border: 2px solid var(--border-color); border-radius: 8px; background: var(--bg-secondary); color: var(--text-primary); font-size: 14px;" onchange="filterUsers()">
                            <option value="all" <?php echo $userType === 'all' ? 'selected' : ''; ?>>All Users</option>
                            <option value="passenger" <?php echo $userType === 'passenger' ? 'selected' : ''; ?>>Passengers</option>
                            <option value="driver" <?php echo $userType === 'driver' ? 'selected' : ''; ?>>Drivers</option>
                            <option value="admin" <?php echo $userType === 'admin' ? 'selected' : ''; ?>>Admins</option>
                        </select>
                    </div>
                    
                    <!-- Search Bar -->
                    <div style="flex: 2; min-width: 300px;">
                        <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--text-primary);">
                            <i class="fas fa-search"></i> Search by ID, Email, or Name
                        </label>
                        <div style="display: flex; gap: 10px;">
                            <input type="text" 
                                   id="searchInput" 
                                   placeholder="Enter ID, email, or name..." 
                                   value="<?php echo htmlspecialchars($searchTerm); ?>"
                                   style="flex: 1; padding: 10px; border: 2px solid var(--border-color); border-radius: 8px; background: var(--bg-secondary); color: var(--text-primary); font-size: 14px;"
                                   onkeyup="handleSearch(event)">
                            <button type="button" 
                                    onclick="filterUsers()" 
                                    class="btn btn-primary"
                                    style="padding: 10px 20px;">
                                <i class="fas fa-search"></i> Search
                            </button>
                        </div>
                    </div>
                    
                    <!-- Clear Filters -->
                    <div style="display: flex; align-items: flex-end;">
                        <button type="button" 
                                onclick="clearFilters()" 
                                class="btn btn-secondary"
                                style="padding: 10px 20px;">
                            <i class="fas fa-times"></i> Clear
                        </button>
                    </div>
                </div>
                
                <!-- Results Count -->
                <div style="margin-top: 15px; padding: 10px; background: var(--bg-secondary); border-radius: 8px; border-left: 4px solid var(--primary-color);">
                    <span style="color: var(--text-secondary); font-size: 14px;">
                        <i class="fas fa-info-circle"></i> 
                        Showing <strong><?php echo count($users); ?></strong> user(s)
                        <?php if ($userType !== 'all'): ?>
                            filtered by <strong><?php echo ucfirst($userType); ?></strong>
                        <?php endif; ?>
                        <?php if (!empty($searchTerm)): ?>
                            matching "<strong><?php echo htmlspecialchars($searchTerm); ?></strong>"
                        <?php endif; ?>
                    </span>
                </div>
            </div>
            
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Type</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?php echo $user['id']; ?></td>
                                <td>
                                    <a href="user_profile.php?id=<?php echo $user['id']; ?>" style="color: var(--primary-color); text-decoration: none; font-weight: 500; display: flex; align-items: center; gap: 8px;">
                                        <?php if ($user['profile_image']): ?>
                                            <img src="../<?php echo htmlspecialchars($user['profile_image']); ?>" 
                                                 alt="Profile" 
                                                 style="width: 30px; height: 30px; border-radius: 50%; object-fit: cover; border: 2px solid var(--border-color);">
                                        <?php else: ?>
                                            <div style="width: 30px; height: 30px; border-radius: 50%; background: linear-gradient(135deg, var(--primary-color), var(--accent-color)); display: flex; align-items: center; justify-content: center; color: white; font-size: 12px; font-weight: bold;">
                                                <?php echo strtoupper(substr($user['full_name'], 0, 1)); ?>
                                            </div>
                                        <?php endif; ?>
                                        <?php echo htmlspecialchars($user['full_name']); ?>
                                        <i class="fas fa-external-link-alt" style="font-size: 12px; opacity: 0.7;"></i>
                                    </a>
                                </td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td><?php echo htmlspecialchars($user['phone']); ?></td>
                                <td>
                                    <span class="badge badge-<?php echo $user['user_type'] === 'admin' ? 'danger' : ($user['user_type'] === 'driver' ? 'warning' : 'info'); ?>">
                                        <?php echo ucfirst($user['user_type']); ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge badge-<?php echo $user['is_verified'] ? 'success' : 'secondary'; ?>">
                                        <?php echo $user['is_verified'] ? 'Verified' : 'Pending'; ?>
                                    </span>
                                </td>
                                <td><?php echo date('M j, Y', strtotime($user['created_at'])); ?></td>
                                <td>
                                    <?php if ($user['user_type'] !== 'admin'): ?>
                                        <?php if (!$user['is_verified']): ?>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="verify_user" value="1">
                                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                <button type="submit" class="btn btn-success btn-sm">
                                                    <i class="fas fa-check"></i> Verify
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this user?')">
                                            <input type="hidden" name="delete_user" value="1">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <button type="submit" class="btn btn-danger btn-sm">
                                                <i class="fas fa-trash"></i> Delete
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        // Function to filter users
        function filterUsers() {
            const userType = document.getElementById('userTypeFilter').value;
            const searchTerm = document.getElementById('searchInput').value;
            
            // Build URL with parameters
            const params = new URLSearchParams();
            if (userType !== 'all') params.append('type', userType);
            if (searchTerm.trim()) params.append('search', searchTerm.trim());
            
            // Redirect to filtered page
            const url = params.toString() ? `users.php?${params.toString()}` : 'users.php';
            window.location.href = url;
        }
        
        // Function to handle search on Enter key
        function handleSearch(event) {
            if (event.key === 'Enter') {
                filterUsers();
            }
        }
        
        // Function to clear all filters
        function clearFilters() {
            document.getElementById('userTypeFilter').value = 'all';
            document.getElementById('searchInput').value = '';
            window.location.href = 'users.php';
        }
        
        // Auto-focus search input when page loads with search term
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.getElementById('searchInput');
            const urlParams = new URLSearchParams(window.location.search);
            const searchParam = urlParams.get('search');
            
            if (searchParam && searchInput) {
                searchInput.focus();
                searchInput.select();
            }
        });
    </script>
</body>
</html>

