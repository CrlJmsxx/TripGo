<?php
require_once '../config/database.php';
require_once '../config/session.php';

requireAdmin();

$currentUser = getCurrentUser();
$pdo = getConnection();

// Get system statistics
$stats = [];

// Total users
$stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE user_type = 'passenger'");
$stmt->execute();
$stats['total_passengers'] = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE user_type = 'driver'");
$stmt->execute();
$stats['total_drivers'] = $stmt->fetchColumn();

// Total bookings
$stmt = $pdo->prepare("SELECT COUNT(*) FROM bookings");
$stmt->execute();
$stats['total_bookings'] = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE status = 'completed'");
$stmt->execute();
$stats['completed_bookings'] = $stmt->fetchColumn();

// Total revenue
$stmt = $pdo->prepare("SELECT SUM(actual_fare) FROM bookings WHERE status = 'completed'");
$stmt->execute();
$stats['total_revenue'] = $stmt->fetchColumn() ?: 0;

// Recent bookings
$stmt = $pdo->prepare("
    SELECT b.*, 
           p.full_name as passenger_name, 
           d.full_name as driver_name 
    FROM bookings b 
    LEFT JOIN users p ON b.passenger_id = p.id 
    LEFT JOIN users d ON b.driver_id = d.id 
    ORDER BY b.booking_time DESC 
    LIMIT 10
");
$stmt->execute();
$recentBookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Pending driver verifications
$stmt = $pdo->prepare("
    SELECT u.*, dp.* 
    FROM users u 
    JOIN driver_profiles dp ON u.id = dp.user_id 
    WHERE u.user_type = 'driver' AND u.is_verified = 0
");
$stmt->execute();
$pendingDrivers = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle admin actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['verify_driver'])) {
        $driverId = $_POST['driver_id'];
        $stmt = $pdo->prepare("UPDATE users SET is_verified = 1 WHERE id = ?");
        $stmt->execute([$driverId]);
        header('Location: dashboard.php');
        exit();
    }
    
    if (isset($_POST['reject_driver'])) {
        $driverId = $_POST['driver_id'];
        $stmt = $pdo->prepare("DELETE FROM driver_profiles WHERE user_id = ?");
        $stmt->execute([$driverId]);
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$driverId]);
        header('Location: dashboard.php');
        exit();
    }
    
    if (isset($_POST['update_settings'])) {
        $baseFare = $_POST['base_fare'];
        $perKmRate = $_POST['per_km_rate'];
        $perMinuteRate = $_POST['per_minute_rate'];
        $minimumFare = $_POST['minimum_fare'];
        
        $settings = [
            'base_fare' => $baseFare,
            'per_km_rate' => $perKmRate,
            'per_minute_rate' => $perMinuteRate,
            'minimum_fare' => $minimumFare
        ];
        
        foreach ($settings as $key => $value) {
            $stmt = $pdo->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = ?");
            $stmt->execute([$value, $key]);
        }
        
        header('Location: dashboard.php');
        exit();
    }
}

// Get current system settings
$stmt = $pdo->prepare("SELECT setting_key, setting_value FROM system_settings");
$stmt->execute();
$systemSettings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - TripGO</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <a href="../index.php" class="logo">
                    <i class="fas fa-car"></i> TripGO
                </a>
                
                <nav class="nav">
                    <a href="../index.php">Home</a>
                    <a href="dashboard.php">Dashboard</a>
                    <a href="users.php">Users</a>
                    <a href="bookings.php">Bookings</a>
                    <a href="settings.php">Settings</a>
                </nav>
                
                <div class="user-menu">
                    <div class="user-info">
                        <div class="user-avatar">
                            <?php echo strtoupper(substr($currentUser['full_name'], 0, 1)); ?>
                        </div>
                        <span><?php echo htmlspecialchars($currentUser['full_name']); ?></span>
                    </div>
                    <a href="../auth/logout.php" class="btn btn-danger">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="container" style="padding: 40px 0;">
        <!-- Welcome Section -->
        <div class="card" style="margin-bottom: 30px;">
            <div class="card-header">
                <h1 class="card-title">
                    <i class="fas fa-cog"></i> Admin Dashboard
                </h1>
            </div>
            <p style="color: #666; font-size: 1.1rem;">
                Manage your ride-sharing platform with comprehensive admin tools.
            </p>
        </div>

        <!-- Statistics -->
        <div class="stats-grid" style="margin-bottom: 40px;">
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-number"><?php echo $stats['total_passengers']; ?></div>
                <div class="stat-label">Total Passengers</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, #28a745 0%, #20c997 100%);">
                    <i class="fas fa-car"></i>
                </div>
                <div class="stat-number"><?php echo $stats['total_drivers']; ?></div>
                <div class="stat-label">Total Drivers</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%);">
                    <i class="fas fa-route"></i>
                </div>
                <div class="stat-number"><?php echo $stats['total_bookings']; ?></div>
                <div class="stat-label">Total Bookings</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, #dc3545 0%, #e83e8c 100%);">
                    <i class="fas fa-dollar-sign"></i>
                </div>
                <div class="stat-number">₱<?php echo number_format($stats['total_revenue'], 2); ?></div>
                <div class="stat-label">Total Revenue</div>
            </div>
        </div>

        <div class="dashboard-grid">
            <!-- Pending Driver Verifications -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-user-check" style="color: #667eea;"></i>
                        Pending Driver Verifications
                    </h3>
                </div>
                
                <?php if (empty($pendingDrivers)): ?>
                    <p style="text-align: center; color: #666; padding: 20px;">
                        <i class="fas fa-check-circle"></i> No pending driver verifications
                    </p>
                <?php else: ?>
                    <div class="booking-list">
                        <?php foreach ($pendingDrivers as $driver): ?>
                            <div class="booking-item">
                                <div class="booking-header">
                                    <span class="booking-id">Driver #<?php echo $driver['user_id']; ?></span>
                                    <span class="booking-status status-pending">Pending</span>
                                </div>
                                <div class="booking-details">
                                    <div class="booking-detail">
                                        <i class="fas fa-user"></i>
                                        <span><?php echo htmlspecialchars($driver['full_name']); ?></span>
                                    </div>
                                    <div class="booking-detail">
                                        <i class="fas fa-envelope"></i>
                                        <span><?php echo htmlspecialchars($driver['email']); ?></span>
                                    </div>
                                    <div class="booking-detail">
                                        <i class="fas fa-phone"></i>
                                        <span><?php echo htmlspecialchars($driver['phone']); ?></span>
                                    </div>
                                    <div class="booking-detail">
                                        <i class="fas fa-id-card"></i>
                                        <span><?php echo htmlspecialchars($driver['license_number']); ?></span>
                                    </div>
                                </div>
                                <div style="margin-top: 15px; padding: 10px; background: #f8f9fa; border-radius: 8px;">
                                    <strong>Vehicle:</strong> <?php echo htmlspecialchars($driver['vehicle_model']); ?><br>
                                    <strong>Plate:</strong> <?php echo htmlspecialchars($driver['vehicle_plate']); ?><br>
                                    <strong>Color:</strong> <?php echo htmlspecialchars($driver['vehicle_color']); ?>
                                </div>
                                <div class="booking-actions">
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="verify_driver" value="1">
                                        <input type="hidden" name="driver_id" value="<?php echo $driver['user_id']; ?>">
                                        <button type="submit" class="btn btn-success">
                                            <i class="fas fa-check"></i> Verify
                                        </button>
                                    </form>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="reject_driver" value="1">
                                        <input type="hidden" name="driver_id" value="<?php echo $driver['user_id']; ?>">
                                        <button type="submit" class="btn btn-danger">
                                            <i class="fas fa-times"></i> Reject
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Recent Bookings -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-clock" style="color: #28a745;"></i>
                        Recent Bookings
                    </h3>
                </div>
                
                <?php if (empty($recentBookings)): ?>
                    <p style="text-align: center; color: #666; padding: 20px;">
                        <i class="fas fa-info-circle"></i> No bookings yet
                    </p>
                <?php else: ?>
                    <div class="booking-list">
                        <?php foreach ($recentBookings as $booking): ?>
                            <div class="booking-item">
                                <div class="booking-header">
                                    <span class="booking-id">#<?php echo $booking['id']; ?></span>
                                    <span class="booking-status status-<?php echo $booking['status']; ?>">
                                        <?php echo ucfirst($booking['status']); ?>
                                    </span>
                                </div>
                                <div class="booking-details">
                                    <div class="booking-detail">
                                        <i class="fas fa-user"></i>
                                        <span><?php echo htmlspecialchars($booking['passenger_name']); ?></span>
                                    </div>
                                    <div class="booking-detail">
                                        <i class="fas fa-car"></i>
                                        <span><?php echo $booking['driver_name'] ? htmlspecialchars($booking['driver_name']) : 'No driver assigned'; ?></span>
                                    </div>
                                    <div class="booking-detail">
                                        <i class="fas fa-dollar-sign"></i>
                                        <span>₱<?php echo number_format($booking['estimated_fare'], 2); ?></span>
                                    </div>
                                    <div class="booking-detail">
                                        <i class="fas fa-clock"></i>
                                        <span><?php echo date('M j, Y g:i A', strtotime($booking['booking_time'])); ?></span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- System Settings -->
        <div class="card" style="margin-top: 30px;">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-cog" style="color: #667eea;"></i>
                    System Settings
                </h3>
            </div>
            
            <form method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label for="base_fare">Base Fare (₱)</label>
                        <input type="number" step="0.01" id="base_fare" name="base_fare" 
                               value="<?php echo $systemSettings['base_fare']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="per_km_rate">Per KM Rate (₱)</label>
                        <input type="number" step="0.01" id="per_km_rate" name="per_km_rate" 
                               value="<?php echo $systemSettings['per_km_rate']; ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="per_minute_rate">Per Minute Rate (₱)</label>
                        <input type="number" step="0.01" id="per_minute_rate" name="per_minute_rate" 
                               value="<?php echo $systemSettings['per_minute_rate']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="minimum_fare">Minimum Fare (₱)</label>
                        <input type="number" step="0.01" id="minimum_fare" name="minimum_fare" 
                               value="<?php echo $systemSettings['minimum_fare']; ?>" required>
                    </div>
                </div>
                <button type="submit" name="update_settings" class="btn btn-primary">
                    <i class="fas fa-save"></i> Update Settings
                </button>
            </form>
        </div>
    </div>

    <script>
        // Auto-refresh page every 30 seconds to check for updates
        setTimeout(() => {
            location.reload();
        }, 30000);
    </script>
</body>
</html>
