<?php
require_once 'config/database.php';
require_once 'config/session.php';

header('Content-Type: text/html; charset=UTF-8');

// Check authentication
$currentUser = getCurrentUser();
if (!$currentUser) {
    die('<h1>Authentication Required</h1><p>Please <a href="auth/login.php">login</a> to access verification.</p>');
}

$pdo = getConnection();

// Passenger Interface Logic verification checklist
$passengerRequirements = [
    [
        'feature' => 'Cancel Button',
        'description' => 'A "Cancel Ride" button is visible when the ride status is \'pending\' or \'searching\'.',
        'status' => 'pending',
        'details' => [],
        'files' => ['passenger/dashboard.php']
    ],
    [
        'feature' => 'Cancellation Modal',
        'description' => 'Clicking "Cancel Ride" opens a modal with the five required radio button/text input options for the reason.',
        'status' => 'pending',
        'details' => [],
        'files' => ['passenger/dashboard.php', 'api/cancel_booking.php']
    ],
    [
        'feature' => 'Acceptance Feedback',
        'description' => 'When the driver accepts, the passenger\'s UI instantly updates (e.g., status text change, notification) and the live driver marker appears on the map.',
        'status' => 'pending',
        'details' => [],
        'files' => ['passenger/dashboard.php']
    ],
    [
        'feature' => 'Geocoding',
        'description' => 'The booking screen displays a readable address (place name) for the Pickup and Drop-off based on coordinates, using an external Geocoding service.',
        'status' => 'pending',
        'details' => [],
        'files' => ['passenger/booking.php', 'api/geocoding.php']
    ],
    [
        'feature' => 'Post-Ride Rating',
        'description' => 'After both driver/passenger mark the ride complete, the passenger is redirected or prompted with the 1-5 star rating UI.',
        'status' => 'pending',
        'details' => [],
        'files' => ['passenger/dashboard.php', 'passenger/rate_ride.php']
    ]
];

// Check 1: Cancel Button
try {
    if (file_exists('passenger/dashboard.php')) {
        $content = file_get_contents('passenger/dashboard.php');
        
        if (strpos($content, 'Cancel Ride') !== false && 
            strpos($content, "in_array(\$activeBooking['status'], ['pending', 'searching'])") !== false) {
            $passengerRequirements[0]['status'] = 'pass';
            $passengerRequirements[0]['details'][] = '✅ Cancel button exists';
            $passengerRequirements[0]['details'][] = '✅ Only shows for pending/searching status';
            $passengerRequirements[0]['details'][] = '✅ Proper conditional display logic';
        } else {
            $passengerRequirements[0]['status'] = 'fail';
            $passengerRequirements[0]['details'][] = '❌ Cancel button or conditional logic missing';
        }
    } else {
        $passengerRequirements[0]['status'] = 'fail';
        $passengerRequirements[0]['details'][] = '❌ Passenger dashboard missing';
    }
} catch (Exception $e) {
    $passengerRequirements[0]['status'] = 'fail';
    $passengerRequirements[0]['details'][] = '❌ Error checking cancel button: ' . $e->getMessage();
}

// Check 2: Cancellation Modal
try {
    if (file_exists('passenger/dashboard.php')) {
        $content = file_get_contents('passenger/dashboard.php');
        
        // Check for modal with required reasons
        $requiredReasons = [
            'Found another ride',
            'Too long wait time',
            'Changed my mind / No longer need a ride',
            'Accidentally placed the request',
            'Other'
        ];
        
        $modalExists = strpos($content, 'Cancel Ride Request') !== false;
        $hasAllReasons = true;
        
        foreach ($requiredReasons as $reason) {
            if (strpos($content, $reason) === false) {
                $hasAllReasons = false;
                break;
            }
        }
        
        if ($modalExists && $hasAllReasons) {
            $passengerRequirements[1]['status'] = 'pass';
            $passengerRequirements[1]['details'][] = '✅ Cancellation modal exists';
            $passengerRequirements[1]['details'][] = '✅ All 5 required reasons present';
            $passengerRequirements[1]['details'][] = '✅ "Other" option with text input';
            
            // Check for API integration
            if (file_exists('api/cancel_booking.php')) {
                $passengerRequirements[1]['details'][] = '✅ Cancellation API exists';
            } else {
                $passengerRequirements[1]['status'] = 'partial';
                $passengerRequirements[1]['details'][] = '❌ Cancellation API missing';
            }
        } else {
            $passengerRequirements[1]['status'] = 'partial';
            $passengerRequirements[1]['details'][] = '⚠️ Modal exists but missing some reasons';
            if (!$modalExists) {
                $passengerRequirements[1]['details'][] = '❌ Cancellation modal missing';
            }
            if (!$hasAllReasons) {
                $passengerRequirements[1]['details'][] = '❌ Some required reasons missing';
            }
        }
    } else {
        $passengerRequirements[1]['status'] = 'fail';
        $passengerRequirements[1]['details'][] = '❌ Passenger dashboard missing';
    }
} catch (Exception $e) {
    $passengerRequirements[1]['status'] = 'fail';
    $passengerRequirements[1]['details'][] = '❌ Error checking cancellation modal: ' . $e->getMessage();
}

// Check 3: Acceptance Feedback
try {
    if (file_exists('passenger/dashboard.php')) {
        $content = file_get_contents('passenger/dashboard.php');
        
        $hasStatusUpdate = strpos($content, 'Driver is on the way!') !== false;
        $hasDriverMarker = strpos($content, 'driverMarker') !== false;
        $hasNotification = strpos($content, 'showAcceptanceNotification') !== false;
        $hasRealTimeUpdate = strpos($content, 'locationUpdateInterval') !== false;
        
        if ($hasStatusUpdate && $hasDriverMarker && $hasNotification) {
            $passengerRequirements[2]['status'] = 'pass';
            $passengerRequirements[2]['details'][] = '✅ Status text updates on acceptance';
            $passengerRequirements[2]['details'][] = '✅ Driver marker appears on map';
            $passengerRequirements[2]['details'][] = '✅ Acceptance notification exists';
            $passengerRequirements[2]['details'][] = '✅ Real-time location tracking';
        } else {
            $passengerRequirements[2]['status'] = 'partial';
            if (!$hasStatusUpdate) {
                $passengerRequirements[2]['details'][] = '❌ Status update missing';
            }
            if (!$hasDriverMarker) {
                $passengerRequirements[2]['details'][] = '❌ Driver marker missing';
            }
            if (!$hasNotification) {
                $passengerRequirements[2]['details'][] = '❌ Acceptance notification missing';
            }
            if (!$hasRealTimeUpdate) {
                $passengerRequirements[2]['details'][] = '⚠️ Real-time updates may be missing';
            }
        }
    } else {
        $passengerRequirements[2]['status'] = 'fail';
        $passengerRequirements[2]['details'][] = '❌ Passenger dashboard missing';
    }
} catch (Exception $e) {
    $passengerRequirements[2]['status'] = 'fail';
    $passengerRequirements[2]['details'][] = '❌ Error checking acceptance feedback: ' . $e->getMessage();
}

// Check 4: Geocoding
try {
    $bookingHasGeocoding = false;
    $apiExists = false;
    
    if (file_exists('passenger/booking.php')) {
        $content = file_get_contents('passenger/booking.php');
        
        if (strpos($content, 'pickupLocationDetails') !== false && 
            strpos($content, 'dropoffLocationDetails') !== false &&
            strpos($content, 'updateLocationDetails') !== false) {
            $bookingHasGeocoding = true;
            $passengerRequirements[3]['details'][] = '✅ Geocoding displays in booking form';
            $passengerRequirements[3]['details'][] = '✅ Real-time address updates';
            $passengerRequirements[3]['details'][] = '✅ Pickup and dropoff location details';
        } else {
            $passengerRequirements[3]['details'][] = '❌ Geocoding displays missing';
        }
    }
    
    if (file_exists('api/geocoding.php')) {
        $content = file_get_contents('api/geocoding.php');
        
        if (strpos($content, 'reverse_geocode') !== false && 
            strpos($content, 'Nominatim') !== false) {
            $apiExists = true;
            $passengerRequirements[3]['details'][] = '✅ Geocoding API exists';
            $passengerRequirements[3]['details'][] = '✅ Uses OpenStreetMap Nominatim';
            $passengerRequirements[3]['details'][] = '✅ Free geocoding service';
        } else {
            $passengerRequirements[3]['details'][] = '❌ Geocoding API incomplete';
        }
    }
    
    if ($bookingHasGeocoding && $apiExists) {
        $passengerRequirements[3]['status'] = 'pass';
    } elseif ($bookingHasGeocoding || $apiExists) {
        $passengerRequirements[3]['status'] = 'partial';
    } else {
        $passengerRequirements[3]['status'] = 'fail';
        $passengerRequirements[3]['details'][] = '❌ Geocoding system missing';
    }
    
} catch (Exception $e) {
    $passengerRequirements[3]['status'] = 'fail';
    $passengerRequirements[3]['details'][] = '❌ Error checking geocoding: ' . $e->getMessage();
}

// Check 5: Post-Ride Rating
try {
    $ratingSystemExists = false;
    $ratingUIExists = false;
    $databaseSupport = false;
    
    // Check database support
    try {
        $result = $pdo->query("SHOW COLUMNS FROM bookings LIKE 'rating_requested'");
        if ($result->rowCount() > 0) {
            $databaseSupport = true;
            $passengerRequirements[4]['details'][] = '✅ Database rating columns exist';
        }
        
        $result = $pdo->query("SHOW TABLES LIKE 'reviews'");
        if ($result->rowCount() > 0) {
            $passengerRequirements[4]['details'][] = '✅ Reviews table exists';
        }
    } catch (Exception $e) {
        $passengerRequirements[4]['details'][] = '❌ Database support missing';
    }
    
    // Check rating UI in dashboard
    if (file_exists('passenger/dashboard.php')) {
        $content = file_get_contents('passenger/dashboard.php');
        
        if (strpos($content, 'Rate Driver') !== false && 
            strpos($content, 'rating_requested') !== false) {
            $ratingUIExists = true;
            $passengerRequirements[4]['details'][] = '✅ Rating prompts in dashboard';
            $passengerRequirements[4]['details'][] = '✅ Pending ratings display';
        } else {
            $passengerRequirements[4]['details'][] = '❌ Rating UI missing';
        }
    }
    
    // Check rating page
    if (file_exists('passenger/rate_ride.php')) {
        $content = file_get_contents('passenger/rate_ride.php');
        
        $hasRatingUI = strpos($content, 'rating') !== false && strpos($content, 'star') !== false;
        $hasCalculationLogic = strpos($content, 'UPDATE users u SET average_rating') !== false && 
                               strpos($content, 'SELECT AVG(rating)') !== false;
        
        if ($hasRatingUI) {
            $ratingSystemExists = true;
            $passengerRequirements[4]['details'][] = '✅ Rating submission page exists';
            $passengerRequirements[4]['details'][] = '✅ 1-5 star rating system';
        } else {
            $passengerRequirements[4]['details'][] = '❌ Rating page incomplete';
        }
        
        if ($hasCalculationLogic) {
            $passengerRequirements[4]['details'][] = '✅ Rating calculation logic exists';
            $passengerRequirements[4]['details'][] = '✅ Updates driver average rating after review submission';
        } else {
            $passengerRequirements[4]['details'][] = '❌ Rating calculation logic missing';
        }
    }
    
    // Check if rating calculation logic exists
    $hasCalculationLogic = false;
    if (file_exists('passenger/rate_ride.php')) {
        $content = file_get_contents('passenger/rate_ride.php');
        $hasCalculationLogic = strpos($content, 'UPDATE users u SET average_rating') !== false && 
                               strpos($content, 'SELECT AVG(rating)') !== false;
    }
    
    if ($databaseSupport && $ratingUIExists && $ratingSystemExists && $hasCalculationLogic) {
        $passengerRequirements[4]['status'] = 'pass';
    } elseif ($databaseSupport || $ratingUIExists || $ratingSystemExists || $hasCalculationLogic) {
        $passengerRequirements[4]['status'] = 'partial';
    } else {
        $passengerRequirements[4]['status'] = 'fail';
        $passengerRequirements[4]['details'][] = '❌ Rating system missing';
    }
    
} catch (Exception $e) {
    $passengerRequirements[4]['status'] = 'fail';
    $passengerRequirements[4]['details'][] = '❌ Error checking post-ride rating: ' . $e->getMessage();
}

// Calculate summary
$pass = count(array_filter($passengerRequirements, fn($r) => $r['status'] === 'pass'));
$partial = count(array_filter($passengerRequirements, fn($r) => $r['status'] === 'partial'));
$fail = count(array_filter($passengerRequirements, fn($r) => $r['status'] === 'fail'));
$total = count($passengerRequirements);

?>
<!DOCTYPE html>
<html>
<head>
    <title>TripGO Passenger Interface Verification</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        h1 { color: #333; text-align: center; margin-bottom: 30px; }
        .requirement { margin-bottom: 25px; padding: 20px; border-radius: 8px; border-left: 4px solid #ddd; }
        .requirement.pass { border-left-color: #28a745; background: #f8fff9; }
        .requirement.partial { border-left-color: #ffc107; background: #fffdf7; }
        .requirement.fail { border-left-color: #dc3545; background: #fff8f8; }
        .feature-name { font-size: 1.1rem; font-weight: bold; margin-bottom: 8px; }
        .status-badge { padding: 3px 10px; border-radius: 15px; font-size: 0.75rem; font-weight: bold; text-transform: uppercase; margin-bottom: 8px; display: inline-block; }
        .status-pass { background: #28a745; color: white; }
        .status-partial { background: #ffc107; color: #212529; }
        .status-fail { background: #dc3545; color: white; }
        .description { color: #666; margin-bottom: 12px; font-size: 0.9rem; }
        .details { font-size: 0.85rem; }
        .details div { margin-bottom: 3px; }
        .files { margin-top: 8px; font-size: 0.8rem; color: #999; }
        .summary { margin-top: 30px; padding: 25px; background: #f8f9fa; border-radius: 8px; }
        .summary h2 { margin-top: 0; color: #333; }
        .stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; text-align: center; margin-bottom: 20px; }
        .stat { padding: 15px; border-radius: 8px; }
        .stat-pass { background: #d4edda; color: #155724; }
        .stat-partial { background: #fff3cd; color: #856404; }
        .stat-fail { background: #f8d7da; color: #721c24; }
        .stat-total { background: #e2e3e5; color: #383d41; }
        .stat-number { font-size: 2rem; font-weight: bold; margin-bottom: 5px; }
        .stat-label { font-size: 0.85rem; }
        .actions { margin-top: 25px; text-align: center; }
        .btn { padding: 12px 24px; margin: 5px; border: none; border-radius: 6px; cursor: pointer; text-decoration: none; display: inline-block; font-weight: 600; transition: all 0.2s; }
        .btn-primary { background: #007bff; color: white; }
        .btn-success { background: #28a745; color: white; }
        .btn-warning { background: #ffc107; color: #212529; }
        .btn-danger { background: #dc3545; color: white; }
        .btn:hover { transform: translateY(-1px); box-shadow: 0 4px 8px rgba(0,0,0,0.2); }
        .test-steps { margin-top: 30px; padding: 20px; background: #e9ecef; border-radius: 8px; border-left: 4px solid #17a2b8; }
        .test-steps h3 { margin-top: 0; color: #17a2b8; }
        .test-steps ol { padding-left: 20px; }
        .test-steps li { margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚗 TripGO Passenger Interface Verification</h1>
        <p style="text-align: center; color: #666; margin-bottom: 30px;">
            <strong>User:</strong> <?php echo htmlspecialchars($currentUser['username']); ?> | 
            <strong>Time:</strong> <?php echo date('Y-m-d H:i:s'); ?>
        </p>
        
        <?php foreach ($passengerRequirements as $req): ?>
            <div class="requirement <?php echo $req['status']; ?>">
                <div class="feature-name"><?php echo htmlspecialchars($req['feature']); ?></div>
                <div class="status-badge status-<?php echo $req['status']; ?>"><?php echo $req['status']; ?></div>
                <div class="description"><?php echo htmlspecialchars($req['description']); ?></div>
                <div class="details">
                    <?php foreach ($req['details'] as $detail): ?>
                        <div><?php echo $detail; ?></div>
                    <?php endforeach; ?>
                </div>
                <?php if (!empty($req['files'])): ?>
                    <div class="files">
                        <strong>Files:</strong> <?php echo implode(', ', $req['files']); ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
        
        <div class="summary">
            <h2>📊 Passenger Interface Summary</h2>
            
            <div class="stats">
                <div class="stat stat-pass">
                    <div class="stat-number"><?php echo $pass; ?></div>
                    <div class="stat-label">Passed</div>
                </div>
                <div class="stat stat-partial">
                    <div class="stat-number"><?php echo $partial; ?></div>
                    <div class="stat-label">Partial</div>
                </div>
                <div class="stat stat-fail">
                    <div class="stat-number"><?php echo $fail; ?></div>
                    <div class="stat-label">Failed</div>
                </div>
                <div class="stat stat-total">
                    <div class="stat-number"><?php echo $total; ?></div>
                    <div class="stat-label">Total</div>
                </div>
            </div>
            
            <?php if ($fail > 0 || $partial > 0): ?>
                <div style="margin-bottom: 20px; padding: 15px; background: #fff3cd; border-radius: 6px; border-left: 4px solid #ffc107;">
                    <strong>⚠️ Action Required:</strong> Some passenger interface features need attention. Check the details above and run migration if needed.
                </div>
            <?php else: ?>
                <div style="margin-bottom: 20px; padding: 15px; background: #d4edda; border-radius: 6px; border-left: 4px solid #28a745;">
                    <strong>✅ All Passenger Features Implemented:</strong> All passenger interface requirements have been successfully implemented and verified.
                </div>
            <?php endif; ?>
            
            <div class="actions">
                <a href="migrate.php" class="btn btn-primary">🔧 Run Migration</a>
                <a href="complete_verification.php" class="btn btn-success">🔍 Complete Verification</a>
                <a href="passenger/dashboard.php" class="btn btn-warning">🚗 Passenger Dashboard</a>
                <a href="index.php" class="btn btn-secondary">🏠 Back to Home</a>
            </div>
        </div>
        
        <div class="test-steps">
            <h3>🧪 Passenger Interface Testing Steps</h3>
            <ol>
                <li><strong>Cancel Button Test:</strong>
                    <ul>
                        <li>Login as passenger</li>
                        <li>Create a new booking</li>
                        <li>Verify "Cancel Ride" button appears for pending/searching status</li>
                        <li>Verify button disappears for accepted/in_progress status</li>
                    </ul>
                </li>
                
                <li><strong>Cancellation Modal Test:</strong>
                    <ul>
                        <li>Click "Cancel Ride" button</li>
                        <li>Verify modal opens with 5 required reasons</li>
                        <li>Test each radio button option</li>
                        <li>Select "Other" and verify text input appears</li>
                        <li>Submit cancellation and verify database update</li>
                    </ul>
                </li>
                
                <li><strong>Acceptance Feedback Test:</strong>
                    <ul>
                        <li>Passenger creates booking</li>
                        <li>Driver accepts the ride</li>
                        <li>Verify status text changes to "Driver is on the way!"</li>
                        <li>Verify driver marker appears on passenger map</li>
                        <li>Verify real-time location updates</li>
                    </ul>
                </li>
                
                <li><strong>Geocoding Test:</strong>
                    <ul>
                        <li>Go to passenger booking page</li>
                        <li>Select pickup location on map</li>
                        <li>Verify readable address appears in "Pickup Location Details"</li>
                        <li>Select dropoff location on map</li>
                        <li>Verify readable address appears in "Dropoff Location Details"</li>
                        <li>Test with different locations</li>
                    </ul>
                </li>
                
                <li><strong>Post-Ride Rating Test:</strong>
                    <ul>
                        <li>Complete a ride (driver marks complete)</li>
                        <li>Verify passenger sees rating prompt in dashboard</li>
                        <li>Click "Rate Driver" button</li>
                        <li>Verify 1-5 star rating interface</li>
                        <li>Submit rating and verify average rating updates</li>
                    </ul>
                </li>
            </ol>
            
            <div style="margin-top: 20px; padding: 15px; background: #d1ecf1; border-radius: 6px; border-left: 4px solid #17a2b8;">
                <strong>📝 Testing Notes:</strong>
                <ul style="margin: 10px 0; padding-left: 20px;">
                    <li>Test with different browser sizes for responsive design</li>
                    <li>Verify error handling for network issues</li>
                    <li>Test real-time updates with multiple tabs</li>
                    <li>Check loading states and user feedback</li>
                    <li>Verify accessibility features (keyboard navigation, screen readers)</li>
                </ul>
            </div>
        </div>
    </div>
</body>
</html>
