-- Performance Indexes for Dashboard Filtering Feature
-- Run these SQL commands to optimize database performance

-- 1. Index for coordinate-based filtering (most important)
CREATE INDEX idx_bookings_coordinates ON bookings(pickup_latitude, pickup_longitude) 
WHERE status = 'pending' AND pickup_latitude IS NOT NULL AND pickup_longitude IS NOT NULL;

-- 2. Index for status filtering
CREATE INDEX idx_bookings_status_pending ON bookings(status) 
WHERE status = 'pending';

-- 3. Composite index for status + coordinates (optimal)
CREATE INDEX idx_bookings_status_coords ON bookings(status, pickup_latitude, pickup_longitude) 
WHERE status = 'pending' AND pickup_latitude IS NOT NULL AND pickup_longitude IS NOT NULL;

-- 4. Index for expiration time filtering
CREATE INDEX idx_bookings_expires ON bookings(expires_at) 
WHERE expires_at IS NOT NULL;

-- 5. Composite index for pending + expiration
CREATE INDEX idx_bookings_pending_expires ON bookings(status, expires_at) 
WHERE status = 'pending' AND expires_at IS NOT NULL;

-- 6. Index for passenger lookups
CREATE INDEX idx_bookings_passenger ON bookings(passenger_id);

-- 7. Driver profile location index
CREATE INDEX idx_driver_profile_location ON driver_profiles(current_latitude, current_longitude) 
WHERE current_latitude IS NOT NULL AND current_longitude IS NOT NULL;

-- 8. Full composite index for optimal performance
CREATE INDEX idx_bookings_full_filter ON bookings(status, pickup_latitude, pickup_longitude, expires_at) 
WHERE status = 'pending' AND pickup_latitude IS NOT NULL AND pickup_longitude IS NOT NULL;

-- Analyze tables to update index statistics
ANALYZE TABLE bookings;
ANALYZE TABLE driver_profiles;
ANALYZE TABLE users;

-- Check index usage (run this to verify indexes are being used)
-- EXPLAIN SELECT b.*, u.full_name FROM bookings b 
-- JOIN users u ON b.passenger_id = u.id 
-- WHERE b.status = 'pending' 
-- AND b.pickup_latitude BETWEEN 14.0 AND 15.0 
-- AND b.pickup_longitude BETWEEN 120.0 AND 121.0;
