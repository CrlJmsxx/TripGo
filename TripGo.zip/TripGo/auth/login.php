<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/security.php';

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: ../index.php');
    exit();
}

// Check for suspicious activity
if (checkSuspiciousActivity()) {
    header('HTTP/1.1 403 Forbidden');
    exit('Access denied');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate CSRF token
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please try again.';
    } else {
        // Rate limiting
        if (!checkRateLimit('login', 5, 300)) {
            $error = 'Too many login attempts. Please try again later.';
        } else {
            $username = sanitizeString($_POST['username']);
            $password = $_POST['password'];
            
            $errors = validateLoginInput($_POST);
            if (!empty($errors)) {
                $error = implode(', ', $errors);
            } else {
                try {
                    $pdo = getConnection();
                    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
                    $stmt->execute([$username, $username]);
                    $user = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($user && password_verify($password, $user['password'])) {
                        $_SESSION['user_id'] = $user['id'];
                        $_SESSION['username'] = $user['username'];
                        $_SESSION['user_type'] = $user['user_type'];
                        $_SESSION['full_name'] = $user['full_name'];
                        
                        // Redirect based on user type
                        if ($user['user_type'] === 'admin') {
                            header('Location: ../admin/dashboard.php');
                        } elseif ($user['user_type'] === 'driver') {
                            header('Location: ../driver/dashboard.php');
                        } else {
                            header('Location: ../index.php');
                        }
                        exit();
                    } else {
                        $error = 'Invalid username or password.';
                    }
                } catch (Exception $e) {
                    $error = 'Login failed. Please try again.';
                }
            } // <-- FIX: Close the else block for validation
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - TripGO</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="auth-body">
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <h1><i class="fas fa-car"></i> TripGO</h1>
                <p>Welcome back! Sign in to continue</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" class="auth-form">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                
                <div class="form-group">
                    <label for="username">Username or Email</label>
                    <input type="text" id="username" name="username" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                
                <button type="submit" class="btn btn-primary btn-full">
                    <i class="fas fa-sign-in-alt"></i> Login
                </button>
            </form>
            
            <div class="auth-footer">
                <p>Don't have an account? <a href="register.php">Register here</a></p>
                <p><a href="../index.php">Back to Home</a></p>
            </div>
        </div>
    </div>
</body>
</html>
