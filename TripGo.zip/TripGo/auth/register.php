<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/security.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate CSRF token
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please try again.';
    } else {
        // Rate limiting
        if (!checkRateLimit('register', 3, 300)) {
            $error = 'Too many registration attempts. Please try again later.';
        } else {
            $username = sanitizeString($_POST['username']);
            $email = sanitizeEmail($_POST['email']);
            $password = $_POST['password'];
            $confirm_password = $_POST['confirm_password'];
            $full_name = sanitizeString($_POST['full_name']);
            $phone = sanitizePhone($_POST['phone']);
            $user_type = $_POST['user_type'];
            
            // Handle profile image upload
            $profile_image = null;
            if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
                $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
                $max_size = 5 * 1024 * 1024; // 5MB
                
                if (!in_array($_FILES['profile_image']['type'], $allowed_types)) {
                    $error = 'Invalid image type. Only JPG, PNG, and GIF are allowed.';
                } elseif ($_FILES['profile_image']['size'] > $max_size) {
                    $error = 'Image size too large. Maximum 5MB allowed.';
                } else {
                    $upload_dir = '../uploads/profile_images/';
                    if (!file_exists($upload_dir)) {
                        mkdir($upload_dir, 0777, true);
                    }
                    
                    $file_extension = pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION);
                    $file_name = 'profile_' . time() . '_' . uniqid() . '.' . $file_extension;
                    $upload_path = $upload_dir . $file_name;
                    
                    if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $upload_path)) {
                        $profile_image = 'uploads/profile_images/' . $file_name;
                    } else {
                        $error = 'Failed to upload profile image.';
                    }
                }
            }
            
            // Validation
            $errors = validateRegistrationInput($_POST);
            if (!empty($errors)) {
                $error = implode(', ', $errors);
            } else {
                try {
                    $pdo = getConnection();
                    
                    // Check if username or email already exists
                    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
                    $stmt->execute([$username, $email]);
                    if ($stmt->fetch()) {
                        $error = 'Username or email already exists.';
                    } else {
                        // Create new user
                        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                        $stmt = $pdo->prepare("INSERT INTO users (username, email, password, full_name, phone, user_type, profile_image) VALUES (?, ?, ?, ?, ?, ?, ?)");
                        $stmt->execute([$username, $email, $hashed_password, $full_name, $phone, $user_type, $profile_image]);
                        
                        // If driver, create driver profile
                        if ($user_type === 'driver') {
                            $user_id = $pdo->lastInsertId();
                            $license_number = $_POST['license_number'];
                            $vehicle_model = $_POST['vehicle_model'];
                            $vehicle_plate = $_POST['vehicle_plate'];
                            $vehicle_color = $_POST['vehicle_color'];
                            
                            $stmt = $pdo->prepare("INSERT INTO driver_profiles (user_id, license_number, vehicle_model, vehicle_plate, vehicle_color) VALUES (?, ?, ?, ?, ?)");
                            $stmt->execute([$user_id, $license_number, $vehicle_model, $vehicle_plate, $vehicle_color]);
                        }
                        
                        $success = 'Registration successful! Please login.';
                    }
                } catch (Exception $e) {
                    $error = 'Registration failed. Please try again.';
                }
            } // <-- FIX: Close the else block for validation
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - TripGO</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="auth-body">
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <h1><i class="fas fa-car"></i> TripGO</h1>
                <p>Join our ride-sharing community</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" class="auth-form" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                
                <div class="form-group">
                    <label for="profile_image">Profile Image (Optional)</label>
                    <input type="file" id="profile_image" name="profile_image" accept="image/jpeg,image/png,image/gif" onchange="previewImage(event)">
                    <small style="color: var(--text-muted); font-size: 12px; margin-top: 5px; display: block;">
                        Allowed formats: JPG, PNG, GIF. Maximum size: 5MB
                    </small>
                    <div id="imagePreview" style="margin-top: 10px; display: none;">
                        <img id="previewImg" style="width: 100px; height: 100px; border-radius: 50%; object-fit: cover; border: 3px solid var(--border-color);">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="user_type">I am a:</label>
                    <select name="user_type" id="user_type" required onchange="toggleDriverFields()">
                        <option value="passenger">Passenger</option>
                        <option value="driver">Driver</option>
                    </select>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="full_name">Full Name</label>
                        <input type="text" id="full_name" name="full_name" required>
                    </div>
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" name="username" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" id="phone" name="phone" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" required>
                    </div>
                    <div class="form-group">
                        <label for="confirm_password">Confirm Password</label>
                        <input type="password" id="confirm_password" name="confirm_password" required>
                    </div>
                </div>
                
                <!-- Driver-specific fields -->
                <div id="driver-fields" style="display: none;">
                    <h3>Driver Information</h3>
                    <div class="form-group">
                        <label for="license_number">License Number</label>
                        <input type="text" id="license_number" name="license_number">
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="vehicle_model">Vehicle Model</label>
                            <input type="text" id="vehicle_model" name="vehicle_model">
                        </div>
                        <div class="form-group">
                            <label for="vehicle_plate">License Plate</label>
                            <input type="text" id="vehicle_plate" name="vehicle_plate">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="vehicle_color">Vehicle Color</label>
                        <input type="text" id="vehicle_color" name="vehicle_color">
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary btn-full">
                    <i class="fas fa-user-plus"></i> Register
                </button>
            </form>
            
            <div class="auth-footer">
                <p>Already have an account? <a href="login.php">Login here</a></p>
            </div>
        </div>
    </div>
    
    <script>
        function toggleDriverFields() {
            const driverFields = document.getElementById('driver-fields');
            const userType = document.getElementById('user_type').value;
            
            if (userType === 'driver') {
                driverFields.style.display = 'block';
                // Make driver fields required
                document.getElementById('license_number').required = true;
                document.getElementById('vehicle_model').required = true;
                document.getElementById('vehicle_plate').required = true;
                document.getElementById('vehicle_color').required = true;
            } else {
                driverFields.style.display = 'none';
                // Remove required attribute
                document.getElementById('license_number').required = false;
                document.getElementById('vehicle_model').required = false;
                document.getElementById('vehicle_plate').required = false;
                document.getElementById('vehicle_color').required = false;
            }
        }
        
        function previewImage(event) {
            const file = event.target.files[0];
            const preview = document.getElementById('imagePreview');
            const previewImg = document.getElementById('previewImg');
            
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    previewImg.src = e.target.result;
                    preview.style.display = 'block';
                }
                reader.readAsDataURL(file);
            } else {
                preview.style.display = 'none';
            }
        }
    </script>
</body>
</html>
