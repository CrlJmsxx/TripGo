<?php
// Start session to ensure we can destroy it
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Include session functions
require_once '../config/session.php';

// Perform logout
logout();

// Clear any remaining session data
$_SESSION = array();

// Destroy session cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Final session destroy
session_destroy();

// Determine the correct redirect path
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
$host = $_SERVER['HTTP_HOST'];
$base_path = dirname($_SERVER['PHP_SELF']);

// Remove the last segment (auth) from the path
$base_path = dirname($base_path);

// Redirect to homepage
$redirect_url = $protocol . "://" . $host . $base_path . "/index.php";

// Debug: Uncomment for troubleshooting
// error_log("Logout redirect URL: " . $redirect_url);

header("Location: " . $redirect_url);
exit();
?>
