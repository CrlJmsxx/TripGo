<?php
// Fix duplicate index issues
echo "<h2>Fixing Database Indexes</h2>";

// Database connection
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'tripgo_booking';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<p style='color: green;'>✓ Database connected successfully</p>";
    
    // Drop existing indexes that might conflict
    $indexesToDrop = [
        'idx_user_location',
        'idx_bookings_status_coords',
        'idx_bookings_coordinates',
        'idx_bookings_status_pending',
        'idx_bookings_expires',
        'idx_bookings_pending_expires',
        'idx_bookings_passenger',
        'idx_driver_profile_location'
    ];
    
    foreach ($indexesToDrop as $indexName) {
        try {
            $pdo->exec("DROP INDEX IF EXISTS $indexName ON driver_profiles");
            $pdo->exec("DROP INDEX IF EXISTS $indexName ON bookings");
            echo "<p style='color: orange;'>⚠ Dropped existing index: $indexName</p>";
        } catch (Exception $e) {
            // Ignore if index doesn't exist
        }
    }
    
    // Recreate indexes with correct names
    $indexes = [
        // Most important index for coordinate filtering
        "CREATE INDEX idx_bookings_status_coords ON bookings(status, pickup_latitude, pickup_longitude)",
        
        // Supporting indexes
        "CREATE INDEX idx_bookings_coordinates ON bookings(pickup_latitude, pickup_longitude)",
        "CREATE INDEX idx_bookings_status_pending ON bookings(status)",
        "CREATE INDEX idx_bookings_expires ON bookings(expires_at)",
        "CREATE INDEX idx_bookings_pending_expires ON bookings(status, expires_at)",
        "CREATE INDEX idx_bookings_passenger ON bookings(passenger_id)",
        "CREATE INDEX idx_driver_profile_location ON driver_profiles(current_latitude, current_longitude)"
    ];
    
    foreach ($indexes as $index) {
        try {
            $pdo->exec($index);
            echo "<p style='color: green;'>✓ Created: " . substr($index, 13, 30) . "...</p>";
        } catch (Exception $e) {
            if (strpos($e->getMessage(), 'Duplicate key name') !== false) {
                echo "<p style='color: orange;'>⚠ Already exists: " . substr($index, 13, 30) . "...</p>";
            } else {
                echo "<p style='color: red;'>✗ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
            }
        }
    }
    
    echo "<br><h3>Index Fix Complete!</h3>";
    echo "<p style='color: blue;'>ℹ️ Your database indexes are now properly configured.</p>";
    
    // Show current indexes
    echo "<br><h3>Current Indexes:</h3>";
    
    $tables = ['bookings', 'driver_profiles'];
    foreach ($tables as $table) {
        echo "<h4>Indexes in $table:</h4>";
        $stmt = $pdo->query("SHOW INDEX FROM $table");
        $indexes = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (empty($indexes)) {
            echo "<p style='color: orange;'>No indexes found</p>";
        } else {
            echo "<ul>";
            foreach ($indexes as $index) {
                echo "<li style='color: green;'>" . htmlspecialchars($index['Key_name']) . "</li>";
            }
            echo "</ul>";
        }
    }
    
    echo "<br><h3>Next Steps:</h3>";
    echo "<p>1. <a href='create_test_requests.php'>Create Test Requests</a></p>";
    echo "<p>2. <a href='driver/dashboard.php'>Test Dashboard Filter</a></p>";
    
} catch (PDOException $e) {
    echo "<p style='color: red;'>✗ Database connection failed: " . htmlspecialchars($e->getMessage()) . "</p>";
}
?>
