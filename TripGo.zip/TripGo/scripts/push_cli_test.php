<?php
// Usage: php scripts/push_cli_test.php <driver_id> "Title" "Body"
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../api/push_helper.php';

if (php_sapi_name() !== 'cli') {
    echo "This script must be run from the command line.\n";
    exit(1);
}

$argv = $_SERVER['argv'];
if (count($argv) < 4) {
    echo "Usage: php scripts/push_cli_test.php <driver_id> \"Title\" \"Body\"\n";
    exit(1);
}

$driverId = intval($argv[1]);
$title = $argv[2];
$body = $argv[3];

$pdo = getConnection();

$payload = json_encode([
    'title' => $title,
    'body' => $body,
    'data' => [],
    'timestamp' => time()
]);

echo "Sending push to driver_id={$driverId}\n";
$res = sendPushNotifications($pdo, $driverId, $payload, ['retry' => 1]);

echo "Result:\n";
print_r($res);

?>
