<?php
/**
 * VAPID Key Generator
 * 
 * This script generates VAPID (Voluntary Application Server Identification) keys
 * for web push notifications. Run this script once to generate your keys:
 * 
 * php scripts/generate-vapid-keys.php
 * 
 * Then copy the generated keys to config/push.php
 */

// Check if vendor/autoload.php exists
$vendorAutoload = __DIR__ . '/../vendor/autoload.php';

if (!file_exists($vendorAutoload)) {
    echo "ERROR: vendor/autoload.php not found.\n";
    echo "Please run 'composer install' first to install dependencies.\n";
    exit(1);
}

require_once $vendorAutoload;

use Minishlink\WebPush\VAPID;

try {
    echo "Generating VAPID keys...\n\n";
    
    $vapidKeys = VAPID::createVapidKeys();
    
    echo "VAPID Keys Generated Successfully!\n";
    echo str_repeat("=", 60) . "\n\n";
    echo "Public Key:\n";
    echo $vapidKeys['publicKey'] . "\n\n";
    echo "Private Key:\n";
    echo $vapidKeys['privateKey'] . "\n\n";
    echo str_repeat("=", 60) . "\n\n";
    echo "IMPORTANT: Copy these keys to config/push.php\n";
    echo "Replace the placeholder values with the keys above.\n\n";
    
    // Optionally update config/push.php automatically
    $configFile = __DIR__ . '/../config/push.php';
    if (file_exists($configFile)) {
        echo "Would you like to automatically update config/push.php? (y/n): ";
        $handle = fopen("php://stdin", "r");
        $line = trim(fgets($handle));
        fclose($handle);
        
        if (strtolower($line) === 'y' || strtolower($line) === 'yes') {
            $configContent = "<?php\n";
            $configContent .= "// Web Push (VAPID) configuration\n";
            $configContent .= "// Generated on " . date('Y-m-d H:i:s') . "\n\n";
            $configContent .= "return [\n";
            $configContent .= "    'public_key'  => '" . $vapidKeys['publicKey'] . "',\n";
            $configContent .= "    'private_key' => '" . $vapidKeys['privateKey'] . "',\n";
            $configContent .= "    'subject'     => 'mailto:admin@example.com' // Change this to your email\n";
            $configContent .= "];\n";
            
            file_put_contents($configFile, $configContent);
            echo "\n✓ config/push.php has been updated with your VAPID keys.\n";
            echo "  Don't forget to update the 'subject' email address!\n";
        }
    }
    
} catch (Exception $e) {
    echo "ERROR: Failed to generate VAPID keys: " . $e->getMessage() . "\n";
    exit(1);
}

