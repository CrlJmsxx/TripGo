# Passenger Rating System - Technical Implementation Plan

## Phase 1: Foundation & Reliability (2-3 weeks)

### **1.1 Automated Triggers Implementation**

#### **Backend Logic - Time-Based Auto-Completion**

**Database Schema Changes:**
```sql
-- Add to bookings table
ALTER TABLE bookings ADD COLUMN auto_completion_time TIMESTAMP NULL;
ALTER TABLE bookings ADD COLUMN completion_method ENUM('manual', 'auto', 'passenger') DEFAULT 'manual';
ALTER TABLE bookings ADD COLUMN estimated_duration_minutes INT DEFAULT NULL;

-- Add completion audit table
CREATE TABLE booking_completion_audit (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    original_status VARCHAR(20) NOT NULL,
    new_status VARCHAR(20) NOT NULL,
    completion_method ENUM('manual', 'auto', 'passenger') NOT NULL,
    triggered_by VARCHAR(50) NOT NULL, -- 'cron', 'driver', 'passenger'
    trigger_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(id)
);
```

**PHP Implementation - Auto-Completion Service:**
```php
<?php
// services/RatingAutoCompletionService.php
class RatingAutoCompletionService {
    private $pdo;
    private $autoCompleteAfterMinutes = 30; // Configurable
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function processAutoCompletions() {
        // Find rides that should be auto-completed
        $stmt = $this->pdo->prepare("
            SELECT b.*, 
                   TIMESTAMPDIFF(MINUTE, b.accepted_time, NOW()) as elapsed_minutes,
                   u.full_name as driver_name
            FROM bookings b
            LEFT JOIN users u ON b.driver_id = u.id
            WHERE b.status IN ('in_progress', 'accepted')
            AND b.completion_method = 'manual'
            AND (
                (b.accepted_time IS NOT NULL AND TIMESTAMPDIFF(MINUTE, b.accepted_time, NOW()) > ?)
                OR (b.booking_time IS NOT NULL AND TIMESTAMPDIFF(MINUTE, b.booking_time, NOW()) > 180) -- 3 hours max
            )
            AND b.auto_completion_time IS NULL
        ");
        $stmt->execute([$this->autoCompleteAfterMinutes]);
        $pendingCompletions = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($pendingCompletions as $booking) {
            $this->autoCompleteRide($booking);
        }
        
        return count($pendingCompletions);
    }
    
    private function autoCompleteRide($booking) {
        try {
            $this->pdo->beginTransaction();
            
            // Update booking status
            $stmt = $this->pdo->prepare("
                UPDATE bookings 
                SET status = 'completed',
                    dropoff_time = NOW(),
                    rating_requested = 1,
                    completion_method = 'auto',
                    auto_completion_time = NOW(),
                    actual_fare = estimated_fare
                WHERE id = ?
            ");
            $stmt->execute([$booking['id']]);
            
            // Log the auto-completion
            $stmt = $this->pdo->prepare("
                INSERT INTO booking_completion_audit 
                (booking_id, original_status, new_status, completion_method, triggered_by, trigger_reason)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $booking['id'],
                $booking['status'],
                'completed',
                'auto',
                'cron',
                "Auto-completed after {$booking['elapsed_minutes']} minutes"
            ]);
            
            // Trigger notification system
            $this->triggerRatingNotification($booking['id'], $booking['passenger_id']);
            
            $this->pdo->commit();
            
            error_log("Auto-completed booking {$booking['id']} for driver {$booking['driver_name']}");
            
        } catch (Exception $e) {
            $this->pdo->rollback();
            error_log("Failed to auto-complete booking {$booking['id']}: " . $e->getMessage());
        }
    }
    
    private function triggerRatingNotification($bookingId, $passengerId) {
        // This will be implemented in the notification system
        $notificationService = new NotificationService($this->pdo);
        $notificationService->createRatingRequest($bookingId, $passengerId);
    }
}
?>
```

**Cron Job Implementation:**
```bash
# Add to crontab (every 5 minutes)
*/5 * * * * /usr/bin/php /path/to/TripGo/scripts/auto_complete_rides.php
```

```php
<?php
// scripts/auto_complete_rides.php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../services/RatingAutoCompletionService.php';

$pdo = getConnection();
$autoCompleteService = new RatingAutoCompletionService($pdo);
$completedCount = $autoCompleteService->processAutoCompletions();

echo "Auto-completed {$completedCount} rides\n";
?>
```

#### **Passenger Confirmation Option**

**Database Additions:**
```sql
ALTER TABLE bookings ADD COLUMN passenger_confirmed_completion BOOLEAN DEFAULT FALSE;
ALTER TABLE bookings ADD COLUMN passenger_completion_time TIMESTAMP NULL;
```

**Frontend Implementation:**
```javascript
// Add to passenger dashboard
class RideCompletionManager {
    constructor() {
        this.initCompletionButtons();
    }
    
    initCompletionButtons() {
        document.querySelectorAll('.confirm-completion-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const bookingId = e.target.dataset.bookingId;
                this.confirmCompletion(bookingId);
            });
        });
    }
    
    async confirmCompletion(bookingId) {
        try {
            const response = await fetch('api/confirm_ride_completion.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ booking_id: bookingId })
            });
            
            if (response.ok) {
                this.showCompletionSuccess(bookingId);
                // Trigger rating modal after 2 seconds
                setTimeout(() => this.showRatingModal(bookingId), 2000);
            }
        } catch (error) {
            console.error('Error confirming completion:', error);
        }
    }
    
    showCompletionSuccess(bookingId) {
        const btn = document.querySelector(`[data-booking-id="${bookingId}"]`);
        btn.innerHTML = '<i class="fas fa-check"></i> Completed!';
        btn.className = 'btn btn-success';
        btn.disabled = true;
    }
}
```

### **1.2 Notification System Implementation**

#### **Database Schema for Notifications:**
```sql
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type ENUM('rating_request', 'rating_reminder', 'completion_confirmation') NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    data JSON, -- Additional data like booking_id, etc.
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE notification_preferences (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    notification_type ENUM('rating_request', 'rating_reminder', 'completion_confirmation') NOT NULL,
    enabled BOOLEAN DEFAULT TRUE,
    delivery_method ENUM('in_app', 'email', 'sms', 'push') NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

#### **Notification Service Backend:**
```php
<?php
// services/NotificationService.php
class NotificationService {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function createRatingRequest($bookingId, $passengerId) {
        // Get booking details
        $stmt = $this->pdo->prepare("
            SELECT b.*, u.full_name as driver_name 
            FROM bookings b 
            LEFT JOIN users u ON b.driver_id = u.id 
            WHERE b.id = ?
        ");
        $stmt->execute([$bookingId]);
        $booking = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$booking) return false;
        
        // Create notification
        $stmt = $this->pdo->prepare("
            INSERT INTO notifications (user_id, type, title, message, data, expires_at)
            VALUES (?, ?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 7 DAY))
        ");
        $stmt->execute([
            $passengerId,
            'rating_request',
            'Rate Your Recent Ride',
            "How was your ride with {$booking['driver_name']}? Your feedback helps us improve our service.",
            json_encode(['booking_id' => $bookingId, 'driver_name' => $booking['driver_name']])
        ]);
        
        // Schedule reminders
        $this->scheduleReminders($bookingId, $passengerId);
        
        return $this->pdo->lastInsertId();
    }
    
    private function scheduleReminders($bookingId, $passengerId) {
        // 24-hour reminder
        $this->scheduleReminder($bookingId, $passengerId, 24, 'rating_reminder');
        
        // 3-day reminder
        $this->scheduleReminder($bookingId, $passengerId, 72, 'rating_reminder');
    }
    
    private function scheduleReminder($bookingId, $passengerId, $hours, $type) {
        // This would typically use a job queue system
        // For now, we'll store in a reminders table
        $stmt = $this->pdo->prepare("
            INSERT INTO scheduled_reminders (booking_id, user_id, reminder_type, scheduled_for)
            VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL ? HOUR))
        ");
        $stmt->execute([$bookingId, $passengerId, $type, $hours]);
    }
}
?>
```

#### **Frontend Notification Display:**
```javascript
// Add to passenger dashboard
class NotificationManager {
    constructor() {
        this.init();
    }
    
    init() {
        this.loadNotifications();
        this.setupNotificationBadge();
    }
    
    async loadNotifications() {
        try {
            const response = await fetch('api/notifications.php');
            const notifications = await response.json();
            
            this.displayNotifications(notifications);
            this.updateBadgeCount(notifications);
        } catch (error) {
            console.error('Error loading notifications:', error);
        }
    }
    
    displayNotifications(notifications) {
        const container = document.getElementById('notificationDropdown');
        if (!container) return;
        
        const html = notifications.map(notification => `
            <div class="notification-item ${notification.is_read ? 'read' : 'unread'}" data-id="${notification.id}">
                <div class="notification-content">
                    <h4>${notification.title}</h4>
                    <p>${notification.message}</p>
                    <small>${this.formatTime(notification.created_at)}</small>
                </div>
                <div class="notification-actions">
                    ${notification.type === 'rating_request' ? 
                        `<button class="btn btn-primary btn-sm" onclick="window.location='rate_ride.php'">
                            Rate Now
                        </button>` : ''
                    }
                </div>
            </div>
        `).join('');
        
        container.innerHTML = html;
    }
    
    updateBadgeCount(notifications) {
        const unreadCount = notifications.filter(n => !n.is_read).length;
        const badge = document.querySelector('.notification-badge');
        
        if (badge) {
            badge.textContent = unreadCount > 0 ? unreadCount : '';
            badge.style.display = unreadCount > 0 ? 'block' : 'none';
        }
    }
    
    formatTime(timestamp) {
        const date = new Date(timestamp);
        const now = new Date();
        const diff = now - date;
        
        if (diff < 60000) return 'Just now';
        if (diff < 3600000) return `${Math.floor(diff / 60000)} min ago`;
        if (diff < 86400000) return `${Math.floor(diff / 3600000)} hours ago`;
        return date.toLocaleDateString();
    }
}
```

#### **Dashboard Integration:**
```php
// Add to passenger/dashboard.php
$notificationManager = new NotificationManager($pdo);
$pendingNotifications = $notificationManager->getUnreadCount($currentUser['id']);
$pendingRatings = $notificationManager->getPendingRatingCount($currentUser['id']);

// Display rating prompt
if ($pendingRatings > 0) {
    echo '<div class="rating-prompt alert alert-info">
            <i class="fas fa-star"></i> 
            You have <strong>' . $pendingRatings . '</strong> ride(s) to rate!
            <a href="rate_ride.php" class="btn btn-primary btn-sm ml-2">Rate Now</a>
          </div>';
}
```

## Phase 2: Enhanced Interface & Data Collection (3-4 weeks)

### **2.1 Multi-Dimensional Ratings**

#### **Database Schema Enhancements:**
```sql
-- Extend reviews table with category ratings
ALTER TABLE reviews ADD COLUMN (
    safety_rating INT CHECK (safety_rating >= 1 AND safety_rating <= 5),
    cleanliness_rating INT CHECK (cleanliness_rating >= 1 AND cleanliness_rating <= 5),
    professionalism_rating INT CHECK (professionalism_rating >= 1 AND professionalism_rating <= 5),
    navigation_rating INT CHECK (navigation_rating >= 1 AND navigation_rating <= 5),
    overall_rating INT CHECK (overall_rating >= 1 AND overall_rating <= 5),
    rating_version INT DEFAULT 1 -- For future schema changes
);

-- Update existing reviews to have overall_rating
UPDATE reviews SET overall_rating = rating WHERE overall_rating IS NULL;

-- Add rating category definitions
CREATE TABLE rating_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    description TEXT,
    icon VARCHAR(50),
    weight DECIMAL(3,2) DEFAULT 1.0, -- For weighted averages
    is_active BOOLEAN DEFAULT TRUE,
    sort_order INT DEFAULT 0
);

-- Insert default categories
INSERT INTO rating_categories (name, description, icon, weight, sort_order) VALUES
('Safety', 'How safe did you feel during the ride?', 'fa-shield-alt', 1.5, 1),
('Cleanliness', 'How clean was the vehicle?', 'fa-car', 1.0, 2),
('Professionalism', 'How professional was the driver?', 'fa-user-tie', 1.2, 3),
('Navigation', 'How well did the driver know the route?', 'fa-route', 0.8, 4);
```

#### **Backend Rating Processing:**
```php
<?php
// services/MultiDimensionalRatingService.php
class MultiDimensionalRatingService {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function submitRating($data) {
        try {
            $this->pdo->beginTransaction();
            
            // Validate rating data
            $this->validateRatingData($data);
            
            // Calculate overall rating if not provided
            if (!isset($data['overall_rating'])) {
                $data['overall_rating'] = $this->calculateOverallRating($data);
            }
            
            // Insert the multi-dimensional rating
            $stmt = $this->pdo->prepare("
                INSERT INTO reviews (
                    booking_id, passenger_id, driver_id, 
                    overall_rating, safety_rating, cleanliness_rating, 
                    professionalism_rating, navigation_rating, 
                    review, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            
            $stmt->execute([
                $data['booking_id'],
                $data['passenger_id'],
                $data['driver_id'],
                $data['overall_rating'],
                $data['safety_rating'] ?? null,
                $data['cleanliness_rating'] ?? null,
                $data['professionalism_rating'] ?? null,
                $data['navigation_rating'] ?? null,
                $data['review'] ?? null
            ]);
            
            // Update driver's average ratings
            $this->updateDriverAverages($data['driver_id']);
            
            // Mark booking as rated
            $this->markBookingAsRated($data['booking_id']);
            
            $this->pdo->commit();
            
            return ['success' => true, 'message' => 'Rating submitted successfully'];
            
        } catch (Exception $e) {
            $this->pdo->rollback();
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    private function calculateOverallRating($data) {
        $categories = ['safety_rating', 'cleanliness_rating', 'professionalism_rating', 'navigation_rating'];
        $ratings = [];
        
        // Get category weights
        $weights = $this->getCategoryWeights();
        
        foreach ($categories as $category) {
            if (isset($data[$category]) && $data[$category] > 0) {
                $weight = $weights[$category] ?? 1.0;
                $ratings[] = $data[$category] * $weight;
            }
        }
        
        if (empty($ratings)) {
            return 5; // Default rating if no categories provided
        }
        
        return round(array_sum($ratings) / array_sum(array_map(function($cat) use ($weights) { 
            return $weights[$cat] ?? 1.0; 
        }, $categories)), 1);
    }
    
    private function getCategoryWeights() {
        $stmt = $this->pdo->prepare("SELECT name, weight FROM rating_categories WHERE is_active = 1");
        $stmt->execute();
        $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $weights = [];
        foreach ($categories as $category) {
            $weights[$category['name'] . '_rating'] = $category['weight'];
        }
        
        return $weights;
    }
    
    private function updateDriverAverages($driverId) {
        // Update overall average
        $stmt = $this->pdo->prepare("
            UPDATE users u SET average_rating = (
                SELECT AVG(overall_rating) 
                FROM reviews r 
                WHERE r.driver_id = u.id
            ) WHERE u.id = ?
        ");
        $stmt->execute([$driverId]);
        
        // Update category averages
        $categories = ['safety_rating', 'cleanliness_rating', 'professionalism_rating', 'navigation_rating'];
        
        foreach ($categories as $category) {
            $categoryName = str_replace('_rating', '', $category);
            
            $stmt = $this->pdo->prepare("
                UPDATE driver_ratings dr 
                SET {$category} = (
                    SELECT AVG({$category}) 
                    FROM reviews r 
                    WHERE r.driver_id = dr.driver_id 
                    AND {$category} IS NOT NULL
                )
                WHERE dr.driver_id = ?
            ");
            $stmt->execute([$driverId]);
        }
    }
}
?>
```

#### **Frontend Multi-Dimensional Rating Interface:**
```html
<!-- Enhanced rating interface -->
<div class="multi-dimensional-rating">
    <div class="rating-header">
        <h3>Rate Your Ride Experience</h3>
        <p>Your detailed feedback helps drivers improve their service</p>
    </div>
    
    <div class="rating-categories">
        <!-- Safety Rating -->
        <div class="rating-category">
            <div class="category-header">
                <i class="fas fa-shield-alt"></i>
                <div class="category-info">
                    <h4>Safety</h4>
                    <small>How safe did you feel during the ride?</small>
                </div>
            </div>
            <div class="star-rating" data-category="safety_rating">
                <i class="fas fa-star" data-rating="1"></i>
                <i class="fas fa-star" data-rating="2"></i>
                <i class="fas fa-star" data-rating="3"></i>
                <i class="fas fa-star" data-rating="4"></i>
                <i class="fas fa-star" data-rating="5"></i>
            </div>
        </div>
        
        <!-- Cleanliness Rating -->
        <div class="rating-category">
            <div class="category-header">
                <i class="fas fa-car"></i>
                <div class="category-info">
                    <h4>Cleanliness</h4>
                    <small>How clean was the vehicle?</small>
                </div>
            </div>
            <div class="star-rating" data-category="cleanliness_rating">
                <i class="fas fa-star" data-rating="1"></i>
                <i class="fas fa-star" data-rating="2"></i>
                <i class="fas fa-star" data-rating="3"></i>
                <i class="fas fa-star" data-rating="4"></i>
                <i class="fas fa-star" data-rating="5"></i>
            </div>
        </div>
        
        <!-- Professionalism Rating -->
        <div class="rating-category">
            <div class="category-header">
                <i class="fas fa-user-tie"></i>
                <div class="category-info">
                    <h4>Professionalism</h4>
                    <small>How professional was the driver?</small>
                </div>
            </div>
            <div class="star-rating" data-category="professionalism_rating">
                <i class="fas fa-star" data-rating="1"></i>
                <i class="fas fa-star" data-rating="2"></i>
                <i class="fas fa-star" data-rating="3"></i>
                <i class="fas fa-star" data-rating="4"></i>
                <i class="fas fa-star" data-rating="5"></i>
            </div>
        </div>
        
        <!-- Navigation Rating -->
        <div class="rating-category">
            <div class="category-header">
                <i class="fas fa-route"></i>
                <div class="category-info">
                    <h4>Navigation</h4>
                    <small>How well did the driver know the route?</small>
                </div>
            </div>
            <div class="star-rating" data-category="navigation_rating">
                <i class="fas fa-star" data-rating="1"></i>
                <i class="fas fa-star" data-rating="2"></i>
                <i class="fas fa-star" data-rating="3"></i>
                <i class="fas fa-star" data-rating="4"></i>
                <i class="fas fa-star" data-rating="5"></i>
            </div>
        </div>
    </div>
    
    <!-- Overall Rating Display -->
    <div class="overall-rating-summary">
        <div class="overall-score">
            <span class="score-label">Overall Rating</span>
            <span class="score-value" id="calculatedOverall">-</span>
            <div class="star-display" id="overallStars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
            </div>
        </div>
    </div>
</div>
```

```css
/* Enhanced rating interface styles */
.multi-dimensional-rating {
    background: var(--bg-secondary);
    border-radius: 16px;
    padding: 24px;
    margin-bottom: 20px;
    border: 1px solid var(--border-light);
}

.rating-header {
    text-align: center;
    margin-bottom: 32px;
}

.rating-header h3 {
    margin: 0 0 8px 0;
    color: var(--text-primary);
    font-size: 1.3rem;
}

.rating-header p {
    margin: 0;
    color: var(--text-muted);
    font-size: 0.95rem;
}

.rating-categories {
    display: grid;
    gap: 24px;
    margin-bottom: 24px;
}

.rating-category {
    background: var(--bg-primary);
    border-radius: 12px;
    padding: 20px;
    border: 1px solid var(--border-color);
    transition: all 0.3s ease;
}

.rating-category:hover {
    border-color: var(--primary-color);
    transform: translateY(-2px);
}

.category-header {
    display: flex;
    align-items: center;
    gap: 16px;
    margin-bottom: 16px;
}

.category-header i {
    font-size: 1.5rem;
    color: var(--primary-color);
    width: 40px;
    text-align: center;
}

.category-info h4 {
    margin: 0 0 4px 0;
    color: var(--text-primary);
    font-size: 1.1rem;
}

.category-info small {
    margin: 0;
    color: var(--text-muted);
    font-size: 0.85rem;
}

.star-rating {
    display: flex;
    gap: 8px;
    justify-content: center;
}

.star-rating i {
    font-size: 1.8rem;
    color: var(--text-muted);
    cursor: pointer;
    transition: all 0.2s ease;
}

.star-rating i:hover {
    transform: scale(1.1);
    color: var(--light-accent);
}

.star-rating i.active {
    color: #ffc107;
    transform: scale(1.05);
}

.overall-rating-summary {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: white;
    border-radius: 12px;
    padding: 20px;
    text-align: center;
}

.overall-score {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
}

.score-label {
    font-size: 0.9rem;
    opacity: 0.9;
}

.score-value {
    font-size: 2.5rem;
    font-weight: bold;
}

.star-display i {
    color: rgba(255, 255, 255, 0.3);
    font-size: 1.2rem;
}

.star-display i.filled {
    color: #ffc107;
}
```

```javascript
// Multi-dimensional rating JavaScript
class MultiDimensionalRating {
    constructor() {
        this.ratings = {};
        this.init();
    }
    
    init() {
        this.setupCategoryRatings();
        this.calculateOverall();
    }
    
    setupCategoryRatings() {
        document.querySelectorAll('.star-rating').forEach(container => {
            const category = container.dataset.category;
            const stars = container.querySelectorAll('i');
            let selectedRating = 0;
            
            stars.forEach((star, index) => {
                star.addEventListener('click', () => {
                    selectedRating = index + 1;
                    this.ratings[category] = selectedRating;
                    this.updateStars(container, selectedRating);
                    this.calculateOverall();
                });
                
                star.addEventListener('mouseenter', () => {
                    this.updateStars(container, index + 1);
                });
            });
            
            container.addEventListener('mouseleave', () => {
                this.updateStars(container, selectedRating);
            });
        });
    }
    
    updateStars(container, rating) {
        const stars = container.querySelectorAll('i');
        stars.forEach((star, index) => {
            if (index < rating) {
                star.classList.add('active');
            } else {
                star.classList.remove('active');
            }
        });
    }
    
    calculateOverall() {
        const categories = ['safety_rating', 'cleanliness_rating', 'professionalism_rating', 'navigation_rating'];
        const validRatings = categories.filter(cat => this.ratings[cat] && this.ratings[cat] > 0);
        
        if (validRatings.length === 0) {
            document.getElementById('calculatedOverall').textContent = '-';
            return;
        }
        
        // Simple average (can be enhanced with weights)
        const average = validRatings.reduce((sum, cat) => sum + this.ratings[cat], 0) / validRatings.length;
        const roundedAverage = Math.round(average * 10) / 10;
        
        document.getElementById('calculatedOverall').textContent = roundedAverage;
        this.updateOverallStars(roundedAverage);
    }
    
    updateOverallStars(rating) {
        const stars = document.querySelectorAll('#overallStars i');
        stars.forEach((star, index) => {
            if (index < Math.floor(rating)) {
                star.classList.add('filled');
            } else {
                star.classList.remove('filled');
            }
        });
    }
    
    getRatingData() {
        return {
            safety_rating: this.ratings['safety_rating'] || null,
            cleanliness_rating: this.ratings['cleanliness_rating'] || null,
            professionalism_rating: this.ratings['professionalism_rating'] || null,
            navigation_rating: this.ratings['navigation_rating'] || null
        };
    }
}
```

### **2.2 Quick Feedback Tags**

#### **Database Schema for Tags:**
```sql
CREATE TABLE feedback_tags (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tag_name VARCHAR(50) NOT NULL UNIQUE,
    display_name VARCHAR(100) NOT NULL,
    icon VARCHAR(50),
    color VARCHAR(20) DEFAULT '#007bff',
    is_active BOOLEAN DEFAULT TRUE,
    usage_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE review_tags (
    id INT AUTO_INCREMENT PRIMARY KEY,
    review_id INT NOT NULL,
    tag_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (review_id) REFERENCES reviews(id) ON DELETE CASCADE,
    FOREIGN KEY (tag_id) REFERENCES feedback_tags(id) ON DELETE CASCADE,
    UNIQUE KEY unique_review_tag (review_id, tag_id)
);

-- Insert default tags
INSERT INTO feedback_tags (tag_name, display_name, icon, color) VALUES
('friendly', 'Friendly', 'fa-smile', '#28a745'),
('clean_car', 'Clean Car', 'fa-car', '#17a2b8'),
('safe_driver', 'Safe Driver', 'fa-shield-alt', '#6f42c1'),
('efficient', 'Efficient', 'fa-tachometer-alt', '#fd7e14'),
('helpful', 'Helpful', 'fa-hands-helping', '#20c997'),
('good_conversation', 'Good Conversation', 'fa-comments', '#6610f2'),
('on_time', 'On Time', 'fa-clock', '#e83e8c'),
('comfortable', 'Comfortable', 'fa-couch', '#6c757d');
```

#### **Backend Tag Management:**
```php
<?php
// services/FeedbackTagService.php
class FeedbackTagService {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function getActiveTags() {
        $stmt = $this->pdo->prepare("
            SELECT * FROM feedback_tags 
            WHERE is_active = 1 
            ORDER BY usage_count DESC, display_name ASC
        ");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function attachTagsToReview($reviewId, $tagNames) {
        try {
            foreach ($tagNames as $tagName) {
                // Get tag ID
                $stmt = $this->pdo->prepare("SELECT id FROM feedback_tags WHERE tag_name = ?");
                $stmt->execute([$tagName]);
                $tag = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($tag) {
                    // Attach tag to review
                    $stmt = $this->pdo->prepare("
                        INSERT IGNORE INTO review_tags (review_id, tag_id) 
                        VALUES (?, ?)
                    ");
                    $stmt->execute([$reviewId, $tag['id']]);
                    
                    // Increment usage count
                    $stmt = $this->pdo->prepare("
                        UPDATE feedback_tags 
                        SET usage_count = usage_count + 1 
                        WHERE id = ?
                    ");
                    $stmt->execute([$tag['id']]);
                }
            }
            
            return true;
        } catch (Exception $e) {
            error_log("Error attaching tags: " . $e->getMessage());
            return false;
        }
    }
    
    public function getPopularTags($limit = 10) {
        $stmt = $this->pdo->prepare("
            SELECT ft.*, COUNT(rt.id) as usage_count
            FROM feedback_tags ft
            LEFT JOIN review_tags rt ON ft.id = rt.tag_id
            WHERE ft.is_active = 1
            GROUP BY ft.id
            ORDER BY usage_count DESC, ft.display_name ASC
            LIMIT ?
        ");
        $stmt->execute([$limit]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
```

#### **Frontend Tag Interface:**
```html
<!-- Quick feedback tags section -->
<div class="quick-feedback-section">
    <div class="section-header">
        <h4>Quick Feedback (Optional)</h4>
        <p>Select any that apply to your ride</p>
    </div>
    
    <div class="tags-container">
        <?php foreach ($activeTags as $tag): ?>
            <span class="feedback-tag" data-tag="<?php echo $tag['tag_name']; ?>">
                <i class="fas <?php echo $tag['icon']; ?>"></i>
                <?php echo htmlspecialchars($tag['display_name']); ?>
            </span>
        <?php endforeach; ?>
    </div>
</div>
```

```css
/* Quick feedback tags styles */
.quick-feedback-section {
    margin: 24px 0;
    padding: 20px;
    background: var(--bg-primary);
    border-radius: 12px;
    border: 1px solid var(--border-color);
}

.section-header h4 {
    margin: 0 0 4px 0;
    color: var(--text-primary);
    font-size: 1.1rem;
}

.section-header p {
    margin: 0 0 16px 0;
    color: var(--text-muted);
    font-size: 0.9rem;
}

.tags-container {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
}

.feedback-tag {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    background: var(--bg-secondary);
    border: 2px solid var(--border-color);
    border-radius: 20px;
    cursor: pointer;
    transition: all 0.2s ease;
    font-size: 0.9rem;
    color: var(--text-secondary);
}

.feedback-tag:hover {
    border-color: var(--primary-color);
    background: rgba(37, 99, 235, 0.05);
    transform: translateY(-1px);
}

.feedback-tag.selected {
    background: var(--primary-color);
    border-color: var(--primary-color);
    color: white;
}

.feedback-tag i {
    font-size: 0.8rem;
}
```

```javascript
// Quick feedback tags JavaScript
class QuickFeedbackTags {
    constructor() {
        this.selectedTags = new Set();
        this.init();
    }
    
    init() {
        this.setupTagListeners();
    }
    
    setupTagListeners() {
        document.querySelectorAll('.feedback-tag').forEach(tag => {
            tag.addEventListener('click', () => {
                const tagName = tag.dataset.tag;
                
                if (this.selectedTags.has(tagName)) {
                    this.selectedTags.delete(tagName);
                    tag.classList.remove('selected');
                } else {
                    this.selectedTags.add(tagName);
                    tag.classList.add('selected');
                }
            });
        });
    }
    
    getSelectedTags() {
        return Array.from(this.selectedTags);
    }
    
    reset() {
        this.selectedTags.clear();
        document.querySelectorAll('.feedback-tag.selected').forEach(tag => {
            tag.classList.remove('selected');
        });
    }
}
```

## Phase 3: Engagement, Analytics, and Quality Control (4-6 weeks)

### **3.1 Gamification System**

#### **Database Schema for Gamification:**
```sql
CREATE TABLE rating_achievements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    icon VARCHAR(50),
    badge_color VARCHAR(20) DEFAULT '#007bff',
    requirement_type ENUM('total_ratings', 'consecutive_ratings', 'quality_score', 'helpful_votes') NOT NULL,
    requirement_value INT NOT NULL,
    points INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE user_achievements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    achievement_id INT NOT NULL,
    earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (achievement_id) REFERENCES rating_achievements(id),
    UNIQUE KEY unique_user_achievement (user_id, achievement_id)
);

CREATE TABLE user_rating_stats (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    total_ratings INT DEFAULT 0,
    consecutive_ratings INT DEFAULT 0,
    quality_score DECIMAL(5,2) DEFAULT 0,
    helpful_votes INT DEFAULT 0,
    total_points INT DEFAULT 0,
    last_rating_date TIMESTAMP NULL,
    current_streak_start TIMESTAMP NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE review_helpfulness (
    id INT AUTO_INCREMENT PRIMARY KEY,
    review_id INT NOT NULL,
    user_id INT NOT NULL,
    is_helpful BOOLEAN NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (review_id) REFERENCES reviews(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id),
    UNIQUE KEY unique_review_user_vote (review_id, user_id)
);

-- Insert default achievements
INSERT INTO rating_achievements (name, description, icon, requirement_type, requirement_value, points) VALUES
('First Rating', 'Submitted your first ride rating', 'fa-star', 'total_ratings', 1, 10),
('Rising Critic', 'Submitted 5 ride ratings', 'fa-chart-line', 'total_ratings', 5, 25),
('Experienced Rater', 'Submitted 25 ride ratings', 'fa-award', 'total_ratings', 25, 100),
('Rating Master', 'Submitted 100 ride ratings', 'fa-crown', 'total_ratings', 100, 500),
('On a Roll', 'Rated 3 rides in a row', 'fa-fire', 'consecutive_ratings', 3, 15),
('Consistent Contributor', 'Rated 10 rides in a row', 'fa-fire-alt', 'consecutive_ratings', 10, 50),
('Quality Feedback', 'Received 10 helpful votes on your reviews', 'fa-thumbs-up', 'helpful_votes', 10, 30),
('Detailed Reviewer', 'Average review length over 100 characters', 'fa-pen', 'quality_score', 100, 20);
```

#### **Gamification Service Backend:**
```php
<?php
// services/GamificationService.php
class GamificationService {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function processRatingSubmission($userId, $reviewData) {
        try {
            $this->pdo->beginTransaction();
            
            // Update user rating stats
            $this->updateUserStats($userId, $reviewData);
            
            // Check for new achievements
            $newAchievements = $this->checkAchievements($userId);
            
            // Award points
            $pointsAwarded = $this->awardPoints($userId, $reviewData);
            
            $this->pdo->commit();
            
            return [
                'success' => true,
                'points' => $pointsAwarded,
                'achievements' => $newAchievements,
                'stats' => $this->getUserStats($userId)
            ];
            
        } catch (Exception $e) {
            $this->pdo->rollback();
            error_log("Gamification error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    private function updateUserStats($userId, $reviewData) {
        // Get current stats
        $stmt = $this->pdo->prepare("SELECT * FROM user_rating_stats WHERE user_id = ?");
        $stmt->execute([$userId]);
        $stats = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$stats) {
            // Create initial stats
            $stmt = $this->pdo->prepare("
                INSERT INTO user_rating_stats 
                (user_id, total_ratings, consecutive_ratings, last_rating_date, current_streak_start)
                VALUES (?, 1, 1, NOW(), NOW())
            ");
            $stmt->execute([$userId]);
        } else {
            // Update existing stats
            $consecutive = $this->calculateConsecutiveRating($userId, $stats['last_rating_date']);
            $qualityScore = $this->calculateQualityScore($reviewData);
            
            $stmt = $this->pdo->prepare("
                UPDATE user_rating_stats 
                SET total_ratings = total_ratings + 1,
                    consecutive_ratings = ?,
                    quality_score = ?,
                    last_rating_date = NOW(),
                    current_streak_start = CASE 
                        WHEN ? > 1 THEN current_streak_start 
                        ELSE NOW() 
                    END
                WHERE user_id = ?
            ");
            $stmt->execute([$consecutive, $qualityScore, $consecutive, $userId]);
        }
    }
    
    private function checkAchievements($userId) {
        $newAchievements = [];
        $stats = $this->getUserStats($userId);
        
        // Get all achievements
        $stmt = $this->pdo->prepare("SELECT * FROM rating_achievements WHERE is_active = 1");
        $stmt->execute();
        $achievements = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($achievements as $achievement) {
            if (!$this->hasAchievement($userId, $achievement['id']) && 
                $this->meetsRequirement($stats, $achievement)) {
                
                // Award achievement
                $stmt = $this->pdo->prepare("
                    INSERT INTO user_achievements (user_id, achievement_id) 
                    VALUES (?, ?)
                ");
                $stmt->execute([$userId, $achievement['id']]);
                
                $newAchievements[] = $achievement;
            }
        }
        
        return $newAchievements;
    }
    
    private function meetsRequirement($stats, $achievement) {
        switch ($achievement['requirement_type']) {
            case 'total_ratings':
                return $stats['total_ratings'] >= $achievement['requirement_value'];
            case 'consecutive_ratings':
                return $stats['consecutive_ratings'] >= $achievement['requirement_value'];
            case 'quality_score':
                return $stats['quality_score'] >= $achievement['requirement_value'];
            case 'helpful_votes':
                return $stats['helpful_votes'] >= $achievement['requirement_value'];
            default:
                return false;
        }
    }
    
    public function getUserStats($userId) {
        $stmt = $this->pdo->prepare("SELECT * FROM user_rating_stats WHERE user_id = ?");
        $stmt->execute([$userId]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    }
    
    public function getUserAchievements($userId) {
        $stmt = $this->pdo->prepare("
            SELECT ra.*, ua.earned_at 
            FROM rating_achievements ra
            JOIN user_achievements ua ON ra.id = ua.achievement_id
            WHERE ua.user_id = ?
            ORDER BY ua.earned_at DESC
        ");
        $stmt->execute([$userId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
```

#### **Frontend Gamification Display:**
```html
<!-- Rating progress and achievements section -->
<div class="rating-progress-section">
    <div class="progress-header">
        <h3>Your Rating Contribution</h3>
        <div class="points-display">
            <i class="fas fa-coins"></i>
            <span id="totalPoints">0</span> Points
        </div>
    </div>
    
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-value" id="totalRatings">0</div>
            <div class="stat-label">Total Ratings</div>
        </div>
        <div class="stat-card">
            <div class="stat-value" id="currentStreak">0</div>
            <div class="stat-label">Current Streak</div>
        </div>
        <div class="stat-card">
            <div class="stat-value" id="helpfulVotes">0</div>
            <div class="stat-label">Helpful Votes</div>
        </div>
    </div>
    
    <div class="achievements-section">
        <h4>Recent Achievements</h4>
        <div class="achievements-grid" id="achievementsGrid">
            <!-- Achievements will be populated here -->
        </div>
    </div>
    
    <div class="next-milestone">
        <div class="milestone-progress">
            <div class="progress-info">
                <span id="nextMilestoneText">Rate 1 more ride to unlock "First Rating"!</span>
                <div class="progress-bar">
                    <div class="progress-fill" id="milestoneProgress" style="width: 0%"></div>
                </div>
            </div>
        </div>
    </div>
</div>
```

```css
/* Gamification styles */
.rating-progress-section {
    background: linear-gradient(135deg, var(--bg-gradient-start), var(--bg-gradient-end));
    color: white;
    border-radius: 16px;
    padding: 24px;
    margin: 24px 0;
}

.progress-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.points-display {
    display: flex;
    align-items: center;
    gap: 8px;
    background: rgba(255, 255, 255, 0.2);
    padding: 8px 16px;
    border-radius: 20px;
    font-weight: bold;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
    gap: 16px;
    margin-bottom: 24px;
}

.stat-card {
    background: rgba(255, 255, 255, 0.1);
    border-radius: 12px;
    padding: 16px;
    text-align: center;
    backdrop-filter: blur(10px);
}

.stat-value {
    font-size: 1.8rem;
    font-weight: bold;
    margin-bottom: 4px;
}

.stat-label {
    font-size: 0.85rem;
    opacity: 0.9;
}

.achievements-section h4 {
    margin: 0 0 16px 0;
    font-size: 1.1rem;
}

.achievements-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(60px, 1fr));
    gap: 12px;
    margin-bottom: 20px;
}

.achievement-badge {
    background: rgba(255, 255, 255, 0.2);
    border-radius: 50%;
    width: 60px;
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    cursor: pointer;
    transition: transform 0.2s ease;
}

.achievement-badge:hover {
    transform: scale(1.1);
}

.achievement-badge i {
    font-size: 1.5rem;
}

.milestone-progress {
    background: rgba(255, 255, 255, 0.1);
    border-radius: 12px;
    padding: 16px;
}

.progress-info {
    text-align: center;
}

.progress-bar {
    background: rgba(255, 255, 255, 0.2);
    border-radius: 10px;
    height: 8px;
    margin-top: 12px;
    overflow: hidden;
}

.progress-fill {
    background: white;
    height: 100%;
    border-radius: 10px;
    transition: width 0.5s ease;
}
```

### **3.2 Advanced Analytics Preparation**

#### **Analytics Aggregation Queries:**
```php
<?php
// services/RatingAnalyticsService.php
class RatingAnalyticsService {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function getDriverPerformanceInsights($driverId, $dateRange = 30) {
        $stmt = $this->pdo->prepare("
            SELECT 
                COUNT(*) as total_ratings,
                AVG(overall_rating) as overall_avg,
                AVG(safety_rating) as safety_avg,
                AVG(cleanliness_rating) as cleanliness_avg,
                AVG(professionalism_rating) as professionalism_avg,
                AVG(navigation_rating) as navigation_avg,
                COUNT(CASE WHEN overall_rating >= 4 THEN 1 END) as positive_ratings,
                COUNT(CASE WHEN overall_rating <= 2 THEN 1 END) as negative_ratings,
                DATE(created_at) as rating_date
            FROM reviews 
            WHERE driver_id = ? 
            AND created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
            GROUP BY DATE(created_at)
            ORDER BY rating_date DESC
        ");
        $stmt->execute([$driverId, $dateRange]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getCommonFeedbackThemes($driverId, $limit = 10) {
        // Get most common positive tags
        $stmt = $this->pdo->prepare("
            SELECT ft.display_name, ft.icon, COUNT(rt.id) as usage_count
            FROM feedback_tags ft
            JOIN review_tags rt ON ft.id = rt.tag_id
            JOIN reviews r ON rt.review_id = r.id
            WHERE r.driver_id = ? AND r.overall_rating >= 4
            GROUP BY ft.id
            ORDER BY usage_count DESC
            LIMIT ?
        ");
        $stmt->execute([$driverId, $limit]);
        $positiveTags = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Get most common negative themes from text reviews
        $stmt = $this->pdo->prepare("
            SELECT review, created_at
            FROM reviews 
            WHERE driver_id = ? AND overall_rating <= 2 AND review IS NOT NULL
            ORDER BY created_at DESC
            LIMIT 20
        ");
        $stmt->execute([$driverId]);
        $negativeReviews = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        return [
            'positive_tags' => $positiveTags,
            'negative_reviews' => $negativeReviews,
            'common_themes' => $this->extractThemes($negativeReviews)
        ];
    }
    
    public function getSystemRatingMetrics() {
        $stmt = $this->pdo->prepare("
            SELECT 
                COUNT(DISTINCT r.id) as total_ratings,
                AVG(r.overall_rating) as system_average,
                COUNT(DISTINCT CASE WHEN r.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) THEN r.id END) as ratings_this_week,
                COUNT(DISTINCT CASE WHEN r.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN r.id END) as ratings_this_month,
                (SELECT COUNT(*) FROM bookings WHERE status = 'completed' AND rating_requested = 1) as total_completed_rides,
                (SELECT COUNT(*) FROM bookings WHERE status = 'completed' AND rating_submitted = 1) as total_rated_rides
            FROM reviews r
            WHERE r.created_at >= DATE_SUB(NOW(), INTERVAL 90 DAY)
        ");
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    public function getRatingDistribution() {
        $stmt = $this->pdo->prepare("
            SELECT 
                overall_rating,
                COUNT(*) as count,
                ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM reviews), 2) as percentage
            FROM reviews 
            WHERE overall_rating IS NOT NULL
            GROUP BY overall_rating 
            ORDER BY overall_rating
        ");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    private function extractThemes($reviews) {
        // Simple keyword-based theme extraction
        $themes = [];
        $keywords = [
            'late' => 'Punctuality Issues',
            'rude' => 'Customer Service',
            'dirty' => 'Cleanliness',
            'lost' => 'Navigation Issues',
            'fast' => 'Driving Speed',
            'slow' => 'Driving Speed',
            'phone' => 'Distraction',
            'music' => 'Music Preference'
        ];
        
        foreach ($reviews as $review) {
            $text = strtolower($review['review']);
            foreach ($keywords as $keyword => $theme) {
                if (strpos($text, $keyword) !== false) {
                    if (!isset($themes[$theme])) {
                        $themes[$theme] = 0;
                    }
                    $themes[$theme]++;
                }
            }
        }
        
        arsort($themes);
        return $themes;
    }
}
?>
```

#### **Analytics API Endpoints:**
```php
<?php
// api/driver_analytics.php
header('Content-Type: application/json');
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../services/RatingAnalyticsService.php';

$currentUser = getCurrentUser();
if (!$currentUser || $currentUser['user_type'] !== 'driver') {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

$driverId = $currentUser['id'];
$analyticsService = new RatingAnalyticsService(getConnection());

$action = $_GET['action'] ?? 'performance';

switch ($action) {
    case 'performance':
        $data = $analyticsService->getDriverPerformanceInsights($driverId);
        break;
    case 'themes':
        $data = $analyticsService->getCommonFeedbackThemes($driverId);
        break;
    case 'trends':
        $data = $analyticsService->getRatingTrends($driverId);
        break;
    default:
        $data = ['error' => 'Invalid action'];
}

echo json_encode(['success' => true, 'data' => $data]);
?>
```

### **3.3 Quality Control Implementation**

#### **Automated Moderation System:**
```php
<?php
// services/ContentModerationService.php
class ContentModerationService {
    private $pdo;
    
    // Inappropriate language patterns
    private $bannedWords = [
        'profanity1', 'profanity2', 'slur1', 'slur2'
        // Add actual inappropriate words here
    ];
    
    private $suspiciousPatterns = [
        '/(.)\1{4,}/', // Repeated characters (aaaaa)
        '/\b\d{10,}\b/', // Phone numbers
        '/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/' // Email addresses
    ];
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function moderateReview($reviewText, $reviewId) {
        $issues = [];
        
        // Check for inappropriate language
        $profanityIssues = $this->checkProfanity($reviewText);
        if (!empty($profanityIssues)) {
            $issues['profanity'] = $profanityIssues;
        }
        
        // Check for suspicious patterns
        $patternIssues = $this->checkSuspiciousPatterns($reviewText);
        if (!empty($patternIssues)) {
            $issues['patterns'] = $patternIssues;
        }
        
        // Check review quality
        $qualityIssues = $this->checkReviewQuality($reviewText);
        if (!empty($qualityIssues)) {
            $issues['quality'] = $qualityIssues;
        }
        
        // Log moderation results
        $this->logModerationResult($reviewId, $issues);
        
        // Take action based on severity
        if (!empty($issues)) {
            return $this->handleModerationIssues($reviewId, $issues);
        }
        
        return ['approved' => true];
    }
    
    private function checkProfanity($text) {
        $found = [];
        $lowerText = strtolower($text);
        
        foreach ($this->bannedWords as $word) {
            if (strpos($lowerText, $word) !== false) {
                $found[] = $word;
            }
        }
        
        return $found;
    }
    
    private function checkSuspiciousPatterns($text) {
        $found = [];
        
        foreach ($this->suspiciousPatterns as $pattern) {
            if (preg_match($pattern, $text)) {
                $found[] = $pattern;
            }
        }
        
        return $found;
    }
    
    private function checkReviewQuality($text) {
        $issues = [];
        
        // Check for extremely short reviews
        if (strlen(trim($text)) < 10) {
            $issues[] = 'too_short';
        }
        
        // Check for spam-like content
        if (preg_match('/(.)\1{10,}/', $text)) {
            $issues[] = 'repetitive';
        }
        
        return $issues;
    }
    
    private function handleModerationIssues($reviewId, $issues) {
        $severity = $this->calculateSeverity($issues);
        
        switch ($severity) {
            case 'high':
                // Auto-hide review and flag for admin review
                $this->flagReview($reviewId, 'auto_hidden', $issues);
                return ['approved' => false, 'action' => 'hidden', 'reason' => 'Auto-moderated'];
                
            case 'medium':
                // Flag for review but keep visible
                $this->flagReview($reviewId, 'flagged', $issues);
                return ['approved' => true, 'action' => 'flagged', 'reason' => 'Under review'];
                
            case 'low':
                // Just log for monitoring
                $this->flagReview($reviewId, 'logged', $issues);
                return ['approved' => true, 'action' => 'logged', 'reason' => 'Minor issues detected'];
                
            default:
                return ['approved' => true];
        }
    }
    
    private function calculateSeverity($issues) {
        if (isset($issues['profanity']) && count($issues['profanity']) > 2) {
            return 'high';
        }
        
        if (isset($issues['patterns']) && count($issues['patterns']) > 1) {
            return 'medium';
        }
        
        if (isset($issues['quality'])) {
            return 'low';
        }
        
        return 'low';
    }
    
    private function flagReview($reviewId, $status, $issues) {
        $stmt = $this->pdo->prepare("
            INSERT INTO review_moderation (review_id, status, issues, created_at)
            VALUES (?, ?, ?, NOW())
        ");
        $stmt->execute([$reviewId, $status, json_encode($issues)]);
    }
}
?>
```

#### **Suspicious Rating Detection:**
```php
<?php
// services/RatingFraudDetectionService.php
class RatingFraudDetectionService {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function validateRatingSubmission($passengerId, $driverId, $bookingId) {
        $checks = [];
        
        // Check rating frequency
        $frequencyCheck = $this->checkRatingFrequency($passengerId);
        if ($frequencyCheck['suspicious']) {
            $checks['frequency'] = $frequencyCheck;
        }
        
        // Check for unusual patterns
        $patternCheck = $this->checkUnusualPatterns($passengerId, $driverId);
        if ($patternCheck['suspicious']) {
            $checks['patterns'] = $patternCheck;
        }
        
        // Check booking validity
        $validityCheck = $this->checkBookingValidity($passengerId, $driverId, $bookingId);
        if ($validityCheck['suspicious']) {
            $checks['validity'] = $validityCheck;
        }
        
        // Log validation results
        $this->logValidationResult($passengerId, $driverId, $bookingId, $checks);
        
        return [
            'allowed' => empty($checks) || $this->shouldAllowRating($checks),
            'checks' => $checks,
            'requires_review' => !empty($checks)
        ];
    }
    
    private function checkRatingFrequency($passengerId) {
        // Check ratings in last hour
        $stmt = $this->pdo->prepare("
            SELECT COUNT(*) as count
            FROM reviews 
            WHERE passenger_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
        ");
        $stmt->execute([$passengerId]);
        $hourlyCount = $stmt->fetchColumn();
        
        // Check ratings in last 24 hours
        $stmt = $this->pdo->prepare("
            SELECT COUNT(*) as count
            FROM reviews 
            WHERE passenger_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
        ");
        $stmt->execute([$passengerId]);
        $dailyCount = $stmt->fetchColumn();
        
        $suspicious = false;
        $reasons = [];
        
        if ($hourlyCount > 5) {
            $suspicious = true;
            $reasons[] = 'Too many ratings in 1 hour';
        }
        
        if ($dailyCount > 20) {
            $suspicious = true;
            $reasons[] = 'Too many ratings in 24 hours';
        }
        
        return [
            'suspicious' => $suspicious,
            'hourly_count' => $hourlyCount,
            'daily_count' => $dailyCount,
            'reasons' => $reasons
        ];
    }
    
    private function checkUnusualPatterns($passengerId, $driverId) {
        // Check if passenger always rates same driver
        $stmt = $this->pdo->prepare("
            SELECT COUNT(*) as total, 
                   COUNT(CASE WHEN driver_id = ? THEN 1 END) as same_driver_count
            FROM reviews 
            WHERE passenger_id = ?
        ");
        $stmt->execute([$driverId, $passengerId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $sameDriverRatio = $result['total'] > 0 ? $result['same_driver_count'] / $result['total'] : 0;
        
        // Check for rating manipulation (always 5 stars or always 1 star)
        $stmt = $this->pdo->prepare("
            SELECT overall_rating, COUNT(*) as count
            FROM reviews 
            WHERE passenger_id = ?
            GROUP BY overall_rating
            ORDER BY count DESC
            LIMIT 1
        ");
        $stmt->execute([$passengerId]);
        $mostCommon = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $suspicious = false;
        $reasons = [];
        
        if ($sameDriverRatio > 0.8 && $result['total'] > 3) {
            $suspicious = true;
            $reasons[] = 'Rates same driver predominantly';
        }
        
        if ($mostCommon && $mostCommon['count'] >= 5 && in_array($mostCommon['overall_rating'], [1, 5])) {
            $suspicious = true;
            $reasons[] = 'Suspicious rating pattern detected';
        }
        
        return [
            'suspicious' => $suspicious,
            'same_driver_ratio' => $sameDriverRatio,
            'most_common_rating' => $mostCommon['overall_rating'] ?? null,
            'reasons' => $reasons
        ];
    }
    
    private function checkBookingValidity($passengerId, $driverId, $bookingId) {
        $stmt = $this->pdo->prepare("
            SELECT * FROM bookings 
            WHERE id = ? AND passenger_id = ? AND driver_id = ?
        ");
        $stmt->execute([$bookingId, $passengerId, $driverId]);
        $booking = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $suspicious = false;
        $reasons = [];
        
        if (!$booking) {
            $suspicious = true;
            $reasons[] = 'Invalid booking relationship';
        } elseif ($booking['status'] !== 'completed') {
            $suspicious = true;
            $reasons[] = 'Booking not completed';
        } elseif (strtotime($booking['dropoff_time']) > strtotime('-1 hour')) {
            $suspicious = true;
            $reasons[] = 'Rating submitted too quickly after completion';
        }
        
        return [
            'suspicious' => $suspicious,
            'booking_status' => $booking['status'] ?? 'not_found',
            'completion_time' => $booking['dropoff_time'] ?? null,
            'reasons' => $reasons
        ];
    }
    
    private function shouldAllowRating($checks) {
        // Allow rating but flag for review if low-level suspicion
        $highSeverityChecks = ['frequency', 'validity'];
        
        foreach ($checks as $type => $check) {
            if (in_array($type, $highSeverityChecks)) {
                return false; // Block rating
            }
        }
        
        return true; // Allow but flag
    }
    
    private function logValidationResult($passengerId, $driverId, $bookingId, $checks) {
        $stmt = $this->pdo->prepare("
            INSERT INTO rating_validation_log 
            (passenger_id, driver_id, booking_id, validation_results, created_at)
            VALUES (?, ?, ?, ?, NOW())
        ");
        $stmt->execute([$passengerId, $driverId, $bookingId, json_encode($checks)]);
    }
}
?>
```

#### **Database Schema for Quality Control:**
```sql
CREATE TABLE review_moderation (
    id INT AUTO_INCREMENT PRIMARY KEY,
    review_id INT NOT NULL,
    status ENUM('approved', 'flagged', 'auto_hidden', 'logged') NOT NULL,
    issues JSON,
    reviewed_by INT NULL, -- Admin who reviewed
    reviewed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (review_id) REFERENCES reviews(id),
    FOREIGN KEY (reviewed_by) REFERENCES users(id)
);

CREATE TABLE rating_validation_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    passenger_id INT NOT NULL,
    driver_id INT NOT NULL,
    booking_id INT NOT NULL,
    validation_results JSON,
    action_taken ENUM('allowed', 'blocked', 'flagged') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (passenger_id) REFERENCES users(id),
    FOREIGN KEY (driver_id) REFERENCES users(id),
    FOREIGN KEY (booking_id) REFERENCES bookings(id)
);

CREATE TABLE rating_limits (
    user_id INT NOT NULL UNIQUE,
    hourly_limit INT DEFAULT 10,
    daily_limit INT DEFAULT 50,
    weekly_limit INT DEFAULT 200,
    current_hourly_count INT DEFAULT 0,
    current_daily_count INT DEFAULT 0,
    current_weekly_count INT DEFAULT 0,
    last_reset TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

This comprehensive implementation plan provides a structured approach to upgrading your passenger rating system while maintaining the existing architecture's integrity. Each phase builds upon the previous one, ensuring a smooth transition and minimal disruption to existing functionality.
