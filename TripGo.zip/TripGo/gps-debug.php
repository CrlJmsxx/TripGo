<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// GPS Debug Information
$debug_info = [
    'timestamp' => date('Y-m-d H:i:s'),
    'server_info' => [
        'php_version' => PHP_VERSION,
        'server_time' => date('Y-m-d H:i:s'),
        'timezone' => date_default_timezone_get()
    ],
    'browser_info' => [
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
        'accept_language' => $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? 'Unknown',
        'connection' => $_SERVER['HTTP_CONNECTION'] ?? 'Unknown'
    ],
    'location_tests' => [
        'ip_geolocation' => null,
        'time_based_location' => null,
        'cache_status' => null
    ],
    'recommendations' => []
];

// Test IP-based geolocation
try {
    $ip_response = file_get_contents('https://ipapi.co/json/');
    if ($ip_response) {
        $ip_data = json_decode($ip_response, true);
        $debug_info['location_tests']['ip_geolocation'] = [
            'success' => true,
            'latitude' => $ip_data['latitude'] ?? null,
            'longitude' => $ip_data['longitude'] ?? null,
            'city' => $ip_data['city'] ?? 'Unknown',
            'region' => $ip_data['region'] ?? 'Unknown',
            'country' => $ip_data['country_name'] ?? 'Unknown',
            'ip' => $ip_data['ip'] ?? 'Unknown'
        ];
    }
} catch (Exception $e) {
    $debug_info['location_tests']['ip_geolocation'] = [
        'success' => false,
        'error' => $e->getMessage()
    ];
}

// Check for common GPS issues
$debug_info['recommendations'] = [
    'browser_cache' => 'Clear browser cache and cookies, then restart browser',
    'location_permissions' => 'Ensure location permissions are granted in browser settings',
    'gps_hardware' => 'Check if device GPS is enabled and has clear sky view',
    'https_required' => 'GPS requires HTTPS connection - ensure you\'re using https://',
    'browser_settings' => 'Try different browser (Chrome, Firefox, Safari) to test',
    'mobile_vs_desktop' => 'GPS works better on mobile devices with built-in GPS',
    'wifi_location' => 'Enable WiFi for better location accuracy even on desktop',
    'movement' => 'Move around to trigger GPS refresh - GPS detects movement better'
];

// Add troubleshooting steps
$debug_info['troubleshooting_steps'] = [
    1 => 'Open browser developer tools (F12) and check Console for GPS errors',
    2 => 'Go to browser settings > Privacy > Location > ensure "Allow" is selected',
    3 => 'Clear browser cache and restart browser',
    4 => 'Try the location-test.html page with different test methods',
    5 => 'On mobile: enable High Accuracy mode in Location settings',
    6 => 'Move to an open area with clear view of the sky',
    7 => 'Wait 2-3 minutes for GPS to get initial fix',
    8 => 'Try refreshing the page after enabling location permissions'
];

echo json_encode($debug_info, JSON_PRETTY_PRINT);
?>
