# Dashboard Filtering & Map Integration - Diagnostic Report

**Date:** November 30, 2025  
**Status:** Failed Implementation - Multiple Critical Issues Identified  
**Severity:** High  

---

## I. DIAGNOSTIC INPUT: What Failed & How

### Implemented Functionality
- New AJAX endpoint: `api/get_all_requests_optimized.php` (with bounding box optimization)
- UI Button: "Filter All Requests" in driver dashboard
- JavaScript handler: `EnhancedRequestManagerFixed` class in `driver-dashboard-enhanced-fixed.js`
- Map integration with Leaflet

### Observed Failure Mode
**Error Message:**
```
Network error: Cannot read properties of null (reading 'updateRequestList'). Please try again.
```

This error occurs when the "Filter All Requests" button is clicked, blocking the feature entirely.

---

## II. ROOT CAUSE ANALYSIS

### Issue 1: Front-End JavaScript Null Reference Error
**Location:** `assets/js/driver-dashboard-enhanced-fixed.js` lines 170-171  
**Problem:**
```javascript
if (this.listManager && typeof this.listManager.updateRequestList === 'function') {
    promises.push(this.listManager.updateRequestList(data.requests));
}
```

The code checks if `this.listManager` exists but doesn't verify the `RequestListManagerFixed` class was instantiated correctly. If the class constructor fails silently, `this.listManager` remains null, causing the error.

**Root Cause:** The `RequestListManagerFixed` class (likely in another JS file) is not being instantiated properly, or its constructor throws an error that's caught but not logged.

**Evidence:** In `initializeComponents()` (lines 42-48), errors are logged but execution continues, potentially leaving `this.listManager` as null.

---

### Issue 2: Back-End Data Validation - Null Coordinates
**Location:** `api/get_all_requests_optimized.php` lines 35-36  
**Problem:**
```php
if (!$driverProfile || !$driverProfile['current_latitude'] || !$driverProfile['current_longitude']) {
    echo json_encode(['success' => false, 'error' => 'Driver location not available']);
    exit();
}
```

The validation uses loose comparison (`!$driverProfile['current_latitude']`), which treats `0.0` (valid latitude on Equator) as false, triggering false negatives.

Additionally, the driver_profiles table may have NULL values in current_latitude/current_longitude columns if:
1. Driver never updated location, OR
2. The columns don't exist yet in older databases

**Impact:** Legitimate requests fail with "Driver location not available" error.

---

### Issue 3: Back-End Performance - No Initial Filter
**Location:** `api/get_all_requests_optimized.php` lines 60-72  
**Problem:**
The Haversine distance formula is applied to ALL pending bookings, calculating trigonometric functions even for bookings far outside the search radius. This causes:
- High CPU usage (trigonometric math on thousands of rows)
- High memory usage (loading all coordinates into PHP memory)
- Slow query execution (for large datasets)

**Observation:** The optimized version DOES include a bounding box pre-filter (lines 41-49), which is good. However, the main issue is the query still processes many rows before Haversine filtering.

---

### Issue 4: Back-End Data Integrity - Invalid Coordinates
**Location:** `api/get_all_requests_optimized.php` lines 89-104  
**Problem:**
The response formatting validates coordinates but skips requests with any null coordinate. This can:
1. Silently drop valid requests from the response
2. Return incomplete data to the JavaScript without explanation

**Better approach:** Return all requests but include a `valid_location` flag, or log/report which requests were excluded.

---

### Issue 5: Front-End Error Handling - Missing Null Checks
**Location:** `driver-dashboard-enhanced-fixed.js` (RequestListManagerFixed class)  
**Problem:**
The `updateRequestList()` function likely assumes all requests have valid coordinates and passenger data, without defensive checks. Missing null/undefined checks on:
- `data.requests` array elements
- Coordinate fields (pickup_latitude, pickup_longitude, etc.)
- passenger_name, passenger_phone fields

If the API returns incomplete data or the JSON parser fails, the function crashes before updating the DOM.

---

## III. ACTIONABLE RECOMMENDATIONS

### Back-End Fixes (Performance & Data Validation)

#### Fix 3.1: Correct the Driver Location Null Check
**File:** `api/get_all_requests_optimized.php`  
**Line:** 35-36  
**Change:**
```php
// BEFORE (wrong - treats 0.0 as invalid)
if (!$driverProfile || !$driverProfile['current_latitude'] || !$driverProfile['current_longitude']) {

// AFTER (correct - explicit null check)
if (!$driverProfile || $driverProfile['current_latitude'] === null || $driverProfile['current_longitude'] === null) {
```

#### Fix 3.2: Add Database Index for Bounding Box Queries
**Rationale:** Bounding box pre-filter benefits from indexes on (status, pickup_latitude, pickup_longitude).

**SQL:**
```sql
ALTER TABLE bookings ADD INDEX idx_pending_location (status, pickup_latitude, pickup_longitude);
ALTER TABLE bookings ADD INDEX idx_expiry (expires_at);
```

#### Fix 3.3: Log Requests with Invalid Coordinates
**File:** `api/get_all_requests_optimized.php`  
**Line:** 95-110  
**Add before returning response:**
```php
// Log requests that were skipped due to invalid coordinates
$skippedCount = count($requests) - count($formattedRequests);
if ($skippedCount > 0) {
    error_log("Skipped $skippedCount requests with invalid coordinates in get_all_requests");
}

// Include diagnostic info in response
'performance' => [
    ...existing fields...,
    'skipped_invalid_coordinates' => $skippedCount
]
```

---

### Front-End Fixes (Reliability & Error Handling)

#### Fix 5.1: Add Defensive Null Checks to RequestListManagerFixed
**Problem Location:** The `updateRequestList()` method  
**Solution:** Add null/undefined guards for all data fields:

```javascript
updateRequestList(requests) {
    try {
        // Defensive null check
        if (!requests || !Array.isArray(requests)) {
            console.warn('updateRequestList: invalid requests array', requests);
            requests = [];
        }

        const container = document.getElementById('requestsListContainer');
        if (!container) {
            console.warn('requestsListContainer element not found');
            return Promise.resolve();
        }

        let html = '';
        
        // Validate each request before rendering
        requests.forEach(request => {
            // Skip requests with missing critical data
            if (!request || !request.id) {
                console.warn('Skipping request with missing id:', request);
                return;
            }

            // Provide fallback values for optional fields
            const passengerName = request.passenger_name || 'Unknown';
            const pickupAddress = request.pickup_address || 'Unknown location';
            const estimatedFare = parseFloat(request.estimated_fare) || 0;
            const distanceKm = parseFloat(request.distance_km) || 0;

            html += `
                <div class="request-item" data-request-id="${request.id}">
                    ...
                </div>
            `;
        });

        container.innerHTML = html || '<p>No requests found</p>';
        return Promise.resolve();
    } catch (error) {
        console.error('Error in updateRequestList:', error);
        return Promise.reject(error);
    }
}
```

#### Fix 5.2: Improve Error Handling in EnhancedRequestManagerFixed
**Problem Location:** `handleRequestData()` method  
**Solution:** Add better error logging and fallbacks:

```javascript
handleRequestData(data) {
    try {
        // Comprehensive validation
        if (!data || typeof data !== 'object') {
            console.error('Invalid data object:', data);
            throw new Error('Invalid response format');
        }

        if (!data.success) {
            this.showError(data.error || 'Failed to load requests');
            return;
        }

        // Ensure requests is array
        const requests = Array.isArray(data.requests) ? data.requests : [];
        this.currentRequests = requests;

        // Check components before calling them
        if (!this.listManager) {
            console.error('List manager not initialized');
            this.showError('Dashboard not fully loaded. Please refresh.');
            return;
        }

        if (!this.mapManager) {
            console.error('Map manager not initialized');
            this.showError('Map not fully loaded. Please refresh.');
            return;
        }

        // Call component methods with explicit error handling
        Promise.all([
            this.listManager.updateRequestList(requests)
                .catch(err => {
                    console.error('List update failed:', err);
                    return Promise.resolve(); // Continue even if one fails
                }),
            this.mapManager.updateMapMarkers(requests, data.driver_location)
                .catch(err => {
                    console.error('Map update failed:', err);
                    return Promise.resolve(); // Continue even if one fails
                })
        ])
        .then(() => this.updateFilterStatus(data))
        .catch(err => console.error('Unhandled error:', err));

    } catch (error) {
        console.error('Error in handleRequestData:', error);
        this.showError('Error processing response. Please try again.');
    }
}
```

---

## IV. DATABASE OPTIMIZATION

### Missing Indexes
**Problem:** Bounding box queries and distance calculations are slow on large datasets without proper indexes.

**Solution - Add These Indexes:**

```sql
-- For get_all_requests_optimized.php bounding box pre-filter
ALTER TABLE bookings ADD INDEX idx_status_location 
    (status, pickup_latitude, pickup_longitude);

-- For expiry check
ALTER TABLE bookings ADD INDEX idx_expires_at (expires_at);

-- For driver location lookup
ALTER TABLE driver_profiles ADD INDEX idx_user_location 
    (user_id, current_latitude, current_longitude);
```

### Verify Indexes
```sql
-- Check what indexes exist
SHOW INDEX FROM bookings;
SHOW INDEX FROM driver_profiles;

-- Explain query performance before/after indexing
EXPLAIN 
SELECT b.*, u.full_name 
FROM bookings b 
JOIN users u ON b.passenger_id = u.id 
WHERE b.status = 'pending' 
AND b.pickup_latitude BETWEEN ? AND ? 
AND b.pickup_longitude BETWEEN ? AND ?;
```

---

## V. SUMMARY OF FIXES TO IMPLEMENT

### Priority 1 (Critical - Blocks Feature)
- [ ] Fix null reference in `initializeComponents()` - ensure RequestListManagerFixed is properly instantiated
- [ ] Add null/undefined checks in `RequestListManagerFixed.updateRequestList()`
- [ ] Fix driver location validation logic (use strict null checks)

### Priority 2 (High - Performance/Reliability)
- [ ] Add database indexes for bounding box queries
- [ ] Improve error handling and logging throughout the feature
- [ ] Add defensive parsing for all JSON responses

### Priority 3 (Medium - Data Integrity)
- [ ] Log and report requests with invalid coordinates
- [ ] Ensure API returns meaningful error messages
- [ ] Add request validation on both client and server

---

## VI. TESTING CHECKLIST

After implementing fixes:
- [ ] Click "Filter All Requests" button - should load without JS errors
- [ ] Verify console shows no errors (F12 > Console tab)
- [ ] Check that nearby requests display in list and on map
- [ ] Test with 0 results - should show "No requests found" gracefully
- [ ] Test with 50+ results - should remain responsive
- [ ] Verify distance calculations are accurate
- [ ] Test with invalid/null coordinates in DB - should skip gracefully
- [ ] Monitor browser Network tab - API response should be valid JSON

---

End of Report
