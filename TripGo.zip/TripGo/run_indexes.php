<?php
// Simple script to run performance indexes
echo "<h2>Creating Performance Indexes</h2>";
echo "<p>This script will create the necessary database indexes for optimal performance.</p>";

// Database connection
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'tripgo_booking';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<p style='color: green;'>✓ Database connected successfully</p>";
    
    // Indexes to create
    $indexes = [
        // Most important index for coordinate filtering
        "CREATE INDEX idx_bookings_status_coords ON bookings(status, pickup_latitude, pickup_longitude)",
        
        // Supporting indexes
        "CREATE INDEX idx_bookings_coordinates ON bookings(pickup_latitude, pickup_longitude)",
        "CREATE INDEX idx_bookings_status_pending ON bookings(status)",
        "CREATE INDEX idx_bookings_expires ON bookings(expires_at)",
        "CREATE INDEX idx_bookings_pending_expires ON bookings(status, expires_at)",
        "CREATE INDEX idx_bookings_passenger ON bookings(passenger_id)",
        "CREATE INDEX idx_driver_profile_location ON driver_profiles(current_latitude, current_longitude)"
    ];
    
    foreach ($indexes as $index) {
        try {
            $pdo->exec($index);
            echo "<p style='color: green;'>✓ Created: " . substr($index, 13, 30) . "...</p>";
        } catch (Exception $e) {
            if (strpos($e->getMessage(), 'Duplicate key name') !== false) {
                echo "<p style='color: orange;'>⚠ Already exists: " . substr($index, 13, 30) . "...</p>";
            } else {
                echo "<p style='color: red;'>✗ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
            }
        }
    }
    
    echo "<br><h3>Index Creation Complete!</h3>";
    echo "<p style='color: blue;'>ℹ️ These indexes will dramatically improve query performance for the dashboard filtering feature.</p>";
    
    echo "<br><h3>Next Steps:</h3>";
    echo "<p>1. <a href='create_test_requests.php'>Create Test Requests</a></p>";
    echo "<p>2. <a href='driver/dashboard.php'>Test Dashboard Filter</a></p>";
    
} catch (PDOException $e) {
    echo "<p style='color: red;'>✗ Database connection failed: " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p>Please check your database credentials in the script.</p>";
}
?>
