# Driver Dashboard Enhancement: Advanced Filtering & Map Visualization

## Overview

Technical blueprint for enhancing the driver dashboard with advanced ride request filtering and spatial visualization capabilities. This implementation will allow drivers to search all active requests beyond the default 10km radius and visualize them on an interactive map.

## I. Advanced Filtering & Sorting (List View)

### **1. Filtering Interface Structure**

#### **HTML/CSS Components**
```html
<!-- Filter Section (add to dashboard.php) -->
<div class="filter-section" style="margin-bottom: 20px;">
    <div class="filter-controls">
        <button id="filterAllRequestsBtn" class="btn btn-primary">
            <i class="fas fa-search"></i> Filter All Requests
        </button>
        
        <div class="filter-options" style="display: inline-block; margin-left: 15px;">
            <label for="maxRadius" style="margin-right: 8px;">Max Radius (km):</label>
            <input type="number" id="maxRadius" min="1" max="100" value="50" 
                   style="width: 80px; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
            <button id="applyRadiusFilter" class="btn btn-secondary" style="margin-left: 8px;">
                <i class="fas fa-filter"></i> Apply
            </button>
        </div>
        
        <div class="filter-status" style="float: right;">
            <span id="filterStatus" style="color: #666; font-size: 14px;"></span>
        </div>
    </div>
</div>

<!-- Enhanced Request List Container -->
<div id="enhancedRequestList" class="request-list-container">
    <!-- Dynamic content will be inserted here -->
</div>
```

#### **CSS Styling**
```css
.filter-section {
    background: var(--bg-primary);
    padding: 20px;
    border-radius: 12px;
    border: 1px solid var(--border-color);
    margin-bottom: 20px;
}

.filter-controls {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 15px;
}

.filter-options {
    display: flex;
    align-items: center;
    gap: 10px;
}

.request-item-enhanced {
    background: white;
    border: 1px solid var(--border-color);
    border-radius: 8px;
    padding: 15px;
    margin-bottom: 12px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    transition: all 0.2s ease;
}

.request-item-enhanced:hover {
    box-shadow: var(--shadow-medium);
    transform: translateY(-2px);
}

.distance-badge {
    background: var(--primary-color);
    color: white;
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: bold;
}

.loading-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(255, 255, 255, 0.8);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1000;
}
```

### **2. Server Endpoint: api/get_all_requests.php**

#### **Complete Implementation**
```php
<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';

session_start();
$currentUser = getCurrentUser();

if (!$currentUser || $currentUser['user_type'] !== 'driver') {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

// Get driver's current location and max radius
$maxRadius = $_GET['max_radius'] ?? 50; // Default 50km
$maxRadius = min(max($maxRadius, 1), 100); // Clamp between 1-100km

// Get driver profile for current location
$pdo = getConnection();
$stmt = $pdo->prepare("SELECT current_latitude, current_longitude FROM driver_profiles WHERE user_id = ?");
$stmt->execute([$currentUser['id']]);
$driverProfile = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$driverProfile || !$driverProfile['current_latitude'] || !$driverProfile['current_longitude']) {
    echo json_encode(['success' => false, 'error' => 'Driver location not available']);
    exit();
}

$driverLat = $driverProfile['current_latitude'];
$driverLng = $driverProfile['current_longitude'];

try {
    // Haversine formula query to calculate distances
    $stmt = $pdo->prepare("
        SELECT 
            b.*,
            u.full_name as passenger_name,
            u.phone as passenger_phone,
            (6371 * acos(
                cos(radians(?)) * 
                cos(radians(b.pickup_latitude)) * 
                cos(radians(b.pickup_longitude) - radians(?)) + 
                sin(radians(?)) * 
                sin(radians(b.pickup_latitude))
            )) as distance_km
        FROM bookings b
        JOIN users u ON b.passenger_id = u.id
        WHERE b.status = 'pending'
        AND (b.expires_at IS NULL OR b.expires_at > NOW())
        AND b.pickup_latitude IS NOT NULL
        AND b.pickup_longitude IS NOT NULL
        HAVING distance_km <= ?
        ORDER BY distance_km ASC
        LIMIT 100
    ");
    
    $stmt->execute([$driverLat, $driverLng, $driverLat, $maxRadius]);
    $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format response data
    $formattedRequests = [];
    foreach ($requests as $request) {
        $formattedRequests[] = [
            'id' => $request['id'],
            'passenger_name' => $request['passenger_name'],
            'passenger_phone' => $request['passenger_phone'],
            'pickup_address' => $request['pickup_address'],
            'dropoff_address' => $request['dropoff_address'],
            'pickup_latitude' => (float) $request['pickup_latitude'],
            'pickup_longitude' => (float) $request['pickup_longitude'],
            'dropoff_latitude' => (float) $request['dropoff_latitude'],
            'dropoff_longitude' => (float) $request['dropoff_longitude'],
            'estimated_fare' => (float) $request['estimated_fare'],
            'distance_km' => round($request['distance_km'], 2),
            'booking_time' => $request['booking_time'],
            'expires_at' => $request['expires_at']
        ];
    }
    
    echo json_encode([
        'success' => true,
        'requests' => $formattedRequests,
        'total_found' => count($formattedRequests),
        'max_radius' => $maxRadius,
        'driver_location' => [
            'latitude' => (float) $driverLat,
            'longitude' => (float) $driverLng
        ]
    ]);
    
} catch (Exception $e) {
    error_log("Get all requests error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Server error']);
}
?>
```

### **3. Distance Calculation: Haversine Formula**

#### **Mathematical Implementation**
```sql
-- Haversine formula in SQL
(6371 * acos(
    cos(radians(driver_lat)) * 
    cos(radians(pickup_lat)) * 
    cos(radians(pickup_lng) - radians(driver_lng)) + 
    sin(radians(driver_lat)) * 
    sin(radians(pickup_lat))
)) as distance_km
```

#### **Parameters**
- **6371**: Earth's radius in kilometers
- **driver_lat/lng**: Driver's current coordinates
- **pickup_lat/lng**: Request pickup coordinates
- **Result**: Distance in kilometers with decimal precision

### **4. Sorting Logic**
- **Primary Sort**: Distance ascending (nearest to furthest)
- **Secondary Sort**: Booking time descending (newest first)
- **Limit**: Maximum 100 requests to prevent overload
- **Filter**: Only active, non-expired requests

## II. Map Integration & Visualization

### **1. Map Interaction Flow**

#### **JavaScript Event Handlers**
```javascript
class EnhancedRequestMap {
    constructor() {
        this.map = null;
        this.driverMarker = null;
        this.requestMarkers = [];
        this.currentRequests = [];
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.initializeMap();
    }
    
    setupEventListeners() {
        document.getElementById('filterAllRequestsBtn').addEventListener('click', () => {
            this.loadAllRequests();
        });
        
        document.getElementById('applyRadiusFilter').addEventListener('click', () => {
            const radius = document.getElementById('maxRadius').value;
            this.loadAllRequests(radius);
        });
    }
}
```

### **2. Marker Placement System**

#### **Dynamic Marker Creation**
```javascript
placeRequestMarkers(requests) {
    // Clear existing request markers
    this.clearRequestMarkers();
    
    requests.forEach(request => {
        const marker = L.marker([request.pickup_latitude, request.pickup_longitude], {
            icon: this.createRequestIcon(request.distance_km)
        });
        
        // Add popup with request details
        marker.bindPopup(this.createPopupContent(request));
        
        // Add click event for modal
        marker.on('click', () => this.showRequestModal(request));
        
        marker.addTo(this.map);
        this.requestMarkers.push(marker);
    });
}

createRequestIcon(distance) {
    const color = this.getDistanceColor(distance);
    return L.divIcon({
        className: 'custom-request-marker',
        html: `<div style="background: ${color}; width: 12px; height: 12px; border-radius: 50%; border: 2px solid white;"></div>`,
        iconSize: [16, 16],
        iconAnchor: [8, 8]
    });
}

getDistanceColor(distance) {
    if (distance < 5) return '#28a745'; // Green - very close
    if (distance < 15) return '#ffc107'; // Yellow - close
    if (distance < 30) return '#fd7e14'; // Orange - moderate
    return '#dc3545'; // Red - far
}
```

### **3. Interactive Modal System**

#### **Modal Structure**
```javascript
showRequestModal(request) {
    // Remove existing modal
    const existingModal = document.getElementById('requestModal');
    if (existingModal) {
        existingModal.remove();
    }
    
    // Create modal element
    const modal = document.createElement('div');
    modal.id = 'requestModal';
    modal.className = 'request-modal';
    modal.innerHTML = `
        <div class="request-modal-content">
            <div class="request-modal-header">
                <h4><i class="fas fa-map-marker-alt"></i> Ride Request #${request.id}</h4>
                <button class="close-modal">&times;</button>
            </div>
            <div class="request-modal-body">
                <div class="request-info">
                    <div class="info-row">
                        <strong>Passenger:</strong> ${request.passenger_name}
                    </div>
                    <div class="info-row">
                        <strong>Distance:</strong> <span class="distance-badge">${request.distance_km} km</span>
                    </div>
                    <div class="info-row">
                        <strong>Pickup:</strong> ${request.pickup_address}
                    </div>
                    <div class="info-row">
                        <strong>Destination:</strong> ${request.dropoff_address}
                    </div>
                    <div class="info-row">
                        <strong>Estimated Fare:</strong> ₱${request.estimated_fare.toFixed(2)}
                    </div>
                    <div class="info-row">
                        <strong>Posted:</strong> ${this.formatTime(request.booking_time)}
                    </div>
                </div>
                <div class="request-actions">
                    <button class="btn btn-primary accept-request" data-booking-id="${request.id}">
                        <i class="fas fa-check"></i> Accept Request
                    </button>
                    <button class="btn btn-secondary close-modal">
                        <i class="fas fa-times"></i> Close
                    </button>
                </div>
            </div>
        </div>
    `;
    
    // Position modal near marker
    const markerElement = document.querySelector(`[data-request-id="${request.id}"]`);
    if (markerElement) {
        const rect = markerElement.getBoundingClientRect();
        modal.style.position = 'fixed';
        modal.style.left = `${rect.left + 20}px`;
        modal.style.top = `${rect.top - 100}px`;
        modal.style.zIndex = '1000';
    }
    
    document.body.appendChild(modal);
    
    // Add event listeners
    modal.querySelector('.accept-request').addEventListener('click', () => {
        this.acceptRequest(request.id);
    });
    
    modal.querySelectorAll('.close-modal').forEach(btn => {
        btn.addEventListener('click', () => modal.remove());
    });
}
```

#### **Modal Styling**
```css
.request-modal {
    background: white;
    border-radius: 8px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.15);
    border: 1px solid #ddd;
    max-width: 350px;
    z-index: 1000;
}

.request-modal-content {
    padding: 0;
}

.request-modal-header {
    background: var(--primary-color);
    color: white;
    padding: 12px 16px;
    border-radius: 8px 8px 0 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.request-modal-header h4 {
    margin: 0;
    font-size: 16px;
}

.close-modal {
    background: none;
    border: none;
    color: white;
    font-size: 20px;
    cursor: pointer;
    padding: 0;
    width: 24px;
    height: 24px;
}

.request-modal-body {
    padding: 16px;
}

.info-row {
    margin-bottom: 8px;
    font-size: 14px;
    line-height: 1.4;
}

.request-actions {
    margin-top: 16px;
    display: flex;
    gap: 8px;
}
```

## III. Technical Structure & API Design

### **1. AJAX Call Architecture**

#### **Primary Request Function**
```javascript
async function loadAllRequests(maxRadius = 50) {
    const filterBtn = document.getElementById('filterAllRequestsBtn');
    const statusElement = document.getElementById('filterStatus');
    
    // Show loading state
    filterBtn.disabled = true;
    filterBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
    statusElement.textContent = 'Searching for requests...';
    
    try {
        const response = await fetch(`../api/get_all_requests.php?max_radius=${maxRadius}`);
        const data = await response.json();
        
        if (data.success) {
            this.updateRequestList(data.requests);
            this.updateMapMarkers(data.requests);
            statusElement.textContent = `Found ${data.total_found} requests within ${maxRadius}km`;
        } else {
            statusElement.textContent = 'Error: ' + data.error;
        }
    } catch (error) {
        console.error('Error loading requests:', error);
        statusElement.textContent = 'Network error. Please try again.';
    } finally {
        filterBtn.disabled = false;
        filterBtn.innerHTML = '<i class="fas fa-search"></i> Filter All Requests';
    }
}
```

### **2. JSON Response Structure**

#### **Complete API Response Format**
```json
{
    "success": true,
    "requests": [
        {
            "id": 123,
            "passenger_name": "John Doe",
            "passenger_phone": "+1234567890",
            "pickup_address": "123 Main St, City",
            "dropoff_address": "456 Oak Ave, City",
            "pickup_latitude": 14.5995,
            "pickup_longitude": 120.9842,
            "dropoff_latitude": 14.6095,
            "dropoff_longitude": 120.9942,
            "estimated_fare": 150.50,
            "distance_km": 12.34,
            "booking_time": "2025-11-29 15:30:00",
            "expires_at": "2025-11-29 16:00:00"
        }
    ],
    "total_found": 15,
    "max_radius": 50,
    "driver_location": {
        "latitude": 14.5995,
        "longitude": 120.9842
    }
}
```

### **3. Frontend State Management**

#### **Cohesive Update System**
```javascript
class DriverDashboardEnhanced {
    constructor() {
        this.currentRequests = [];
        this.filteredRequests = [];
        this.mapManager = new EnhancedRequestMap();
        this.listManager = new RequestListManager();
        this.init();
    }
    
    async loadAllRequests(maxRadius = 50) {
        // Show loading overlay
        this.showLoadingState();
        
        try {
            const data = await this.fetchRequests(maxRadius);
            
            if (data.success) {
                // Update both list and map simultaneously
                this.currentRequests = data.requests;
                this.filteredRequests = data.requests;
                
                // Parallel updates for better performance
                await Promise.all([
                    this.listManager.updateRequestList(data.requests),
                    this.mapManager.updateMapMarkers(data.requests, data.driver_location)
                ]);
                
                // Update UI status
                this.updateFilterStatus(data);
            }
        } catch (error) {
            this.handleError(error);
        } finally {
            this.hideLoadingState();
        }
    }
    
    updateFilterStatus(data) {
        const statusElement = document.getElementById('filterStatus');
        statusElement.innerHTML = `
            <span style="color: #28a745;">
                <i class="fas fa-check-circle"></i> 
                Found ${data.total_found} requests within ${data.max_radius}km
            </span>
        `;
    }
}
```

### **4. List View Updates**

#### **Dynamic HTML Generation**
```javascript
updateRequestList(requests) {
    const container = document.getElementById('enhancedRequestList');
    
    if (requests.length === 0) {
        container.innerHTML = `
            <div class="no-requests" style="text-align: center; padding: 40px; color: #666;">
                <i class="fas fa-search" style="font-size: 48px; margin-bottom: 16px;"></i>
                <p>No requests found within the specified radius.</p>
            </div>
        `;
        return;
    }
    
    const html = requests.map(request => `
        <div class="request-item-enhanced" data-request-id="${request.id}">
            <div class="request-details">
                <div class="request-header">
                    <strong>${request.passenger_name}</strong>
                    <span class="distance-badge">${request.distance_km} km</span>
                </div>
                <div class="request-route">
                    <div class="route-point">
                        <i class="fas fa-map-marker-alt pickup"></i>
                        ${request.pickup_address}
                    </div>
                    <div class="route-point">
                        <i class="fas fa-flag-checkered dropoff"></i>
                        ${request.dropoff_address}
                    </div>
                </div>
                <div class="request-meta">
                    <span><i class="fas fa-dollar-sign"></i> ₱${request.estimated_fare.toFixed(2)}</span>
                    <span><i class="fas fa-clock"></i> ${this.formatTime(request.booking_time)}</span>
                </div>
            </div>
            <div class="request-actions">
                <button class="btn btn-primary btn-sm accept-btn" data-booking-id="${request.id}">
                    <i class="fas fa-check"></i> Accept
                </button>
                <button class="btn btn-outline btn-sm view-btn" data-request-id="${request.id}">
                    <i class="fas fa-eye"></i> View
                </button>
            </div>
        </div>
    `).join('');
    
    container.innerHTML = html;
    
    // Add event listeners
    this.attachListEventListeners();
}
```

### **5. Performance Optimizations**

#### **Debouncing and Caching**
```javascript
class PerformanceManager {
    constructor() {
        this.requestCache = new Map();
        this.debounceTimers = {};
    }
    
    // Debounce rapid filter changes
    debouncedSearch(maxRadius, delay = 300) {
        clearTimeout(this.debounceTimers.search);
        this.debounceTimers.search = setTimeout(() => {
            this.performSearch(maxRadius);
        }, delay);
    }
    
    // Cache request results
    getCachedRequests(maxRadius) {
        const cacheKey = `requests_${maxRadius}`;
        const cached = this.requestCache.get(cacheKey);
        
        if (cached && (Date.now() - cached.timestamp) < 30000) { // 30 seconds cache
            return cached.data;
        }
        
        return null;
    }
    
    setCachedRequests(maxRadius, data) {
        const cacheKey = `requests_${maxRadius}`;
        this.requestCache.set(cacheKey, {
            data: data,
            timestamp: Date.now()
        });
    }
}
```

## Implementation Checklist

### **Backend Requirements**
- [ ] Create `api/get_all_requests.php` endpoint
- [ ] Implement Haversine distance calculation
- [ ] Add proper error handling and validation
- [ ] Optimize database queries with indexes

### **Frontend Requirements**
- [ ] Add filter controls to dashboard
- [ ] Implement AJAX request handling
- [ ] Create dynamic map marker system
- [ ] Build interactive modal components
- [ ] Add loading states and error handling

### **Integration Points**
- [ ] Update existing map initialization
- [ ] Integrate with current booking system
- [ ] Maintain existing functionality
- [ ] Ensure responsive design compatibility

### **Performance Considerations**
- [ ] Implement request debouncing
- [ ] Add result caching mechanism
- [ ] Optimize marker rendering
- [ ] Limit concurrent requests

This comprehensive plan provides a robust foundation for implementing advanced filtering and map visualization while maintaining smooth user experience and system performance.
