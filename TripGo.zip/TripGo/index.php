<?php
require_once 'config/database.php';
require_once 'config/session.php';

// Get current user if logged in
$currentUser = null;
if (isLoggedIn()) {
    $currentUser = getCurrentUser();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TripGO - Your Ride, Your Way</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="manifest" href="manifest.json">
    <meta name="theme-color" content="#667eea">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="apple-mobile-web-app-title" content="TripGO">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <a href="index.php" class="logo">
                    <i class="fas fa-car"></i> TripGO
                </a>
                
                <nav class="nav">
                    <a href="index.php">Home</a>
                    <a href="#about">About</a>
                    <a href="#features">Features</a>
                    <a href="#contact">Contact</a>
                </nav>
                
                <div class="user-menu">
                    <?php if ($currentUser): ?>
                        <div class="user-info">
                            <div class="user-avatar">
                                <?php echo strtoupper(substr($currentUser['full_name'], 0, 1)); ?>
                            </div>
                            <span><?php echo htmlspecialchars($currentUser['full_name']); ?></span>
                        </div>
                        
                        <?php if ($currentUser['user_type'] === 'admin'): ?>
                            <a href="admin/dashboard.php" class="btn btn-secondary">
                                <i class="fas fa-cog"></i> Admin
                            </a>
                        <?php elseif ($currentUser['user_type'] === 'driver'): ?>
                            <a href="driver/dashboard.php" class="btn btn-secondary">
                                <i class=""></i> Driver Dashboard
                            </a>
                        <?php else: ?>
                            <a href="passenger/dashboard.php" class="btn btn-primary">
                                <i class=""></i> Book Ride
                            </a>
                        <?php endif; ?>
                        
                        <a href="./auth/logout.php" class="btn btn-danger">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    <?php else: ?>
                        <a href="auth/login.php" class="btn btn-secondary">
                            <i class="fas fa-sign-in-alt"></i> Login
                        </a>
                        <a href="auth/register.php" class="btn btn-primary">
                            <i class="fas fa-user-plus"></i> Register
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <h1>Your Journey, Redefined</h1>
            <p>Experience sophisticated transportation with TripGO - where elegance meets efficiency in every ride</p>
            
            <?php if (!$currentUser): ?>
                <div class="hero-buttons">
                    <a href="auth/register.php" class="btn btn-primary btn-full">
                        <i class="fas fa-user-plus"></i> Begin Your Journey
                    </a>
                    <a href="auth/login.php" class="btn btn-secondary">
                        <i class="fas fa-sign-in-alt"></i> Welcome Back
                    </a>
                </div>
            <?php else: ?>
                <div class="hero-buttons">
                    <?php if ($currentUser['user_type'] === 'passenger'): ?>
                        <a href="passenger/dashboard.php" class="btn btn-primary btn-full">
                            <i class="fas fa-map-marker-alt"></i> Book Your Ride
                        </a>
                    <?php elseif ($currentUser['user_type'] === 'driver'): ?>
                        <a href="driver/dashboard.php" class="btn btn-primary btn-full">
                            <i class="fas fa-car"></i> Driver Dashboard
                        </a>
                    <?php else: ?>
                        <a href="admin/dashboard.php" class="btn btn-primary btn-full">
                            <i class="fas fa-cog"></i> Admin Panel
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="features">
        <div class="container">
            <div class="section-title">
                <h2>Why Choose TripGO?</h2>
                <p>Discover the perfect blend of sophistication, reliability, and innovation in urban transportation</p>
            </div>
            
            <div class="dashboard-grid">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-user" style="color: var(--accent-color); margin-right: 12px;"></i>
                            For Passengers
                        </h3>
                    </div>
                    <ul style="list-style: none; padding: 0;">
                        <li style="padding: 12px 0; border-bottom: 1px solid var(--border-color); color: var(--text-secondary);">
                            <i class="fas fa-check" style="color: var(--accent-color); margin-right: 12px;"></i>
                            Effortless booking with precise fare estimation
                        </li>
                        <li style="padding: 12px 0; border-bottom: 1px solid var(--border-color); color: var(--text-secondary);">
                            <i class="fas fa-check" style="color: var(--accent-color); margin-right: 12px;"></i>
                            Real-time ride tracking and updates
                        </li>
                        <li style="padding: 12px 0; border-bottom: 1px solid var(--border-color); color: var(--text-secondary);">
                            <i class="fas fa-check" style="color: var(--accent-color); margin-right: 12px;"></i>
                            Secure and flexible payment options
                        </li>
                        <li style="padding: 12px 0; color: var(--text-secondary);">
                            <i class="fas fa-check" style="color: var(--accent-color); margin-right: 12px;"></i>
                            Complete journey history and insights
                        </li>
                    </ul>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-car" style="color: var(--accent-color); margin-right: 12px;"></i>
                            For Drivers
                        </h3>
                    </div>
                    <ul style="list-style: none; padding: 0;">
                        <li style="padding: 12px 0; border-bottom: 1px solid var(--border-color); color: var(--text-secondary);">
                            <i class="fas fa-check" style="color: var(--accent-color); margin-right: 12px;"></i>
                            Flexible schedule and work-life balance
                        </li>
                        <li style="padding: 12px 0; border-bottom: 1px solid var(--border-color); color: var(--text-secondary);">
                            <i class="fas fa-check" style="color: var(--accent-color); margin-right: 12px;"></i>
                            Instant booking notifications and requests
                        </li>
                        <li style="padding: 12px 0; border-bottom: 1px solid var(--border-color); color: var(--text-secondary);">
                            <i class="fas fa-check" style="color: var(--accent-color); margin-right: 12px;"></i>
                            Comprehensive earnings analytics
                        </li>
                        <li style="padding: 12px 0; color: var(--text-secondary);">
                            <i class="fas fa-check" style="color: var(--accent-color); margin-right: 12px;"></i>
                            Professional rating and feedback system
                        </li>
                    </ul>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-shield-alt" style="color: var(--accent-color); margin-right: 12px;"></i>
                            Safety & Trust
                        </h3>
                    </div>
                    <ul style="list-style: none; padding: 0;">
                        <li style="padding: 12px 0; border-bottom: 1px solid var(--border-color); color: var(--text-secondary);">
                            <i class="fas fa-check" style="color: var(--accent-color); margin-right: 12px;"></i>
                            Thoroughly verified professional drivers
                        </li>
                        <li style="padding: 12px 0; border-bottom: 1px solid var(--border-color); color: var(--text-secondary);">
                            <i class="fas fa-check" style="color: var(--accent-color); margin-right: 12px;"></i>
                            Advanced real-time GPS tracking
                        </li>
                        <li style="padding: 12px 0; border-bottom: 1px solid var(--border-color); color: var(--text-secondary);">
                            <i class="fas fa-check" style="color: var(--accent-color); margin-right: 12px;"></i>
                           
                        </li>
                        <li style="padding: 12px 0; color: var(--text-secondary);">
                            <i class="fas fa-check" style="color: var(--accent-color); margin-right: 12px;"></i>
                            
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="features">
        <div class="container">
            <div class="section-title">
                <h2>How TripGo Works for Passenger</h2>
                <p>Our platform simplifies ride booking for everyone involved</p>
            </div>
            <!-- Grid Wrapper for Card Containers -->
            <div class="card-containers-grid">
                <div class="card-container">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <h3>Set Your Location</h3>
                        <p>Enter your pickup and drop-off locations with our intuitive interface or map selection.</p>
                    </div>
                </div>
                
                <div class="card-container">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-car"></i>
                        </div>
                        <h3>Choose Your Ride</h3>
                        <p>Select from motorcycle, tricycle, or car options based on your needs and budget.</p>
                    </div>
                </div>
                
                <div class="card-container">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-user-check"></i>
                        </div>
                        <h3>Get Matched</h3>
                        <p>Our algorithm finds the nearest available driver and sends them your request.</p>
                    </div>
                </div>
                
                <div class="card-container">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-credit-card"></i>
                        </div>
                        <h3>Pay Your Way</h3>
                        <p>Pay with cash or card. Your fare is calculated based on distance and ride type.</p>
                    </div>
                </div>
                
                <div class="card-container">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-star"></i>
                        </div>
                        <h3>Rate Your Experience</h3>
                        <p>Share feedback about your ride to help maintain quality across our platform.</p>
                    </div>
                </div>
                
                <div class="card-container">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <h3>Track Performance</h3>
                        <p>Drivers and admins can monitor earnings, ride history, and system metrics.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Driver Section -->
    <section id="drivers" class="features" style="background: var(--bg-secondary);">
        <div class="container">
            <div class="section-title">
                <h2>How TripGo Works for Drivers</h2>
                <p>Join our driver community and start earning with flexible schedules and great support</p>
            </div>
            <!-- Grid Wrapper for Card Containers -->
            <div class="card-containers-grid">
                <div class="card-container">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-car"></i>
                        </div>
                        <h3>Register Your Vehicle</h3>
                        <p>Sign up as a driver, submit your vehicle details and license to get verified quickly.</p>
                    </div>
                </div>
                <div class="card-container">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-bell"></i>
                        </div>
                        <h3>Receive Ride Requests</h3>
                        <p>Get instant notifications for nearby ride requests and accept them with one tap.</p>
                    </div>
                </div>
                <div class="card-container">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-route"></i>
                        </div>
                        <h3>Navigate to Pickup</h3>
                        <p>Use our integrated GPS to find the fastest route to your passenger's location.</p>
                    </div>
                </div>
                <div class="card-container">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>
                        <h3>Earn & Get Paid</h3>
                        <p>Complete rides and receive payments instantly through multiple payment options.</p>
                    </div>
                </div>
                <div class="card-container">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-star"></i>
                        </div>
                        <h3>Build Your Rating</h3>
                        <p>Provide excellent service to earn 5-star ratings and increase your earnings potential.</p>
                    </div>
                </div>
                <div class="card-container">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <h3>Track Your Earnings</h3>
                        <p>Monitor your daily earnings, ride history, and performance metrics in real-time.</p>
                    </div>
                </div>
            </div>
            
            <!-- Driver Benefits -->
            <div style="margin-top: 60px; text-align: center;">
                <h3 style="font-size: 2rem; margin-bottom: 30px; color: var(--text-primary);">Why Drive With TripGo?</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 30px; margin-top: 40px;">
                    <div style="text-align: center; padding: 30px; background: var(--bg-primary); border-radius: 16px; border: 1px solid var(--border-light);">
                        <div style="font-size: 3rem; color: var(--primary-color); margin-bottom: 20px;">
                            <i class="fas fa-clock"></i>
                        </div>
                        <h4 style="font-size: 1.3rem; margin-bottom: 15px; color: var(--text-primary);">Flexible Hours</h4>
                        <p style="color: var(--text-secondary); line-height: 1.6;">Work when you want, where you want. Be your own boss with complete schedule flexibility.</p>
                    </div>
                    <div style="text-align: center; padding: 30px; background: var(--bg-primary); border-radius: 16px; border: 1px solid var(--border-light);">
                        <div style="font-size: 3rem; color: var(--success-color); margin-bottom: 20px;">
                            <i class="fas fa-dollar-sign"></i>
                        </div>
                        <h4 style="font-size: 1.3rem; margin-bottom: 15px; color: var(--text-primary);">Competitive Earnings</h4>
                        <p style="color: var(--text-secondary); line-height: 1.6;">Earn more with our competitive rates, bonuses, and incentive programs.</p>
                    </div>
                    <div style="text-align: center; padding: 30px; background: var(--bg-primary); border-radius: 16px; border: 1px solid var(--border-light);">
                        <div style="font-size: 3rem; color: var(--creative-accent); margin-bottom: 20px;">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <h4 style="font-size: 1.3rem; margin-bottom: 15px; color: var(--text-primary);">Safety First</h4>
                        <p style="color: var(--text-secondary); line-height: 1.6;">24/7 support, insurance coverage, and advanced safety features to protect you.</p>
                    </div>
                    <div style="text-align: center; padding: 30px; background: var(--bg-primary); border-radius: 16px; border: 1px solid var(--border-light);">
                        <div style="font-size: 3rem; color: var(--accent-color); margin-bottom: 20px;">
                            <i class="fas fa-users"></i>
                        </div>
                        <h4 style="font-size: 1.3rem; margin-bottom: 15px; color: var(--text-primary);">Support Community</h4>
                        <p style="color: var(--text-secondary); line-height: 1.6;">Join thousands of drivers and get access to training, resources, and community support.</p>
                    </div>
                </div>
                
                <!-- Driver CTA -->
                <div style="margin-top: 50px; padding: 40px; background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); border-radius: 20px; color: white;">
                    <h3 style="font-size: 2rem; margin-bottom: 20px;">Ready to Start Earning?</h3>
                    <p style="font-size: 1.2rem; margin-bottom: 30px; opacity: 0.95;">Join thousands of drivers already earning with TripGo. Sign up today and start your journey!</p>
                    <div style="display: flex; gap: 20px; justify-content: center; flex-wrap: wrap;">
                        <a href="auth/register.php" class="btn btn-secondary" style="background: var(--white); color: var(--primary-color); border: none;">
                            <i class="fas fa-user-plus"></i> Register as Driver
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact">
        <div class="container">
            <div>
                <h2>Connect With Us</h2>
                <p>We're here to provide exceptional service and support for your transportation needs</p>
                <div class="contact-info">
                    <div class="contact-item">
                        <i class="fas fa-envelope"></i>
                        <h4>Email Support</h4>
                        <p>tripgo25@gmail.com</p>
                    </div>
                    <div class="contact-item">
                        <i class="fas fa-phone"></i>
                        <h4>Phone Support</h4>
                        <p>+63 9956149536</p>
                    </div>
                    <div class="contact-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <h4>Visit Us</h4>
                        <p>CTU Agujo, Daanbantayan, Cebu 3016</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2025 TripGO. All rights reserved. | Crafted with <a href="#">elegance</a> for sophisticated transportation</p>
        </div>
    </footer>

    <!-- PWA Install Prompt -->
    <div id="pwa-install" class="pwa-install">
        <div class="pwa-install-content">
            <div class="pwa-install-text">
                <h4>Install TripGO</h4>
                <p>Get the full app experience on your device</p>
            </div>
            <button class="pwa-install-close" onclick="hidePWAInstall()">×</button>
        </div>
    </div>

    <!-- Mobile Navigation -->
    <nav class="mobile-nav">
        <a href="index.php" class="mobile-nav-item">
            <i class="fas fa-home"></i>
            <span>Home</span>
        </a>
        <a href="passenger/dashboard.php" class="mobile-nav-item">
            <i class="fas fa-map-marker-alt"></i>
            <span>Book</span>
        </a>
        <a href="driver/dashboard.php" class="mobile-nav-item">
            <i class="fas fa-car"></i>
            <span>Drive</span>
        </a>
        <a href="auth/login.php" class="mobile-nav-item">
            <i class="fas fa-user"></i>
            <span>Account</span>
        </a>
    </nav>

    <script src="assets/js/gps-tracking.js"></script>
    <script src="assets/js/payment-gateway.js"></script>
    <script src="assets/js/push-notifications.js"></script>
    <script src="assets/js/multi-language.js"></script>
    
    <script>
        // Register Service Worker
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('/sw.js')
                    .then(registration => {
                        console.log('SW registered: ', registration);
                    })
                    .catch(registrationError => {
                        console.log('SW registration failed: ', registrationError);
                    });
            });
        }

        // PWA Install Prompt
        let deferredPrompt;
        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            deferredPrompt = e;
            document.getElementById('pwa-install').classList.add('show');
        });

        function hidePWAInstall() {
            document.getElementById('pwa-install').classList.remove('show');
        }

        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });

        // Add animation on scroll
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);

        // Observe all cards
        document.querySelectorAll('.card').forEach(card => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(30px)';
            card.style.transition = 'all 0.6s ease-out';
            observer.observe(card);
        });

        // Mobile app-like features
        document.body.classList.add('mobile-optimized');
        
        // Touch gestures
        let startX, startY, endX, endY;
        document.addEventListener('touchstart', (e) => {
            startX = e.touches[0].clientX;
            startY = e.touches[0].clientY;
        });

        document.addEventListener('touchend', (e) => {
            endX = e.changedTouches[0].clientX;
            endY = e.changedTouches[0].clientY;
            handleSwipe();
        });

        function handleSwipe() {
            const deltaX = endX - startX;
            const deltaY = endY - startY;
            
            if (Math.abs(deltaX) > Math.abs(deltaY)) {
                if (deltaX > 50) {
                    // Swipe right
                    console.log('Swipe right detected');
                } else if (deltaX < -50) {
                    // Swipe left
                    console.log('Swipe left detected');
                }
            }
        }
    </script>
</body>
</html>
