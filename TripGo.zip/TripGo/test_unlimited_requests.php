<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Unlimited Driver Requests</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background: #f5f5f5;
        }
        
        .test-container {
            max-width: 1000px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .test-button {
            background: #007bff;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 6px;
            cursor: pointer;
            margin: 10px;
            font-size: 16px;
        }
        
        .test-button:hover {
            background: #0056b3;
        }
        
        .test-button.success {
            background: #28a745;
        }
        
        .test-button.warning {
            background: #ffc107;
            color: #000;
        }
        
        .test-button.danger {
            background: #dc3545;
        }
        
        .test-output {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            padding: 15px;
            margin: 15px 0;
            font-family: monospace;
            font-size: 12px;
            max-height: 400px;
            overflow-y: auto;
            white-space: pre-wrap;
        }
        
        .status-good { color: #28a745; font-weight: bold; }
        .status-error { color: #dc3545; font-weight: bold; }
        .status-warning { color: #ffc107; font-weight: bold; }
        .status-info { color: #007bff; font-weight: bold; }
        
        .comparison-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        
        .comparison-table th,
        .comparison-table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        
        .comparison-table th {
            background: #f8f9fa;
            font-weight: bold;
        }
        
        .comparison-table .limited {
            background: #fff5f5;
        }
        
        .comparison-table .unlimited {
            background: #f0fff4;
        }
        
        .request-demo {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 20px;
            margin: 15px 0;
        }
        
        .distance-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: bold;
            margin-left: 8px;
        }
        
        .distance-nearby { background: #d4edda; color: #155724; }
        .distance-medium { background: #fff3cd; color: #856404; }
        .distance-far { background: #f8d7da; color: #721c24; }
        .distance-very-far { background: #f5c6cb; color: #491217; }
    </style>
</head>
<body>
    <div class="test-container">
        <h1>🚗 Test Unlimited Driver Requests</h1>
        <p>This tool tests the unlimited range driver request system vs the old limited system.</p>
        
        <h3>Test Controls:</h3>
        <button class="test-button" onclick="testLimitedAPI()">Test Old Limited API</button>
        <button class="test-button success" onclick="testUnlimitedAPI()">Test New Unlimited API</button>
        <button class="test-button warning" onclick="createFarRequests()">Create Far Distance Requests</button>
        <button class="test-button" onclick="compareResults()">Compare Results</button>
        <button class="test-button danger" onclick="clearOutput()">Clear Output</button>
        
        <div class="test-output" id="testOutput">
            Test output will appear here...
        </div>
        
        <h3>📊 System Comparison:</h3>
        <table class="comparison-table">
            <thead>
                <tr>
                    <th>Feature</th>
                    <th class="limited">Old Limited System</th>
                    <th class="unlimited">New Unlimited System</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><strong>Request Range</strong></td>
                    <td class="limited">Only requests ≤ 50km</td>
                    <td class="unlimited">ALL requests regardless of distance</td>
                </tr>
                <tr>
                    <td><strong>Driver Choice</strong></td>
                    <td class="limited">System filters for driver</td>
                    <td class="unlimited">Driver sees all, decides themselves</td>
                </tr>
                <tr>
                    <td><strong>Distance Info</strong></td>
                    <td class="limited">Basic distance</td>
                    <td class="unlimited">Distance + color coding + categories</td>
                </tr>
                <tr>
                    <td><strong>Notifications</strong></td>
                    <td class="limited">Only nearby requests</td>
                    <td class="unlimited">All new requests with distance</td>
                </tr>
                <tr>
                    <td><strong>Filtering</strong></td>
                    <td class="limited">Fixed 50km limit</td>
                    <td class="unlimited">Optional distance filter (driver choice)</td>
                </tr>
            </tbody>
        </table>
        
        <h3>🎯 Expected Behavior:</h3>
        <div class="request-demo">
            <h4>Old System (Limited):</h4>
            <ul>
                <li>❌ Driver sees 0 requests if all are > 50km</li>
                <li>❌ No notifications for far requests</li>
                <li>❌ Driver misses potential rides</li>
                <li>❌ Limited earning opportunities</li>
            </ul>
        </div>
        
        <div class="request-demo">
            <h4>New System (Unlimited):</h4>
            <ul>
                <li>✅ Driver sees ALL requests regardless of distance</li>
                <li>✅ Clear distance information with color coding</li>
                <li>✅ Driver decides which rides to accept</li>
                <li>✅ Maximum earning opportunities</li>
            </ul>
        </div>
        
        <h3>📈 Distance Categories:</h3>
        <div class="request-demo">
            <span class="distance-badge distance-nearby">Nearby (≤ 20km)</span>
            <span class="distance-badge distance-medium">Medium (20-50km)</span>
            <span class="distance-badge distance-far">Far (50-100km)</span>
            <span class="distance-badge distance-very-far">Very Far (> 100km)</span>
        </div>
        
        <h3>🔗 Quick Links:</h3>
        <ul>
            <li><a href="driver/dashboard.php" target="_blank">Driver Dashboard (Unlimited)</a></li>
            <li><a href="debug_driver_requests.php" target="_blank">Debug Tool</a></li>
            <li><a href="fix_all_issues.php" target="_blank">Fix All Issues</a></li>
        </ul>
    </div>

    <script>
        let testOutput = document.getElementById('testOutput');
        let limitedResults = null;
        let unlimitedResults = null;
        
        function log(message, type = 'info') {
            const timestamp = new Date().toLocaleTimeString();
            const className = type;
            testOutput.innerHTML += `<span class="${className}">[${timestamp}] ${message}</span>\n`;
            testOutput.scrollTop = testOutput.scrollHeight;
        }
        
        function clearOutput() {
            testOutput.innerHTML = 'Output cleared...\n';
            limitedResults = null;
            unlimitedResults = null;
        }
        
        async function testLimitedAPI() {
            log('=== Testing Old Limited API ===', 'info');
            
            try {
                const response = await fetch('api/get_all_requests_optimized.php?max_radius=50');
                const data = await response.json();
                
                if (data.success) {
                    limitedResults = data;
                    log(`✅ Limited API: Found ${data.requests?.length || 0} requests within 50km`, 'status-good');
                    
                    if (data.requests && data.requests.length > 0) {
                        log('Sample requests:', 'info');
                        data.requests.slice(0, 3).forEach((req, i) => {
                            log(`  ${i+1}. ${req.passenger_name} - ${req.distance_km}km - ₱${req.estimated_fare}`, 'info');
                        });
                    }
                } else {
                    log(`❌ Limited API Error: ${data.error}`, 'status-error');
                }
            } catch (error) {
                log(`❌ Limited API Failed: ${error.message}`, 'status-error');
            }
        }
        
        async function testUnlimitedAPI() {
            log('=== Testing New Unlimited API ===', 'info');
            
            try {
                const response = await fetch('api/get_all_requests_unlimited.php');
                const data = await response.json();
                
                if (data.success) {
                    unlimitedResults = data;
                    log(`✅ Unlimited API: Found ${data.requests?.length || 0} total requests`, 'status-good');
                    
                    if (data.stats) {
                        log(`📊 Stats: Nearby=${data.stats.nearby_requests}, Medium=${data.stats.medium_requests}, Far=${data.stats.far_requests}, Very Far=${data.stats.very_far_requests}`, 'status-info');
                    }
                    
                    if (data.requests && data.requests.length > 0) {
                        log('Sample requests by distance:', 'info');
                        
                        const grouped = {
                            nearby: data.requests.filter(r => r.distance_km <= 20),
                            medium: data.requests.filter(r => r.distance_km > 20 && r.distance_km <= 50),
                            far: data.requests.filter(r => r.distance_km > 50 && r.distance_km <= 100),
                            very_far: data.requests.filter(r => r.distance_km > 100)
                        };
                        
                        Object.entries(grouped).forEach(([category, requests]) => {
                            if (requests.length > 0) {
                                log(`  ${category.toUpperCase()}: ${requests.length} requests`, 'status-info');
                                requests.slice(0, 2).forEach((req, i) => {
                                    log(`    ${i+1}. ${req.passenger_name} - ${req.distance_km}km - ₱${req.estimated_fare}`, 'info');
                                });
                            }
                        });
                    }
                } else {
                    log(`❌ Unlimited API Error: ${data.error}`, 'status-error');
                }
            } catch (error) {
                log(`❌ Unlimited API Failed: ${error.message}`, 'status-error');
            }
        }
        
        async function createFarRequests() {
            log('=== Creating Far Distance Requests ===', 'info');
            
            // Create requests at different distances
            const farLocations = [
                { pickup: 'Baguio City, Benguet', lat: 16.4023, lng: 120.5960, dropoff: 'Manila City Hall, Manila', dropoff_lat: 14.5995, dropoff_lng: 120.9842, fare: 2500 },
                { pickup: 'Subic Bay, Zambales', lat: 14.8775, lng: 120.2835, dropoff: 'Makati City Hall, Makati', dropoff_lat: 14.5547, dropoff_lng: 120.0244, fare: 1800 },
                { pickup: 'Tagaytay City, Cavite', lat: 14.1214, lng: 120.9464, dropoff: 'Quezon City Hall, Quezon City', dropoff_lat: 14.6760, dropoff_lng: 121.0437, fare: 1200 },
                { pickup: 'Batangas City, Batangas', lat: 13.2403, lng: 123.3456, dropoff: 'Pasay City Hall, Pasay', dropoff_lat: 14.5378, dropoff_lng: 121.0014, fare: 1500 },
                { pickup: 'Angeles City, Pampanga', lat: 15.1474, lng: 120.5884, dropoff: 'Mandaluyong City Hall, Mandaluyong', dropoff_lat: 14.5794, dropoff_lng: 121.0359, fare: 1000 }
            ];
            
            for (let i = 0; i < farLocations.length; i++) {
                const location = farLocations[i];
                
                try {
                    // Create a simple booking request
                    const formData = new FormData();
                    formData.append('create_test_booking', '1');
                    formData.append('pickup_address', location.pickup);
                    formData.append('pickup_latitude', location.lat);
                    formData.append('pickup_longitude', location.lng);
                    formData.append('dropoff_address', location.dropoff);
                    formData.append('dropoff_latitude', location.dropoff_lat);
                    formData.append('dropoff_longitude', location.dropoff_lng);
                    formData.append('estimated_fare', location.fare);
                    
                    const response = await fetch('create_test_booking.php', {
                        method: 'POST',
                        body: formData
                    });
                    
                    const text = await response.text();
                    log(`✅ Created far request: ${location.pickup} → ${location.dropoff} (₱${location.fare})`, 'status-good');
                    
                } catch (error) {
                    log(`❌ Failed to create far request: ${error.message}`, 'status-error');
                }
                
                // Small delay between requests
                await new Promise(resolve => setTimeout(resolve, 500));
            }
            
            log('🎯 Far distance requests created successfully!', 'status-good');
            log('Now test both APIs to see the difference!', 'status-warning');
        }
        
        function compareResults() {
            log('=== Comparing Results ===', 'info');
            
            if (!limitedResults || !unlimitedResults) {
                log('❌ Please test both APIs first to compare results', 'status-warning');
                return;
            }
            
            const limitedCount = limitedResults.requests?.length || 0;
            const unlimitedCount = unlimitedResults.requests?.length || 0;
            
            log(`📊 Comparison Results:`, 'status-info');
            log(`  Limited API: ${limitedCount} requests (≤ 50km)`, limitedCount > 0 ? 'status-good' : 'status-warning');
            log(`  Unlimited API: ${unlimitedCount} requests (all distances)`, 'status-good');
            log(`  Difference: ${unlimitedCount - limitedCount} additional requests`, unlimitedCount > limitedCount ? 'status-good' : 'status-info');
            
            if (unlimitedCount > limitedCount) {
                log(`🎉 SUCCESS: Unlimited system shows ${unlimitedCount - limitedCount} more requests!`, 'status-good');
                log('Drivers will now see far requests they can choose to accept.', 'status-info');
            } else {
                log('⚠️ No difference detected. Try creating far distance requests first.', 'status-warning');
            }
            
            // Show distance breakdown from unlimited results
            if (unlimitedResults.stats) {
                log(`📍 Distance breakdown:`, 'status-info');
                log(`  Nearby (≤ 20km): ${unlimitedResults.stats.nearby_requests}`, 'status-good');
                log(`  Medium (20-50km): ${unlimitedResults.stats.medium_requests}`, 'status-info');
                log(`  Far (50-100km): ${unlimitedResults.stats.far_requests}`, 'status-warning');
                log(`  Very Far (> 100km): ${unlimitedResults.stats.very_far_requests}`, 'status-error');
            }
        }
        
        // Initialize
        log('Unlimited driver request test tool ready', 'status-good');
        log('Test both APIs to see the difference in request visibility', 'info');
    </script>
</body>
</html>
