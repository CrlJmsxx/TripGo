<?php
require_once 'config/database.php';
require_once 'config/session.php';

header('Content-Type: text/html; charset=UTF-8');

// Check authentication
$currentUser = getCurrentUser();
if (!$currentUser) {
    die('<h1>Authentication Required</h1><p>Please <a href="auth/login.php">login</a> to access diagnostics.</p>');
}

$pdo = getConnection();
$issues = [];
$solutions = [];

// Check database connection
try {
    $pdo->query("SELECT 1");
    $issues[] = "✅ Database connection: OK";
} catch (Exception $e) {
    $issues[] = "❌ Database connection: FAILED";
    $solutions[] = "Check database credentials in config/database.php";
}

// Check required tables
$tables = ['users', 'bookings', 'driver_profiles', 'reviews'];
foreach ($tables as $table) {
    try {
        $result = $pdo->query("DESCRIBE $table");
        $issues[] = "✅ Table '$table': EXISTS";
    } catch (Exception $e) {
        $issues[] = "❌ Table '$table': MISSING";
        $solutions[] = "Run migration: <a href='migrate.php'>Click here</a>";
    }
}

// Check booking table columns
$requiredColumns = [
    'id', 'passenger_id', 'driver_id', 'pickup_address', 'dropoff_address',
    'pickup_latitude', 'pickup_longitude', 'dropoff_latitude', 'dropoff_longitude',
    'estimated_fare', 'actual_fare', 'distance_km', 'status', 'booking_time',
    'expires_at', 'cancellation_reason', 'cancelled_by', 'cancelled_at',
    'accepted_time', 'rating_requested', 'rating_submitted'
];

try {
    $result = $pdo->query("SHOW COLUMNS FROM bookings");
    $existingColumns = [];
    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        $existingColumns[] = $row['Field'];
    }
    
    foreach ($requiredColumns as $column) {
        if (in_array($column, $existingColumns)) {
            $issues[] = "✅ Column 'bookings.$column': EXISTS";
        } else {
            $issues[] = "❌ Column 'bookings.$column': MISSING";
            $solutions[] = "Run migration: <a href='migrate.php'>Click here</a>";
        }
    }
} catch (Exception $e) {
    $issues[] = "❌ Cannot check bookings table columns";
    $solutions[] = "Ensure bookings table exists";
}

// Check users table columns
$userColumns = ['id', 'username', 'email', 'password', 'full_name', 'phone', 'user_type', 'average_rating'];
try {
    $result = $pdo->query("SHOW COLUMNS FROM users");
    $existingUserColumns = [];
    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        $existingUserColumns[] = $row['Field'];
    }
    
    foreach ($userColumns as $column) {
        if (in_array($column, $existingUserColumns)) {
            $issues[] = "✅ Column 'users.$column': EXISTS";
        } else {
            $issues[] = "❌ Column 'users.$column': MISSING";
            $solutions[] = "Run migration: <a href='migrate.php'>Click here</a>";
        }
    }
} catch (Exception $e) {
    $issues[] = "❌ Cannot check users table columns";
    $solutions[] = "Ensure users table exists";
}

// Check file permissions
$files = [
    'config/database.php',
    'api/geocoding.php',
    'api/cancel_booking.php',
    'api/expiry_system.php',
    'passenger/booking.php',
    'driver/dashboard.php',
    'passenger/dashboard.php'
];

foreach ($files as $file) {
    if (file_exists($file)) {
        $issues[] = "✅ File '$file': EXISTS";
    } else {
        $issues[] = "❌ File '$file': MISSING";
        $solutions[] = "Ensure all required files are present";
    }
}

// Test booking creation
try {
    $testData = [
        'passenger_id' => $currentUser['id'],
        'pickup_address' => 'Test Pickup',
        'dropoff_address' => 'Test Dropoff',
        'pickup_latitude' => 10.0,
        'pickup_longitude' => 123.0,
        'dropoff_latitude' => 10.1,
        'dropoff_longitude' => 123.1,
        'estimated_fare' => 100.00,
        'distance_km' => 5.0
    ];
    
    // Try with expires_at
    try {
        $stmt = $pdo->prepare("INSERT INTO bookings (passenger_id, pickup_address, dropoff_address, pickup_latitude, pickup_longitude, dropoff_latitude, dropoff_longitude, estimated_fare, distance_km, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 60 SECOND))");
        $stmt->execute(array_values($testData));
        $bookingId = $pdo->lastInsertId();
        
        // Clean up test booking
        $pdo->prepare("DELETE FROM bookings WHERE id = ?")->execute([$bookingId]);
        
        $issues[] = "✅ Booking creation (with expiry): WORKS";
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'expires_at') !== false) {
            // Try without expires_at
            $stmt = $pdo->prepare("INSERT INTO bookings (passenger_id, pickup_address, dropoff_address, pickup_latitude, pickup_longitude, dropoff_latitude, dropoff_longitude, estimated_fare, distance_km) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute(array_values($testData));
            $bookingId = $pdo->lastInsertId();
            
            // Clean up test booking
            $pdo->prepare("DELETE FROM bookings WHERE id = ?")->execute([$bookingId]);
            
            $issues[] = "⚠️ Booking creation (without expiry): WORKS (expiry columns missing)";
            $solutions[] = "Run migration to add expiry columns: <a href='migrate.php'>Click here</a>";
        } else {
            $issues[] = "❌ Booking creation: FAILED";
            $solutions[] = "Error: " . $e->getMessage();
        }
    }
} catch (Exception $e) {
    $issues[] = "❌ Booking test: FAILED";
    $solutions[] = "Error: " . $e->getMessage();
}

// Check geocoding API
try {
    $url = "http://localhost/TripGO/api/geocoding.php";
    $data = ['action' => 'geocode', 'address' => 'Cebu City'];
    
    $options = [
        'http' => [
            'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
            'method' => 'POST',
            'content' => http_build_query($data)
        ]
    ];
    
    $context = stream_context_create($options);
    $response = file_get_contents($url, false, $context);
    
    if ($response && json_decode($response)->success ?? false) {
        $issues[] = "✅ Geocoding API: WORKING";
    } else {
        $issues[] = "❌ Geocoding API: FAILED";
        $solutions[] = "Check if geocoding.php exists and is accessible";
    }
} catch (Exception $e) {
    $issues[] = "❌ Geocoding API test: FAILED";
    $solutions[] = "Error: " . $e->getMessage();
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>TripGO System Diagnostics</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .status-ok { color: green; }
        .status-warning { color: orange; }
        .status-error { color: red; }
        .solution { background: #f0f8ff; padding: 10px; margin: 5px 0; border-left: 4px solid #007bff; }
        h1, h2 { color: #333; }
        .back-link { margin-top: 20px; }
    </style>
</head>
<body>
    <h1>🔍 TripGO System Diagnostics</h1>
    <p><strong>User:</strong> <?php echo htmlspecialchars($currentUser['username']); ?> (<?php echo htmlspecialchars($currentUser['user_type']); ?>)</p>
    <p><strong>Time:</strong> <?php echo date('Y-m-d H:i:s'); ?></p>
    
    <h2>📋 System Status</h2>
    <?php foreach ($issues as $issue): ?>
        <div class="<?php echo strpos($issue, '✅') !== false ? 'status-ok' : (strpos($issue, '⚠️') !== false ? 'status-warning' : 'status-error'); ?>">
            <?php echo $issue; ?>
        </div>
    <?php endforeach; ?>
    
    <?php if (!empty($solutions)): ?>
        <h2>🛠️ Recommended Solutions</h2>
        <?php foreach (array_unique($solutions) as $solution): ?>
            <div class="solution">
                <?php echo $solution; ?>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
    
    <div class="back-link">
        <a href="index.php">← Back to Homepage</a> | 
        <a href="migrate.php">Run Migration</a> |
        <a href="passenger/dashboard.php">Passenger Dashboard</a> |
        <a href="driver/dashboard.php">Driver Dashboard</a>
    </div>
</body>
</html>
