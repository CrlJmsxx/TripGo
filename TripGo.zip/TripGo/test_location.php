<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Location Test Tool</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background: #f5f5f5;
        }
        
        .test-container {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .test-button {
            background: #007bff;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 6px;
            cursor: pointer;
            margin: 10px;
            font-size: 16px;
        }
        
        .test-button:hover {
            background: #0056b3;
        }
        
        .test-button:disabled {
            background: #6c757d;
            cursor: not-allowed;
        }
        
        .location-info {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            padding: 15px;
            margin: 15px 0;
            font-family: monospace;
            font-size: 14px;
        }
        
        .success { color: #28a745; }
        .error { color: #dc3545; }
        .warning { color: #ffc107; }
        .info { color: #007bff; }
        
        #map {
            height: 400px;
            border-radius: 8px;
            margin: 15px 0;
        }
    </style>
</head>
<body>
    <div class="test-container">
        <h1>📍 Location Test Tool</h1>
        <p>This tool helps test and debug geolocation functionality.</p>
        
        <div class="location-info" id="browserInfo">
            Checking browser capabilities...
        </div>
        
        <h3>Location Tests:</h3>
        <button class="test-button" onclick="testBasicLocation()">Test Basic Location</button>
        <button class="test-button" onclick="testHighAccuracy()">Test High Accuracy</button>
        <button class="test-button" onclick="testWatchLocation()">Watch Location</button>
        <button class="test-button" onclick="testFallbackLocation()">Test Fallback Methods</button>
        <button class="test-button" onclick="useTestLocation()">Use Test Location</button>
        
        <div class="location-info" id="locationOutput">
            Location test results will appear here...
        </div>
        
        <div id="map"></div>
        
        <h3>Troubleshooting Tips:</h3>
        <ul>
            <li><strong>HTTPS Required:</strong> Geolocation requires HTTPS in most browsers</li>
            <li><strong>Permissions:</strong> Allow location access when prompted</li>
            <li><strong>Localhost Issues:</strong> Localhost often has geolocation problems</li>
            <li><strong>Browser Support:</strong> Use Chrome, Firefox, Safari, or Edge</li>
            <li><strong>GPS Required:</strong> Mobile devices work better than desktop</li>
        </ul>
    </div>

    <!-- Leaflet CSS and JS -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    
    <script>
        let map;
        let marker;
        let accuracyCircle;
        let watchId;
        
        // Initialize map
        function initMap() {
            map = L.map('map').setView([14.5995, 120.9842], 13);
            
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors',
                maxZoom: 18
            }).addTo(map);
        }
        
        function log(message, type = 'info') {
            const output = document.getElementById('locationOutput');
            const timestamp = new Date().toLocaleTimeString();
            const className = type;
            output.innerHTML += `<div class="${className}">[${timestamp}] ${message}</div>`;
            output.scrollTop = output.scrollHeight;
        }
        
        function checkBrowserInfo() {
            const info = document.getElementById('browserInfo');
            const checks = [];
            
            checks.push(`Geolocation Support: ${navigator.geolocation ? '✓ Yes' : '✗ No'}`);
            checks.push(`HTTPS: ${window.isSecureContext ? '✓ Yes' : '✗ No'}`);
            checks.push(`Hostname: ${window.location.hostname}`);
            checks.push(`User Agent: ${navigator.userAgent.substring(0, 50)}...`);
            checks.push(`Platform: ${navigator.platform}`);
            
            info.innerHTML = checks.join('<br>');
        }
        
        function showLocationOnMap(lat, lng, accuracy = null) {
            // Remove existing marker and circle
            if (marker) map.removeLayer(marker);
            if (accuracyCircle) map.removeLayer(accuracyCircle);
            
            // Add marker
            marker = L.marker([lat, lng]).addTo(map);
            marker.bindPopup(`Lat: ${lat.toFixed(6)}<br>Lng: ${lng.toFixed(6)}`).openPopup();
            
            // Add accuracy circle if available
            if (accuracy) {
                accuracyCircle = L.circle([lat, lng], {
                    radius: accuracy,
                    fillColor: '#007bff',
                    fillOpacity: 0.1,
                    color: '#007bff',
                    weight: 2
                }).addTo(map);
            }
            
            // Center map
            map.setView([lat, lng], 15);
        }
        
        function testBasicLocation() {
            log('=== Testing Basic Location ===', 'info');
            
            if (!navigator.geolocation) {
                log('Geolocation not supported', 'error');
                return;
            }
            
            log('Requesting basic location...', 'info');
            
            navigator.geolocation.getCurrentPosition(
                function(position) {
                    log(`✓ Location obtained!`, 'success');
                    log(`  Latitude: ${position.coords.latitude}`, 'info');
                    log(`  Longitude: ${position.coords.longitude}`, 'info');
                    log(`  Accuracy: ${position.coords.accuracy}m`, 'info');
                    log(`  Altitude: ${position.coords.altitude || 'N/A'}`, 'info');
                    log(`  Speed: ${position.coords.speed || 'N/A'}`, 'info');
                    log(`  Timestamp: ${new Date(position.timestamp).toLocaleString()}`, 'info');
                    
                    showLocationOnMap(position.coords.latitude, position.coords.longitude, position.coords.accuracy);
                },
                function(error) {
                    log(`✗ Location failed: ${error.message}`, 'error');
                    log(`  Error code: ${error.code}`, 'warning');
                    switch(error.code) {
                        case error.PERMISSION_DENIED:
                            log('  Permission denied - user blocked location access', 'warning');
                            break;
                        case error.POSITION_UNAVAILABLE:
                            log('  Position unavailable - GPS/network issue', 'warning');
                            break;
                        case error.TIMEOUT:
                            log('  Request timeout - took too long', 'warning');
                            break;
                    }
                },
                {
                    enableHighAccuracy: false,
                    timeout: 15000,
                    maximumAge: 300000 // 5 minutes cache
                }
            );
        }
        
        function testHighAccuracy() {
            log('=== Testing High Accuracy Location ===', 'info');
            
            if (!navigator.geolocation) {
                log('Geolocation not supported', 'error');
                return;
            }
            
            log('Requesting high accuracy location...', 'info');
            
            navigator.geolocation.getCurrentPosition(
                function(position) {
                    log(`✓ High accuracy location obtained!`, 'success');
                    log(`  Latitude: ${position.coords.latitude}`, 'info');
                    log(`  Longitude: ${position.coords.longitude}`, 'info');
                    log(`  Accuracy: ${position.coords.accuracy}m`, 'info');
                    
                    if (position.coords.accuracy < 50) {
                        log(`  ✓ Excellent accuracy (< 50m)`, 'success');
                    } else if (position.coords.accuracy < 100) {
                        log(`  ⚠ Good accuracy (< 100m)`, 'warning');
                    } else {
                        log(`  ✗ Poor accuracy (> 100m)`, 'error');
                    }
                    
                    showLocationOnMap(position.coords.latitude, position.coords.longitude, position.coords.accuracy);
                },
                function(error) {
                    log(`✗ High accuracy failed: ${error.message}`, 'error');
                    log('  This often happens on desktop/localhost', 'warning');
                },
                {
                    enableHighAccuracy: true,
                    timeout: 20000,
                    maximumAge: 0
                }
            );
        }
        
        function testWatchLocation() {
            log('=== Testing Location Watch ===', 'info');
            
            if (!navigator.geolocation) {
                log('Geolocation not supported', 'error');
                return;
            }
            
            if (watchId) {
                navigator.geolocation.clearWatch(watchId);
                watchId = null;
                log('✓ Stopped watching location', 'info');
                return;
            }
            
            log('Starting to watch location updates...', 'info');
            
            watchId = navigator.geolocation.watchPosition(
                function(position) {
                    log(`✓ Location update: ${position.coords.latitude.toFixed(6)}, ${position.coords.longitude.toFixed(6)} (${position.coords.accuracy}m)`, 'success');
                    showLocationOnMap(position.coords.latitude, position.coords.longitude, position.coords.accuracy);
                },
                function(error) {
                    log(`✗ Watch error: ${error.message}`, 'error');
                },
                {
                    enableHighAccuracy: true,
                    timeout: 10000,
                    maximumAge: 5000
                }
            );
        }
        
        function testFallbackLocation() {
            log('=== Testing Fallback Methods ===', 'info');
            
            // Test with different options
            const tests = [
                { name: 'Cached location (5min)', options: { enableHighAccuracy: false, timeout: 5000, maximumAge: 300000 } },
                { name: 'Low accuracy', options: { enableHighAccuracy: false, timeout: 10000, maximumAge: 60000 } },
                { name: 'Network only', options: { enableHighAccuracy: false, timeout: 5000, maximumAge: 0 } }
            ];
            
            tests.forEach((test, index) => {
                setTimeout(() => {
                    log(`Testing: ${test.name}`, 'info');
                    
                    navigator.geolocation.getCurrentPosition(
                        function(position) {
                            log(`✓ ${test.name} successful: ${position.coords.accuracy}m accuracy`, 'success');
                            if (index === 0) {
                                showLocationOnMap(position.coords.latitude, position.coords.longitude, position.coords.accuracy);
                            }
                        },
                        function(error) {
                            log(`✗ ${test.name} failed: ${error.message}`, 'error');
                        },
                        test.options
                    );
                }, index * 2000);
            });
        }
        
        function useTestLocation() {
            log('=== Using Test Location ===', 'info');
            
            // Test locations
            const testLocations = [
                { name: 'Manila', lat: 14.5995, lng: 120.9842 },
                { name: 'Quezon City', lat: 14.6760, lng: 121.0437 },
                { name: 'Makati', lat: 14.5547, lng: 121.0244 },
                { name: 'Bonifacio Global City', lat: 14.5425, lng: 121.0459 }
            ];
            
            const location = testLocations[Math.floor(Math.random() * testLocations.length)];
            
            log(`Using test location: ${location.name}`, 'info');
            log(`  Coordinates: ${location.lat}, ${location.lng}`, 'info');
            
            showLocationOnMap(location.lat, location.lng, 50);
        }
        
        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            initMap();
            checkBrowserInfo();
            log('Location test tool ready', 'success');
        });
    </script>
</body>
</html>
