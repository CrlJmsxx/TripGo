<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Debug Booking Modal</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background: #f5f5f5;
        }
        
        .debug-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .debug-button {
            background: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            margin: 5px;
            font-size: 14px;
        }
        
        .debug-button:hover {
            background: #0056b3;
        }
        
        .debug-output {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            padding: 15px;
            margin: 15px 0;
            font-family: monospace;
            font-size: 12px;
            max-height: 300px;
            overflow-y: auto;
            white-space: pre-wrap;
        }
        
        .status-good { color: #28a745; }
        .status-error { color: #dc3545; }
        .status-warning { color: #ffc107; }
        
        /* Include the modal styles */
        .modal-header {
            position: relative !important;
        }
        
        .modal-controls {
            position: absolute;
            top: 15px;
            right: 15px;
            display: flex;
            gap: 8px;
            z-index: 10001;
        }
        
        .modal-control-btn {
            width: 32px;
            height: 32px;
            border: none;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
            backdrop-filter: blur(10px);
        }
        
        .modal-control-btn:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: scale(1.05);
        }
        
        .modal-control-btn svg {
            width: 16px;
            height: 16px;
        }

        .booking-minimized-badge {
            position: fixed;
            right: 20px;
            bottom: 20px;
            z-index: 20000;
            display: none;
            align-items: center;
            gap: 12px;
            background: linear-gradient(135deg, #ffffff, #f8f9fa);
            color: #111;
            padding: 12px 16px;
            border-radius: 50px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.2);
            min-width: 160px;
            max-width: 300px;
            cursor: pointer;
            transition: all 0.3s ease;
            user-select: none;
            border: 1px solid rgba(0,0,0,0.1);
        }
        
        .booking-minimized-badge:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 40px rgba(0,0,0,0.25);
        }
        
        .booking-minimized-badge .badge-icon {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #007bff;
            color: #fff;
            font-size: 16px;
            flex-shrink: 0;
        }
        
        .booking-minimized-badge .badge-text {
            font-size: 14px;
            color: #222;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            font-weight: 500;
        }
        
        .booking-minimized-badge.state-pending .badge-icon { background: #ffc107; color: #000; }
        .booking-minimized-badge.state-searching .badge-icon { background: #007bff; }
        .booking-minimized-badge.state-accepted .badge-icon { background: #28a745; }
        .booking-minimized-badge.state-completed .badge-icon { background: #6c757d; }
        .booking-minimized-badge.state-cancelled .badge-icon { background: #dc3545; }
    </style>
</head>
<body>
    <div class="debug-container">
        <h1>🔍 Booking Modal Debug Tool</h1>
        <p>This tool helps debug the modal minimize/restore functionality.</p>
        
        <div class="debug-output" id="debugOutput">
            Debug output will appear here...
        </div>
        
        <h3>Debug Controls:</h3>
        <button class="debug-button" onclick="checkElements()">Check Elements</button>
        <button class="debug-button" onclick="showModal()">Show Modal</button>
        <button class="debug-button" onclick="testMinimizeButton()">Test Minimize Button</button>
        <button class="debug-button" onclick="testCloseButton()">Test Close Button</button>
        <button class="debug-button" onclick="testBadge()">Test Badge</button>
        <button class="debug-button" onclick="simulateBookingFlow()">Simulate Booking Flow</button>
        <button class="debug-button" onclick="clearDebugOutput()">Clear Output</button>
        
        <h3>Manual Testing:</h3>
        <ul>
            <li>1. Click "Show Modal" to display the booking modal</li>
            <li>2. Try clicking the minimize (−) button in the modal header</li>
            <li>3. Check if badge appears in bottom-right corner</li>
            <li>4. Click the badge to restore the modal</li>
            <li>5. Try the close (×) button</li>
            <li>6. Press 'M' key to test keyboard shortcut</li>
        </ul>
    </div>

    <!-- Test Modal (same structure as booking.php) -->
    <div id="bookingStatusModal" class="modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999;">
        <div class="modal-content" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 0; border-radius: 15px; max-width: 500px; width: 90%; max-height: 80vh; overflow-y: auto; box-shadow: 0 10px 30px rgba(0,0,0,0.3);">
            
            <!-- Modal Header -->
            <div class="modal-header" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 15px 15px 0 0; text-align: center; position: relative;">
                <h3 style="margin: 0; font-size: 1.5rem;">
                    <i class="fas fa-car"></i> Ride Status
                </h3>
                <!-- Minimize and Close controls -->
                <div class="modal-controls">
                    <button id="bookingMinimizeBtn" class="modal-control-btn" aria-label="Minimize booking status" title="Minimize" type="button">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                            <path d="M6 12h12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                    </button>
                    <button id="bookingCloseBtn" class="modal-control-btn" aria-label="Close booking status" title="Close" type="button">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                            <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                    </button>
                </div>
            </div>
            
            <!-- Modal Body -->
            <div class="modal-body" style="padding: 30px 20px;">
                <div id="statusDisplay" style="text-align: center; margin-bottom: 30px;">
                    <div id="statusIcon" style="font-size: 3rem; margin-bottom: 15px;">
                        <i class="fas fa-clock" style="color: #ffc107;"></i>
                    </div>
                    <h2 id="statusTitle" style="margin: 0 0 10px 0; color: #333;">Finding Driver...</h2>
                    <p id="statusMessage" style="margin: 0; color: #666;">We're searching for available drivers near you.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Minimized Badge -->
    <div id="bookingMinimizedBadge" class="booking-minimized-badge" role="button" aria-label="Booking status minimized. Click to restore." tabindex="0" style="display:none;">
        <div class="badge-icon">⏳</div>
        <div class="badge-text">Finding driver…</div>
    </div>

    <script>
        let debugOutput = document.getElementById('debugOutput');
        
        function log(message, type = 'info') {
            const timestamp = new Date().toLocaleTimeString();
            const className = type === 'error' ? 'status-error' : type === 'warning' ? 'status-warning' : 'status-good';
            debugOutput.innerHTML += `<span class="${className}">[${timestamp}] ${message}</span>\n`;
            debugOutput.scrollTop = debugOutput.scrollHeight;
        }
        
        function clearDebugOutput() {
            debugOutput.innerHTML = 'Debug output cleared...\n';
        }
        
        function checkElements() {
            log('=== CHECKING ELEMENTS ===');
            
            const modal = document.getElementById('bookingStatusModal');
            const minimizeBtn = document.getElementById('bookingMinimizeBtn');
            const closeBtn = document.getElementById('bookingCloseBtn');
            const badge = document.getElementById('bookingMinimizedBadge');
            
            log(`Modal: ${modal ? '✓ FOUND' : '✗ NOT FOUND'}`, modal ? 'info' : 'error');
            log(`Minimize button: ${minimizeBtn ? '✓ FOUND' : '✗ NOT FOUND'}`, minimizeBtn ? 'info' : 'error');
            log(`Close button: ${closeBtn ? '✓ FOUND' : '✗ NOT FOUND'}`, closeBtn ? 'info' : 'error');
            log(`Badge: ${badge ? '✓ FOUND' : '✗ NOT FOUND'}`, badge ? 'info' : 'error');
            
            if (minimizeBtn) {
                log(`Minimize button onclick: ${minimizeBtn.onclick ? '✓ SET' : '✗ NOT SET'}`, minimizeBtn.onclick ? 'info' : 'warning');
                log(`Minimize button listeners: ${getEventListeners ? getEventListeners(minimizeBtn).click?.length || 0 : 'N/A'}`, 'info');
            }
            
            if (closeBtn) {
                log(`Close button onclick: ${closeBtn.onclick ? '✓ SET' : '✗ NOT SET'}`, closeBtn.onclick ? 'info' : 'warning');
                log(`Close button listeners: ${getEventListeners ? getEventListeners(closeBtn).click?.length || 0 : 'N/A'}`, 'info');
            }
            
            log('=== ELEMENT CHECK COMPLETE ===');
        }
        
        function showModal() {
            const modal = document.getElementById('bookingStatusModal');
            if (modal) {
                modal.style.display = 'block';
                document.body.style.overflow = 'hidden';
                log('Modal shown manually', 'info');
            } else {
                log('Modal not found', 'error');
            }
        }
        
        function testMinimizeButton() {
            const minimizeBtn = document.getElementById('bookingMinimizeBtn');
            if (minimizeBtn) {
                log('Testing minimize button click...', 'info');
                
                // Try to trigger click
                try {
                    minimizeBtn.click();
                    log('Minimize button click() method called', 'info');
                } catch (e) {
                    log(`Error calling click(): ${e.message}`, 'error');
                }
                
                // Try direct event
                try {
                    const event = new MouseEvent('click', {
                        bubbles: true,
                        cancelable: true,
                        view: window
                    });
                    minimizeBtn.dispatchEvent(event);
                    log('Minimize button dispatchEvent() called', 'info');
                } catch (e) {
                    log(`Error with dispatchEvent(): ${e.message}`, 'error');
                }
            } else {
                log('Minimize button not found', 'error');
            }
        }
        
        function testCloseButton() {
            const closeBtn = document.getElementById('bookingCloseBtn');
            if (closeBtn) {
                log('Testing close button click...', 'info');
                
                try {
                    closeBtn.click();
                    log('Close button click() method called', 'info');
                } catch (e) {
                    log(`Error calling click(): ${e.message}`, 'error');
                }
                
                try {
                    const event = new MouseEvent('click', {
                        bubbles: true,
                        cancelable: true,
                        view: window
                    });
                    closeBtn.dispatchEvent(event);
                    log('Close button dispatchEvent() called', 'info');
                } catch (e) {
                    log(`Error with dispatchEvent(): ${e.message}`, 'error');
                }
            } else {
                log('Close button not found', 'error');
            }
        }
        
        function testBadge() {
            const badge = document.getElementById('bookingMinimizedBadge');
            if (badge) {
                log('Testing badge...', 'info');
                
                // Show badge
                badge.style.display = 'flex';
                log('Badge shown manually', 'info');
                
                // Test click
                setTimeout(() => {
                    try {
                        badge.click();
                        log('Badge click() method called', 'info');
                    } catch (e) {
                        log(`Error clicking badge: ${e.message}`, 'error');
                    }
                }, 1000);
            } else {
                log('Badge not found', 'error');
            }
        }
        
        function simulateBookingFlow() {
            log('=== SIMULATING BOOKING FLOW ===');
            
            // Show modal
            showModal();
            
            // Wait 1 second, then minimize
            setTimeout(() => {
                log('Simulating user clicking minimize button...', 'info');
                testMinimizeButton();
            }, 1000);
            
            // Wait 2 seconds, then update status
            setTimeout(() => {
                log('Simulating status update to "Searching"...', 'info');
                if (typeof window.updateBookingStatusBadge === 'function') {
                    window.updateBookingStatusBadge('Searching for Driver...', 'searching');
                } else {
                    log('updateBookingStatusBadge function not found', 'warning');
                }
            }, 3000);
            
            // Wait 2 more seconds, then update to accepted
            setTimeout(() => {
                log('Simulating status update to "Accepted"...', 'info');
                if (typeof window.updateBookingStatusBadge === 'function') {
                    window.updateBookingStatusBadge('Driver Found!', 'accepted');
                } else {
                    log('updateBookingStatusBadge function not found', 'warning');
                }
            }, 5000);
            
            log('Booking flow simulation started', 'info');
        }
        
        // Initialize the modal controls when DOM is ready
        document.addEventListener('DOMContentLoaded', function() {
            log('DOM loaded - checking if modal controls are initialized...', 'info');
            
            setTimeout(function() {
                if (typeof initializeModalControls === 'function') {
                    log('Calling initializeModalControls()...', 'info');
                    initializeModalControls();
                } else {
                    log('initializeModalControls function not found - modal controls may not be working', 'error');
                }
                
                // Check elements after initialization
                setTimeout(checkElements, 500);
            }, 200);
        });
        
        log('Debug page loaded', 'info');
    </script>
    
    <!-- Include the modal controls script from booking.php -->
    <script>
    // Wait for DOM to be fully loaded before initializing modal controls
    document.addEventListener('DOMContentLoaded', function() {
        console.log('DOM loaded - initializing modal controls');
        
        // Use a timeout to ensure all elements are available
        setTimeout(function() {
            initializeModalControls();
        }, 100);
    });

    function initializeModalControls() {
        const modal = document.getElementById('bookingStatusModal');
        const minimizeBtn = document.getElementById('bookingMinimizeBtn');
        const closeBtn = document.getElementById('bookingCloseBtn');
        let badge = document.getElementById('bookingMinimizedBadge');
        
        console.log('Modal elements check:');
        console.log('Modal:', modal ? 'found' : 'NOT FOUND');
        console.log('Minimize button:', minimizeBtn ? 'found' : 'NOT FOUND');
        console.log('Close button:', closeBtn ? 'found' : 'NOT FOUND');
        console.log('Badge:', badge ? 'found' : 'NOT FOUND');
        
        // Create badge if it doesn't exist
        if (!badge) {
            badge = document.createElement('div');
            badge.id = 'bookingMinimizedBadge';
            badge.className = 'booking-minimized-badge';
            badge.setAttribute('role', 'button');
            badge.setAttribute('tabindex', '0');
            badge.setAttribute('aria-label', 'Click to restore booking status');
            badge.innerHTML = '<div class="badge-icon">⏳</div><div class="badge-text">Finding driver…</div>';
            document.body.appendChild(badge);
            console.log('Badge created and added to body');
        }

        // Badge management functions
        function showBadge(text, state) {
            if (!badge) return;
            
            badge.style.display = 'flex';
            const badgeText = badge.querySelector('.badge-text');
            const badgeIcon = badge.querySelector('.badge-icon');
            
            if (badgeText) badgeText.textContent = text || 'Finding driver…';
            if (badgeIcon) {
                // Update icon based on state
                const icons = {
                    'pending': '⏳',
                    'searching': '🔍',
                    'accepted': '✓',
                    'completed': '🏁',
                    'cancelled': '✕'
                };
                badgeIcon.textContent = icons[state] || '⏳';
            }
            
            // Update state class
            badge.classList.remove('state-pending', 'state-searching', 'state-accepted', 'state-completed', 'state-cancelled');
            badge.classList.add('state-' + (state || 'pending'));
            
            console.log('Badge shown:', text, state);
        }

        function hideBadge() {
            if (!badge) return;
            badge.style.display = 'none';
            console.log('Badge hidden');
        }

        function minimizeModal() {
            if (!modal) {
                console.error('Modal not found for minimization');
                return;
            }
            
            console.log('Minimizing modal');
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
            
            // Show badge with current status
            const currentStatus = document.getElementById('statusTitle')?.textContent || 'Finding driver…';
            const statusKey = getCurrentStatusKey();
            showBadge(currentStatus, statusKey);
            
            // Save minimized state
            try {
                localStorage.setItem('booking_minimized', '1');
                localStorage.setItem('booking_minimized_time', Date.now().toString());
            } catch (e) {
                console.warn('Could not save minimized state:', e);
            }
        }

        function restoreModal() {
            if (!modal) {
                console.error('Modal not found for restoration');
                return;
            }
            
            console.log('Restoring modal');
            modal.style.display = 'block';
            document.body.style.overflow = 'hidden';
            hideBadge();
            
            // Clear minimized state
            try {
                localStorage.removeItem('booking_minimized');
                localStorage.removeItem('booking_minimized_time');
            } catch (e) {
                console.warn('Could not clear minimized state:', e);
            }
            
            // Focus management
            setTimeout(() => {
                const focusTarget = modal.querySelector('button, [tabindex], input, textarea, select');
                if (focusTarget) {
                    focusTarget.focus();
                }
            }, 100);
        }

        function getCurrentStatusKey() {
            const statusTitle = document.getElementById('statusTitle')?.textContent || '';
            const statusMessage = document.getElementById('statusMessage')?.textContent || '';
            
            // Determine status based on text content
            if (statusTitle.includes('Accepted') || statusMessage.includes('accepted')) return 'accepted';
            if (statusTitle.includes('Completed') || statusMessage.includes('completed')) return 'completed';
            if (statusTitle.includes('Cancelled') || statusMessage.includes('cancelled')) return 'cancelled';
            if (statusTitle.includes('Searching') || statusMessage.includes('searching')) return 'searching';
            return 'pending';
        }

        // Global function for updating badge from status updates
        window.updateBookingStatusBadge = function(text, stateKey) {
            try {
                const key = stateKey || getCurrentStatusKey();
                const txt = (typeof text === 'string') ? text : String(text || 'Finding driver…');
                
                // Only show badge if modal is minimized
                if (modal && modal.style.display === 'none') {
                    showBadge(txt, key);
                }
                
                // Auto-restore when accepted (with delay)
                if (key === 'accepted') {
                    setTimeout(() => {
                        restoreModal();
                    }, 2000);
                }
                
                console.log('Badge updated:', txt, key);
            } catch (e) {
                console.error('Failed to update booking status badge:', e);
            }
        };

        // Event listeners for modal controls - ADD THEM PROPERLY
        if (minimizeBtn) {
            console.log('Adding click listener to minimize button');
            minimizeBtn.addEventListener('click', function(e) {
                console.log('Minimize button clicked!');
                e.preventDefault();
                e.stopPropagation();
                minimizeModal();
            });
            
            // Also test with direct onclick as fallback
            minimizeBtn.onclick = function(e) {
                console.log('Minimize button onclick fired!');
                e.preventDefault();
                e.stopPropagation();
                minimizeModal();
            };
        } else {
            console.error('Minimize button not found - cannot add listener');
        }

        if (closeBtn) {
            console.log('Adding click listener to close button');
            closeBtn.addEventListener('click', function(e) {
                console.log('Close button clicked!');
                e.preventDefault();
                e.stopPropagation();
                hideBadge();
                modal.style.display = 'none';
                document.body.style.overflow = 'auto';
            });
            
            // Also test with direct onclick as fallback
            closeBtn.onclick = function(e) {
                console.log('Close button onclick fired!');
                e.preventDefault();
                e.stopPropagation();
                hideBadge();
                modal.style.display = 'none';
                document.body.style.overflow = 'auto';
            };
        } else {
            console.error('Close button not found - cannot add listener');
        }

        // Badge click to restore
        if (badge) {
            badge.addEventListener('click', function(e) {
                console.log('Badge clicked - restoring modal');
                e.preventDefault();
                restoreModal();
            });

            // Badge keyboard support
            badge.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    console.log('Badge key pressed - restoring modal');
                    restoreModal();
                }
            });
        }

        // Keyboard shortcut: press M to minimize when modal is visible
        document.addEventListener('keydown', function(e) {
            if ((e.key === 'm' || e.key === 'M') && modal && modal.style.display !== 'none') {
                e.preventDefault();
                console.log('M key pressed - minimizing modal');
                minimizeModal();
            }
        });

        console.log('Modal controls initialization complete');
    }
    </script>
</body>
</html>
