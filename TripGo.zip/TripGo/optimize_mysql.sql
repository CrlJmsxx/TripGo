-- Optimize MySQL performance
SET GLOBAL innodb_buffer_pool_size = 256M;
SET GLOBAL query_cache_size = 32M;
SET GLOBAL query_cache_type = ON;
SET GLOBAL innodb_log_file_size = 64M;

-- Optimize TripGo tables
USE tripgo_booking;

-- Add indexes for better performance
ALTER TABLE bookings ADD INDEX idx_status (status);
ALTER TABLE bookings ADD INDEX idx_passenger (passenger_id);
ALTER TABLE bookings ADD INDEX idx_driver (driver_id);
ALTER TABLE bookings ADD INDEX idx_booking_time (booking_time);

-- Optimize users table
ALTER TABLE users ADD INDEX idx_user_type (user_type);
ALTER TABLE users ADD INDEX idx_email (email);

-- Analyze tables for better query planning
ANALYZE TABLE users;
ANALYZE TABLE bookings;
ANALYZE TABLE driver_profiles;
ANALYZE TABLE reviews;
