-- First, drop the table if it exists (to handle corruption)
DROP TABLE IF EXISTS driver_profiles;

-- Create fresh driver_profiles table
CREATE TABLE driver_profiles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    license_number VARCHAR(50) NOT NULL,
    vehicle_type ENUM('motorcycle', 'tricycle', 'car') NULL,
    vehicle_brand VARCHAR(50) NULL,
    vehicle_model VARCHAR(100) NOT NULL,
    vehicle_plate VARCHAR(20) NOT NULL,
    vehicle_color VARCHAR(30) NOT NULL,
    vehicle_capacity INT NULL,
    is_available BOOLEAN DEFAULT TRUE,
    current_latitude DECIMAL(10, 8),
    current_longitude DECIMAL(11, 8),
    rating DECIMAL(3, 2) DEFAULT 0.00,
    total_rides INT DEFAULT 0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
