<?php
require_once __DIR__ . '/config/database.php';

header('Content-Type: text/plain');

try {
    $pdo = getConnection();
    
    // Clear expired requests
    $stmt = $pdo->prepare("
        DELETE FROM bookings 
        WHERE status = 'pending' 
        AND expires_at IS NOT NULL 
        AND expires_at < NOW()
    ");
    $result = $stmt->execute();
    $clearedCount = $stmt->rowCount();
    
    echo "Cleared {$clearedCount} expired requests\n";
    
    // Also clear very old pending requests (older than 1 hour)
    $stmt = $pdo->prepare("
        DELETE FROM bookings 
        WHERE status = 'pending' 
        AND booking_time < DATE_SUB(NOW(), INTERVAL 1 HOUR)
    ");
    $stmt->execute();
    $oldClearedCount = $stmt->rowCount();
    
    echo "Cleared {$oldClearedCount} old pending requests (> 1 hour)\n";
    
    echo "Cleanup completed successfully\n";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
