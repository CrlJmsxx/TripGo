<?php
require_once 'config/database.php';
require_once 'config/session.php';

header('Content-Type: text/html; charset=UTF-8');

// Check authentication
$currentUser = getCurrentUser();
if (!$currentUser) {
    die('<h1>Authentication Required</h1><p>Please <a href="auth/login.php">login</a> to access verification.</p>');
}

$pdo = getConnection();

// Verification checklist
$requirements = [
    [
        'feature' => 'Location Update',
        'description' => 'api/update_location.php successfully updates current_lat and current_lng in the users table for both drivers and passengers.',
        'status' => 'pending',
        'details' => []
    ],
    [
        'feature' => 'Ride Acceptance Logic',
        'description' => 'api/accept_ride.php (or equivalent) checks if the driver has any ride with status = \'accepted\' or \'in_progress\' and rejects the new booking attempt if true.',
        'status' => 'pending',
        'details' => []
    ],
    [
        'feature' => 'Cancellation Reason',
        'description' => 'The rides table has a new field (cancellation_reason) to store the passenger\'s selected reason/text.',
        'status' => 'pending',
        'details' => []
    ],
    [
        'feature' => 'Rating Calculation',
        'description' => 'A mechanism exists to update the Driver\'s overall average rating in the users table after a new review is submitted.',
        'status' => 'pending',
        'details' => []
    ],
    [
        'feature' => 'Request Expiry',
        'description' => 'New rides are recorded with a creation timestamp, and a background/cron task (or API check) sets the status to \'expired\' if the timestamp exceeds the set duration (e.g., 60 seconds) without acceptance.',
        'status' => 'pending',
        'details' => []
    ]
];

// Check 1: Location Update
try {
    // Check if update_location.php exists for drivers
    if (file_exists('driver/update_location.php')) {
        $requirements[0]['status'] = 'pass';
        $requirements[0]['details'][] = '✅ Driver location update API exists';
        
        // Check if it updates driver_profiles table
        $content = file_get_contents('driver/update_location.php');
        if (strpos($content, 'UPDATE driver_profiles') !== false && strpos($content, 'current_latitude') !== false) {
            $requirements[0]['details'][] = '✅ Updates driver_profiles.current_latitude and current_longitude';
        }
        
        // Check if it updates bookings table
        if (strpos($content, 'UPDATE bookings') !== false && strpos($content, 'driver_latitude') !== false) {
            $requirements[0]['details'][] = '✅ Updates bookings.driver_latitude and driver_longitude for active rides';
        }
        
        // Check if passenger location update exists (need to create)
        if (!file_exists('passenger/update_location.php')) {
            $requirements[0]['status'] = 'partial';
            $requirements[0]['details'][] = '❌ Passenger location update API missing';
        } else {
            $requirements[0]['details'][] = '✅ Passenger location update API exists';
        }
    } else {
        $requirements[0]['status'] = 'fail';
        $requirements[0]['details'][] = '❌ Driver location update API missing';
    }
} catch (Exception $e) {
    $requirements[0]['status'] = 'fail';
    $requirements[0]['details'][] = '❌ Error checking location update: ' . $e->getMessage();
}

// Check 2: Ride Acceptance Logic
try {
    // Check if ride acceptance logic exists in driver dashboard
    if (file_exists('driver/dashboard.php')) {
        $content = file_get_contents('driver/dashboard.php');
        
        if (strpos($content, 'SELECT COUNT(*) as active_count') !== false && 
            strpos($content, 'WHERE driver_id = ? AND status IN (\'accepted\', \'in_progress\')') !== false) {
            $requirements[1]['status'] = 'pass';
            $requirements[1]['details'][] = '✅ Checks for active rides before accepting new ones';
            $requirements[1]['details'][] = '✅ Rejects acceptance if driver has active rides';
        } else {
            $requirements[1]['status'] = 'fail';
            $requirements[1]['details'][] = '❌ Active ride check logic missing';
        }
        
        if (strpos($content, 'accept_booking') !== false) {
            $requirements[1]['details'][] = '✅ Accept booking functionality exists';
        }
    } else {
        $requirements[1]['status'] = 'fail';
        $requirements[1]['details'][] = '❌ Driver dashboard missing';
    }
} catch (Exception $e) {
    $requirements[1]['status'] = 'fail';
    $requirements[1]['details'][] = '❌ Error checking ride acceptance: ' . $e->getMessage();
}

// Check 3: Cancellation Reason
try {
    // Check database schema
    $result = $pdo->query("SHOW COLUMNS FROM bookings LIKE 'cancellation_reason'");
    if ($result->rowCount() > 0) {
        $requirements[2]['status'] = 'pass';
        $requirements[2]['details'][] = '✅ bookings.cancellation_reason column exists';
        
        // Check other cancellation columns
        $columns = ['cancelled_by', 'cancelled_at'];
        foreach ($columns as $col) {
            $result = $pdo->query("SHOW COLUMNS FROM bookings LIKE '$col'");
            if ($result->rowCount() > 0) {
                $requirements[2]['details'][] = "✅ bookings.$col column exists";
            } else {
                $requirements[2]['status'] = 'partial';
                $requirements[2]['details'][] = "❌ bookings.$col column missing";
            }
        }
        
        // Check if cancellation API exists
        if (file_exists('api/cancel_booking.php')) {
            $requirements[2]['details'][] = '✅ Cancellation API exists';
        } else {
            $requirements[2]['status'] = 'partial';
            $requirements[2]['details'][] = '❌ Cancellation API missing';
        }
    } else {
        $requirements[2]['status'] = 'fail';
        $requirements[2]['details'][] = '❌ bookings.cancellation_reason column missing';
    }
} catch (Exception $e) {
    $requirements[2]['status'] = 'fail';
    $requirements[2]['details'][] = '❌ Error checking cancellation reason: ' . $e->getMessage();
}

// Check 4: Rating Calculation
try {
    // Check if average_rating column exists in users table
    $result = $pdo->query("SHOW COLUMNS FROM users LIKE 'average_rating'");
    if ($result->rowCount() > 0) {
        $requirements[3]['details'][] = '✅ users.average_rating column exists';
        
        // Check if rating calculation logic exists
        if (file_exists('passenger/rate_ride.php')) {
            $content = file_get_contents('passenger/rate_ride.php');
            
            if (strpos($content, 'UPDATE users u SET average_rating = (SELECT AVG(rating)') !== false) {
                $requirements[3]['status'] = 'pass';
                $requirements[3]['details'][] = '✅ Rating calculation logic exists';
                $requirements[3]['details'][] = '✅ Updates driver average rating after review submission';
            } else {
                $requirements[3]['status'] = 'partial';
                $requirements[3]['details'][] = '❌ Rating calculation logic missing';
            }
            
            // Check if reviews table exists
            $result = $pdo->query("SHOW TABLES LIKE 'reviews'");
            if ($result->rowCount() > 0) {
                $requirements[3]['details'][] = '✅ reviews table exists';
            } else {
                $requirements[3]['status'] = 'partial';
                $requirements[3]['details'][] = '❌ reviews table missing';
            }
        } else {
            $requirements[3]['status'] = 'partial';
            $requirements[3]['details'][] = '❌ Rating submission API missing';
        }
    } else {
        $requirements[3]['status'] = 'fail';
        $requirements[3]['details'][] = '❌ users.average_rating column missing';
    }
} catch (Exception $e) {
    $requirements[3]['status'] = 'fail';
    $requirements[3]['details'][] = '❌ Error checking rating calculation: ' . $e->getMessage();
}

// Check 5: Request Expiry
try {
    // Check if expires_at column exists
    $result = $pdo->query("SHOW COLUMNS FROM bookings LIKE 'expires_at'");
    if ($result->rowCount() > 0) {
        $requirements[4]['details'][] = '✅ bookings.expires_at column exists';
        
        // Check if booking creation sets expiry time
        if (file_exists('passenger/booking.php')) {
            $content = file_get_contents('passenger/booking.php');
            
            if (strpos($content, 'DATE_ADD(NOW(), INTERVAL 60 SECOND)') !== false) {
                $requirements[4]['details'][] = '✅ Booking creation sets 60-second expiry';
            } else {
                $requirements[4]['status'] = 'partial';
                $requirements[4]['details'][] = '❌ Booking expiry time not set';
            }
        }
        
        // Check if expiry processing exists
        if (file_exists('driver/dashboard.php')) {
            $content = file_get_contents('driver/dashboard.php');
            
            if (strpos($content, 'expires_at <= NOW()') !== false && strpos($content, 'status = \'expired\'') !== false) {
                $requirements[4]['status'] = 'pass';
                $requirements[4]['details'][] = '✅ Expiry processing exists (runs on dashboard load)';
            } else {
                $requirements[4]['status'] = 'partial';
                $requirements[4]['details'][] = '❌ Expiry processing logic missing';
            }
        }
        
        // Check if status enum includes 'expired'
        $result = $pdo->query("SHOW COLUMNS FROM bookings LIKE 'status'");
        $row = $result->fetch(PDO::FETCH_ASSOC);
        if ($row && strpos($row['Type'], 'expired') !== false) {
            $requirements[4]['details'][] = '✅ Status enum includes \'expired\'';
        } else {
            $requirements[4]['status'] = 'partial';
            $requirements[4]['details'][] = '❌ Status enum missing \'expired\'';
        }
    } else {
        $requirements[4]['status'] = 'fail';
        $requirements[4]['details'][] = '❌ bookings.expires_at column missing';
    }
} catch (Exception $e) {
    $requirements[4]['status'] = 'fail';
    $requirements[4]['details'][] = '❌ Error checking request expiry: ' . $e->getMessage();
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>TripGO Feature Verification Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        h1 { color: #333; text-align: center; margin-bottom: 30px; }
        .requirement { margin-bottom: 30px; padding: 20px; border-radius: 8px; border-left: 4px solid #ddd; }
        .requirement.pass { border-left-color: #28a745; background: #f8fff9; }
        .requirement.partial { border-left-color: #ffc107; background: #fffdf7; }
        .requirement.fail { border-left-color: #dc3545; background: #fff8f8; }
        .feature-name { font-size: 1.2rem; font-weight: bold; margin-bottom: 10px; }
        .status-badge { padding: 4px 12px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase; margin-bottom: 10px; display: inline-block; }
        .status-pass { background: #28a745; color: white; }
        .status-partial { background: #ffc107; color: #212529; }
        .status-fail { background: #dc3545; color: white; }
        .description { color: #666; margin-bottom: 15px; }
        .details { font-size: 0.9rem; }
        .details div { margin-bottom: 5px; }
        .summary { margin-top: 30px; padding: 20px; background: #f8f9fa; border-radius: 8px; }
        .summary h2 { margin-top: 0; }
        .actions { margin-top: 20px; text-align: center; }
        .btn { padding: 10px 20px; margin: 5px; border: none; border-radius: 6px; cursor: pointer; text-decoration: none; display: inline-block; }
        .btn-primary { background: #007bff; color: white; }
        .btn-success { background: #28a745; color: white; }
        .btn-warning { background: #ffc107; color: #212529; }
        .btn-danger { background: #dc3545; color: white; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 TripGO Feature Verification Report</h1>
        <p style="text-align: center; color: #666; margin-bottom: 30px;">
            <strong>User:</strong> <?php echo htmlspecialchars($currentUser['username']); ?> | 
            <strong>Time:</strong> <?php echo date('Y-m-d H:i:s'); ?>
        </p>
        
        <?php foreach ($requirements as $req): ?>
            <div class="requirement <?php echo $req['status']; ?>">
                <div class="feature-name"><?php echo htmlspecialchars($req['feature']); ?></div>
                <div class="status-badge status-<?php echo $req['status']; ?>"><?php echo $req['status']; ?></div>
                <div class="description"><?php echo htmlspecialchars($req['description']); ?></div>
                <div class="details">
                    <?php foreach ($req['details'] as $detail): ?>
                        <div><?php echo $detail; ?></div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>
        
        <div class="summary">
            <h2>📊 Summary</h2>
            <?php
            $pass = count(array_filter($requirements, fn($r) => $r['status'] === 'pass'));
            $partial = count(array_filter($requirements, fn($r) => $r['status'] === 'partial'));
            $fail = count(array_filter($requirements, fn($r) => $r['status'] === 'fail'));
            $total = count($requirements);
            ?>
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; text-align: center;">
                <div>
                    <div style="font-size: 2rem; font-weight: bold; color: #28a745;"><?php echo $pass; ?></div>
                    <div style="color: #666;">Passed</div>
                </div>
                <div>
                    <div style="font-size: 2rem; font-weight: bold; color: #ffc107;"><?php echo $partial; ?></div>
                    <div style="color: #666;">Partial</div>
                </div>
                <div>
                    <div style="font-size: 2rem; font-weight: bold; color: #dc3545;"><?php echo $fail; ?></div>
                    <div style="color: #666;">Failed</div>
                </div>
                <div>
                    <div style="font-size: 2rem; font-weight: bold; color: #333;"><?php echo $total; ?></div>
                    <div style="color: #666;">Total</div>
                </div>
            </div>
            
            <?php if ($fail > 0 || $partial > 0): ?>
                <div style="margin-top: 20px; padding: 15px; background: #fff3cd; border-radius: 6px; border-left: 4px solid #ffc107;">
                    <strong>⚠️ Action Required:</strong> Some features need attention. See details above and run the migration to fix missing components.
                </div>
            <?php else: ?>
                <div style="margin-top: 20px; padding: 15px; background: #d4edda; border-radius: 6px; border-left: 4px solid #28a745;">
                    <strong>✅ All Features Implemented:</strong> All technical requirements have been successfully implemented.
                </div>
            <?php endif; ?>
        </div>
        
        <div class="actions">
            <a href="migrate.php" class="btn btn-primary">🔧 Run Migration</a>
            <a href="diagnostics.php" class="btn btn-success">🔍 Run Diagnostics</a>
            <a href="index.php" class="btn btn-warning">🏠 Back to Home</a>
            <?php if ($currentUser['user_type'] === 'passenger'): ?>
                <a href="passenger/dashboard.php" class="btn btn-success">🚗 Passenger Dashboard</a>
            <?php elseif ($currentUser['user_type'] === 'driver'): ?>
                <a href="driver/dashboard.php" class="btn btn-success">🚙 Driver Dashboard</a>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
