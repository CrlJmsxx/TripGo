<?php
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Cache-Control');

require_once '../config/database.php';
require_once '../config/session.php';

// Get booking ID from query parameter
$booking_id = $_GET['booking_id'] ?? '';

if (empty($booking_id)) {
    echo "data: " . json_encode(['error' => 'Booking ID is required']) . "\n\n";
    exit();
}

// Get current user
$currentUser = getCurrentUser();
if (!$currentUser) {
    echo "data: " . json_encode(['error' => 'Not authenticated']) . "\n\n";
    exit();
}

try {
    $pdo = getConnection();
    
    // Verify booking belongs to current user
    $stmt = $pdo->prepare("
        SELECT * FROM bookings 
        WHERE id = ? AND passenger_id = ?
    ");
    $stmt->execute([$booking_id, $currentUser['id']]);
    $booking = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$booking) {
        echo "data: " . json_encode(['error' => 'Booking not found']) . "\n\n";
        exit();
    }
    
    // Send initial status
    sendStatusUpdate($booking);
    
    // Continuously check for updates (SSE implementation)
    $last_status = $booking['status'];
    $max_iterations = 300; // 5 minutes max
    $iteration = 0;
    
    while ($iteration < $max_iterations) {
        // Check if client is still connected
        if (connection_aborted()) {
            break;
        }
        
        // Refresh booking data from database
        $stmt = $pdo->prepare("
            SELECT b.*, u.full_name as driver_name, u.rating as driver_rating,
                   dp.vehicle_type, dp.license_plate,
                   (6371 * acos(cos(radians(b.pickup_latitude)) * cos(radians(dp.current_latitude)) * 
                   cos(radians(dp.current_longitude) - radians(b.pickup_longitude)) + 
                   sin(radians(b.pickup_latitude)) * sin(radians(dp.current_latitude)))) as distance
            FROM bookings b
            LEFT JOIN users u ON b.driver_id = u.id
            LEFT JOIN driver_profiles dp ON b.driver_id = dp.user_id
            WHERE b.id = ?
        ");
        $stmt->execute([$booking_id]);
        $current_booking = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($current_booking && $current_booking['status'] !== $last_status) {
            sendStatusUpdate($current_booking);
            $last_status = $current_booking['status'];
            
            // Stop streaming if booking is in final state
            if (in_array($last_status, ['cancelled', 'completed', 'expired'])) {
                break;
            }
        }
        
        // Check for expiry
        if ($current_booking['status'] === 'pending' && $current_booking['expires_at']) {
            $expires_at = new DateTime($current_booking['expires_at']);
            $now = new DateTime();
            
            if ($now > $expires_at) {
                // Update to expired and notify
                $stmt = $pdo->prepare("UPDATE bookings SET status = 'expired' WHERE id = ?");
                $stmt->execute([$booking_id]);
                
                $current_booking['status'] = 'expired';
                sendStatusUpdate($current_booking);
                break;
            }
        }
        
        // Send heartbeat every 30 seconds
        if ($iteration % 15 === 0) {
            echo "data: " . json_encode(['heartbeat' => true, 'timestamp' => time()]) . "\n\n";
            ob_flush();
            flush();
        }
        
        // Sleep for 2 seconds before next check
        sleep(2);
        $iteration++;
    }
    
    // Send final message
    echo "data: " . json_encode(['stream_end' => true, 'reason' => 'timeout_or_complete']) . "\n\n";
    ob_flush();
    flush();
    
} catch (Exception $e) {
    error_log("SSE error: " . $e->getMessage());
    echo "data: " . json_encode(['error' => 'Server error']) . "\n\n";
}

function sendStatusUpdate($booking) {
    $data = [
        'success' => true,
        'status' => $booking['status'],
        'booking_id' => $booking['id'],
        'timestamp' => time()
    ];
    
    // Add driver details if accepted
    if ($booking['status'] === 'accepted' || $booking['status'] === 'in_progress') {
        $data['driver'] = [
            'id' => $booking['driver_id'],
            'full_name' => $booking['driver_name'],
            'rating' => $booking['driver_rating'] ? number_format($booking['driver_rating'], 1) : '4.8',
            'vehicle_type' => $booking['vehicle_type'] ?: 'Sedan',
            'license_plate' => $booking['license_plate'] ?: 'ABC 123',
            'distance' => $booking['distance'] ? round($booking['distance'], 1) : null,
            'estimated_arrival' => calculateETA($booking['distance'])
        ];
    }
    
    // Add cancellation details if cancelled
    if ($booking['status'] === 'cancelled') {
        $data['cancellation_reason'] = $booking['cancellation_reason'];
        $data['cancelled_by'] = $booking['cancelled_by'];
        $data['cancelled_at'] = $booking['cancelled_at'];
    }
    
    echo "data: " . json_encode($data) . "\n\n";
    ob_flush();
    flush();
}

function calculateETA($distance) {
    if (!$distance) return '5 mins';
    
    // Average speed in city: 30 km/h
    $time_minutes = ($distance / 30) * 60;
    
    if ($time_minutes < 1) {
        return 'Arriving';
    } elseif ($time_minutes < 60) {
        return round($time_minutes) . ' mins';
    } else {
        $hours = floor($time_minutes / 60);
        $minutes = round($time_minutes % 60);
        return $hours . 'h ' . $minutes . 'm';
    }
}
?>
