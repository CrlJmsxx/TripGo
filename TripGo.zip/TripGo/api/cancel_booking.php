<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';
require_once '../config/session.php';

// Get current user
$currentUser = getCurrentUser();
if (!$currentUser) {
    echo json_encode(['success' => false, 'error' => 'Not authenticated']);
    exit();
}

// Handle cancellation request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bookingId = $_POST['booking_id'] ?? null;
    $reason = $_POST['reason'] ?? '';
    
    if (!$bookingId) {
        echo json_encode(['success' => false, 'error' => 'Booking ID is required']);
        exit();
    }
    
    if (empty($reason)) {
        echo json_encode(['success' => false, 'error' => 'Cancellation reason is required']);
        exit();
    }
    
    try {
        $pdo = getConnection();
        
        // Verify booking belongs to current user and is in cancellable status
        $stmt = $pdo->prepare("
            SELECT * FROM bookings 
            WHERE id = ? AND passenger_id = ? AND status IN ('pending', 'searching')
        ");
        $stmt->execute([$bookingId, $currentUser['id']]);
        $booking = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$booking) {
            echo json_encode(['success' => false, 'error' => 'Booking not found or cannot be cancelled']);
            exit();
        }
        
        // Update booking status and cancellation details
        $stmt = $pdo->prepare("
            UPDATE bookings 
            SET status = 'cancelled', 
                cancellation_reason = ?, 
                cancelled_by = 'passenger', 
                cancelled_at = NOW()
            WHERE id = ?
        ");
        $stmt->execute([$reason, $bookingId]);
        
        // Log the cancellation
        $stmt = $pdo->prepare("
            INSERT INTO ride_tracking (booking_id, driver_id, status_update, timestamp) 
            VALUES (?, ?, ?, NOW())
        ");
        $stmt->execute([$bookingId, $booking['driver_id'] ?: null, 'Ride cancelled by passenger: ' . $reason]);
        
        echo json_encode([
            'success' => true, 
            'message' => 'Booking cancelled successfully'
        ]);
        
    } catch (Exception $e) {
        error_log("Cancellation error: " . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Failed to cancel booking']);
    }
    exit();
}

echo json_encode(['success' => false, 'error' => 'Invalid request method']);
?>
