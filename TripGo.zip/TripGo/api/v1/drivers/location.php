<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once '../../../config/database.php';

// Authenticate API request
function authenticateRequest() {
    $headers = getallheaders();
    $token = $headers['Authorization'] ?? '';
    
    if (empty($token)) {
        http_response_code(401);
        echo json_encode(['error' => 'Authorization token required']);
        exit();
    }
    
    $token = str_replace('Bearer ', '', $token);
    
    try {
        $pdo = getConnection();
        $stmt = $pdo->prepare("
            SELECT u.*, t.expires_at 
            FROM users u 
            JOIN api_tokens t ON u.id = t.user_id 
            WHERE t.token = ? AND t.expires_at > NOW()
        ");
        $stmt->execute([$token]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$user) {
            http_response_code(401);
            echo json_encode(['error' => 'Invalid or expired token']);
            exit();
        }
        
        return $user;
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Authentication failed']);
        exit();
    }
}

// Authenticate user
$user = authenticateRequest();

// Only allow drivers
if ($user['user_type'] !== 'driver') {
    http_response_code(403);
    echo json_encode(['error' => 'Access denied. Driver account required.']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update driver location
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid JSON input']);
        exit();
    }
    
    $latitude = $input['latitude'] ?? null;
    $longitude = $input['longitude'] ?? null;
    
    if ($latitude === null || $longitude === null) {
        http_response_code(400);
        echo json_encode(['error' => 'Latitude and longitude are required']);
        exit();
    }
    
    try {
        $pdo = getConnection();
        
        // Update driver location
        $stmt = $pdo->prepare("
            UPDATE driver_profiles 
            SET current_latitude = ?, current_longitude = ? 
            WHERE user_id = ?
        ");
        $stmt->execute([$latitude, $longitude, $user['id']]);
        
        // Log location update
        $stmt = $pdo->prepare("
            INSERT INTO ride_tracking (driver_id, driver_latitude, driver_longitude, status_update, timestamp) 
            VALUES (?, ?, ?, 'Location updated', NOW())
        ");
        $stmt->execute([$user['id'], $latitude, $longitude]);
        
        echo json_encode([
            'success' => true,
            'message' => 'Location updated successfully',
            'location' => [
                'latitude' => $latitude,
                'longitude' => $longitude,
                'timestamp' => date('Y-m-d H:i:s')
            ]
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Location update failed', 'message' => $e->getMessage()]);
    }
    
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Get nearby drivers
    $latitude = $_GET['latitude'] ?? null;
    $longitude = $_GET['longitude'] ?? null;
    $radius = $_GET['radius'] ?? 10; // Default 10km radius
    
    if ($latitude === null || $longitude === null) {
        http_response_code(400);
        echo json_encode(['error' => 'Latitude and longitude are required']);
        exit();
    }
    
    try {
        $pdo = getConnection();
        
        // Get nearby drivers
        $stmt = $pdo->prepare("
            SELECT 
                u.id, u.full_name, u.phone,
                dp.rating, dp.vehicle_model, dp.vehicle_plate, dp.vehicle_color,
                dp.current_latitude, dp.current_longitude,
                (6371 * acos(cos(radians(?)) * cos(radians(dp.current_latitude)) * 
                cos(radians(dp.current_longitude) - radians(?)) + 
                sin(radians(?)) * sin(radians(dp.current_latitude)))) AS distance
            FROM users u
            JOIN driver_profiles dp ON u.id = dp.user_id
            WHERE u.user_type = 'driver' 
            AND u.is_verified = 1 
            AND dp.is_available = 1
            AND dp.current_latitude IS NOT NULL 
            AND dp.current_longitude IS NOT NULL
            HAVING distance <= ?
            ORDER BY distance
            LIMIT 20
        ");
        $stmt->execute([$latitude, $longitude, $latitude, $radius]);
        $drivers = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'drivers' => $drivers,
            'count' => count($drivers)
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to get nearby drivers', 'message' => $e->getMessage()]);
    }
    
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
}
?>
