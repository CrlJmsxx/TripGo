<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once '../../../config/database.php';
require_once '../../../config/session.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit();
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON input']);
    exit();
}

$username = $input['username'] ?? '';
$password = $input['password'] ?? '';

if (empty($username) || empty($password)) {
    http_response_code(400);
    echo json_encode(['error' => 'Username and password are required']);
    exit();
}

try {
    $pdo = getConnection();
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username, $username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user && password_verify($password, $user['password'])) {
        // Generate API token
        $token = bin2hex(random_bytes(32));
        
        // Store token in database
        $stmt = $pdo->prepare("
            INSERT INTO api_tokens (user_id, token, expires_at) 
            VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 30 DAY))
        ");
        $stmt->execute([$user['id'], $token]);
        
        // Get user profile
        $profile = [
            'id' => $user['id'],
            'username' => $user['username'],
            'email' => $user['email'],
            'full_name' => $user['full_name'],
            'phone' => $user['phone'],
            'user_type' => $user['user_type'],
            'is_verified' => $user['is_verified']
        ];
        
        // Get driver profile if applicable
        if ($user['user_type'] === 'driver') {
            $stmt = $pdo->prepare("SELECT * FROM driver_profiles WHERE user_id = ?");
            $stmt->execute([$user['id']]);
            $driverProfile = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($driverProfile) {
                $profile['driver_profile'] = $driverProfile;
            }
        }
        
        echo json_encode([
            'success' => true,
            'message' => 'Login successful',
            'token' => $token,
            'user' => $profile
        ]);
    } else {
        http_response_code(401);
        echo json_encode(['error' => 'Invalid credentials']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Login failed', 'message' => $e->getMessage()]);
}
?>
