<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once '../../../config/database.php';

// Authenticate API request
function authenticateRequest() {
    $headers = getallheaders();
    $token = $headers['Authorization'] ?? '';
    
    if (empty($token)) {
        http_response_code(401);
        echo json_encode(['error' => 'Authorization token required']);
        exit();
    }
    
    $token = str_replace('Bearer ', '', $token);
    
    try {
        $pdo = getConnection();
        $stmt = $pdo->prepare("
            SELECT u.*, t.expires_at 
            FROM users u 
            JOIN api_tokens t ON u.id = t.user_id 
            WHERE t.token = ? AND t.expires_at > NOW()
        ");
        $stmt->execute([$token]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$user) {
            http_response_code(401);
            echo json_encode(['error' => 'Invalid or expired token']);
            exit();
        }
        
        return $user;
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Authentication failed']);
        exit();
    }
}

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit();
}

// Authenticate user
$user = authenticateRequest();

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON input']);
    exit();
}

$pickupAddress = $input['pickup_address'] ?? '';
$dropoffAddress = $input['dropoff_address'] ?? '';
$pickupLatitude = $input['pickup_latitude'] ?? null;
$pickupLongitude = $input['pickup_longitude'] ?? null;
$dropoffLatitude = $input['dropoff_latitude'] ?? null;
$dropoffLongitude = $input['dropoff_longitude'] ?? null;
$estimatedFare = $input['estimated_fare'] ?? 0;
$distanceKm = $input['distance_km'] ?? 0;

if (empty($pickupAddress) || empty($dropoffAddress)) {
    http_response_code(400);
    echo json_encode(['error' => 'Pickup and dropoff addresses are required']);
    exit();
}

try {
    $pdo = getConnection();
    
    // Create booking
    $stmt = $pdo->prepare("
        INSERT INTO bookings (
            passenger_id, pickup_address, dropoff_address, 
            pickup_latitude, pickup_longitude, dropoff_latitude, dropoff_longitude,
            estimated_fare, distance_km, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
    ");
    $stmt->execute([
        $user['id'],
        $pickupAddress,
        $dropoffAddress,
        $pickupLatitude,
        $pickupLongitude,
        $dropoffLatitude,
        $dropoffLongitude,
        $estimatedFare,
        $distanceKm
    ]);
    
    $bookingId = $pdo->lastInsertId();
    
    // Get created booking
    $stmt = $pdo->prepare("
        SELECT b.*, u.full_name as passenger_name, u.phone as passenger_phone 
        FROM bookings b 
        JOIN users u ON b.passenger_id = u.id 
        WHERE b.id = ?
    ");
    $stmt->execute([$bookingId]);
    $booking = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'message' => 'Booking created successfully',
        'booking' => $booking
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Booking creation failed', 'message' => $e->getMessage()]);
}
?>
