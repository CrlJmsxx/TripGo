<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0);

// Only start session if not already active
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$currentUser = getCurrentUser();

if (!$currentUser || $currentUser['user_type'] !== 'driver') {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

// Get driver's current location and max radius
$maxRadius = $_GET['max_radius'] ?? 50; // Default 50km
$maxRadius = min(max($maxRadius, 1), 100); // Clamp between 1-100km

try {
    // Get driver profile for current location
    $pdo = getConnection();
    $stmt = $pdo->prepare("SELECT current_latitude, current_longitude FROM driver_profiles WHERE user_id = ?");
    $stmt->execute([$currentUser['id']]);
    $driverProfile = $stmt->fetch(PDO::FETCH_ASSOC);

    // FIXED: Use strict null checks, not loose comparison (0.0 is a valid latitude on Equator)
    if (!$driverProfile || $driverProfile['current_latitude'] === null || $driverProfile['current_longitude'] === null) {
        echo json_encode(['success' => false, 'error' => 'Driver location not available']);
        exit();
    }

    $driverLat = (float) $driverProfile['current_latitude'];
    $driverLng = (float) $driverProfile['current_longitude'];

    // OPTIMIZATION 1: Use bounding box to pre-filter requests
    // Calculate approximate bounding box coordinates
    $latDelta = $maxRadius / 111.0; // 1 degree ≈ 111 km
    $lngDelta = $maxRadius / (111.0 * cos(deg2rad($driverLat)));
    
    $minLat = $driverLat - $latDelta;
    $maxLat = $driverLat + $latDelta;
    $minLng = $driverLng - $lngDelta;
    $maxLng = $driverLng + $lngDelta;

    // OPTIMIZED QUERY: First filter by bounding box, then calculate exact distance
    $stmt = $pdo->prepare("
        SELECT 
            b.*,
            u.full_name as passenger_name,
            u.phone as passenger_phone,
            (6371 * acos(
                cos(radians(?)) * 
                cos(radians(b.pickup_latitude)) * 
                cos(radians(b.pickup_longitude) - radians(?)) + 
                sin(radians(?)) * 
                sin(radians(b.pickup_latitude))
            )) as distance_km
        FROM bookings b
        JOIN users u ON b.passenger_id = u.id
        WHERE b.status = 'pending'
        AND (b.expires_at IS NULL OR b.expires_at > NOW())
        AND b.pickup_latitude IS NOT NULL
        AND b.pickup_longitude IS NOT NULL
        AND b.pickup_latitude BETWEEN ? AND ?
        AND b.pickup_longitude BETWEEN ? AND ?
        HAVING distance_km <= ?
        ORDER BY distance_km ASC
        LIMIT 100
    ");
    
    $stmt->execute([
        $driverLat, $driverLng, $driverLat, 
        $minLat, $maxLat, $minLng, $maxLng, 
        $maxRadius
    ]);
    $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // OPTIMIZATION 2: Validate and format response data safely
    $formattedRequests = [];
    $skippedCount = 0;
    
    foreach ($requests as $request) {
        // Validate coordinates before including in response
        $pickupLat = is_numeric($request['pickup_latitude']) ? (float) $request['pickup_latitude'] : null;
        $pickupLng = is_numeric($request['pickup_longitude']) ? (float) $request['pickup_longitude'] : null;
        $dropoffLat = is_numeric($request['dropoff_latitude']) ? (float) $request['dropoff_latitude'] : null;
        $dropoffLng = is_numeric($request['dropoff_longitude']) ? (float) $request['dropoff_longitude'] : null;
        
        // FIXED: Only require pickup coordinates (dropoff can be null for now)
        if ($pickupLat !== null && $pickupLng !== null) {
            $formattedRequests[] = [
                'id' => (int) $request['id'],
                'passenger_name' => $request['passenger_name'] ?? 'Unknown',
                'passenger_phone' => $request['passenger_phone'] ?? '',
                'pickup_address' => $request['pickup_address'] ?? '',
                'dropoff_address' => $request['dropoff_address'] ?? '',
                'pickup_latitude' => $pickupLat,
                'pickup_longitude' => $pickupLng,
                'dropoff_latitude' => $dropoffLat,
                'dropoff_longitude' => $dropoffLng,
                'estimated_fare' => is_numeric($request['estimated_fare']) ? (float) $request['estimated_fare'] : 0.0,
                'distance_km' => round((float) ($request['distance_km'] ?? 0), 2),
                'booking_time' => $request['booking_time'] ?? '',
                'expires_at' => $request['expires_at'] ?? null
            ];
        } else {
            $skippedCount++;
        }
    }
    
    // Log skipped requests for monitoring
    if ($skippedCount > 0) {
        error_log("get_all_requests_optimized: Skipped $skippedCount requests with invalid pickup coordinates");
    }
                      echo json_encode([
        'success' => true,
        'requests' => $formattedRequests,
        'total_found' => count($formattedRequests),
        'max_radius' => $maxRadius,
        'driver_location' => [
            'latitude' => $driverLat,
            'longitude' => $driverLng
        ],
        'performance' => [
            'bounding_box' => [
                'min_lat' => $minLat,
                'max_lat' => $maxLat,
                'min_lng' => $minLng,
                'max_lng' => $maxLng
            ],
            'pre_filtered_count' => count($requests),
            'final_count' => count($formattedRequests),
            'skipped_invalid_coordinates' => $skippedCount
        ]
    ]);
    
} catch (Exception $e) {
    error_log("Get all requests error: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'error' => 'Server error: ' . $e->getMessage()
    ]);
}
?>
