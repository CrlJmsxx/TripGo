<?php
/**
 * Centralized Push Helper
 * Provides a single function to send web-push notifications to a user's subscriptions.
 * Uses minishlink/web-push when available; otherwise falls back to logging.
 */

require_once __DIR__ . '/../config/database.php';

function sendPushNotifications($pdo, $userId, $payload, $options = []) {
    $result = [
        'success_count' => 0,
        'total_count' => 0,
        'failed' => [],
        'using_webpush' => false,
        'error' => null
    ];

    try {
        $stmt = $pdo->prepare("SELECT id, endpoint, p256dh_key, auth_key FROM push_subscriptions WHERE user_id = ?");
        $stmt->execute([$userId]);
        $subscriptions = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (empty($subscriptions)) {
            return $result;
        }

        $result['total_count'] = count($subscriptions);

        $vendorAutoload = __DIR__ . '/../vendor/autoload.php';
        $pushConfigFile = __DIR__ . '/../config/push.php';
        $useWebPush = file_exists($vendorAutoload) && file_exists($pushConfigFile);
        
        if ($useWebPush) {
            require_once $vendorAutoload;
            $pushCfg = require $pushConfigFile;

            // Validate VAPID keys are configured
            if (empty($pushCfg['public_key']) || 
                empty($pushCfg['private_key']) || 
                $pushCfg['public_key'] === 'REPLACE_WITH_YOUR_VAPID_PUBLIC_KEY' ||
                $pushCfg['private_key'] === 'REPLACE_WITH_YOUR_VAPID_PRIVATE_KEY') {
                error_log('[push_helper] VAPID keys not configured. Please update config/push.php with your VAPID keys.');
                $useWebPush = false;
            }
        }

        $result['using_webpush'] = $useWebPush;

        if ($useWebPush) {
            try {
                $auth = [
                    'VAPID' => [
                        'subject' => $pushCfg['subject'] ?? 'mailto:admin@example.com',
                        'publicKey' => $pushCfg['public_key'],
                        'privateKey' => $pushCfg['private_key']
                    ]
                ];

                /** @var \Minishlink\WebPush\WebPush $webPush */
                $webPush = new Minishlink\WebPush\WebPush($auth);

                // Queue all notifications
                foreach ($subscriptions as $sub) {
                    try {
                        $subscriptionArray = [
                            'endpoint' => $sub['endpoint'],
                            'keys' => [
                                'p256dh' => $sub['p256dh_key'],
                                'auth' => $sub['auth_key']
                            ]
                        ];

                        $webPush->queueNotification(
                            $subscriptionArray, 
                            $payload,
                            [
                                'TTL' => $options['ttl'] ?? 3600, // Default 1 hour
                                'urgency' => $options['urgency'] ?? 'normal' // normal, very-low, low, high
                            ]
                        );
                    } catch (Exception $e) {
                        error_log('[push_helper] Error queueing notification: ' . $e->getMessage());
                        $result['failed'][] = [
                            'endpoint' => $sub['endpoint'], 
                            'reason' => 'Queue error: ' . $e->getMessage()
                        ];
                    }
                }

                $failedEndpoints = [];

                // Flush notifications and process results
                foreach ($webPush->flush() as $report) {
                    $endpoint = (string) $report->getRequest()->getUri();
                    if ($report->isSuccess()) {
                        $result['success_count']++;
                    } else {
                        $failedEndpoints[] = $endpoint;
                        $reason = $report->getReason();
                        $result['failed'][] = [
                            'endpoint' => $endpoint, 
                            'reason' => $reason
                        ];
                        
                        // Log failure details
                        error_log('[push_helper] Push failed to ' . $endpoint . ': ' . $reason);
                    }
                }

                // Optional retry for transient failures
                $retry = intval($options['retry'] ?? 0);
                if ($retry > 0 && !empty($failedEndpoints)) {
                    // Create a new WebPush instance for retry
                    $retryWebPush = new Minishlink\WebPush\WebPush($auth);
                    
                    // Re-queue failed subscriptions only
                    foreach ($subscriptions as $sub) {
                        if (in_array($sub['endpoint'], $failedEndpoints, true)) {
                            try {
                                $subscriptionArray = [
                                    'endpoint' => $sub['endpoint'],
                                    'keys' => [
                                        'p256dh' => $sub['p256dh_key'],
                                        'auth' => $sub['auth_key']
                                    ]
                                ];
                                $retryWebPush->queueNotification($subscriptionArray, $payload);
                            } catch (Exception $e) {
                                error_log('[push_helper] Error queueing retry notification: ' . $e->getMessage());
                            }
                        }
                    }

                    // Process retry results
                    foreach ($retryWebPush->flush() as $report) {
                        $endpoint = (string) $report->getRequest()->getUri();
                        if ($report->isSuccess()) {
                            $result['success_count']++;
                            // Remove from failed list
                            $result['failed'] = array_filter($result['failed'], function($f) use ($endpoint) {
                                return $f['endpoint'] !== $endpoint;
                            });
                        }
                    }
                }

                // Remove permanently failed subscriptions (410 Gone, 404 Not Found, etc.)
                foreach ($result['failed'] as $f) {
                    $reason = $f['reason'] ?? '';
                    // Remove subscriptions that are permanently invalid
                    if (stripos($reason, '410') !== false || 
                        stripos($reason, '404') !== false ||
                        stripos($reason, 'Gone') !== false ||
                        stripos($reason, 'Not Found') !== false) {
                        try {
                            $stmtDel = $pdo->prepare("DELETE FROM push_subscriptions WHERE endpoint = ?");
                            $stmtDel->execute([$f['endpoint']]);
                            error_log('[push_helper] Removed invalid subscription: ' . $f['endpoint']);
                        } catch (Exception $e) {
                            error_log('[push_helper] Error removing subscription: ' . $e->getMessage());
                        }
                    }
                }

            } catch (Exception $e) {
                error_log('[push_helper] WebPush error: ' . $e->getMessage());
                $result['error'] = $e->getMessage();
                // Fall through to fallback behavior
                $useWebPush = false;
            }
        }

        // Fallback: simulate sends if web-push is not available
        if (!$useWebPush) {
            foreach ($subscriptions as $sub) {
                error_log('[push_helper] Simulated push to: ' . $sub['endpoint']);
                error_log('[push_helper] Payload: ' . $payload);
                $result['success_count']++;
            }
        }

        return $result;

    } catch (Exception $e) {
        error_log('[push_helper] Error sending push: ' . $e->getMessage());
        $result['error'] = $e->getMessage();
        return $result;
    }
}
