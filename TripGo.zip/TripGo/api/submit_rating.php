<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';

session_start();
$currentUser = getCurrentUser();

if (!$currentUser || $currentUser['user_type'] !== 'passenger') {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);
$bookingId = $data['booking_id'] ?? 0;
$rating = $data['rating'] ?? 0;
$review = $data['review'] ?? '';

// Validate input
if (!$bookingId || $rating < 1 || $rating > 5) {
    echo json_encode(['success' => false, 'error' => 'Invalid input']);
    exit();
}

try {
    $pdo = getConnection();
    
    // Start transaction
    $pdo->beginTransaction();
    
    // Verify booking belongs to current passenger and is completed
    $stmt = $pdo->prepare("
        SELECT b.*, u.full_name as driver_name 
        FROM bookings b 
        LEFT JOIN users u ON b.driver_id = u.id 
        WHERE b.id = ? AND b.passenger_id = ? AND b.status = 'completed'
    ");
    $stmt->execute([$bookingId, $currentUser['id']]);
    $booking = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$booking) {
        echo json_encode(['success' => false, 'error' => 'Invalid booking']);
        exit();
    }
    
    // Check if rating already exists (integrity check)
    $stmt = $pdo->prepare("SELECT id FROM reviews WHERE booking_id = ? AND passenger_id = ?");
    $stmt->execute([$bookingId, $currentUser['id']]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'error' => 'Rating already submitted']);
        exit();
    }
    
    // Insert the rating
    $stmt = $pdo->prepare("
        INSERT INTO reviews (booking_id, passenger_id, driver_id, rating, review)
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([$bookingId, $currentUser['id'], $booking['driver_id'], $rating, $review]);
    
    // Update booking as rated
    try {
        $stmt = $pdo->prepare("UPDATE bookings SET rating_submitted = 1 WHERE id = ?");
        $stmt->execute([$bookingId]);
    } catch (PDOException $e) {
        // Column might not exist, continue anyway
        if (strpos($e->getMessage(), 'rating_submitted') === false) {
            throw $e;
        }
    }
    
    // Recalculate driver's average rating
    $stmt = $pdo->prepare("
        UPDATE users u SET average_rating = (
            SELECT AVG(rating) 
            FROM reviews r 
            WHERE r.driver_id = u.id
        ) WHERE u.id = ?
    ");
    $stmt->execute([$booking['driver_id']]);
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Rating submitted successfully!',
        'driver_name' => $booking['driver_name']
    ]);
    
} catch (Exception $e) {
    if (isset($pdo)) {
        $pdo->rollback();
    }
    error_log("Rating submission error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Server error']);
}
?>
