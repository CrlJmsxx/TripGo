<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';
require_once '../config/session.php';

try {
    $pdo = getConnection();
    $currentUser = getCurrentUser();
    
    if (!$currentUser) {
        echo json_encode(['success' => false, 'error' => 'Not authenticated']);
        exit();
    }
    
    // Get the most recent active booking for the current user
    $stmt = $pdo->prepare("
        SELECT b.*, u.full_name as driver_name, u.rating as driver_rating,
               dp.vehicle_type, dp.license_plate,
               (6371 * acos(cos(radians(b.pickup_latitude)) * cos(radians(dp.current_latitude)) * 
               cos(radians(dp.current_longitude) - radians(b.pickup_longitude)) + 
               sin(radians(b.pickup_latitude)) * sin(radians(dp.current_latitude)))) as distance
        FROM bookings b
        LEFT JOIN users u ON b.driver_id = u.id
        LEFT JOIN driver_profiles dp ON b.driver_id = dp.user_id
        WHERE b.passenger_id = ? 
        AND b.status IN ('pending', 'accepted', 'in_progress')
        ORDER BY b.created_at DESC
        LIMIT 1
    ");
    $stmt->execute([$currentUser['id']]);
    $booking = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$booking) {
        echo json_encode(['success' => false, 'active' => false]);
        exit();
    }
    
    // Check if booking has expired (no driver acceptance within time limit)
    if ($booking['status'] === 'pending' && $booking['expires_at']) {
        $expires_at = new DateTime($booking['expires_at']);
        $now = new DateTime();
        
        if ($now > $expires_at) {
            // Update booking to expired
            $stmt = $pdo->prepare("UPDATE bookings SET status = 'expired' WHERE id = ?");
            $stmt->execute([$booking['id']]);
            $booking['status'] = 'expired';
            echo json_encode(['success' => false, 'active' => false]);
            exit();
        }
    }
    
    // Prepare response data
    $response = [
        'success' => true,
        'active' => true,
        'status' => $booking['status'],
        'booking_id' => $booking['id'],
        'booking_time' => $booking['booking_time'],
        'estimated_fare' => $booking['estimated_fare'],
        'distance_km' => $booking['distance_km'],
        'pickup_address' => $booking['pickup_address'],
        'dropoff_address' => $booking['dropoff_address'],
        'rating_requested' => $booking['rating_requested'] ?? false
    ];
    
    // Add driver details if accepted or in_progress
    if ($booking['status'] === 'accepted' || $booking['status'] === 'in_progress') {
        $response['driver'] = [
            'id' => $booking['driver_id'],
            'full_name' => $booking['driver_name'],
            'rating' => $booking['driver_rating'] ? number_format($booking['driver_rating'], 1) : '4.8',
            'vehicle_type' => $booking['vehicle_type'] ?: 'Sedan',
            'license_plate' => $booking['license_plate'] ?: 'N/A',
            'distance' => $booking['distance'] ? round($booking['distance'], 1) : null,
            'estimated_arrival' => calculateETA($booking['distance']),
            'phone' => getDriverPhone($pdo, $booking['driver_id'])
        ];
    }
    
    // Add cancellation details if cancelled
    if ($booking['status'] === 'cancelled') {
        $response['cancellation_reason'] = $booking['cancellation_reason'];
        $response['cancelled_by'] = $booking['cancelled_by'];
        $response['cancelled_at'] = $booking['cancelled_at'];
    }
    
    echo json_encode($response);
    
} catch (Exception $e) {
    error_log('Error getting active booking: ' . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Failed to check active booking']);
}

function calculateETA($distance) {
    if (!$distance) return '5 mins';
    
    // Average speed in city: 30 km/h
    $time_minutes = ($distance / 30) * 60;
    
    if ($time_minutes < 1) {
        return 'Arriving';
    } elseif ($time_minutes < 60) {
        return round($time_minutes) . ' mins';
    } else {
        $hours = floor($time_minutes / 60);
        $minutes = round($time_minutes % 60);
        return $hours . 'h ' . $minutes . 'm';
    }
}

function getDriverPhone($pdo, $driver_id) {
    if (!$driver_id) return null;
    
    try {
        $stmt = $pdo->prepare("SELECT phone FROM users WHERE id = ?");
        $stmt->execute([$driver_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        return $user['phone'] ?? null;
    } catch (Exception $e) {
        return null;
    }
}
?>

