<?php
/**
 * Performance Index Migration
 * 
 * This script safely adds missing indexes to optimize the "Filter All Requests" feature.
 * It checks if indexes exist before adding them to avoid duplicate key errors.
 * 
 * Use: Run this from CLI or open in browser if authenticated as admin
 * Example: php api/add_performance_indexes.php
 */

require_once __DIR__ . '/../config/database.php';

// CLI mode or web mode check
$isCli = php_sapi_name() === 'cli';
$isWeb = !$isCli;

// Output function for both CLI and web
function output($message, $type = 'info') {
    global $isCli;
    if ($isCli) {
        $colors = [
            'info' => "\033[34m",    // Blue
            'success' => "\033[32m", // Green
            'warning' => "\033[33m", // Yellow
            'error' => "\033[31m",   // Red
            'reset' => "\033[0m"
        ];
        $color = $colors[$type] ?? $colors['info'];
        echo $color . $message . $colors['reset'] . PHP_EOL;
    } else {
        $bgColor = [
            'info' => '#d1ecf1',
            'success' => '#d4edda',
            'warning' => '#fff3cd',
            'error' => '#f8d7da'
        ];
        $textColor = [
            'info' => '#0c5460',
            'success' => '#155724',
            'warning' => '#856404',
            'error' => '#721c24'
        ];
        $bg = $bgColor[$type] ?? $bgColor['info'];
        $text = $textColor[$type] ?? $textColor['info'];
        echo "<div style='background-color: $bg; color: $text; padding: 10px; margin: 10px 0; border-radius: 4px; border-left: 4px solid $text;'>
                $message
              </div>";
    }
}

// Check if index exists
function indexExists($pdo, $tableName, $indexName) {
    try {
        // Sanitize table name to avoid injection via dynamic table names
        $safeTable = preg_replace('/[^0-9a-zA-Z_]/', '', $tableName);
        $stmt = $pdo->prepare("SHOW INDEX FROM `$safeTable` WHERE Key_name = ?");
        $stmt->execute([$indexName]);
        return $stmt->rowCount() > 0;
    } catch (Exception $e) {
        return false;
    }
}

// Main execution
try {
    echo $isWeb ? '<h2>Performance Index Migration</h2>' : "\n=== Performance Index Migration ===\n\n";
    
    output('Connecting to database...', 'info');
    $pdo = getConnection();
    output('✓ Database connection successful', 'success');
    
    // List of indexes to add
    $indexes = [
        // Table, Index Name, Index Definition
        ['bookings', 'idx_status_location', 'status, pickup_latitude, pickup_longitude'],
        ['bookings', 'idx_expires_at', 'expires_at'],
        ['bookings', 'idx_pending_status', 'status, booking_time'],
        ['driver_profiles', 'idx_user_location', 'user_id, current_latitude, current_longitude'],
    ];
    
    $addedCount = 0;
    $skippedCount = 0;
    
    echo $isWeb ? '<h3>Index Status:</h3>' : "\nIndex Status:\n";
    
    foreach ($indexes as [$table, $indexName, $columns]) {
        if (indexExists($pdo, $table, $indexName)) {
            output("⊘ Index $indexName on $table already exists - SKIPPED", 'warning');
            $skippedCount++;
        } else {
            try {
                // Sanitize table name for DDL
                $safeTable = preg_replace('/[^0-9a-zA-Z_]/', '', $table);
                $sql = "ALTER TABLE `$safeTable` ADD INDEX `$indexName` ($columns)";
                $pdo->exec($sql);
                output("✓ Index $indexName on $table created successfully", 'success');
                $addedCount++;
            } catch (PDOException $e) {
                // MySQL error code is in $e->errorInfo[1] when using PDO
                $errno = isset($e->errorInfo[1]) ? (int)$e->errorInfo[1] : null;
                if ($errno === 1061) {
                    // Duplicate key name - treat as already existing and skip
                    output("⊘ Index $indexName on $table already exists (duplicate key) - SKIPPED", 'warning');
                    $skippedCount++;
                } else {
                    output("✗ Failed to create index $indexName on $table: " . $e->getMessage(), 'error');
                }
            } catch (Exception $e) {
                output("✗ Failed to create index $indexName on $table: " . $e->getMessage(), 'error');
            }
        }
    }
    
    echo $isWeb ? '<h3>Summary:</h3>' : "\n=== Summary ===\n";
    output("Indexes created: $addedCount", 'success');
    output("Indexes skipped (already exist): $skippedCount", 'warning');
    
    // Verify indexes
    echo $isWeb ? '<h3>Verification - Current Indexes:</h3>' : "\n=== Verification - Current Indexes ===\n";
    
    foreach (['bookings', 'driver_profiles'] as $table) {
        output("\nIndexes on $table:", 'info');
        $stmt = $pdo->query("SHOW INDEX FROM $table");
        $indexData = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if ($isWeb) {
            echo '<table style="border-collapse: collapse; width: 100%; margin: 10px 0;">';
            echo '<tr style="background: #f5f5f5;">';
            echo '<th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Key Name</th>';
            echo '<th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Column Name</th>';
            echo '</tr>';
            foreach ($indexData as $idx) {
                echo '<tr><td style="border: 1px solid #ddd; padding: 8px;">' . htmlspecialchars($idx['Key_name']) . '</td>';
                echo '<td style="border: 1px solid #ddd; padding: 8px;">' . htmlspecialchars($idx['Column_name']) . '</td></tr>';
            }
            echo '</table>';
        } else {
            foreach ($indexData as $idx) {
                echo "  - " . $idx['Key_name'] . " on " . $idx['Column_name'] . PHP_EOL;
            }
        }
    }
    
    output("\n✓ Migration completed successfully!", 'success');
    
} catch (Exception $e) {
    output("Fatal error: " . $e->getMessage(), 'error');
    if (!$isCli) {
        http_response_code(500);
    }
    exit(1);
}

// Output HTML footer if web mode
if ($isWeb) {
    echo '<hr style="margin: 20px 0;"><p style="color: #666; font-size: 0.9rem;">
    <strong>Next steps:</strong> Test the "Filter All Requests" feature in the driver dashboard to verify improved performance.
    </p>';
}
?>
