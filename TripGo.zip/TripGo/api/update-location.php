<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';
require_once '../config/session.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit();
}

// Check if user is logged in
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$currentUser = getCurrentUser();

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON input']);
    exit();
}

// Validate required fields
$requiredFields = ['latitude', 'longitude', 'timestamp'];
foreach ($requiredFields as $field) {
    if (!isset($input[$field])) {
        http_response_code(400);
        echo json_encode(['error' => "Missing required field: $field"]);
        exit();
    }
}

try {
    $pdo = getConnection();
    
    // Update driver location
    if ($currentUser['user_type'] === 'driver') {
        $stmt = $pdo->prepare("
            UPDATE driver_profiles 
            SET current_latitude = ?, current_longitude = ? 
            WHERE user_id = ?
        ");
        $stmt->execute([
            $input['latitude'],
            $input['longitude'],
            $currentUser['id']
        ]);
    }
    
    // Log location update
    $stmt = $pdo->prepare("
        INSERT INTO ride_tracking (driver_id, driver_latitude, driver_longitude, status_update, timestamp) 
        VALUES (?, ?, ?, ?, NOW())
    ");
    $stmt->execute([
        $currentUser['id'],
        $input['latitude'],
        $input['longitude'],
        'Location updated'
    ]);
    
    // Get active booking for this driver
    $stmt = $pdo->prepare("
        SELECT id, passenger_id, status 
        FROM bookings 
        WHERE driver_id = ? AND status IN ('accepted', 'in_progress')
        ORDER BY booking_time DESC 
        LIMIT 1
    ");
    $stmt->execute([$currentUser['id']]);
    $activeBooking = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($activeBooking) {
        // Update booking with driver location
        $stmt = $pdo->prepare("
            UPDATE bookings 
            SET driver_latitude = ?, driver_longitude = ? 
            WHERE id = ?
        ");
        $stmt->execute([
            $input['latitude'],
            $input['longitude'],
            $activeBooking['id']
        ]);
        
        // Notify passenger of driver location
        notifyPassenger($activeBooking['passenger_id'], $input);
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Location updated successfully',
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Database error',
        'message' => $e->getMessage()
    ]);
}

// Function to notify passenger
function notifyPassenger($passengerId, $locationData) {
    // In a real implementation, this would send push notifications
    // For now, we'll just log the notification
    error_log("Notification sent to passenger $passengerId: Driver location updated");
}
?>
