<?php
/**
 * Get VAPID Public Key API
 * Returns the VAPID public key for use in the frontend push subscription
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$pushConfigFile = __DIR__ . '/../config/push.php';

if (!file_exists($pushConfigFile)) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Push configuration not found'
    ]);
    exit();
}

try {
    $pushCfg = require $pushConfigFile;
    
    $publicKey = $pushCfg['public_key'] ?? null;
    
    if (empty($publicKey) || $publicKey === 'REPLACE_WITH_YOUR_VAPID_PUBLIC_KEY') {
        http_response_code(503);
        echo json_encode([
            'error' => 'VAPID keys not configured',
            'message' => 'Please configure VAPID keys in config/push.php'
        ]);
        exit();
    }
    
    echo json_encode([
        'success' => true,
        'publicKey' => $publicKey
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Failed to load VAPID configuration',
        'message' => $e->getMessage()
    ]);
}

