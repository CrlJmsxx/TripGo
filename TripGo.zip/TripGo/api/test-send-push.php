<?php
// Local-only test endpoint to send a push to a single driver (for QA)
header('Content-Type: application/json');

require_once '../config/database.php';
require_once '../config/session.php';
require_once __DIR__ . '/push_helper.php';

// Allow only local requests (127.0.0.1 or ::1) for safety in this test endpoint
$remote = $_SERVER['REMOTE_ADDR'] ?? '';
if (!in_array($remote, ['127.0.0.1', '::1'], true)) {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden: test endpoint only allowed from localhost']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON input']);
    exit();
}

$driverId = intval($input['driver_id'] ?? 0);
$title = $input['title'] ?? 'Test Notification';
$body = $input['body'] ?? 'This is a test push notification';
$bookingId = $input['booking_id'] ?? null;

if ($driverId <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'driver_id is required']);
    exit();
}

$pdo = getConnection();

// Insert a driver_notifications row for QA visibility
try {
    $stmt = $pdo->prepare("INSERT INTO driver_notifications (driver_id, booking_id, notification_type, message, created_at) VALUES (?, ?, 'test_push', ?, NOW())");
    $message = $body;
    $stmt->execute([$driverId, $bookingId, $message]);
} catch (Exception $e) {
    // continue even if logging fails
}

$payload = json_encode([
    'title' => $title,
    'body' => $body,
    'data' => ['booking_id' => $bookingId],
    'timestamp' => time()
]);

$result = sendPushNotifications($pdo, $driverId, $payload, ['retry' => 1]);

echo json_encode(['success' => true, 'result' => $result]);

?>
