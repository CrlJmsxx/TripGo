<?php
require_once 'config/database.php';

// Process expired ride requests
function processExpiredRides() {
    try {
        $pdo = getConnection();
        
        // Find rides that have expired
        $stmt = $pdo->prepare("
            UPDATE bookings 
            SET status = 'expired', 
                cancelled_by = 'system', 
                cancellation_reason = 'Request expired - no driver available within time limit',
                cancelled_at = NOW()
            WHERE status IN ('pending', 'searching') 
            AND expires_at <= NOW()
        ");
        
        $expiredCount = $stmt->rowCount();
        
        return [
            'success' => true,
            'expired_count' => $expiredCount,
            'message' => "Processed {$expiredCount} expired ride requests"
        ];
        
    } catch (Exception $e) {
        return [
            'success' => false,
            'error' => 'Database error: ' . $e->getMessage()
        ];
    }
}

// Set expiry time for new bookings (60 seconds from creation)
function setBookingExpiry($bookingId) {
    try {
        $pdo = getConnection();
        
        $stmt = $pdo->prepare("
            UPDATE bookings 
            SET expires_at = DATE_ADD(NOW(), INTERVAL 60 SECOND)
            WHERE id = ? AND status = 'pending'
        ");
        
        $stmt->execute([$bookingId]);
        
        return $stmt->rowCount() > 0;
        
    } catch (Exception $e) {
        error_log("Error setting booking expiry: " . $e->getMessage());
        return false;
    }
}

// Handle API requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'process_expired':
            $result = processExpiredRides();
            echo json_encode($result);
            break;
            
        case 'set_expiry':
            $bookingId = $_POST['booking_id'] ?? '';
            if (!empty($bookingId)) {
                $success = setBookingExpiry($bookingId);
                echo json_encode([
                    'success' => $success,
                    'message' => $success ? 'Expiry time set' : 'Failed to set expiry time'
                ]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Booking ID required']);
            }
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
            break;
    }
} else {
    // For direct access or cron jobs
    header('Content-Type: application/json');
    $result = processExpiredRides();
    echo json_encode($result);
}
?>
