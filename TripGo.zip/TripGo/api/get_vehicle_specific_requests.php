<?php
require_once '../config/database.php';
require_once '../config/session.php';

header('Content-Type: application/json');

// Get current driver
$currentUser = getCurrentUser();
if (!$currentUser || $currentUser['user_type'] !== 'driver') {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

$pdo = getConnection();

// Get driver's vehicle type
$stmt = $pdo->prepare("SELECT vehicle_type, is_available FROM driver_profiles WHERE user_id = ?");
$stmt->execute([$currentUser['id']]);
$driverProfile = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$driverProfile || !$driverProfile['vehicle_type']) {
    echo json_encode(['success' => false, 'error' => 'Driver vehicle type not set']);
    exit();
}

if (!$driverProfile['is_available']) {
    echo json_encode(['success' => false, 'error' => 'Driver not available']);
    exit();
}

$driverVehicleType = $driverProfile['vehicle_type'];

// Get ride requests matching driver's vehicle type
try {
    $stmt = $pdo->prepare("
        SELECT b.*, u.full_name as passenger_name, u.phone as passenger_phone,
               (6371 * acos(cos(radians(?)) * cos(radians(b.pickup_latitude)) * 
               cos(radians(b.pickup_longitude) - radians(?)) + sin(radians(?)) * 
               sin(radians(b.pickup_latitude)))) AS distance_km
        FROM bookings b
        JOIN users u ON b.passenger_id = u.id
        WHERE b.status = 'pending'
        AND b.vehicle_type = ?
        AND b.created_at >= DATE_SUB(NOW(), INTERVAL 30 MINUTE)
        AND b.expires_at > NOW()
        HAVING distance_km <= 20
        ORDER BY distance_km ASC, b.created_at ASC
        LIMIT 50
    ");
    
    // Get driver's current location (default to city center if not set)
    $driverLat = $driverProfile['current_latitude'] ?? 12.8797;
    $driverLng = $driverProfile['current_longitude'] ?? 121.7740;
    
    $stmt->execute([$driverLat, $driverLng, $driverLat, $driverVehicleType]);
    $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format response
    $formattedRequests = [];
    foreach ($requests as $request) {
        $formattedRequests[] = [
            'id' => $request['id'],
            'pickup_address' => $request['pickup_address'],
            'dropoff_address' => $request['dropoff_address'],
            'pickup_latitude' => $request['pickup_latitude'],
            'pickup_longitude' => $request['pickup_longitude'],
            'dropoff_latitude' => $request['dropoff_latitude'],
            'dropoff_longitude' => $request['dropoff_longitude'],
            'estimated_fare' => $request['estimated_fare'],
            'distance_km' => round($request['distance_km'], 2),
            'vehicle_type' => $request['vehicle_type'],
            'passenger_name' => $request['passenger_name'],
            'passenger_phone' => $request['passenger_phone'],
            'created_at' => $request['created_at'],
            'expires_at' => $request['expires_at'],
            'time_remaining' => max(0, strtotime($request['expires_at']) - time())
        ];
    }
    
    echo json_encode([
        'success' => true,
        'requests' => $formattedRequests,
        'driver_vehicle_type' => $driverVehicleType,
        'total_requests' => count($formattedRequests)
    ]);
    
} catch (Exception $e) {
    error_log("Error getting vehicle-specific requests: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Failed to fetch requests']);
}
?>
