<?php
// Free geocoding service using Nominatim (OpenStreetMap)
function geocodeAddress($address) {
    $url = 'https://nominatim.openstreetmap.org/search?format=json&q=' . urlencode($address) . '&limit=1';
    
    $options = [
        'http' => [
            'header' => 'User-Agent: TripGO/1.0 (https://tripgo.com; contact@tripgo.com)'
        ]
    ];
    
    $context = stream_context_create($options);
    $response = file_get_contents($url, false, $context);
    
    if ($response === false) {
        return null;
    }
    
    $data = json_decode($response, true);
    
    if (empty($data) || !isset($data[0])) {
        return null;
    }
    
    $result = $data[0];
    
    return [
        'latitude' => floatval($result['lat']),
        'longitude' => floatval($result['lon']),
        'display_name' => $result['display_name'] ?? $address,
        'address' => $result['address'] ?? []
    ];
}

// Reverse geocoding - get address from coordinates
function reverseGeocode($latitude, $longitude) {
    $url = "https://nominatim.openstreetmap.org/reverse?format=json&lat=$latitude&lon=$longitude";
    
    $options = [
        'http' => [
            'header' => 'User-Agent: TripGO/1.0 (https://tripgo.com; contact@tripgo.com)'
        ]
    ];
    
    $context = stream_context_create($options);
    $response = file_get_contents($url, false, $context);
    
    if ($response === false) {
        return null;
    }
    
    $data = json_decode($response, true);
    
    if (isset($data['error'])) {
        return null;
    }
    
    return [
        'display_name' => $data['display_name'] ?? 'Unknown Location',
        'address' => $data['address'] ?? [],
        'latitude' => $latitude,
        'longitude' => $longitude
    ];
}

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    if ($_POST['action'] === 'geocode') {
        $address = $_POST['address'] ?? '';
        $result = geocodeAddress($address);
        
        if ($result) {
            echo json_encode([
                'success' => true,
                'data' => $result
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'error' => 'Address not found'
            ]);
        }
    } elseif ($_POST['action'] === 'reverse_geocode') {
        $latitude = $_POST['latitude'] ?? '';
        $longitude = $_POST['longitude'] ?? '';
        
        if (is_numeric($latitude) && is_numeric($longitude)) {
            $result = reverseGeocode($latitude, $longitude);
            
            if ($result) {
                echo json_encode([
                    'success' => true,
                    'data' => $result
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'error' => 'Location not found'
                ]);
            }
        } else {
            echo json_encode([
                'success' => false,
                'error' => 'Invalid coordinates'
            ]);
        }
    }
    exit();
}
?>
