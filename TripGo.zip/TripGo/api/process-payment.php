<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';
require_once '../config/session.php';

// Process card payment (Stripe integration)
function processCardPayment($input, $amount) {
    // In a real implementation, you would integrate with Stripe
    // For demo purposes, we'll simulate a successful payment
    
    $stripeSecretKey = STRIPE_SECRET_KEY;
    
    // Simulate Stripe API call
    $transactionId = 'stripe_' . time() . '_' . rand(1000, 9999);
    
    return [
        'transaction_id' => $transactionId,
        'status' => 'paid'
    ];
}

// Process PayPal payment
function processPayPalPayment($input, $amount) {
    // In a real implementation, you would integrate with PayPal
    // For demo purposes, we'll simulate a successful payment
    
    $transactionId = 'paypal_' . time() . '_' . rand(1000, 9999);
    
    return [
        'transaction_id' => $transactionId,
        'status' => 'paid'
    ];
}

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit();
}

// Check if user is logged in
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$currentUser = getCurrentUser();

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON input']);
    exit();
}

$paymentMethod = $input['payment_method'] ?? '';
$bookingId = $input['booking_id'] ?? '';
$amount = $input['amount'] ?? 0;

try {
    $pdo = getConnection();
    
    // Get booking details
    $stmt = $pdo->prepare("
        SELECT * FROM bookings 
        WHERE id = ? AND passenger_id = ?
    ");
    $stmt->execute([$bookingId, $currentUser['id']]);
    $booking = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$booking) {
        throw new Exception('Booking not found');
    }
    
    // Process payment based on method
    $transactionId = null;
    $paymentStatus = 'pending';
    
    switch ($paymentMethod) {
        case 'card':
            $result = processCardPayment($input, $amount);
            $transactionId = $result['transaction_id'];
            $paymentStatus = $result['status'];
            break;
            
        case 'paypal':
            $result = processPayPalPayment($input, $amount);
            $transactionId = $result['transaction_id'];
            $paymentStatus = $result['status'];
            break;
            
        case 'cash':
            $transactionId = 'CASH_' . time();
            $paymentStatus = 'pending';
            break;
            
        default:
            throw new Exception('Invalid payment method');
    }
    
    // Update booking with payment info
    $stmt = $pdo->prepare("
        UPDATE bookings 
        SET payment_method = ?, payment_status = ?, transaction_id = ?
        WHERE id = ?
    ");
    $stmt->execute([
        $paymentMethod,
        $paymentStatus,
        $transactionId,
        $bookingId
    ]);
    
    // Log payment transaction
    $stmt = $pdo->prepare("
        INSERT INTO payment_transactions (booking_id, user_id, payment_method, amount, transaction_id, status, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, NOW())
    ");
    $stmt->execute([
        $bookingId,
        $currentUser['id'],
        $paymentMethod,
        $amount,
        $transactionId,
        $paymentStatus
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Payment processed successfully',
        'transaction_id' => $transactionId,
        'payment_status' => $paymentStatus
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Payment processing failed',
        'message' => $e->getMessage()
    ]);
}

?>
