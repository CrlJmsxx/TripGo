<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display errors in JSON response

// Only start session if not already active
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$currentUser = getCurrentUser();

if (!$currentUser || $currentUser['user_type'] !== 'driver') {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

// Get driver's current location and max radius
$maxRadius = $_GET['max_radius'] ?? 50; // Default 50km
$maxRadius = min(max($maxRadius, 1), 100); // Clamp between 1-100km

try {
    // Get driver profile for current location
    $pdo = getConnection();
    $stmt = $pdo->prepare("SELECT current_latitude, current_longitude FROM driver_profiles WHERE user_id = ?");
    $stmt->execute([$currentUser['id']]);
    $driverProfile = $stmt->fetch(PDO::FETCH_ASSOC);

    // FIXED: Use strict null checks, not loose comparison (0.0 is a valid latitude on Equator)
    if (!$driverProfile || $driverProfile['current_latitude'] === null || $driverProfile['current_longitude'] === null) {
        echo json_encode(['success' => false, 'error' => 'Driver location not available']);
        exit();
    }

    $driverLat = $driverProfile['current_latitude'];
    $driverLng = $driverProfile['current_longitude'];

    // Haversine formula query to calculate distances
    $stmt = $pdo->prepare("
        SELECT 
            b.*,
            u.full_name as passenger_name,
            u.phone as passenger_phone,
            (6371 * acos(
                cos(radians(?)) * 
                cos(radians(b.pickup_latitude)) * 
                cos(radians(b.pickup_longitude) - radians(?)) + 
                sin(radians(?)) * 
                sin(radians(b.pickup_latitude))
            )) as distance_km
        FROM bookings b
        JOIN users u ON b.passenger_id = u.id
        WHERE b.status = 'pending'
        AND (b.expires_at IS NULL OR b.expires_at > NOW())
        AND b.pickup_latitude IS NOT NULL
        AND b.pickup_longitude IS NOT NULL
        HAVING distance_km <= ?
        ORDER BY distance_km ASC
        LIMIT 100
    ");
    
    $stmt->execute([$driverLat, $driverLng, $driverLat, $maxRadius]);
    $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format response data
    $formattedRequests = [];
    foreach ($requests as $request) {
        $formattedRequests[] = [
            'id' => $request['id'],
            'passenger_name' => $request['passenger_name'],
            'passenger_phone' => $request['passenger_phone'],
            'pickup_address' => $request['pickup_address'],
            'dropoff_address' => $request['dropoff_address'],
            'pickup_latitude' => (float) $request['pickup_latitude'],
            'pickup_longitude' => (float) $request['pickup_longitude'],
            'dropoff_latitude' => (float) $request['dropoff_latitude'],
            'dropoff_longitude' => (float) $request['dropoff_longitude'],
            'estimated_fare' => (float) $request['estimated_fare'],
            'distance_km' => round($request['distance_km'], 2),
            'booking_time' => $request['booking_time'],
            'expires_at' => $request['expires_at']
        ];
    }
    
    echo json_encode([
        'success' => true,
        'requests' => $formattedRequests,
        'total_found' => count($formattedRequests),
        'max_radius' => $maxRadius,
        'driver_location' => [
            'latitude' => (float) $driverLat,
            'longitude' => (float) $driverLng
        ]
    ]);
    
} catch (Exception $e) {
    error_log("Get all requests error: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'error' => 'Server error: ' . $e->getMessage()
    ]);
}
?>
