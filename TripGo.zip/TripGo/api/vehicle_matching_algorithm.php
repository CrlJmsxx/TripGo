<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once __DIR__ . '/push_helper.php';

header('Content-Type: application/json');

/**
 * Vehicle Type Matching Algorithm
 * 
 * This algorithm matches passenger ride requests with available drivers
 * based on vehicle type, location proximity, and availability status.
 */

class VehicleMatchingAlgorithm {
    private $pdo;
    
    public function __construct() {
        $this->pdo = getConnection();
    }
    
    /**
     * Find matching drivers for a ride request
     * 
     * @param string $vehicleType The vehicle type requested
     * @param float $pickupLat Pickup latitude
     * @param float $pickupLng Pickup longitude
     * @param int $maxDistance Maximum distance in km (default: 20)
     * @return array Matching drivers with distance and score
     */
    public function findMatchingDrivers($vehicleType, $pickupLat, $pickupLng, $maxDistance = 20) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT 
                    dp.user_id as driver_id,
                    u.full_name as driver_name,
                    u.phone as driver_phone,
                    dp.vehicle_type,
                    dp.vehicle_brand,
                    dp.vehicle_model,
                    dp.vehicle_plate,
                    dp.vehicle_capacity,
                    dp.current_latitude,
                    dp.current_longitude,
                    dp.rating,
                    (6371 * acos(
                        cos(radians(?)) * cos(radians(dp.current_latitude)) * 
                        cos(radians(dp.current_longitude) - radians(?)) + 
                        sin(radians(?)) * sin(radians(dp.current_latitude))
                    )) AS distance_km,
                    CASE 
                        WHEN dp.rating >= 4.5 THEN 3
                        WHEN dp.rating >= 4.0 THEN 2
                        WHEN dp.rating >= 3.5 THEN 1
                        ELSE 0
                    END as rating_score,
                    CASE 
                        WHEN dp.current_latitude IS NOT NULL AND dp.current_longitude IS NOT NULL THEN 1
                        ELSE 0
                    END as location_score
                FROM driver_profiles dp
                JOIN users u ON dp.user_id = u.id
                WHERE dp.vehicle_type = ?
                AND dp.is_available = TRUE
                AND dp.current_latitude IS NOT NULL
                AND dp.current_longitude IS NOT NULL
                HAVING distance_km <= ?
                ORDER BY 
                    distance_km ASC,
                    rating_score DESC,
                    location_score DESC,
                    dp.updated_at DESC
                LIMIT 10
            ");
            
            $stmt->execute([$pickupLat, $pickupLng, $pickupLat, $vehicleType, $maxDistance]);
            $drivers = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Calculate matching scores
            foreach ($drivers as &$driver) {
                $driver['matching_score'] = $this->calculateMatchingScore($driver, $pickupLat, $pickupLng);
                $driver['estimated_arrival'] = $this->estimateArrivalTime($driver['distance_km']);
            }
            
            // Sort by matching score
            usort($drivers, function($a, $b) {
                return $b['matching_score'] <=> $a['matching_score'];
            });
            
            return [
                'success' => true,
                'matching_drivers' => $drivers,
                'total_matches' => count($drivers),
                'search_radius' => $maxDistance,
                'vehicle_type_requested' => $vehicleType
            ];
            
        } catch (Exception $e) {
            error_log("Vehicle matching error: " . $e->getMessage());
            return [
                'success' => false,
                'error' => 'Failed to find matching drivers'
            ];
        }
    }
    
    /**
     * Calculate matching score based on multiple factors
     */
    private function calculateMatchingScore($driver, $pickupLat, $pickupLng) {
        $score = 0;
        
        // Distance score (closer is better)
        $distanceScore = max(0, 100 - ($driver['distance_km'] * 5));
        $score += $distanceScore;
        
        // Rating score
        $ratingScore = $driver['rating_score'] * 20;
        $score += $ratingScore;
        
        // Location freshness score
        $locationScore = $driver['location_score'] * 10;
        $score += $locationScore;
        
        // Capacity bonus (for appropriate vehicle types)
        if ($driver['vehicle_type'] === 'car' && $driver['vehicle_capacity'] >= 4) {
            $score += 5;
        }
        
        return round($score, 2);
    }
    
    /**
     * Estimate arrival time in minutes
     */
    private function estimateArrivalTime($distanceKm) {
        // Average speed in city: ~30 km/h
        $avgSpeedKmPerMin = 0.5;
        return ceil($distanceKm / $avgSpeedKmPerMin);
    }
    
    /**
     * Broadcast ride request to matched drivers
     */
    public function broadcastRideRequest($bookingId, $matchingDrivers) {
        $broadcastResults = [];
        
        foreach ($matchingDrivers as $driver) {
            try {
                // Create notification for driver
                $stmt = $this->pdo->prepare("
                    INSERT INTO driver_notifications (driver_id, booking_id, notification_type, message, created_at)
                    VALUES (?, ?, 'new_ride_request', ?, NOW())
                ");
                
                $message = "New ride request matching your {$driver['vehicle_type']} ({$driver['distance_km']} km away)";
                $stmt->execute([$driver['driver_id'], $bookingId, $message]);

                // Use centralized push helper (best-effort, non-blocking)
                try {
                    $payload = json_encode([
                        'title' => 'New Ride Request',
                        'body' => $message,
                        'data' => ['booking_id' => $bookingId],
                        'icon' => '/assets/icons/icon-192x192.png',
                        'badge' => '/assets/icons/icon-72x72.png',
                        'timestamp' => time()
                    ]);

                    // Send with a single retry allowed
                    $sendResult = sendPushNotifications($this->pdo, $driver['driver_id'], $payload, ['retry' => 1]);
                    if (!empty($sendResult['failed'])) {
                        foreach ($sendResult['failed'] as $f) {
                            error_log('[vehicle_matching] Push failed for ' . $f['endpoint'] . ' reason: ' . ($f['reason'] ?? 'unknown'));
                        }
                    }
                } catch (Exception $e) {
                    error_log('Push send error: ' . $e->getMessage());
                }
                
                $broadcastResults[] = [
                    'driver_id' => $driver['driver_id'],
                    'driver_name' => $driver['driver_name'],
                    'notification_sent' => true,
                    'distance_km' => $driver['distance_km']
                ];
                
            } catch (Exception $e) {
                $broadcastResults[] = [
                    'driver_id' => $driver['driver_id'],
                    'driver_name' => $driver['driver_name'],
                    'notification_sent' => false,
                    'error' => $e->getMessage()
                ];
            }
        }
        
        return $broadcastResults;
    }
}

// API Endpoint Usage
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['action'])) {
        echo json_encode(['success' => false, 'error' => 'Action not specified']);
        exit();
    }
    
    $matcher = new VehicleMatchingAlgorithm();
    
    switch ($input['action']) {
        case 'find_drivers':
            if (!isset($input['vehicle_type']) || !isset($input['pickup_lat']) || !isset($input['pickup_lng'])) {
                echo json_encode(['success' => false, 'error' => 'Missing required parameters']);
                exit();
            }
            
            $result = $matcher->findMatchingDrivers(
                $input['vehicle_type'],
                $input['pickup_lat'],
                $input['pickup_lng'],
                $input['max_distance'] ?? 20
            );
            
            echo json_encode($result);
            break;
            
        case 'broadcast_request':
            if (!isset($input['booking_id']) || !isset($input['matching_drivers'])) {
                echo json_encode(['success' => false, 'error' => 'Missing required parameters']);
                exit();
            }
            
            $result = $matcher->broadcastRideRequest($input['booking_id'], $input['matching_drivers']);
            echo json_encode(['success' => true, 'broadcast_results' => $result]);
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
            break;
    }
}
?>
