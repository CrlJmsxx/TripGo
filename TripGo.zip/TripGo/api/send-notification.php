<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';
require_once '../config/session.php';
require_once __DIR__ . '/push_helper.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit();
}

// Check if user is logged in
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$currentUser = getCurrentUser();

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON input']);
    exit();
}

$userId = $input['user_id'] ?? '';
$title = $input['title'] ?? '';
$body = $input['body'] ?? '';
$data = $input['data'] ?? [];

try {
    $pdo = getConnection();

    // Prepare payload
    $payload = json_encode([
        'title' => $title,
        'body' => $body,
        'data' => $data,
        'icon' => '/assets/icons/icon-192x192.png',
        'badge' => '/assets/icons/icon-72x72.png',
        'timestamp' => time()
    ]);

    // Use centralized helper (with a single retry attempt)
    $sendResult = sendPushNotifications($pdo, $userId, $payload, [
        'retry' => 1,
        'ttl' => 3600, // 1 hour TTL
        'urgency' => 'normal'
    ]);

    $successCount = $sendResult['success_count'] ?? 0;
    $totalCount = $sendResult['total_count'] ?? 0;
    $usingWebpush = $sendResult['using_webpush'] ?? false;
    $error = $sendResult['error'] ?? null;
    $failed = $sendResult['failed'] ?? [];

    // Log notification
    try {
        $stmt = $pdo->prepare("
            INSERT INTO notification_logs (user_id, title, body, data, sent_count, total_count, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $userId,
            $title,
            $body,
            json_encode($data),
            $successCount,
            $totalCount
        ]);
    } catch (Exception $e) {
        error_log('[send-notification] Error logging notification: ' . $e->getMessage());
    }

    $response = [
        'success' => true,
        'message' => "Notification sent to $successCount of $totalCount subscriptions",
        'sent_count' => $successCount,
        'total_count' => $totalCount,
        'using_webpush' => $usingWebpush
    ];

    if ($error) {
        $response['warning'] = $error;
    }

    if (!empty($failed)) {
        $response['failed_count'] = count($failed);
        $response['failed'] = $failed;
    }

    echo json_encode($response);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Notification sending failed',
        'message' => $e->getMessage()
    ]);
}

?>
