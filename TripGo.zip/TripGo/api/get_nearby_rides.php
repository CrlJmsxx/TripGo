<?php
require_once '../config/database.php';
require_once '../config/session.php';

requireDriver();

header('Content-Type: application/json');

// Get current user
$currentUser = getCurrentUser();
if (!$currentUser) {
    echo json_encode(['success' => false, 'error' => 'Not authenticated']);
    exit();
}

// Get driver's current location from POST data
$latitude = $_POST['latitude'] ?? null;
$longitude = $_POST['longitude'] ?? null;

if (!$latitude || !$longitude) {
    // Try to get from driver profile
    try {
        $pdo = getConnection();
        $stmt = $pdo->prepare("SELECT current_latitude, current_longitude FROM driver_profiles WHERE user_id = ?");
        $stmt->execute([$currentUser['id']]);
        $location = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($location) {
            $latitude = $location['current_latitude'];
            $longitude = $location['current_longitude'];
        }
    } catch (Exception $e) {
        // Continue without location
    }
}

if (!$latitude || !$longitude) {
    echo json_encode(['success' => false, 'error' => 'Driver location not available']);
    exit();
}

// Validate coordinates
if (!is_numeric($latitude) || !is_numeric($longitude) ||
    $latitude < -90 || $latitude > 90 ||
    $longitude < -180 || $longitude > 180) {
    echo json_encode(['success' => false, 'error' => 'Invalid coordinates']);
    exit();
}

try {
    $pdo = getConnection();
    
    // Search radius in km (10km)
    $searchRadius = 10;
    
    // Haversine formula to find nearby rides
    $stmt = $pdo->prepare("
        SELECT b.*, u.full_name as passenger_name, u.phone as passenger_phone,
               (6371 * acos(
                   cos(radians(?)) * 
                   cos(radians(b.pickup_latitude)) * 
                   cos(radians(b.pickup_longitude) - radians(?)) + 
                   sin(radians(?)) * 
                   sin(radians(b.pickup_latitude))
               )) AS distance_km
        FROM bookings b 
        JOIN users u ON b.passenger_id = u.id 
        WHERE b.status = 'pending' 
        AND b.pickup_latitude IS NOT NULL 
        AND b.pickup_longitude IS NOT NULL
        AND (b.expires_at IS NULL OR b.expires_at > NOW())
        HAVING distance_km <= ?
        ORDER BY distance_km ASC, b.booking_time ASC
        LIMIT 20
    ");
    
    $stmt->execute([$latitude, $longitude, $latitude, $searchRadius]);
    $nearbyRides = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format response
    $formattedRides = array_map(function($ride) {
        return [
            'id' => (int)$ride['id'],
            'passenger_name' => $ride['passenger_name'],
            'passenger_phone' => $ride['passenger_phone'],
            'pickup_address' => $ride['pickup_address'],
            'dropoff_address' => $ride['dropoff_address'],
            'pickup_latitude' => (float)$ride['pickup_latitude'],
            'pickup_longitude' => (float)$ride['pickup_longitude'],
            'dropoff_latitude' => (float)$ride['dropoff_latitude'],
            'dropoff_longitude' => (float)$ride['dropoff_longitude'],
            'estimated_fare' => (float)$ride['estimated_fare'],
            'distance_km' => round((float)$ride['distance_km'], 2),
            'booking_time' => $ride['booking_time'],
            'status' => $ride['status']
        ];
    }, $nearbyRides);
    
    echo json_encode([
        'success' => true,
        'data' => $formattedRides,
        'count' => count($formattedRides),
        'search_radius' => $searchRadius,
        'driver_location' => [
            'latitude' => (float)$latitude,
            'longitude' => (float)$longitude
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
}
?>
