<?php
require_once __DIR__ . '/config/database.php';

echo "<h2>Creating Test Ride Requests</h2>";

try {
    $pdo = getConnection();
    
    // Get a passenger user for testing
    $stmt = $pdo->prepare("SELECT id FROM users WHERE user_type = 'passenger' LIMIT 1");
    $stmt->execute();
    $passenger = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$passenger) {
        echo "<p style='color: red;'>No passenger user found. Please run setup_test_environment.php first.</p>";
        exit();
    }
    
    // Create multiple test requests around Manila area with varying distances
    $testRequests = [
        [
            'pickup' => 'Makati City Hall',
            'pickup_lat' => 14.5547,
            'pickup_lng' => 121.0244,
            'dropoff' => 'Ayala Mall',
            'dropoff_lat' => 14.5577,
            'dropoff_lng' => 121.0188,
            'fare' => 150.00,
            'distance_from_driver' => 8.2 // km from default driver location (14.5995, 120.9842)
        ],
        [
            'pickup' => 'Quezon City Circle',
            'pickup_lat' => 14.6760,
            'pickup_lng' => 121.0437,
            'dropoff' => 'SM North EDSA',
            'dropoff_lat' => 14.6566,
            'dropoff_lng' => 121.0335,
            'fare' => 200.00,
            'distance_from_driver' => 12.5
        ],
        [
            'pickup' => 'Bonifacio Global City',
            'pickup_lat' => 14.5425,
            'pickup_lng' => 121.0459,
            'dropoff' => 'Market! Market!',
            'dropoff_lat' => 14.5409,
            'dropoff_lng' => 121.0449,
            'fare' => 120.00,
            'distance_from_driver' => 6.8
        ],
        [
            'pickup' => 'Manila Cathedral',
            'pickup_lat' => 14.5911,
            'pickup_lng' => 120.9759,
            'dropoff' => 'Rizal Park',
            'dropoff_lat' => 14.5847,
            'dropoff_lng' => 120.9800,
            'fare' => 100.00,
            'distance_from_driver' => 1.2
        ],
        [
            'pickup' => 'Pasay City Hall',
            'pickup_lat' => 14.5378,
            'pickup_lng' => 121.0015,
            'dropoff' => 'NAIA Terminal 3',
            'dropoff_lat' => 14.5085,
            'dropoff_lng' => 121.0194,
            'fare' => 250.00,
            'distance_from_driver' => 3.5
        ],
        [
            'pickup' => 'Ortigas Center',
            'pickup_lat' => 14.5855,
            'pickup_lng' => 121.0585,
            'dropoff' => 'SM Megamall',
            'dropoff_lat' => 14.5833,
            'dropoff_lng' => 121.0586,
            'fare' => 180.00,
            'distance_from_driver' => 7.8
        ],
        [
            'pickup' => 'Mandaluyong City Hall',
            'pickup_lat' => 14.5794,
            'pickup_lng' => 121.0297,
            'dropoff' => 'Robinsons Pioneer',
            'dropoff_lat' => 14.5775,
            'dropoff_lng' => 121.0305,
            'fare' => 130.00,
            'distance_from_driver' => 4.6
        ],
        [
            'pickup' => 'San Juan City Hall',
            'pickup_lat' => 14.6022,
            'pickup_lng' => 121.0363,
            'dropoff' => 'Greenhills Shopping Center',
            'dropoff_lat' => 14.6043,
            'dropoff_lng' => 121.0366,
            'fare' => 110.00,
            'distance_from_driver' => 5.4
        ],
        [
            'pickup' => 'Pasig City Hall',
            'pickup_lat' => 14.5764,
            'pickup_lng' => 121.0851,
            'dropoff' => 'Tiendesitas',
            'dropoff_lat' => 14.5743,
            'dropoff_lng' => 121.0874,
            'fare' => 160.00,
            'distance_from_driver' => 9.2
        ],
        [
            'pickup' => 'Marikina City Hall',
            'pickup_lat' => 14.6508,
            'pickup_lng' => 121.0996,
            'dropoff' => 'Riverbanks Center',
            'dropoff_lat' => 14.6489,
            'dropoff_lng' => 121.0978,
            'fare' => 220.00,
            'distance_from_driver' => 15.3
        ]
    ];
    
    $createdCount = 0;
    
    foreach ($testRequests as $i => $request) {
        // Check if request already exists
        $stmt = $pdo->prepare("
            SELECT id FROM bookings 
            WHERE passenger_id = ? 
            AND pickup_address = ? 
            AND status = 'pending'
            AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)
        ");
        $stmt->execute([$passenger['id'], $request['pickup']]);
        $existing = $stmt->fetch();
        
        if ($existing) {
            echo "<p style='color: orange;'>Request " . ($i + 1) . " already exists: " . htmlspecialchars($request['pickup']) . "</p>";
            continue;
        }
        
        // Create new booking
        $stmt = $pdo->prepare("
            INSERT INTO bookings (
                passenger_id, 
                pickup_address, 
                pickup_latitude, 
                pickup_longitude, 
                dropoff_address, 
                dropoff_latitude, 
                dropoff_longitude, 
                estimated_fare, 
                status, 
                booking_time,
                expires_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', NOW(), DATE_ADD(NOW(), INTERVAL 30 MINUTE))
        ");
        
        $stmt->execute([
            $passenger['id'],
            $request['pickup'],
            $request['pickup_lat'],
            $request['pickup_lng'],
            $request['dropoff'],
            $request['dropoff_lat'],
            $request['dropoff_lng'],
            $request['fare']
        ]);
        
        $createdCount++;
        echo "<p style='color: green;'>✓ Created request " . ($i + 1) . ": " . htmlspecialchars($request['pickup']) . " → " . htmlspecialchars($request['dropoff']) . " (₱" . number_format($request['fare'], 2) . ", ~" . $request['distance_from_driver'] . "km from driver)</p>";
    }
    
    echo "<br><h3>Summary</h3>";
    echo "<p style='color: green;'>✓ Created $createdCount new test requests</p>";
    echo "<p style='color: blue;'>ℹ️ All requests expire in 30 minutes</p>";
    echo "<p style='color: blue;'>ℹ️ Distances calculated from driver location (14.5995, 120.9842)</p>";
    
    echo "<br><h3>Next Steps:</h3>";
    echo "<p>1. <a href='driver/dashboard.php'>Go to Driver Dashboard</a></p>";
    echo "<p>2. Click 'Filter All Requests' button</p>";
    echo "<p>3. Verify requests appear in order of distance</p>";
    echo "<p>4. Test map markers and request acceptance</p>";
    
    echo "<br><h3>Testing Checklist:</h3>";
    echo "<p>□ Filter button loads requests without errors</p>";
    echo "<p>□ Requests sorted by distance (Manila Cathedral should be first)</p>";
    echo "<p>□ Map shows colored markers for each request</p>";
    echo "<p>□ Clicking markers shows popup with details</p>";
    echo "<p>□ Accept buttons work correctly</p>";
    echo "<p>□ Radius filter functions properly</p>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}
?>
