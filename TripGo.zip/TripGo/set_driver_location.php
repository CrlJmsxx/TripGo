<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/session.php';

session_start();
$currentUser = getCurrentUser();

if (!$currentUser || $currentUser['user_type'] !== 'driver') {
    die("Error: You must be logged in as a driver");
}

// Set a default location for testing (Manila area)
$defaultLat = 14.5995;
$defaultLng = 120.9842;

try {
    $pdo = getConnection();
    $stmt = $pdo->prepare("
        UPDATE driver_profiles 
        SET current_latitude = ?, current_longitude = ? 
        WHERE user_id = ?
    ");
    $stmt->execute([$defaultLat, $defaultLng, $currentUser['id']]);
    
    echo "✓ Driver location updated successfully!<br>";
    echo "Latitude: $defaultLat<br>";
    echo "Longitude: $defaultLng<br>";
    echo "Driver ID: " . $currentUser['id'] . "<br>";
    echo "<br><a href='driver/dashboard.php'>Go to Driver Dashboard</a>";
    
} catch (Exception $e) {
    echo "Error updating location: " . $e->getMessage();
}
?>
