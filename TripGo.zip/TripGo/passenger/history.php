<?php
require_once '../config/database.php';
require_once '../config/session.php';

requirePassenger();

$currentUser = getCurrentUser();
$pdo = getConnection();

// Get all user's bookings
$stmt = $pdo->prepare("
    SELECT b.*, u.full_name as driver_name, u.phone as driver_phone 
    FROM bookings b 
    LEFT JOIN users u ON b.driver_id = u.id 
    WHERE b.passenger_id = ? 
    ORDER BY b.booking_time DESC
");
$stmt->execute([$currentUser['id']]);
$bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ride History - TripGO</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <a href="../index.php" class="logo">
                    <i class="fas fa-car"></i> TripGO
                </a>
                
                <nav class="nav">
                    <a href="../index.php">Home</a>
                    <a href="dashboard.php">Dashboard</a>
                    <a href="booking.php">Book Ride</a>
                    <a href="history.php">History</a>
                </nav>
                
                <div class="user-menu">
                    <div class="user-info">
                        <div class="user-avatar">
                            <?php echo strtoupper(substr($currentUser['full_name'], 0, 1)); ?>
                        </div>
                        <span><?php echo htmlspecialchars($currentUser['full_name']); ?></span>
                    </div>
                    <a href="../auth/logout.php" class="btn btn-danger">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="container" style="padding: 40px 0;">
        <div class="card">
            <div class="card-header">
                <h1 class="card-title">
                    <i class="fas fa-history"></i> Ride History
                </h1>
            </div>
            
            <?php if (empty($bookings)): ?>
                <div style="text-align: center; padding: 60px 20px; color: #666;">
                    <i class="fas fa-route" style="font-size: 4rem; margin-bottom: 20px; opacity: 0.5;"></i>
                    <h3>No rides yet</h3>
                    <p>Book your first ride to see your history here!</p>
                    <a href="booking.php" class="btn btn-primary" style="margin-top: 20px;">
                        <i class="fas fa-map-marker-alt"></i> Book a Ride
                    </a>
                </div>
            <?php else: ?>
                <div class="booking-list">
                    <?php foreach ($bookings as $booking): ?>
                        <div class="booking-item">
                            <div class="booking-header">
                                <span class="booking-id">#<?php echo $booking['id']; ?></span>
                                <span class="booking-status status-<?php echo $booking['status']; ?>">
                                    <?php echo ucfirst($booking['status']); ?>
                                </span>
                            </div>
                            <div class="booking-details">
                                <div class="booking-detail">
                                    <i class="fas fa-map-marker-alt"></i>
                                    <span><?php echo htmlspecialchars($booking['pickup_address']); ?></span>
                                </div>
                                <div class="booking-detail">
                                    <i class="fas fa-flag-checkered"></i>
                                    <span><?php echo htmlspecialchars($booking['dropoff_address']); ?></span>
                                </div>
                                <div class="booking-detail">
                                    <i class="fas fa-dollar-sign"></i>
                                    <span>₱<?php echo number_format($booking['estimated_fare'], 2); ?></span>
                                </div>
                                <div class="booking-detail">
                                    <i class="fas fa-clock"></i>
                                    <span><?php echo date('M j, Y g:i A', strtotime($booking['booking_time'])); ?></span>
                                </div>
                            </div>
                            
                            <?php if ($booking['driver_name']): ?>
                                <div style="margin-top: 15px; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                                    <h4 style="margin-bottom: 10px; color: #333;">Driver Information</h4>
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                                        <div>
                                            <strong>Name:</strong> <?php echo htmlspecialchars($booking['driver_name']); ?>
                                        </div>
                                        <div>
                                            <strong>Phone:</strong> <?php echo htmlspecialchars($booking['driver_phone']); ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($booking['status'] === 'completed'): ?>
                                <div style="margin-top: 15px; padding: 15px; background: #d4edda; border-radius: 8px; border-left: 4px solid #28a745;">
                                    <h4 style="margin-bottom: 10px; color: #155724;">Ride Completed</h4>
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                                        <div>
                                            <strong>Final Fare:</strong> ₱<?php echo number_format($booking['actual_fare'], 2); ?>
                                        </div>
                                        <div>
                                            <strong>Completed:</strong> <?php echo date('M j, Y g:i A', strtotime($booking['dropoff_time'])); ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
