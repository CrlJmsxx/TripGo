<?php
require_once '../config/database.php';
require_once '../config/session.php';

requirePassenger();

// Get current user
$currentUser = getCurrentUser();
if (!$currentUser) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Not authenticated']);
    exit();
}

// Handle rating submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    if ($_POST['action'] === 'skip_rating') {
        $bookingId = $_POST['booking_id'] ?? null;
        
        if (!$bookingId) {
            echo json_encode(['success' => false, 'error' => 'Invalid booking ID']);
            exit();
        }
        
        try {
            $pdo = getConnection();
            
            // Verify booking belongs to current user (try with rating columns, fallback without them)
            try {
                $stmt = $pdo->prepare("
                    SELECT id FROM bookings 
                    WHERE id = ? AND passenger_id = ? AND status = 'completed' AND rating_requested = 1 AND rating_submitted = 0
                ");
                $stmt->execute([$bookingId, $currentUser['id']]);
                $booking = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$booking) {
                    echo json_encode(['success' => false, 'error' => 'Invalid booking or rating not available']);
                    exit();
                }
                
                // Mark rating as skipped
                $stmt = $pdo->prepare("UPDATE bookings SET rating_submitted = 1 WHERE id = ?");
                $stmt->execute([$bookingId]);
            } catch (PDOException $e) {
                // Fallback for databases without rating columns
                if (strpos($e->getMessage(), 'rating_requested') !== false || strpos($e->getMessage(), 'rating_submitted') !== false) {
                    echo json_encode(['success' => false, 'error' => 'Rating system not available']);
                    exit();
                } else {
                    throw $e;
                }
            }
            
            echo json_encode([
                'success' => true, 
                'message' => 'Rating skipped'
            ]);
            
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
        }
        exit();
    }
    
    if ($_POST['action'] === 'submit_rating') {
        $bookingId = $_POST['booking_id'] ?? null;
        $rating = $_POST['rating'] ?? null;
        $review = $_POST['review'] ?? '';
        
        if (!$bookingId || !$rating || !is_numeric($rating) || $rating < 1 || $rating > 5) {
            echo json_encode(['success' => false, 'error' => 'Invalid rating data']);
            exit();
        }
        
        try {
            $pdo = getConnection();
            
            // Verify booking belongs to current user and is completed (try with rating columns, fallback without them)
            try {
                $stmt = $pdo->prepare("
                    SELECT b.*, u.id as driver_id 
                    FROM bookings b 
                    LEFT JOIN users u ON b.driver_id = u.id 
                    WHERE b.id = ? AND b.passenger_id = ? AND b.status = 'completed' AND b.rating_requested = 1
                ");
                $stmt->execute([$bookingId, $currentUser['id']]);
                $booking = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$booking) {
                    echo json_encode(['success' => false, 'error' => 'Invalid booking or rating not available']);
                    exit();
                }
            } catch (PDOException $e) {
                // Fallback for databases without rating columns
                if (strpos($e->getMessage(), 'rating_requested') !== false) {
                    echo json_encode(['success' => false, 'error' => 'Rating system not available']);
                    exit();
                } else {
                    throw $e;
                }
            }
            
            // Check if rating already exists
            $stmt = $pdo->prepare("SELECT id FROM reviews WHERE booking_id = ?");
            $stmt->execute([$bookingId]);
            if ($stmt->fetch()) {
                echo json_encode(['success' => false, 'error' => 'Rating already submitted']);
                exit();
            }
            
            // Insert the review
            $stmt = $pdo->prepare("
                INSERT INTO reviews (booking_id, passenger_id, driver_id, rating, review, created_at) 
                VALUES (?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([$bookingId, $currentUser['id'], $booking['driver_id'], $rating, $review]);
            
            // Update driver's average rating (try with average_rating column, fallback without it)
            try {
                $stmt = $pdo->prepare("
                    UPDATE users u 
                    SET average_rating = (
                        SELECT AVG(rating) 
                        FROM reviews 
                        WHERE driver_id = u.id
                    ) 
                    WHERE u.id = ?
                ");
                $stmt->execute([$booking['driver_id']]);
            } catch (PDOException $e) {
                // Fallback for databases without average_rating column
                if (strpos($e->getMessage(), 'average_rating') !== false) {
                    // Average rating not available, just continue without it
                } else {
                    throw $e;
                }
            }
            
            // Mark rating as submitted (try with rating_submitted column, fallback without it)
            try {
                $stmt = $pdo->prepare("UPDATE bookings SET rating_submitted = 1 WHERE id = ?");
                $stmt->execute([$bookingId]);
            } catch (PDOException $e) {
                // Fallback for databases without rating_submitted column
                if (strpos($e->getMessage(), 'rating_submitted') !== false) {
                    // Rating submission tracking not available, just continue without it
                } else {
                    throw $e;
                }
            }
            
            echo json_encode([
                'success' => true, 
                'message' => 'Thank you for your rating!'
            ]);
            
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
        }
        exit();
    }
    
    // Get bookings that need rating
    if ($_POST['action'] === 'get_pending_ratings') {
        try {
            $pdo = getConnection();
            
            // Try with rating columns, fallback without them
            try {
                $stmt = $pdo->prepare("
                    SELECT b.*, u.full_name as driver_name, u.average_rating as driver_rating
                    FROM bookings b 
                    LEFT JOIN users u ON b.driver_id = u.id 
                    WHERE b.passenger_id = ? AND b.status = 'completed' AND b.rating_requested = 1 AND b.rating_submitted = 0
                    ORDER BY b.dropoff_time DESC
                    LIMIT 5
                ");
                $stmt->execute([$currentUser['id']]);
                $pendingRatings = $stmt->fetchAll(PDO::FETCH_ASSOC);
            } catch (PDOException $e) {
                // Fallback for databases without rating columns
                if (strpos($e->getMessage(), 'rating_requested') !== false || strpos($e->getMessage(), 'rating_submitted') !== false) {
                    $pendingRatings = [];
                } else {
                    throw $e;
                }
            }
            
            echo json_encode([
                'success' => true,
                'data' => $pendingRatings
            ]);
            
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
        }
        exit();
    }
}

// If not POST request, show rating page
$pendingRatings = [];
try {
    $pdo = getConnection();
    
    // Try with rating columns, fallback without them
    try {
        $stmt = $pdo->prepare("
            SELECT b.*, u.full_name as driver_name, u.average_rating as driver_rating
            FROM bookings b 
            LEFT JOIN users u ON b.driver_id = u.id 
            WHERE b.passenger_id = ? AND b.status = 'completed' AND b.rating_requested = 1 AND b.rating_submitted = 0
            ORDER BY b.dropoff_time DESC
            LIMIT 5
        ");
        $stmt->execute([$currentUser['id']]);
        $pendingRatings = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        // Fallback for databases without rating columns
        if (strpos($e->getMessage(), 'rating_requested') !== false || strpos($e->getMessage(), 'rating_submitted') !== false) {
            $pendingRatings = [];
        } else {
            throw $e;
        }
    }
    
} catch (Exception $e) {
    $error = 'Error loading pending ratings';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rate Your Ride - TripGO</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .rating-container {
            background: var(--bg-primary);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            border: 1px solid var(--border-color);
        }
        .rating-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 15px;
        }
        .driver-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
        }
        .rating-stars {
            display: flex;
            gap: 10px;
            margin: 15px 0;
        }
        .star {
            font-size: 2rem;
            color: var(--text-muted);
            cursor: pointer;
            transition: all 0.2s ease;
        }
        .star:hover {
            transform: scale(1.1);
        }
        .star.active {
            color: #ffc107;
        }
        .review-textarea {
            width: 100%;
            min-height: 100px;
            padding: 12px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-family: inherit;
            resize: vertical;
        }
        .rating-summary {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            margin-bottom: 30px;
        }
        .no-ratings {
            text-align: center;
            padding: 40px;
            color: var(--text-muted);
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <a href="../index.php" class="logo">
                    <i class="fas fa-car"></i> TripGO
                </a>
                
                <div class="nav-links">
                    <a href="dashboard.php" class="nav-link">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                    </a>
                    <a href="booking.php" class="nav-link">
                        <i class="fas fa-plus-circle"></i> Book Ride
                    </a>
                    <a href="../auth/logout.php" class="btn btn-danger">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="container" style="padding: 40px 0;">
        <div class="rating-summary">
            <h1 style="margin: 0 0 10px 0;">
                <i class="fas fa-star"></i> Rate Your Ride
            </h1>
            <p style="margin: 0; opacity: 0.9;">Your feedback helps us improve the service</p>
        </div>

        <?php if (empty($pendingRatings)): ?>
            <div class="no-ratings">
                <i class="fas fa-check-circle" style="font-size: 3rem; margin-bottom: 15px; color: var(--success-color);"></i>
                <h3>All Caught Up!</h3>
                <p>You don't have any rides to rate right now.</p>
                <a href="dashboard.php" class="btn btn-primary" style="margin-top: 20px;">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
        <?php else: ?>
            <?php foreach ($pendingRatings as $booking): ?>
                <div class="rating-container" data-booking-id="<?php echo $booking['id']; ?>">
                    <div class="rating-header">
                        <div class="driver-avatar">
                            <?php echo strtoupper(substr($booking['driver_name'], 0, 2)); ?>
                        </div>
                        <div>
                            <h3 style="margin: 0;"><?php echo htmlspecialchars($booking['driver_name']); ?></h3>
                            <p style="margin: 5px 0; color: var(--text-muted);">
                                Ride #<?php echo $booking['id']; ?> • 
                                <?php echo date('M j, Y', strtotime($booking['dropoff_time'])); ?>
                            </p>
                            <?php if ($booking['driver_rating']): ?>
                                <div style="color: #ffc107;">
                                    <i class="fas fa-star"></i> <?php echo number_format($booking['driver_rating'], 1); ?> Driver Rating
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div style="margin-bottom: 15px;">
                        <strong>How was your ride?</strong>
                    </div>
                    
                    <div class="rating-stars">
                        <i class="fas fa-star star" data-rating="1"></i>
                        <i class="fas fa-star star" data-rating="2"></i>
                        <i class="fas fa-star star" data-rating="3"></i>
                        <i class="fas fa-star star" data-rating="4"></i>
                        <i class="fas fa-star star" data-rating="5"></i>
                    </div>

                    <div style="margin-bottom: 15px;">
                        <label for="review_<?php echo $booking['id']; ?>">
                            <strong>Share your experience (optional)</strong>
                        </label>
                        <textarea 
                            id="review_<?php echo $booking['id']; ?>" 
                            class="review-textarea" 
                            placeholder="Tell us about your ride..."
                        ></textarea>
                    </div>

                    <div style="display: flex; gap: 10px;">
                        <button type="button" class="btn btn-primary submit-rating" data-booking-id="<?php echo $booking['id']; ?>">
                            <i class="fas fa-paper-plane"></i> Submit Rating
                        </button>
                        <button type="button" class="btn btn-secondary skip-rating" data-booking-id="<?php echo $booking['id']; ?>">
                            Skip
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <script>
        // Rating functionality
        document.addEventListener('DOMContentLoaded', function() {
            // Handle star ratings
            document.querySelectorAll('.rating-stars').forEach(container => {
                const stars = container.querySelectorAll('.star');
                let selectedRating = 0;

                stars.forEach(star => {
                    star.addEventListener('click', function() {
                        selectedRating = parseInt(this.dataset.rating);
                        updateStars(selectedRating);
                    });

                    star.addEventListener('mouseenter', function() {
                        const hoverRating = parseInt(this.dataset.rating);
                        updateStars(hoverRating);
                    });
                });

                container.addEventListener('mouseleave', function() {
                    updateStars(selectedRating);
                });

                function updateStars(rating) {
                    stars.forEach((star, index) => {
                        if (index < rating) {
                            star.classList.add('active');
                        } else {
                            star.classList.remove('active');
                        }
                    });
                }
            });

            // Submit rating
            document.querySelectorAll('.submit-rating').forEach(button => {
                button.addEventListener('click', function() {
                    const bookingId = this.dataset.bookingId;
                    const container = document.querySelector(`[data-booking-id="${bookingId}"]`);
                    const selectedStars = container.querySelectorAll('.star.active').length;
                    const review = container.querySelector('.review-textarea').value;

                    if (selectedStars === 0) {
                        alert('Please select a rating');
                        return;
                    }

                    submitRating(bookingId, selectedStars, review);
                });
            });

            // Skip rating
            document.querySelectorAll('.skip-rating').forEach(button => {
                button.addEventListener('click', function() {
                    const bookingId = this.dataset.bookingId;
                    const container = document.querySelector(`[data-booking-id="${bookingId}"]`);
                    
                    container.style.opacity = '0.5';
                    container.style.pointerEvents = 'none';
                    
                    // Mark as skipped in backend
                    fetch('rate_ride.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: `action=skip_rating&booking_id=${bookingId}`
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            container.remove();
                            
                            // Check if no more ratings
                            if (document.querySelectorAll('.rating-container').length === 0) {
                                location.reload();
                            }
                        }
                    });
                });
            });
        });

        function submitRating(bookingId, rating, review) {
            const button = document.querySelector(`[data-booking-id="${bookingId}"] .submit-rating`);
            const originalText = button.innerHTML;
            
            button.disabled = true;
            button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';

            fetch('rate_ride.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=submit_rating&booking_id=${bookingId}&rating=${rating}&review=${encodeURIComponent(review)}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const container = document.querySelector(`[data-booking-id="${bookingId}"]`);
                    container.style.background = '#d4edda';
                    container.innerHTML = `
                        <div style="text-align: center; padding: 20px;">
                            <i class="fas fa-check-circle" style="font-size: 3rem; color: #28a745; margin-bottom: 15px;"></i>
                            <h3 style="color: #155724;">Thank You!</h3>
                            <p style="color: #155724;">Your rating has been submitted successfully.</p>
                        </div>
                    `;
                    
                    // Remove after 2 seconds
                    setTimeout(() => {
                        container.remove();
                        if (document.querySelectorAll('.rating-container').length === 0) {
                            location.reload();
                        }
                    }, 2000);
                } else {
                    alert(data.error || 'Error submitting rating');
                    button.disabled = false;
                    button.innerHTML = originalText;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error submitting rating');
                button.disabled = false;
                button.innerHTML = originalText;
            });
        }
    </script>
</body>
</html>
