<?php
require_once '../config/database.php';
require_once '../config/session.php';

requirePassenger();

$currentUser = getCurrentUser();
$pdo = getConnection();

// Get user's recent bookings
$stmt = $pdo->prepare("
    SELECT b.*, u.full_name as driver_name, u.phone as driver_phone 
    FROM bookings b 
    LEFT JOIN users u ON b.driver_id = u.id 
    WHERE b.passenger_id = ? 
    ORDER BY b.booking_time DESC 
    LIMIT 10
");
$stmt->execute([$currentUser['id']]);
$recentBookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get booking statistics
$stmt = $pdo->prepare("
    SELECT 
        COUNT(*) as total_bookings,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_rides,
        SUM(CASE WHEN status = 'completed' THEN actual_fare ELSE 0 END) as total_spent
    FROM bookings 
    WHERE passenger_id = ?
");
$stmt->execute([$currentUser['id']]);
$stats = $stmt->fetch(PDO::FETCH_ASSOC);

// Get pending ratings (try with rating columns, fallback without them)
$pendingRatings = [];
try {
    $stmt = $pdo->prepare("
        SELECT b.*, u.full_name as driver_name
        FROM bookings b 
        LEFT JOIN users u ON b.driver_id = u.id 
        WHERE b.passenger_id = ? AND b.status = 'completed' AND b.rating_requested = 1 AND b.rating_submitted = 0
        ORDER BY b.dropoff_time DESC
        LIMIT 3
    ");
    $stmt->execute([$currentUser['id']]);
    $pendingRatings = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Fallback for databases without rating columns
    if (strpos($e->getMessage(), 'rating_requested') !== false || strpos($e->getMessage(), 'rating_submitted') !== false) {
        // Rating system not available, just set empty array
        $pendingRatings = [];
    } else {
        throw $e; // Re-throw if it's a different error
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Passenger Dashboard - TripGO</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <!-- Leaflet CSS for OpenStreetMap -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <style>
        #passengerMap { 
            height: 400px; 
            width: 100%; 
            border-radius: 12px; 
            margin: 20px 0;
            border: 2px solid var(--border-color);
        }
        .leaflet-control-custom {
            background: white;
            border: 2px solid var(--primary-color);
            border-radius: 8px;
            padding: 5px 10px;
            font-weight: bold;
            color: var(--primary-color);
        }
        .driver-marker {
            background: var(--primary-color);
            border: 3px solid white;
            border-radius: 50%;
            width: 12px;
            height: 12px;
        }
        .booking-card {
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }
        .booking-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-medium);
        }
        .status-indicator {
            display: inline-block;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 8px;
            animation: pulse 2s infinite;
        }
        .status-pending { background: var(--creative-accent); }
        .status-accepted { background: var(--primary-color); }
        .status-in_progress { background: var(--success-color); }
        .status-completed { background: var(--text-muted); }
        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.5; }
            100% { opacity: 1; }
        }
        .real-time-tracking {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }
        .eta-info {
            background: var(--bg-primary);
            border-left: 4px solid var(--success-color);
            padding: 15px;
            border-radius: 8px;
            margin: 15px 0;
        }
        @keyframes slideInDown {
            from {
                transform: translateY(-100%);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        .driver-approaching {
            animation: pulse 2s infinite;
            background: linear-gradient(135deg, #28a745, #20c997) !important;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <a href="../index.php" class="logo">
                    <i class="fas fa-car"></i> TripGO
                </a>
                
                <nav class="nav">
                    <a href="../index.php">Home</a>
                    <a href="dashboard.php">Dashboard</a>
                    <a href="booking.php">Book Ride</a>
                    <a href="history.php">History</a>
                </nav>
                
                <div class="user-menu">
                    <div class="user-info">
                        <div class="user-avatar">
                            <?php echo strtoupper(substr($currentUser['full_name'], 0, 1)); ?>
                        </div>
                        <span><?php echo htmlspecialchars($currentUser['full_name']); ?></span>
                    </div>
                    <a href="../auth/logout.php" class="btn btn-danger">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="container" style="padding: 40px 0;">
        <!-- Welcome Section -->
        <div class="card" style="margin-bottom: 30px;">
            <div class="card-header">
                <h1 class="card-title">
                    <i class="fas fa-user"></i> Welcome back, <?php echo htmlspecialchars($currentUser['full_name']); ?>!
                </h1>
            </div>
            <p style="color: #666; font-size: 1.1rem;">
                Ready for your next ride? Book now and get where you need to go safely and comfortably.
            </p>
            <div style="margin-top: 20px;">
                <a href="booking.php" class="btn btn-primary">
                    <i class="fas fa-map-marker-alt"></i> Book a Ride
                </a>
            </div>
        </div>

        <!-- Statistics -->
        <div class="stats-grid" style="margin-bottom: 40px;">
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                    <i class="fas fa-route"></i>
                </div>
                <div class="stat-number"><?php echo $stats['total_bookings']; ?></div>
                <div class="stat-label">Total Rides</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, #28a745 0%, #20c997 100%);">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="stat-number"><?php echo $stats['completed_rides']; ?></div>
                <div class="stat-label">Completed Rides</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%);">
                    <i class="fas fa-dollar-sign"></i>
                </div>
                <div class="stat-number">₱<?php echo number_format($stats['total_spent'], 2); ?></div>
                <div class="stat-label">Total Spent</div>
            </div>
        </div>

        <!-- Real-Time Ride Tracking -->
        <?php 
        // Get active booking
        $activeBooking = null;
        foreach ($recentBookings as $booking) {
            if ($booking['status'] === 'accepted' || $booking['status'] === 'in_progress') {
                $activeBooking = $booking;
                break;
            }
        }
        ?>
        
        <?php if ($activeBooking): ?>
        <div class="card" style="margin-bottom: 30px;">
            <div class="card-header">
                <h2 class="card-title">
                    <i class="fas fa-map"></i> Real-Time Ride Tracking
                </h2>
            </div>
            
            <!-- Acceptance Notification -->
            <div id="acceptanceNotification" style="display: none; background: linear-gradient(135deg, #28a745, #20c997); color: white; padding: 20px; border-radius: 12px; margin-bottom: 20px; text-align: center; animation: slideInDown 0.5s ease-out;">
                <div style="display: flex; align-items: center; justify-content: center; gap: 15px; margin-bottom: 10px;">
                    <div style="width: 50px; height: 50px; background: white; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                        <i class="fas fa-check" style="font-size: 24px; color: #28a745;"></i>
                    </div>
                    <div style="text-align: left;">
                        <h3 style="margin: 0; font-size: 1.3rem;">Ride Accepted!</h3>
                        <p style="margin: 5px 0; opacity: 0.9;">Your driver is on the way</p>
                    </div>
                </div>
            </div>

            <div class="real-time-tracking">
                <div style="display: flex; align-items: center; justify-content: center; gap: 10px;">
                    <span class="status-indicator status-<?php echo $activeBooking['status']; ?>"></span>
                    <span style="font-weight: 600;">
                        <?php 
                        if ($activeBooking['status'] === 'pending') {
                            echo 'Finding nearby drivers...';
                        } elseif ($activeBooking['status'] === 'accepted') {
                            echo 'Driver is on the way!';
                        } elseif ($activeBooking['status'] === 'in_progress') {
                            echo 'Ride in Progress';
                        }
                        ?>
                    </span>
                </div>
                <div style="margin-top: 10px; font-size: 0.9rem; opacity: 0.9;">
                    <i class="fas fa-sync-alt"></i> Location updates every 5 seconds
                </div>
            </div>
            
            <div id="passengerMap"></div>
            
            <div class="eta-info">
                <h4 style="margin: 0 0 10px 0; color: var(--success-color);">
                    <i class="fas fa-info-circle"></i> Ride Details
                </h4>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div>
                        <strong>Driver:</strong> <?php echo htmlspecialchars($activeBooking['driver_name']); ?>
                    </div>
                    <div>
                        <strong>Status:</strong> <?php echo ucfirst($activeBooking['status']); ?>
                    </div>
                    <div>
                        <strong>Pickup:</strong> <?php echo htmlspecialchars(substr($activeBooking['pickup_address'], 0, 30)) . '...'; ?>
                    </div>
                    <div>
                        <strong>Dropoff:</strong> <?php echo htmlspecialchars(substr($activeBooking['dropoff_address'], 0, 30)) . '...'; ?>
                    </div>
                </div>
                <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid var(--border-color);">
                    <div id="etaDisplay" style="font-weight: 600; color: var(--primary-color);">
                        <i class="fas fa-clock"></i> Calculating ETA...
                    </div>
                </div>
            </div>
            
            <div style="display: flex; gap: 15px; margin-top: 15px; flex-wrap: wrap;">
                <?php if (in_array($activeBooking['status'], ['pending', 'searching'])): ?>
                    <button type="button" id="cancelRide" class="btn btn-danger" style="font-size: 14px;" data-booking-id="<?php echo $activeBooking['id']; ?>">
                        <i class="fas fa-times-circle"></i> Cancel Ride
                    </button>
                <?php endif; ?>
                <button type="button" id="centerOnRoute" class="btn btn-secondary" style="font-size: 14px;">
                    <i class="fas fa-compress-arrows-alt"></i> Fit Route to Screen
                </button>
                <button type="button" id="refreshLocation" class="btn btn-primary" style="font-size: 14px;">
                    <i class="fas fa-sync"></i> Refresh Location
                </button>
            </div>
        </div>
        <?php endif; ?>

        <!-- Rating Prompts -->
        <?php if (!empty($pendingRatings)): ?>
        <div class="card" style="margin-bottom: 30px;">
            <div class="card-header">
                <h2 class="card-title">
                    <i class="fas fa-star"></i> Rate Your Recent Rides
                </h2>
            </div>
            
            <div style="background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                <p style="margin: 0;">
                    <i class="fas fa-info-circle"></i> Your feedback helps us improve service quality and recognize great drivers!
                </p>
            </div>
            
            <?php foreach ($pendingRatings as $rating): ?>
                <div class="rating-prompt" style="background: var(--bg-primary); border: 1px solid var(--border-color); border-radius: 8px; padding: 15px; margin-bottom: 15px;">
                    <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 10px;">
                        <div style="width: 40px; height: 40px; border-radius: 50%; background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
                            <?php echo strtoupper(substr($rating['driver_name'], 0, 2)); ?>
                        </div>
                        <div style="flex: 1;">
                            <div style="font-weight: 600;"><?php echo htmlspecialchars($rating['driver_name']); ?></div>
                            <div style="font-size: 0.85rem; color: var(--text-muted);">
                                Ride #<?php echo $rating['id']; ?> • <?php echo date('M j, Y', strtotime($rating['dropoff_time'])); ?>
                            </div>
                        </div>
                    </div>
                    
                    <div style="display: flex; gap: 10px;">
                        <a href="rate_ride.php" class="btn btn-primary" style="font-size: 14px;">
                            <i class="fas fa-star"></i> Rate Driver
                        </a>
                        <button type="button" class="btn btn-secondary skip-rating-btn" data-booking-id="<?php echo $rating['id']; ?>" style="font-size: 14px;">
                            Skip
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
            
            <?php if (count($pendingRatings) > 1): ?>
                <div style="text-align: center; margin-top: 15px;">
                    <a href="rate_ride.php" class="btn btn-secondary">
                        <i class="fas fa-list"></i> View All Pending Ratings
                    </a>
                </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <!-- Quick Actions -->
        <div class="dashboard-grid">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-plus-circle" style="color: #667eea;"></i>
                        Quick Actions
                    </h3>
                </div>
                <div style="display: grid; gap: 15px;">
                    <a href="booking.php" class="btn btn-primary">
                        <i class="fas fa-map-marker-alt"></i> Book New Ride
                    </a>
                    <a href="history.php" class="btn btn-secondary">
                        <i class="fas fa-history"></i> View Ride History
                    </a>
                    <a href="profile.php" class="btn btn-secondary">
                        <i class="fas fa-user-edit"></i> Edit Profile
                    </a>
                </div>
            </div>

            <!-- Recent Bookings -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-clock" style="color: #667eea;"></i>
                        Recent Bookings
                    </h3>
                </div>
                <?php if (empty($recentBookings)): ?>
                    <p style="text-align: center; color: #666; padding: 20px;">
                        <i class="fas fa-info-circle"></i> No bookings yet. Book your first ride!
                    </p>
                <?php else: ?>
                    <div class="booking-list">
                        <?php foreach ($recentBookings as $booking): ?>
                            <div class="booking-item">
                                <div class="booking-header">
                                    <span class="booking-id">#<?php echo $booking['id']; ?></span>
                                    <span class="booking-status status-<?php echo $booking['status']; ?>">
                                        <?php echo ucfirst($booking['status']); ?>
                                    </span>
                                </div>
                                <div class="booking-details">
                                    <div class="booking-detail">
                                        <i class="fas fa-map-marker-alt"></i>
                                        <span><?php echo htmlspecialchars($booking['pickup_address']); ?></span>
                                    </div>
                                    <div class="booking-detail">
                                        <i class="fas fa-flag-checkered"></i>
                                        <span><?php echo htmlspecialchars($booking['dropoff_address']); ?></span>
                                    </div>
                                    <div class="booking-detail">
                                        <i class="fas fa-dollar-sign"></i>
                                        <span>₱<?php echo number_format($booking['estimated_fare'], 2); ?></span>
                                    </div>
                                    <div class="booking-detail">
                                        <i class="fas fa-clock"></i>
                                        <span><?php echo date('M j, Y g:i A', strtotime($booking['booking_time'])); ?></span>
                                    </div>
                                </div>
                                <?php if ($booking['driver_name']): ?>
                                    <div style="margin-top: 10px; padding: 10px; background: #f8f9fa; border-radius: 8px;">
                                        <strong>Driver:</strong> <?php echo htmlspecialchars($booking['driver_name']); ?>
                                        <?php if ($booking['driver_phone']): ?>
                                            <br><strong>Phone:</strong> <?php echo htmlspecialchars($booking['driver_phone']); ?>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Leaflet JS for OpenStreetMap -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
        <?php if ($activeBooking): ?>
        let map;
        let driverMarker;
        let pickupMarker;
        let dropoffMarker;
        let routeLine;
        let locationUpdateInterval;
        let activeBooking = <?php echo json_encode($activeBooking); ?>;
        let bookingId = <?php echo $activeBooking['id']; ?>;

        // Initialize passenger tracking map
        function initPassengerMap() {
            // Initialize map
            map = L.map('passengerMap').setView([12.8797, 121.7740], 13);

            // Add OpenStreetMap tiles (free)
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors',
                maxZoom: 18
            }).addTo(map);

            // Custom icons
            const driverIcon = L.divIcon({
                html: '<div style="background: #007bff; color: white; border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; font-weight: bold; border: 3px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3);"><i class="fas fa-car" style="font-size: 16px;"></i></div>',
                iconSize: [40, 40],
                className: 'custom-div-icon'
            });

            const pickupIcon = L.divIcon({
                html: '<div style="background: #28a745; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; font-weight: bold; border: 3px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3);">P</div>',
                iconSize: [30, 30],
                className: 'custom-div-icon'
            });

            const dropoffIcon = L.divIcon({
                html: '<div style="background: #dc3545; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; font-weight: bold; border: 3px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3);">D</div>',
                iconSize: [30, 30],
                className: 'custom-div-icon'
            });

            // Add pickup marker
            if (activeBooking.pickup_latitude && activeBooking.pickup_longitude) {
                pickupMarker = L.marker([activeBooking.pickup_latitude, activeBooking.pickup_longitude], {icon: pickupIcon})
                    .addTo(map)
                    .bindPopup('<b>Pickup Location</b>');
            }

            // Add dropoff marker
            if (activeBooking.dropoff_latitude && activeBooking.dropoff_longitude) {
                dropoffMarker = L.marker([activeBooking.dropoff_latitude, activeBooking.dropoff_longitude], {icon: dropoffIcon})
                    .addTo(map)
                    .bindPopup('<b>Dropoff Location</b>');
            }

            // Add driver marker (initially at pickup or last known location)
            if (activeBooking.driver_latitude && activeBooking.driver_longitude) {
                driverMarker = L.marker([activeBooking.driver_latitude, activeBooking.driver_longitude], {icon: driverIcon})
                    .addTo(map)
                    .bindPopup('<b>Driver Location</b>');
            }

            // Draw route line
            if (pickupMarker && dropoffMarker) {
                routeLine = L.polyline([
                    [activeBooking.pickup_latitude, activeBooking.pickup_longitude],
                    [activeBooking.dropoff_latitude, activeBooking.dropoff_longitude]
                ], {
                    color: '#007bff',
                    weight: 4,
                    opacity: 0.7,
                    dashArray: '10, 10'
                }).addTo(map);
            }

            // Fit map to show all markers
            if (pickupMarker && dropoffMarker) {
                const group = new L.featureGroup([pickupMarker, dropoffMarker]);
                if (driverMarker) {
                    group.addLayer(driverMarker);
                }
                map.fitBounds(group.getBounds().pad(0.1));
            }

            // Center on route button
            document.getElementById('centerOnRoute').addEventListener('click', function() {
                if (pickupMarker && dropoffMarker) {
                    const group = new L.featureGroup([pickupMarker, dropoffMarker]);
                    if (driverMarker) {
                        group.addLayer(driverMarker);
                    }
                    map.fitBounds(group.getBounds().pad(0.1));
                }
            });

            // Refresh location button
            document.getElementById('refreshLocation').addEventListener('click', function() {
                updateDriverLocation();
            });

            // Start real-time updates
            startRealTimeUpdates();
        }

        // Start real-time location updates
        function startRealTimeUpdates() {
            // Update immediately
            updateDriverLocation();
            
            // Then update every 5 seconds
            locationUpdateInterval = setInterval(updateDriverLocation, 5000);
        }

        // Update driver location and status
        function updateDriverLocation() {
            fetch('get_driver_location.php?booking_id=' + bookingId)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Check for status changes
                        if (data.booking.status !== activeBooking.status) {
                            handleStatusChange(activeBooking.status, data.booking.status);
                            activeBooking.status = data.booking.status;
                        }
                        
                        if (data.driver_location) {
                            const lat = parseFloat(data.driver_location.latitude);
                            const lng = parseFloat(data.driver_location.longitude);
                            
                            if (driverMarker) {
                                driverMarker.setLatLng([lat, lng]);
                            } else {
                                // Create driver marker if it doesn't exist
                                const driverIcon = L.divIcon({
                                    html: '<div style="background: #007bff; color: white; border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; font-weight: bold; border: 3px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3);"><i class="fas fa-car" style="font-size: 16px;"></i></div>',
                                    iconSize: [40, 40],
                                    className: 'custom-div-icon'
                                });
                                
                                driverMarker = L.marker([lat, lng], {icon: driverIcon})
                                    .addTo(map)
                                    .bindPopup('<b>Driver Location</b>');
                            }
                            
                            // Update ETA
                            updateETA(lat, lng);
                            
                            // Update route line to show full route
                            updateRouteLine(lat, lng);
                        }
                    }
                })
                .catch(error => {
                    console.error('Error updating driver location:', error);
                });
        }

        // Handle status changes with notifications
        function handleStatusChange(oldStatus, newStatus) {
            const statusText = document.querySelector('.real-time-tracking span:last-child');
            const statusIndicator = document.querySelector('.status-indicator');
            const trackingDiv = document.querySelector('.real-time-tracking');
            
            // Update status indicator and text
            if (statusIndicator) {
                statusIndicator.className = `status-indicator status-${newStatus}`;
            }
            
            if (statusText) {
                if (newStatus === 'pending') {
                    statusText.textContent = 'Finding nearby drivers...';
                } else if (newStatus === 'accepted') {
                    statusText.textContent = 'Driver is on the way!';
                    showAcceptanceNotification();
                    trackingDiv.classList.add('driver-approaching');
                } else if (newStatus === 'in_progress') {
                    statusText.textContent = 'Ride in Progress';
                    trackingDiv.classList.remove('driver-approaching');
                }
            }
        }

        // Show acceptance notification
        function showAcceptanceNotification() {
            const notification = document.getElementById('acceptanceNotification');
            if (notification) {
                notification.style.display = 'block';
                
                // Auto-hide after 5 seconds
                setTimeout(() => {
                    notification.style.display = 'none';
                }, 5000);
                
                // Play notification sound (if available)
                playNotificationSound();
            }
        }

        // Play notification sound
        function playNotificationSound() {
            // Create a simple beep sound using Web Audio API
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            oscillator.frequency.value = 800;
            oscillator.type = 'sine';
            
            gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
            
            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + 0.5);
        }

        // Update route line based on status
        function updateRouteLine(driverLat, driverLng) {
            if (routeLine) {
                map.removeLayer(routeLine);
            }
            
            const routePoints = [];
            
            if (activeBooking.status === 'accepted') {
                // Driver -> Pickup -> Destination
                routePoints.push([driverLat, driverLng]);
                routePoints.push([activeBooking.pickup_latitude, activeBooking.pickup_longitude]);
                routePoints.push([activeBooking.dropoff_latitude, activeBooking.dropoff_longitude]);
            } else if (activeBooking.status === 'in_progress') {
                // Current location -> Destination
                routePoints.push([driverLat, driverLng]);
                routePoints.push([activeBooking.dropoff_latitude, activeBooking.dropoff_longitude]);
            } else {
                // Just pickup to destination
                routePoints.push([activeBooking.pickup_latitude, activeBooking.pickup_longitude]);
                routePoints.push([activeBooking.dropoff_latitude, activeBooking.dropoff_longitude]);
            }
            
            if (routePoints.length > 1) {
                routeLine = L.polyline(routePoints, {
                    color: '#007bff',
                    weight: 4,
                    opacity: 0.7,
                    dashArray: '10, 10'
                }).addTo(map);
            }
        }

        // Update ETA display
        function updateETA(driverLat, driverLng) {
            if (activeBooking.status === 'accepted' && pickupMarker) {
                // Calculate distance from driver to pickup
                const distance = calculateDistance(
                    driverLat, driverLng,
                    parseFloat(activeBooking.pickup_latitude),
                    parseFloat(activeBooking.pickup_longitude)
                );
                
                // Estimate ETA (assuming average speed of 30 km/h in city)
                const avgSpeed = 30; // km/h
                const etaMinutes = Math.round((distance / avgSpeed) * 60);
                
                const etaDisplay = document.getElementById('etaDisplay');
                if (etaDisplay) {
                    if (etaMinutes <= 1) {
                        etaDisplay.innerHTML = '<i class="fas fa-clock"></i> Driver arriving soon!';
                    } else {
                        etaDisplay.innerHTML = `<i class="fas fa-clock"></i> Estimated arrival: ${etaMinutes} minutes (${distance.toFixed(1)} km away)`;
                    }
                }
            } else if (activeBooking.status === 'in_progress' && dropoffMarker) {
                // Calculate distance from current location to dropoff
                const distance = calculateDistance(
                    driverLat, driverLng,
                    parseFloat(activeBooking.dropoff_latitude),
                    parseFloat(activeBooking.dropoff_longitude)
                );
                
                const avgSpeed = 30; // km/h
                const etaMinutes = Math.round((distance / avgSpeed) * 60);
                
                const etaDisplay = document.getElementById('etaDisplay');
                if (etaDisplay) {
                    if (etaMinutes <= 1) {
                        etaDisplay.innerHTML = '<i class="fas fa-flag-checkered"></i> Arriving at destination!';
                    } else {
                        etaDisplay.innerHTML = `<i class="fas fa-flag-checkered"></i> Destination arrival: ${etaMinutes} minutes (${distance.toFixed(1)} km remaining)`;
                    }
                }
            }
        }

        // Calculate distance between two points
        function calculateDistance(lat1, lon1, lat2, lon2) {
            const R = 6371; // Radius of the Earth in km
            const dLat = (lat2 - lat1) * Math.PI / 180;
            const dLon = (lon2 - lon1) * Math.PI / 180;
            const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                    Math.sin(dLon/2) * Math.sin(dLon/2);
            const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
            return R * c;
        }

        // Initialize map on page load
        document.addEventListener('DOMContentLoaded', function() {
            initPassengerMap();
        });

        // Cleanup on page unload
        window.addEventListener('beforeunload', function() {
            if (locationUpdateInterval) {
                clearInterval(locationUpdateInterval);
            }
        });
        <?php else: ?>
        // No active booking - just auto refresh
        setTimeout(() => {
            location.reload();
        }, 30000);
        <?php endif; ?>

        // Skip rating functionality
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.skip-rating-btn').forEach(button => {
                button.addEventListener('click', function() {
                    const bookingId = this.dataset.bookingId;
                    const ratingPrompt = this.closest('.rating-prompt');
                    
                    if (confirm('Skip rating for this ride?')) {
                        button.disabled = true;
                        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Skipping...';
                        
                        fetch('rate_ride.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded',
                            },
                            body: `action=skip_rating&booking_id=${bookingId}`
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                ratingPrompt.style.opacity = '0.5';
                                ratingPrompt.style.pointerEvents = 'none';
                                button.innerHTML = '<i class="fas fa-check"></i> Skipped';
                                
                                // Remove after 1 second
                                setTimeout(() => {
                                    ratingPrompt.remove();
                                    
                                    // Check if no more rating prompts
                                    if (document.querySelectorAll('.rating-prompt').length === 0) {
                                        location.reload();
                                    }
                                }, 1000);
                            } else {
                                alert('Error skipping rating');
                                button.disabled = false;
                                button.innerHTML = 'Skip';
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            alert('Error skipping rating');
                            button.disabled = false;
                            button.innerHTML = 'Skip';
                        });
                    }
                });
            });
        });

        // Cancellation functionality
        document.addEventListener('DOMContentLoaded', function() {
            const cancelRideBtn = document.getElementById('cancelRide');
            
            if (cancelRideBtn) {
                cancelRideBtn.addEventListener('click', function() {
                    const bookingId = this.dataset.bookingId;
                    showCancellationModal(bookingId);
                });
            }
        });

        function showCancellationModal(bookingId) {
            // Create modal if it doesn't exist
            let modal = document.getElementById('cancellationModal');
            if (!modal) {
                modal = createCancellationModal();
                document.body.appendChild(modal);
            }
            
            modal.dataset.bookingId = bookingId;
            modal.style.display = 'flex';
        }

        function createCancellationModal() {
            const modal = document.createElement('div');
            modal.id = 'cancellationModal';
            modal.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.5);
                display: none;
                align-items: center;
                justify-content: center;
                z-index: 10000;
            `;
            
            modal.innerHTML = `
                <div style="background: white; border-radius: 12px; padding: 30px; max-width: 500px; width: 90%; max-height: 80vh; overflow-y: auto; box-shadow: 0 10px 30px rgba(0,0,0,0.3);">
                    <div style="text-align: center; margin-bottom: 20px;">
                        <i class="fas fa-exclamation-triangle" style="font-size: 3rem; color: #dc3545; margin-bottom: 15px;"></i>
                        <h3 style="margin: 0; color: #333;">Cancel Ride Request</h3>
                        <p style="margin: 10px 0; color: #666;">Please select a reason for cancellation</p>
                    </div>
                    
                    <form id="cancellationForm">
                        <div style="margin-bottom: 20px;">
                            <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #333;">
                                Cancellation Reason <span style="color: #dc3545;">*</span>
                            </label>
                            <div style="display: grid; gap: 10px;">
                                <label style="display: flex; align-items: center; padding: 10px; border: 1px solid #ddd; border-radius: 6px; cursor: pointer; transition: all 0.2s;">
                                    <input type="radio" name="reason" value="Found another ride" style="margin-right: 10px;" required>
                                    <span>Found another ride</span>
                                </label>
                                <label style="display: flex; align-items: center; padding: 10px; border: 1px solid #ddd; border-radius: 6px; cursor: pointer; transition: all 0.2s;">
                                    <input type="radio" name="reason" value="Too long wait time" style="margin-right: 10px;" required>
                                    <span>Too long wait time</span>
                                </label>
                                <label style="display: flex; align-items: center; padding: 10px; border: 1px solid #ddd; border-radius: 6px; cursor: pointer; transition: all 0.2s;">
                                    <input type="radio" name="reason" value="Changed my mind / No longer need a ride" style="margin-right: 10px;" required>
                                    <span>Changed my mind / No longer need a ride</span>
                                </label>
                                <label style="display: flex; align-items: center; padding: 10px; border: 1px solid #ddd; border-radius: 6px; cursor: pointer; transition: all 0.2s;">
                                    <input type="radio" name="reason" value="Accidentally placed the request" style="margin-right: 10px;" required>
                                    <span>Accidentally placed the request</span>
                                </label>
                                <label style="display: flex; align-items: center; padding: 10px; border: 1px solid #ddd; border-radius: 6px; cursor: pointer; transition: all 0.2s;">
                                    <input type="radio" name="reason" value="Other" style="margin-right: 10px;" required>
                                    <span>Other (please specify)</span>
                                </label>
                            </div>
                        </div>
                        
                        <div id="otherReasonDiv" style="margin-bottom: 20px; display: none;">
                            <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #333;">
                                Please specify <span style="color: #dc3545;">*</span>
                            </label>
                            <textarea id="otherReason" name="other_reason" rows="3" 
                                      style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; resize: vertical;" 
                                      placeholder="Please provide details..."></textarea>
                        </div>
                        
                        <div style="display: flex; gap: 10px; justify-content: flex-end;">
                            <button type="button" onclick="closeCancellationModal()" 
                                    style="padding: 10px 20px; border: 1px solid #ddd; background: #f8f9fa; color: #333; border-radius: 6px; cursor: pointer; font-weight: 600;">
                                Keep Ride
                            </button>
                            <button type="submit" id="confirmCancelBtn"
                                    style="padding: 10px 20px; background: #dc3545; color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 600;">
                                Cancel Ride
                            </button>
                        </div>
                    </form>
                </div>
            `;
            
            // Add radio button change handler
            modal.querySelectorAll('input[name="reason"]').forEach(radio => {
                radio.addEventListener('change', function() {
                    const otherDiv = document.getElementById('otherReasonDiv');
                    const otherTextarea = document.getElementById('otherReason');
                    
                    if (this.value === 'Other') {
                        otherDiv.style.display = 'block';
                        otherTextarea.required = true;
                    } else {
                        otherDiv.style.display = 'none';
                        otherTextarea.required = false;
                        otherTextarea.value = '';
                    }
                });
            });
            
            // Add form submit handler
            modal.querySelector('#cancellationForm').addEventListener('submit', function(e) {
                e.preventDefault();
                submitCancellation(modal.dataset.bookingId);
            });
            
            // Add hover effects for radio labels
            modal.querySelectorAll('label').forEach(label => {
                label.addEventListener('mouseenter', function() {
                    this.style.backgroundColor = '#f8f9fa';
                    this.style.borderColor = '#007bff';
                });
                label.addEventListener('mouseleave', function() {
                    this.style.backgroundColor = 'white';
                    this.style.borderColor = '#ddd';
                });
            });
            
            return modal;
        }

        function closeCancellationModal() {
            const modal = document.getElementById('cancellationModal');
            if (modal) {
                modal.style.display = 'none';
                // Reset form
                const form = modal.querySelector('#cancellationForm');
                form.reset();
                document.getElementById('otherReasonDiv').style.display = 'none';
            }
        }

        function submitCancellation(bookingId) {
            const form = document.getElementById('cancellationForm');
            const formData = new FormData(form);
            const reason = formData.get('reason');
            const otherReason = formData.get('other_reason');
            
            if (!reason || (reason === 'Other' && !otherReason)) {
                alert('Please select a cancellation reason and provide details if "Other" is selected.');
                return;
            }
            
            const confirmBtn = document.getElementById('confirmCancelBtn');
            const originalText = confirmBtn.innerHTML;
            confirmBtn.disabled = true;
            confirmBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Cancelling...';
            
            fetch('../api/cancel_booking.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=cancel_booking&booking_id=${bookingId}&reason=${encodeURIComponent(reason)}&other_reason=${encodeURIComponent(otherReason)}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    closeCancellationModal();
                    showNotification('Ride cancelled successfully', 'success');
                    // Reload page after 2 seconds
                    setTimeout(() => {
                        location.reload();
                    }, 2000);
                } else {
                    alert(data.error || 'Error cancelling ride');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error cancelling ride');
            })
            .finally(() => {
                confirmBtn.disabled = false;
                confirmBtn.innerHTML = originalText;
            });
        }

        // Close modal when clicking outside
        document.addEventListener('click', function(e) {
            const modal = document.getElementById('cancellationModal');
            if (modal && e.target === modal) {
                closeCancellationModal();
            }
        });
    </script>
</body>
</html>
