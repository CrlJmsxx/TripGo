<?php
require_once '../config/database.php';
require_once '../config/session.php';

requirePassenger();

header('Content-Type: application/json');

// Get current user
$currentUser = getCurrentUser();
if (!$currentUser) {
    echo json_encode(['success' => false, 'error' => 'Not authenticated']);
    exit();
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['latitude']) || !isset($input['longitude'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid input']);
    exit();
}

$latitude = $input['latitude'];
$longitude = $input['longitude'];

// Validate coordinates
if (!is_numeric($latitude) || !is_numeric($longitude) ||
    $latitude < -90 || $latitude > 90 ||
    $longitude < -180 || $longitude > 180) {
    echo json_encode(['success' => false, 'error' => 'Invalid coordinates']);
    exit();
}

try {
    $pdo = getConnection();
    
    // Update passenger location in users table (if current_lat/current_lng columns exist)
    try {
        $stmt = $pdo->prepare("
            UPDATE users 
            SET current_lat = ?, current_lng = ?, updated_at = NOW() 
            WHERE id = ?
        ");
        $stmt->execute([$latitude, $longitude, $currentUser['id']]);
    } catch (PDOException $e) {
        // Fallback if current_lat/current_lng columns don't exist
        if (strpos($e->getMessage(), 'current_lat') !== false || strpos($e->getMessage(), 'current_lng') !== false) {
            // Just continue without updating location
        } else {
            throw $e;
        }
    }
    
    // Update any active booking with passenger location
    try {
        $stmt = $pdo->prepare("
            UPDATE bookings 
            SET pickup_latitude = ?, pickup_longitude = ? 
            WHERE passenger_id = ? AND status = 'pending'
        ");
        $stmt->execute([$latitude, $longitude, $currentUser['id']]);
    } catch (PDOException $e) {
        // Just log error but continue
        error_log("Passenger location update error: " . $e->getMessage());
    }
    
    echo json_encode([
        'success' => true, 
        'message' => 'Location updated successfully',
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
}
?>
