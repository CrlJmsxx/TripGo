<?php
require_once '../config/database.php';
require_once '../config/session.php';

requirePassenger();

header('Content-Type: application/json');

// Get current user
$currentUser = getCurrentUser();
if (!$currentUser) {
    echo json_encode(['success' => false, 'error' => 'Not authenticated']);
    exit();
}

// Get booking ID
$bookingId = $_GET['booking_id'] ?? null;
if (!$bookingId || !is_numeric($bookingId)) {
    echo json_encode(['success' => false, 'error' => 'Invalid booking ID']);
    exit();
}

try {
    $pdo = getConnection();
    
    // Verify this booking belongs to the current user
    $stmt = $pdo->prepare("
        SELECT b.*, u.full_name as driver_name 
        FROM bookings b 
        LEFT JOIN users u ON b.driver_id = u.id 
        WHERE b.id = ? AND b.passenger_id = ? AND b.status IN ('accepted', 'in_progress')
    ");
    $stmt->execute([$bookingId, $currentUser['id']]);
    $booking = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$booking) {
        echo json_encode(['success' => false, 'error' => 'Booking not found or not active']);
        exit();
    }
    
    // Get driver's current location
    $driverLocation = null;
    if ($booking['driver_id']) {
        $stmt = $pdo->prepare("
            SELECT current_latitude, current_longitude, updated_at 
            FROM driver_profiles 
            WHERE user_id = ?
        ");
        $stmt->execute([$booking['driver_id']]);
        $driverProfile = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($driverProfile && $driverProfile['current_latitude'] && $driverProfile['current_longitude']) {
            // Check if location data is recent (within last 2 minutes)
            $lastUpdate = new DateTime($driverProfile['updated_at']);
            $now = new DateTime();
            $interval = $now->diff($lastUpdate);
            $minutesAgo = $interval->i + ($interval->h * 60) + ($interval->d * 24 * 60);
            
            if ($minutesAgo <= 2) {
                $driverLocation = [
                    'latitude' => $driverProfile['current_latitude'],
                    'longitude' => $driverProfile['current_longitude'],
                    'last_updated' => $driverProfile['updated_at']
                ];
            }
        }
    }
    
    // Fallback: use booking's driver_location if available
    if (!$driverLocation && $booking['driver_latitude'] && $booking['driver_longitude']) {
        $driverLocation = [
            'latitude' => $booking['driver_latitude'],
            'longitude' => $booking['driver_longitude'],
            'last_updated' => $booking['booking_time']
        ];
    }
    
    echo json_encode([
        'success' => true,
        'booking' => [
            'id' => $booking['id'],
            'status' => $booking['status'],
            'driver_name' => $booking['driver_name'],
            'pickup_latitude' => $booking['pickup_latitude'],
            'pickup_longitude' => $booking['pickup_longitude'],
            'dropoff_latitude' => $booking['dropoff_latitude'],
            'dropoff_longitude' => $booking['dropoff_longitude']
        ],
        'driver_location' => $driverLocation,
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
}
?>
