<?php
require_once '../config/database.php';
require_once '../config/session.php';

requirePassenger();

$currentUser = getCurrentUser();
$pdo = getConnection();

$error = '';
$success = '';

// Handle AJAX booking submission only
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
    $pickup_address = trim($_POST['pickup_address']);
    $dropoff_address = trim($_POST['dropoff_address']);
    $pickup_latitude = $_POST['pickup_latitude'];
    $pickup_longitude = $_POST['pickup_longitude'];
    $dropoff_latitude = $_POST['dropoff_latitude'];
    $dropoff_longitude = $_POST['dropoff_longitude'];
    $estimated_fare = $_POST['estimated_fare'];
    $distance_km = $_POST['distance_km'];
    $selected_vehicle_type = $_POST['selected_vehicle_type'] ?? '';
    
    if (empty($pickup_address) || empty($dropoff_address)) {
        echo json_encode(['success' => false, 'error' => 'Please enter both pickup and dropoff addresses.']);
        exit();
    } elseif (empty($selected_vehicle_type)) {
        echo json_encode(['success' => false, 'error' => 'Please select a vehicle type.']);
        exit();
    } else {
        try {
            // Create new booking with expiry time (try with expires_at, fallback without it)
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO bookings (passenger_id, pickup_address, dropoff_address, pickup_latitude, pickup_longitude, dropoff_latitude, dropoff_longitude, estimated_fare, distance_km, vehicle_type, expires_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 60 SECOND))
                ");
                $stmt->execute([
                    $currentUser['id'],
                    $pickup_address,
                    $dropoff_address,
                    $pickup_latitude,
                    $pickup_longitude,
                    $dropoff_latitude,
                    $dropoff_longitude,
                    $estimated_fare,
                    $distance_km,
                    $selected_vehicle_type
                ]);
            } catch (PDOException $e) {
                // Fallback for databases without expires_at column
                if (strpos($e->getMessage(), 'expires_at') !== false) {
                    $stmt = $pdo->prepare("
                        INSERT INTO bookings (passenger_id, pickup_address, dropoff_address, pickup_latitude, pickup_longitude, dropoff_latitude, dropoff_longitude, estimated_fare, distance_km, vehicle_type) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([
                        $currentUser['id'],
                        $pickup_address,
                        $dropoff_address,
                        $pickup_latitude,
                        $pickup_longitude,
                        $dropoff_latitude,
                        $dropoff_longitude,
                        $estimated_fare,
                        $distance_km,
                        $selected_vehicle_type
                    ]);
                } else {
                    throw $e; // Re-throw if it's a different error
                }
            }
            
            $booking_id = $pdo->lastInsertId();
            
            // Return booking ID for JavaScript handling
            echo json_encode([
                'success' => true,
                'booking_id' => $booking_id,
                'message' => 'Booking created successfully!'
            ]);
            exit();
        } catch (Exception $e) {
            error_log("Booking creation error: " . $e->getMessage());
            echo json_encode(['success' => false, 'error' => 'Failed to create booking. Please try again.']);
            exit();
        }
    }
}

// Get system settings for fare calculation
$stmt = $pdo->prepare("SELECT setting_key, setting_value FROM system_settings");
$stmt->execute();
$settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book a Ride - TripGO</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <!-- Leaflet CSS for OpenStreetMap -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <style>
        #map { 
            height: 400px; 
            width: 100%; 
            border-radius: 12px; 
            margin: 20px 0;
            border: 2px solid var(--border-color);
        }
        .leaflet-control-custom {
            background: white;
            border: 2px solid var(--primary-color);
            border-radius: 8px;
            padding: 5px 10px;
            font-weight: bold;
            color: var(--primary-color);
        }
        .location-marker {
            background: var(--primary-color);
            border: 3px solid white;
            border-radius: 50%;
            width: 12px;
            height: 12px;
        }
        .route-info {
            background: var(--bg-primary);
            padding: 15px;
            border-radius: 8px;
            margin: 15px 0;
            border-left: 4px solid var(--primary-color);
        }
        
        /* Vehicle Selection Styles */
        .vehicle-types-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        
        .vehicle-card {
            background: var(--bg-primary);
            border: 2px solid var(--border-color);
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .vehicle-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
            border-color: var(--primary-color);
        }
        
        .vehicle-card.selected {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border-color: var(--primary-color);
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
        }
        
        .vehicle-card.selected .vehicle-icon,
        .vehicle-card.selected .vehicle-name,
        .vehicle-card.selected .vehicle-description {
            color: white;
        }
        
        .vehicle-icon {
            font-size: 2.5rem;
            margin-bottom: 10px;
            color: var(--primary-color);
            transition: transform 0.3s ease;
        }
        
        .vehicle-card:hover .vehicle-icon {
            transform: scale(1.1);
        }
        
        .vehicle-name {
            font-weight: 600;
            font-size: 1.1rem;
            margin-bottom: 5px;
            color: var(--text-primary);
        }
        
        .vehicle-description {
            font-size: 0.85rem;
            color: var(--text-secondary);
            line-height: 1.4;
        }
        
        .vehicle-price {
            margin-top: 10px;
            font-weight: 600;
            font-size: 0.9rem;
            color: var(--accent-color);
        }
        
        .vehicle-card.selected .vehicle-price {
            color: #ffd700;
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .vehicle-types-grid {
                grid-template-columns: 1fr;
                gap: 10px;
            }
            
            .vehicle-card {
                padding: 15px;
            }
            
            .vehicle-icon {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <a href="../index.php" class="logo">
                    <i class="fas fa-car"></i> TripGO
                </a>
                
                <nav class="nav">
                    <a href="../index.php">Home</a>
                    <a href="dashboard.php">Dashboard</a>
                    <a href="booking.php">Book Ride</a>
                    <a href="history.php">History</a>
                </nav>
                
                <div class="user-menu">
                    <div class="user-info">
                        <div class="user-avatar">
                            <?php echo strtoupper(substr($currentUser['full_name'], 0, 1)); ?>
                        </div>
                        <span><?php echo htmlspecialchars($currentUser['full_name']); ?></span>
                    </div>
                    <a href="../auth/logout.php" class="btn btn-danger">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        </div>

        <!-- Booking Accepted Modal -->
        <div id="bookingAcceptedModal" class="modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 11000;">
            <div class="modal-content" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: #fff; border-radius: 15px; max-width: 400px; width: 90%; box-shadow: 0 15px 35px rgba(0,0,0,0.25); overflow: hidden;">
                <div class="modal-header" style="background: linear-gradient(135deg, #28a745, #20c997); color: #fff; padding: 20px;">
                    <h4 id="bookingAcceptedLabel" style="margin: 0; font-size: 1.3rem;">Booking Accepted</h4>
                    <button type="button" id="bookingAcceptedCloseBtn" style="background: transparent; border: none; color: #fff; font-size: 1.5rem; cursor: pointer;">&times;</button>
                </div>
                <div class="modal-body" style="padding: 25px;">
                    <p style="font-size: 1.1rem; color: #333; margin-bottom: 15px;">Rider is on the way!</p>
                    <p data-accepted-driver style="margin: 0 0 10px 0; font-weight: 600; color: #333; display: none;"></p>
                    <p data-accepted-vehicle style="margin: 0 0 10px 0; color: #555; display: none;"></p>
                    <p data-accepted-eta style="margin: 0; color: #555; display: none;"></p>
                </div>
                <div class="modal-footer" style="padding: 15px 25px 25px 25px; text-align: right;">
                    <button type="button" id="bookingAcceptedOkBtn" class="btn btn-primary" style="padding: 10px 25px; border-radius: 25px;">OK</button>
                </div>
            </div>
        </div>
    </header>

    <div class="container" style="padding: 40px 0;">
        <div class="dashboard-grid">
            <!-- Booking Form -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-map-marker-alt"></i> Book Your Ride
                    </h2>
                </div>
                
                <?php if ($error): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" id="bookingForm">
                    <!-- Map Container -->
                    <div class="form-group">
                        <label>Select Locations on Map</label>
                        <div id="map"></div>
                        <div style="margin-top: 10px; display: flex; gap: 15px; flex-wrap: wrap;">
                            <button type="button" id="getCurrentLocation" class="btn btn-secondary" style="font-size: 14px;">
                                <i class="fas fa-location-arrow"></i> Use Current Location
                            </button>
                            <button type="button" id="clearMarkers" class="btn btn-secondary" style="font-size: 14px;">
                                <i class="fas fa-times"></i> Clear Markers
                            </button>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="pickup_address">Pickup Location</label>
                            <div style="position: relative;">
                                <input type="text" id="pickup_address" name="pickup_address" required 
                                       placeholder="Enter address or click on map" 
                                       value="<?php echo isset($_POST['pickup_address']) ? htmlspecialchars($_POST['pickup_address']) : ''; ?>">
                                <button type="button" id="pickupSearchBtn" class="btn btn-secondary" style="position: absolute; right: 5px; top: 50%; transform: translateY(-50%); padding: 8px 12px;">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                            <div id="pickupAddressDisplay" style="margin-top: 5px; font-size: 0.85rem; color: #666;"></div>
                        </div>
                        
                        <div class="form-group">
                            <label for="dropoff_address">Dropoff Location</label>
                            <div style="position: relative;">
                                <input type="text" id="dropoff_address" name="dropoff_address" required 
                                       placeholder="Enter address or click on map"
                                   value="<?php echo isset($_POST['dropoff_address']) ? htmlspecialchars($_POST['dropoff_address']) : ''; ?>">
                                <button type="button" id="dropoffSearchBtn" class="btn btn-secondary" style="position: absolute; right: 5px; top: 50%; transform: translateY(-50%); padding: 8px 12px;">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                            <div id="dropoffAddressDisplay" style="margin-top: 5px; font-size: 0.85rem; color: #666;"></div>
                        </div>
                    </div>
                    
                    <!-- Hidden fields for coordinates -->
                    <input type="hidden" id="pickup_latitude" name="pickup_latitude">
                    <input type="hidden" id="pickup_longitude" name="pickup_longitude">
                    <input type="hidden" id="dropoff_latitude" name="dropoff_latitude">
                    <input type="hidden" id="dropoff_longitude" name="dropoff_longitude">
                    <input type="hidden" id="distance_km" name="distance_km">
                    <input type="hidden" id="estimated_fare" name="estimated_fare">
                    <input type="hidden" id="selected_vehicle_type" name="selected_vehicle_type">
                    
                    <!-- Geocoding displays -->
                    <div class="form-group">
                        <label>Pickup Location Details:</label>
                        <div id="pickupLocationDetails" style="padding: 10px; background: #f8f9fa; border-radius: 6px; min-height: 40px; color: #666; font-size: 0.9rem;">
                            <i class="fas fa-map-marker-alt"></i> Select pickup location on map
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Dropoff Location Details:</label>
                        <div id="dropoffLocationDetails" style="padding: 10px; background: #f8f9fa; border-radius: 6px; min-height: 40px; color: #666; font-size: 0.9rem;">
                            <i class="fas fa-flag-checkered"></i> Select dropoff location on map
                        </div>
                    </div>
                    
                    <!-- Vehicle Type Selection -->
                    <div class="form-group" id="vehicleSelectionSection" style="display: none;">
                        <label>Select Vehicle Type</label>
                        <div class="vehicle-types-grid" id="vehicleTypesGrid">
                            <!-- Vehicle options will be populated by JavaScript -->
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <button type="button" id="calculateFare" class="btn btn-secondary" disabled>
                            <i class="fas fa-calculator"></i> Calculate Fare
                        </button>
                    </div>
                    
                    <div id="fareEstimate" style="display: none; padding: 20px; background: #f8f9fa; border-radius: 10px; margin-bottom: 20px;">
                        <h4>Fare Estimate</h4>
                        <div id="fareDetails"></div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-full" id="submitBooking" disabled>
                        <i class="fas fa-car"></i> Book Ride
                    </button>
                </form>
            </div>
            
            <!-- Map -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-map"></i> Route Map
                    </h3>
                </div>
                <div id="map" class="map-container">
                    <div style="display: flex; align-items: center; justify-content: center; height: 100%; color: #666;">
                        <div style="text-align: center;">
                            <i class="fas fa-map-marked-alt" style="font-size: 3rem; margin-bottom: 20px; opacity: 0.5;"></i>
                            <p>Map will be displayed here</p>
                            <p style="font-size: 0.9rem; opacity: 0.7;">Enter pickup and dropoff locations to see the route</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Fare Information -->
        <div class="card" style="margin-top: 30px;">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-info-circle"></i> Fare Information
                </h3>
            </div>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
                <div style="text-align: center; padding: 15px; background: #f8f9fa; border-radius: 10px;">
                    <i class="fas fa-dollar-sign" style="font-size: 2rem; color: #667eea; margin-bottom: 10px;"></i>
                    <h4>Base Fare</h4>
                    <p style="font-size: 1.2rem; font-weight: 600;">₱<?php echo $settings['base_fare']; ?></p>
                </div>
                <div style="text-align: center; padding: 15px; background: #f8f9fa; border-radius: 10px;">
                    <i class="fas fa-route" style="font-size: 2rem; color: #28a745; margin-bottom: 10px;"></i>
                    <h4>Per KM</h4>
                    <p style="font-size: 1.2rem; font-weight: 600;">₱<?php echo $settings['per_km_rate']; ?></p>
                </div>
                <div style="text-align: center; padding: 15px; background: #f8f9fa; border-radius: 10px;">
                    <i class="fas fa-clock" style="font-size: 2rem; color: #ffc107; margin-bottom: 10px;"></i>
                    <h4>Per Minute</h4>
                    <p style="font-size: 1.2rem; font-weight: 600;">₱<?php echo $settings['per_minute_rate']; ?></p>
                </div>
                <div style="text-align: center; padding: 15px; background: #f8f9fa; border-radius: 10px;">
                    <i class="fas fa-shield-alt" style="font-size: 2rem; color: #dc3545; margin-bottom: 10px;"></i>
                    <h4>Minimum Fare</h4>
                    <p style="font-size: 1.2rem; font-weight: 600;">₱<?php echo $settings['minimum_fare']; ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Minimized Badge -->
    <div id="bookingMinimizedBadge" class="booking-minimized-badge" role="button" aria-label="Booking status minimized. Click to restore." tabindex="0" style="display:none;">
        <span class="badge-icon" aria-hidden="true">⏳</span>
        <span class="badge-text">Finding driver…</span>
    </div>
    
    <script>
    // Wait for DOM to be fully loaded before initializing modal controls
    document.addEventListener('DOMContentLoaded', function() {
        console.log('DOM loaded - initializing modal controls');
        
        // Use a timeout to ensure all elements are available
        setTimeout(function() {
            initializeModalControls();
        }, 100);
    });

    function initializeModalControls() {
        const modal = document.getElementById('bookingStatusModal');
        const minimizeBtn = document.getElementById('bookingMinimizeBtn');
        const closeBtn = document.getElementById('bookingCloseBtn');
        let badge = document.getElementById('bookingMinimizedBadge');
        
        console.log('Modal elements check:');
        console.log('Modal:', modal ? 'found' : 'NOT FOUND');
        console.log('Minimize button:', minimizeBtn ? 'found' : 'NOT FOUND');
        console.log('Close button:', closeBtn ? 'found' : 'NOT FOUND');
        console.log('Badge:', badge ? 'found' : 'NOT FOUND');
        
        // Create badge if it doesn't exist
        if (!badge) {
            badge = document.createElement('div');
            badge.id = 'bookingMinimizedBadge';
            badge.className = 'booking-minimized-badge';
            badge.setAttribute('role', 'button');
            badge.setAttribute('tabindex', '0');
            badge.setAttribute('aria-label', 'Click to restore booking status');
            badge.innerHTML = '<div class="badge-icon">⏳</div><div class="badge-text">Finding driver…</div>';
            document.body.appendChild(badge);
            console.log('Badge created and added to body');
        }

        // Badge management functions
        function showBadge(text, state) {
            if (!badge) return;
            
            badge.style.display = 'flex';
            const badgeText = badge.querySelector('.badge-text');
            const badgeIcon = badge.querySelector('.badge-icon');
            
            if (badgeText) badgeText.textContent = text || 'Finding driver…';
            if (badgeIcon) {
                // Update icon based on state
                const icons = {
                    'pending': '⏳',
                    'searching': '🔍',
                    'accepted': '✓',
                    'completed': '🏁',
                    'cancelled': '✕'
                };
                badgeIcon.textContent = icons[state] || '⏳';
            }
            
            // Update state class
            badge.classList.remove('state-pending', 'state-searching', 'state-accepted', 'state-completed', 'state-cancelled');
            badge.classList.add('state-' + (state || 'pending'));
            
            console.log('Badge shown:', text, state);
        }

        function hideBadge() {
            if (!badge) return;
            badge.style.display = 'none';
            console.log('Badge hidden');
        }

        function minimizeModal() {
            if (!modal) {
                console.error('Modal not found for minimization');
                return;
            }
            
            console.log('Minimizing modal');
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
            
            // Show badge with current status
            const currentStatus = document.getElementById('statusTitle')?.textContent || 'Finding driver…';
            const statusKey = getCurrentStatusKey();
            showBadge(currentStatus, statusKey);
            
            // Save minimized state
            try {
                localStorage.setItem('booking_minimized', '1');
                localStorage.setItem('booking_minimized_time', Date.now().toString());
            } catch (e) {
                console.warn('Could not save minimized state:', e);
            }
        }

        function restoreModal() {
            if (!modal) {
                console.error('Modal not found for restoration');
                return;
            }
            
            console.log('Restoring modal');
            modal.style.display = 'block';
            document.body.style.overflow = 'hidden';
            hideBadge();
            
            // Clear minimized state
            try {
                localStorage.removeItem('booking_minimized');
                localStorage.removeItem('booking_minimized_time');
            } catch (e) {
                console.warn('Could not clear minimized state:', e);
            }
            
            // Focus management
            setTimeout(() => {
                const focusTarget = modal.querySelector('button, [tabindex], input, textarea, select');
                if (focusTarget) {
                    focusTarget.focus();
                }
            }, 100);
        }

        function getCurrentStatusKey() {
            const statusTitle = document.getElementById('statusTitle')?.textContent || '';
            const statusMessage = document.getElementById('statusMessage')?.textContent || '';
            
            // Determine status based on text content
            if (statusTitle.includes('Accepted') || statusMessage.includes('accepted')) return 'accepted';
            if (statusTitle.includes('Completed') || statusMessage.includes('completed')) return 'completed';
            if (statusTitle.includes('Cancelled') || statusMessage.includes('cancelled')) return 'cancelled';
            if (statusTitle.includes('Searching') || statusMessage.includes('searching')) return 'searching';
            return 'pending';
        }

        // Global function for updating badge from status updates
        window.updateBookingStatusBadge = function(text, stateKey) {
            try {
                const key = stateKey || getCurrentStatusKey();
                const txt = (typeof text === 'string') ? text : String(text || 'Finding driver…');
                
                // Only show badge if modal is minimized
                if (modal && modal.style.display === 'none') {
                    showBadge(txt, key);
                }
                
                // Auto-restore when accepted (with delay)
                if (key === 'accepted') {
                    setTimeout(() => {
                        restoreModal();
                    }, 2000);
                }
                
                console.log('Badge updated:', txt, key);
            } catch (e) {
                console.error('Failed to update booking status badge:', e);
            }
        };

        // Event listeners for modal controls - ADD THEM PROPERLY
        if (minimizeBtn) {
            console.log('Adding click listener to minimize button');
            minimizeBtn.addEventListener('click', function(e) {
                console.log('Minimize button clicked!');
                e.preventDefault();
                e.stopPropagation();
                minimizeModal();
            });
            
            // Also test with direct onclick as fallback
            minimizeBtn.onclick = function(e) {
                console.log('Minimize button onclick fired!');
                e.preventDefault();
                e.stopPropagation();
                minimizeModal();
            };
        } else {
            console.error('Minimize button not found - cannot add listener');
        }

        if (closeBtn) {
            console.log('Adding click listener to close button');
            closeBtn.addEventListener('click', function(e) {
                console.log('Close button clicked!');
                e.preventDefault();
                e.stopPropagation();
                hideBadge();
                // Use existing close function if available
                if (typeof hideBookingStatusModal === 'function') {
                    hideBookingStatusModal();
                } else {
                    modal.style.display = 'none';
                    document.body.style.overflow = 'auto';
                }
            });
            
            // Also test with direct onclick as fallback
            closeBtn.onclick = function(e) {
                console.log('Close button onclick fired!');
                e.preventDefault();
                e.stopPropagation();
                hideBadge();
                if (typeof hideBookingStatusModal === 'function') {
                    hideBookingStatusModal();
                } else {
                    modal.style.display = 'none';
                    document.body.style.overflow = 'auto';
                }
            };
        } else {
            console.error('Close button not found - cannot add listener');
        }

        // Badge click to restore
        if (badge) {
            badge.addEventListener('click', function(e) {
                console.log('Badge clicked - restoring modal');
                e.preventDefault();
                restoreModal();
            });

            // Badge keyboard support
            badge.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    console.log('Badge key pressed - restoring modal');
                    restoreModal();
                }
            });
        }

        // Keyboard shortcut: press M to minimize when modal is visible
        document.addEventListener('keydown', function(e) {
            if ((e.key === 'm' || e.key === 'M') && modal && modal.style.display !== 'none') {
                e.preventDefault();
                console.log('M key pressed - minimizing modal');
                minimizeModal();
            }
        });

        // Restore minimized state on page load
        try {
            const wasMinimized = localStorage.getItem('booking_minimized') === '1';
            const minimizedTime = localStorage.getItem('booking_minimized_time');
            
            if (wasMinimized && minimizedTime) {
                const timeDiff = Date.now() - parseInt(minimizedTime);
                // Only restore if minimized within last 30 minutes
                if (timeDiff < 30 * 60 * 1000) {
                    setTimeout(() => {
                        minimizeModal();
                    }, 500);
                } else {
                    // Clear old minimized state
                    localStorage.removeItem('booking_minimized');
                    localStorage.removeItem('booking_minimized_time');
                }
            }
        } catch (e) {
            console.warn('Could not restore minimized state:', e);
        }

        // Add test functions for debugging
        window.testModalControls = function() {
            console.log('Testing modal controls...');
            console.log('Modal element:', modal);
            console.log('Minimize button:', minimizeBtn);
            console.log('Close button:', closeBtn);
            console.log('Badge element:', badge);
            
            // Test showing modal
            if (modal) {
                modal.style.display = 'block';
                document.body.style.overflow = 'hidden';
                console.log('Modal shown for testing');
            }
        };

        console.log('Modal controls initialization complete');
    }
    </script>

    <!-- Leaflet JS for OpenStreetMap -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
        let map;
        let pickupMarker;
        let dropoffMarker;
        let routeControl;
        let currentLocationMarker;
        let pickupCoords = null;
        let dropoffCoords = null;

        // Initialize map
        function initMap() {
            // Initialize map centered on Philippines
            map = L.map('map').setView([12.8797, 121.7740], 6);

            // Add OpenStreetMap tiles (free)
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors',
                maxZoom: 18
            }).addTo(map);

            // Custom icons
            const pickupIcon = L.divIcon({
                html: '<div style="background: #28a745; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; font-weight: bold; border: 3px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3);">P</div>',
                iconSize: [30, 30],
                className: 'custom-div-icon'
            });

            const dropoffIcon = L.divIcon({
                html: '<div style="background: #dc3545; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; font-weight: bold; border: 3px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3);">D</div>',
                iconSize: [30, 30],
                className: 'custom-div-icon'
            });

            const currentLocationIcon = L.divIcon({
                html: '<div style="background: #007bff; color: white; border-radius: 50%; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; border: 2px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3);"><i class="fas fa-location-arrow" style="font-size: 10px;"></i></div>',
                iconSize: [20, 20],
                className: 'custom-div-icon'
            });

            // Map click event for setting pickup/dropoff
            let clickMode = 'pickup';
            map.on('click', function(e) {
                if (clickMode === 'pickup') {
                    setPickupLocation(e.latlng.lat, e.latlng.lng);
                    clickMode = 'dropoff';
                } else {
                    setDropoffLocation(e.latlng.lat, e.latlng.lng);
                    clickMode = 'pickup';
                }
            });

            // Get current location button
            document.getElementById('getCurrentLocation').addEventListener('click', function() {
                if (navigator.geolocation) {
                    // Show loading state
                    const button = document.getElementById('getCurrentLocation');
                    const originalText = button.innerHTML;
                    button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Getting location...';
                    button.disabled = true;
                    
                    // Try multiple approaches for better reliability
                    tryLocationWithFallback();
                    
                    function tryLocationWithFallback() {
                        // First try with high accuracy
                        navigator.geolocation.getCurrentPosition(function(position) {
                            handleLocationSuccess(position, button, originalText);
                        }, function(error) {
                            // If high accuracy fails, try with lower accuracy
                            console.warn('High accuracy location failed, trying with lower accuracy:', error);
                            navigator.geolocation.getCurrentPosition(function(position) {
                                handleLocationSuccess(position, button, originalText);
                            }, function(error2) {
                                // If that fails, try with cached location
                                console.warn('Lower accuracy location failed, trying with cached location:', error2);
                                navigator.geolocation.getCurrentPosition(function(position) {
                                    handleLocationSuccess(position, button, originalText);
                                }, function(error3) {
                                    // All attempts failed, use fallback
                                    console.error('All location methods failed:', error3);
                                    handleLocationError(error3, button, originalText);
                                }, {
                                    enableHighAccuracy: false,
                                    timeout: 15000,
                                    maximumAge: 60000 // Use cached location up to 1 minute old
                                });
                            }, {
                                enableHighAccuracy: false,
                                timeout: 15000,
                                maximumAge: 30000 // Use cached location up to 30 seconds old
                            });
                        }, {
                            enableHighAccuracy: true,
                            timeout: 10000, // Shorter timeout for high accuracy
                            maximumAge: 0 // Don't use cached location
                        });
                    }
                    
                    function handleLocationSuccess(position, button, originalText) {
                        const lat = position.coords.latitude;
                        const lng = position.coords.longitude;
                        
                        console.log('Location obtained:', lat, lng, 'Accuracy:', position.coords.accuracy + 'm');
                        
                        // Show accuracy info
                        let accuracyMessage = '';
                        if (position.coords.accuracy > 100) {
                            accuracyMessage = 'Location accuracy is low (' + Math.round(position.coords.accuracy) + 'm). For better accuracy, please move to an open area with clear view of the sky.';
                        } else if (position.coords.accuracy > 50) {
                            accuracyMessage = 'Location accuracy: ' + Math.round(position.coords.accuracy) + 'm (moderate)';
                        } else {
                            accuracyMessage = 'Location accuracy: ' + Math.round(position.coords.accuracy) + 'm (good)';
                        }
                        
                        // Set current location marker
                        if (currentLocationMarker) {
                            map.removeLayer(currentLocationMarker);
                        }
                        currentLocationMarker = L.marker([lat, lng], {icon: currentLocationIcon}).addTo(map);
                        
                        // Add accuracy circle
                        if (window.accuracyCircle) {
                            map.removeLayer(window.accuracyCircle);
                        }
                        window.accuracyCircle = L.circle([lat, lng], {
                            radius: position.coords.accuracy,
                            fillColor: '#007bff',
                            fillOpacity: 0.1,
                            color: '#007bff',
                            weight: 2
                        }).addTo(map);
                        
                        // Center map on current location with appropriate zoom
                        const zoomLevel = position.coords.accuracy > 100 ? 14 : 16;
                        map.setView([lat, lng], zoomLevel);
                        
                        // Set as pickup location
                        setPickupLocation(lat, lng);
                        
                        // Show success message
                        showNotification('Location found successfully! ' + accuracyMessage, 'success');
                        
                        // Reset button
                        button.innerHTML = '<i class="fas fa-location-arrow"></i> Use Current Location';
                        button.disabled = false;
                    }
                    
                    function handleLocationError(error, button, originalText) {
                        let errorMessage = 'Unable to get your location. ';
                        let suggestion = '';
                        
                        switch(error.code) {
                            case error.PERMISSION_DENIED:
                                errorMessage += 'Location access was denied.';
                                suggestion = 'Please enable location services in your browser settings and click the location permission when prompted.';
                                break;
                            case error.POSITION_UNAVAILABLE:
                                errorMessage += 'Location information is unavailable.';
                                suggestion = 'Check if your GPS/location services are enabled, or try using a different browser.';
                                break;
                            case error.TIMEOUT:
                                errorMessage += 'Location request timed out.';
                                suggestion = 'This often happens in localhost environments. Try accessing from a live server or use the manual map selection.';
                                break;
                            default:
                                errorMessage += 'An unknown error occurred.';
                                suggestion = 'Please try again or select your location manually on the map.';
                        }
                        
                        console.error('Geolocation error:', error);
                        
                        // Show detailed error message
                        showNotification(errorMessage + ' ' + suggestion, 'error');
                        
                        // Offer fallback location for testing
                        if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
                            if (confirm('Location services not working on localhost. Would you like to use a test location (Manila area) for testing?')) {
                                // Use Manila as test location
                                const testLat = 14.5995;
                                const testLng = 120.9842;
                                
                                if (currentLocationMarker) {
                                    map.removeLayer(currentLocationMarker);
                                }
                                currentLocationMarker = L.marker([testLat, testLng], {icon: currentLocationIcon}).addTo(map);
                                map.setView([testLat, testLng], 15);
                                setPickupLocation(testLat, testLng);
                                
                                showNotification('Using test location (Manila) for demonstration', 'info');
                            }
                        }
                        
                        // Reset button
                        button.innerHTML = originalText;
                        button.disabled = false;
                    }
                    
                } else {
                    showNotification('Geolocation is not supported by your browser. Please try using a modern browser like Chrome, Firefox, or Safari.', 'error');
                }
            });

            // Clear markers button
            document.getElementById('clearMarkers').addEventListener('click', function() {
                clearAllMarkers();
            });
        }

        // Notification system for better user feedback
        function showNotification(message, type = 'info') {
            // Create notification element if it doesn't exist
            let notificationContainer = document.getElementById('notificationContainer');
            if (!notificationContainer) {
                notificationContainer = document.createElement('div');
                notificationContainer.id = 'notificationContainer';
                notificationContainer.style.cssText = `
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    z-index: 10000;
                    max-width: 400px;
                `;
                document.body.appendChild(notificationContainer);
            }
            
            // Create notification
            const notification = document.createElement('div');
            notification.style.cssText = `
                margin-bottom: 10px;
                padding: 15px 20px;
                border-radius: 8px;
                color: white;
                font-weight: 500;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                transform: translateX(100%);
                transition: transform 0.3s ease;
                display: flex;
                align-items: center;
                gap: 10px;
            `;
            
            // Set color based on type
            const colors = {
                'success': '#28a745',
                'error': '#dc3545',
                'warning': '#ffc107',
                'info': '#007bff'
            };
            notification.style.background = colors[type] || colors.info;
            
            // Add icon
            const icons = {
                'success': '✓',
                'error': '✕',
                'warning': '⚠',
                'info': 'ℹ'
            };
            notification.innerHTML = `<span style="font-size: 18px;">${icons[type] || icons.info}</span><span>${message}</span>`;
            
            // Add to container
            notificationContainer.appendChild(notification);
            
            // Animate in
            setTimeout(() => {
                notification.style.transform = 'translateX(0)';
            }, 100);
            
            // Auto remove after 5 seconds
            setTimeout(() => {
                notification.style.transform = 'translateX(100%)';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 300);
            }, 5000);
            
            // Add click to dismiss
            notification.style.cursor = 'pointer';
            notification.addEventListener('click', () => {
                notification.style.transform = 'translateX(100%)';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 300);
            });
        }

        function setPickupLocation(lat, lng, address = null) {
            // Remove existing pickup marker
            if (pickupMarker) {
                map.removeLayer(pickupMarker);
            }

            // Add new pickup marker
            const pickupIcon = L.divIcon({
                html: '<div style="background: #28a745; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; font-weight: bold; border: 3px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3);">P</div>',
                iconSize: [30, 30],
                className: 'custom-div-icon'
            });

            pickupMarker = L.marker([lat, lng], {icon: pickupIcon}).addTo(map);
            pickupCoords = {lat: lat, lng: lng};

            // Update form fields
            document.getElementById('pickup_latitude').value = lat;
            document.getElementById('pickup_longitude').value = lng;
            
            // Get human-readable address if not provided
            if (!address) {
                reverseGeocode(lat, lng, function(result) {
                    if (result) {
                        document.getElementById('pickup_address').value = result.display_name;
                        document.getElementById('pickupAddressDisplay').textContent = result.display_name;
                    } else {
                        document.getElementById('pickup_address').value = `Lat: ${lat.toFixed(6)}, Lng: ${lng.toFixed(6)}`;
                        document.getElementById('pickupAddressDisplay').textContent = 'Coordinates only';
                    }
                });
            } else {
                document.getElementById('pickup_address').value = address;
                document.getElementById('pickupAddressDisplay').textContent = address;
            }

            // Draw route if dropoff is set
            if (dropoffCoords) {
                drawRoute();
            }
        }

        function setDropoffLocation(lat, lng, address = null) {
            // Remove existing dropoff marker
            if (dropoffMarker) {
                map.removeLayer(dropoffMarker);
            }

            // Add new dropoff marker
            const dropoffIcon = L.divIcon({
                html: '<div style="background: #dc3545; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; font-weight: bold; border: 3px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3);">D</div>',
                iconSize: [30, 30],
                className: 'custom-div-icon'
            });

            dropoffMarker = L.marker([lat, lng], {icon: dropoffIcon}).addTo(map);
            dropoffCoords = {lat: lat, lng: lng};

            // Update form fields
            document.getElementById('dropoff_latitude').value = lat;
            document.getElementById('dropoff_longitude').value = lng;
            
            // Get human-readable address if not provided
            if (!address) {
                reverseGeocode(lat, lng, function(result) {
                    if (result) {
                        document.getElementById('dropoff_address').value = result.display_name;
                        document.getElementById('dropoffAddressDisplay').textContent = result.display_name;
                    } else {
                        document.getElementById('dropoff_address').value = `Lat: ${lat.toFixed(6)}, Lng: ${lng.toFixed(6)}`;
                        document.getElementById('dropoffAddressDisplay').textContent = 'Coordinates only';
                    }
                });
            } else {
                document.getElementById('dropoff_address').value = address;
                document.getElementById('dropoffAddressDisplay').textContent = address;
            }

            // Draw route if pickup is set
            if (pickupCoords) {
                drawRoute();
            }
        }

        // Geocoding functions
        function geocodeAddress(address, callback) {
            fetch('../api/geocoding.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=geocode&address=' + encodeURIComponent(address)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    callback(data.data);
                } else {
                    callback(null);
                }
            })
            .catch(error => {
                console.error('Geocoding error:', error);
                callback(null);
            });
        }

        function reverseGeocode(lat, lng, callback) {
            fetch('../api/geocoding.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=reverse_geocode&latitude=' + lat + '&longitude=' + lng
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    callback(data.data);
                } else {
                    callback(null);
                }
            })
            .catch(error => {
                console.error('Reverse geocoding error:', error);
                callback(null);
            });
        }

        // Address search functionality
        function setupAddressSearch() {
            // Pickup address search
            document.getElementById('pickupSearchBtn').addEventListener('click', function() {
                const address = document.getElementById('pickup_address').value;
                if (address.trim()) {
                    geocodeAddress(address, function(result) {
                        if (result) {
                            map.setView([result.latitude, result.longitude], 16);
                            setPickupLocation(result.latitude, result.longitude, result.display_name);
                        } else {
                            alert('Address not found. Please try a different address or click on the map.');
                        }
                    });
                }
            });

            // Dropoff address search
            document.getElementById('dropoffSearchBtn').addEventListener('click', function() {
                const address = document.getElementById('dropoff_address').value;
                if (address.trim()) {
                    geocodeAddress(address, function(result) {
                        if (result) {
                            map.setView([result.latitude, result.longitude], 16);
                            setDropoffLocation(result.latitude, result.longitude, result.display_name);
                        } else {
                            alert('Address not found. Please try a different address or click on the map.');
                        }
                    });
                }
            });

            // Enter key support for address inputs
            document.getElementById('pickup_address').addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    document.getElementById('pickupSearchBtn').click();
                }
            });

            document.getElementById('dropoff_address').addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    document.getElementById('dropoffSearchBtn').click();
                }
            });

            // Update geocoding displays when coordinates change
            function updateLocationDetails(lat, lng, elementId, icon) {
                if (!lat || !lng) {
                    document.getElementById(elementId).innerHTML = `<i class="fas ${icon}"></i> Select location on map`;
                    return;
                }

                fetch('../api/geocoding.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `action=reverse_geocode&latitude=${lat}&longitude=${lng}`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.data) {
                        const displayName = data.data.display_name;
                        const shortName = displayName.length > 80 ? displayName.substring(0, 80) + '...' : displayName;
                        document.getElementById(elementId).innerHTML = `<i class="fas ${icon}"></i> ${shortName}`;
                        document.getElementById(elementId).style.color = '#333';
                    } else {
                        document.getElementById(elementId).innerHTML = `<i class="fas ${icon}"></i> ${lat.toFixed(6)}, ${lng.toFixed(6)}`;
                        document.getElementById(elementId).style.color = '#666';
                    }
                })
                .catch(error => {
                    console.error('Geocoding error:', error);
                    document.getElementById(elementId).innerHTML = `<i class="fas ${icon}"></i> ${lat.toFixed(6)}, ${lng.toFixed(6)}`;
                    document.getElementById(elementId).style.color = '#666';
                });
            }

            // Monitor coordinate changes and update displays
            const pickupLatInput = document.getElementById('pickup_latitude');
            const pickupLngInput = document.getElementById('pickup_longitude');
            const dropoffLatInput = document.getElementById('dropoff_latitude');
            const dropoffLngInput = document.getElementById('dropoff_longitude');

            function monitorCoordinateChanges() {
                const lastPickupLat = pickupLatInput.value;
                const lastPickupLng = pickupLngInput.value;
                const lastDropoffLat = dropoffLatInput.value;
                const lastDropoffLng = dropoffLngInput.value;

                setTimeout(() => {
                    if (pickupLatInput.value !== lastPickupLat || pickupLngInput.value !== lastPickupLng) {
                        updateLocationDetails(pickupLatInput.value, pickupLngInput.value, 'pickupLocationDetails', 'fa-map-marker-alt');
                    }
                    if (dropoffLatInput.value !== lastDropoffLat || dropoffLngInput.value !== lastDropoffLng) {
                        updateLocationDetails(dropoffLatInput.value, dropoffLngInput.value, 'dropoffLocationDetails', 'fa-flag-checkered');
                    }
                    monitorCoordinateChanges();
                }, 500);
            }

            monitorCoordinateChanges();
        }

        function drawRoute() {
            // Remove existing route
            if (routeControl) {
                map.removeControl(routeControl);
            }

            // Calculate distance and draw simple line
            const distance = calculateDistance(
                pickupCoords.lat, pickupCoords.lng,
                dropoffCoords.lat, dropoffCoords.lng
            );

            // Draw straight line between points (simplified route)
            const routeLine = L.polyline([
                [pickupCoords.lat, pickupCoords.lng],
                [dropoffCoords.lat, dropoffCoords.lng]
            ], {
                color: '#007bff',
                weight: 4,
                opacity: 0.7,
                dashArray: '10, 10'
            }).addTo(map);

            // Update distance and calculate fare
            document.getElementById('distance_km').value = distance.toFixed(2);
            calculateFare(distance);
        }

        function calculateDistance(lat1, lon1, lat2, lon2) {
            const R = 6371; // Radius of the Earth in km
            const dLat = (lat2 - lat1) * Math.PI / 180;
            const dLon = (lon2 - lon1) * Math.PI / 180;
            const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                    Math.sin(dLon/2) * Math.sin(dLon/2);
            const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
            return R * c;
        }

        function calculateFare(distance) {
            // Check if vehicle type is selected
            if (!selectedVehicleType) {
                showNotification('Please select a vehicle type first', 'warning');
                return;
            }
            
            // Use vehicle-specific pricing
            const vehicle = selectedVehicleType;
            const baseFare = vehicle.baseFare;
            const perKmRate = vehicle.perKmRate;
            const perMinuteRate = vehicle.perMinuteRate;
            const minimumFare = vehicle.minimumFare;
            
            // Estimate duration (roughly 3 minutes per km in city traffic)
            const duration = distance * 3;
            
            const distanceFare = distance * perKmRate;
            const timeFare = duration * perMinuteRate;
            const totalFare = Math.max(baseFare + distanceFare + timeFare, minimumFare);
            
            // Update hidden field
            document.getElementById('estimated_fare').value = totalFare.toFixed(2);
            
            // Show fare estimate with vehicle type
            document.getElementById('fareDetails').innerHTML = `
                <div class="route-info">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                        <div>
                            <strong>Distance:</strong> ${distance.toFixed(2)} km
                        </div>
                        <div>
                            <strong>Estimated Duration:</strong> ${Math.round(duration)} minutes
                        </div>
                    </div>
                    <div style="background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); color: white; padding: 12px; border-radius: 8px; margin-bottom: 15px; text-align: center;">
                        <div style="font-size: 0.9rem; opacity: 0.9; margin-bottom: 5px;">Vehicle Type</div>
                        <div style="font-size: 1.2rem; font-weight: 600;">
                            <i class="${vehicle.icon}" style="margin-right: 8px;"></i>${vehicle.name}
                        </div>
                    </div>
                    <div style="border-top: 2px solid var(--border-color); padding-top: 15px;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                            <span>Base Fare:</span>
                            <span>₱${baseFare.toFixed(2)}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                            <span>Distance (${distance.toFixed(2)} km × ₱${perKmRate}):</span>
                            <span>₱${distanceFare.toFixed(2)}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                            <span>Time (${Math.round(duration)} min × ₱${perMinuteRate}):</span>
                            <span>₱${timeFare.toFixed(2)}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; font-weight: 600; font-size: 1.1rem; border-top: 1px solid var(--border-color); padding-top: 10px; color: var(--primary-color);">
                            <span>Total Fare:</span>
                            <span>₱${totalFare.toFixed(2)}</span>
                        </div>
                    </div>
                </div>
            `;
            
            document.getElementById('fareEstimate').style.display = 'block';
            document.getElementById('submitBooking').disabled = false;
            
            // Show success notification
            showNotification(`Fare calculated for ${vehicle.name}: ₱${totalFare.toFixed(2)}`, 'success');
        }

        function clearAllMarkers() {
            if (pickupMarker) {
                map.removeLayer(pickupMarker);
                pickupMarker = null;
            }
            if (dropoffMarker) {
                map.removeLayer(dropoffMarker);
                dropoffMarker = null;
            }
            if (routeControl) {
                map.removeControl(routeControl);
                routeControl = null;
            }
            
            // Clear form fields
            document.getElementById('pickup_address').value = '';
            document.getElementById('dropoff_address').value = '';
            document.getElementById('pickup_latitude').value = '';
            document.getElementById('pickup_longitude').value = '';
            document.getElementById('dropoff_latitude').value = '';
            document.getElementById('dropoff_longitude').value = '';
            document.getElementById('distance_km').value = '';
            document.getElementById('estimated_fare').value = '';
            
            // Clear address displays
            document.getElementById('pickupAddressDisplay').textContent = '';
            document.getElementById('dropoffAddressDisplay').textContent = '';
            
            // Reset geocoding displays
            document.getElementById('pickupLocationDetails').innerHTML = '<i class="fas fa-map-marker-alt"></i> Select pickup location on map';
            document.getElementById('pickupLocationDetails').style.color = '#666';
            document.getElementById('dropoffLocationDetails').innerHTML = '<i class="fas fa-flag-checkered"></i> Select dropoff location on map';
            document.getElementById('dropoffLocationDetails').style.color = '#666';
            
            // Hide fare estimate
            document.getElementById('fareEstimate').style.display = 'none';
            document.getElementById('submitBooking').disabled = true;
            
            pickupCoords = null;
            dropoffCoords = null;
        }

        // Vehicle Type Selection System
        let selectedVehicleType = null;
        
        const vehicleTypes = [
            {
                id: 'motorcycle',
                name: 'Motorcycle',
                icon: 'fas fa-motorcycle',
                description: 'Quick and affordable for solo riders',
                baseFare: 30,
                perKmRate: 12,
                perMinuteRate: 4,
                minimumFare: 40,
                estimatedPrice: 'Starts at ₱40'
            },
            {
                id: 'tricycle',
                name: 'Tricycle',
                icon: 'fas fa-tricycle-monster',
                description: 'Good for 2-3 passengers, short distances',
                baseFare: 40,
                perKmRate: 15,
                perMinuteRate: 5,
                minimumFare: 50,
                estimatedPrice: 'Starts at ₱50'
            },
            {
                id: 'car',
                name: '4-Wheel Car',
                icon: 'fas fa-car',
                description: 'Comfortable for up to 4 passengers',
                baseFare: 50,
                perKmRate: 18,
                perMinuteRate: 6,
                minimumFare: 65,
                estimatedPrice: 'Starts at ₱65'
            }
        ];

        function initVehicleSelection() {
            // Monitor location inputs to show vehicle selection when both are filled
            const pickupAddress = document.getElementById('pickup_address');
            const dropoffAddress = document.getElementById('dropoff_address');
            
            function checkLocationsAndShowVehicles() {
                const pickupFilled = pickupAddress.value.trim() !== '';
                const dropoffFilled = dropoffAddress.value.trim() !== '';
                
                if (pickupFilled && dropoffFilled && !selectedVehicleType) {
                    showVehicleSelection();
                } else if (!pickupFilled || !dropoffFilled) {
                    hideVehicleSelection();
                    resetVehicleSelection();
                }
            }
            
            pickupAddress.addEventListener('input', checkLocationsAndShowVehicles);
            dropoffAddress.addEventListener('input', checkLocationsAndShowVehicles);
            
            // Also check when coordinates are set (via map clicks)
            const pickupLat = document.getElementById('pickup_latitude');
            const dropoffLat = document.getElementById('dropoff_latitude');
            
            const observer = new MutationObserver(checkLocationsAndShowVehicles);
            observer.observe(pickupLat, { attributes: true, attributeFilter: ['value'] });
            observer.observe(dropoffLat, { attributes: true, attributeFilter: ['value'] });
        }

        function showVehicleSelection() {
            const vehicleSection = document.getElementById('vehicleSelectionSection');
            const vehicleGrid = document.getElementById('vehicleTypesGrid');
            
            // Clear existing content
            vehicleGrid.innerHTML = '';
            
            // Create vehicle cards
            vehicleTypes.forEach(vehicle => {
                const card = document.createElement('div');
                card.className = 'vehicle-card';
                card.dataset.vehicleId = vehicle.id;
                card.innerHTML = `
                    <div class="vehicle-icon">
                        <i class="${vehicle.icon}"></i>
                    </div>
                    <div class="vehicle-name">${vehicle.name}</div>
                    <div class="vehicle-description">${vehicle.description}</div>
                    <div class="vehicle-price">${vehicle.estimatedPrice}</div>
                `;
                
                card.addEventListener('click', () => selectVehicle(vehicle));
                vehicleGrid.appendChild(card);
            });
            
            vehicleSection.style.display = 'block';
            
            // Animate cards appearing
            setTimeout(() => {
                document.querySelectorAll('.vehicle-card').forEach((card, index) => {
                    setTimeout(() => {
                        card.style.opacity = '0';
                        card.style.transform = 'translateY(20px)';
                        card.style.transition = 'all 0.3s ease';
                        
                        setTimeout(() => {
                            card.style.opacity = '1';
                            card.style.transform = 'translateY(0)';
                        }, 50);
                    }, index * 100);
                });
            }, 100);
        }

        function hideVehicleSelection() {
            const vehicleSection = document.getElementById('vehicleSelectionSection');
            vehicleSection.style.display = 'none';
        }

        function selectVehicle(vehicle) {
            selectedVehicleType = vehicle;
            
            // Update UI
            document.querySelectorAll('.vehicle-card').forEach(card => {
                card.classList.remove('selected');
            });
            
            const selectedCard = document.querySelector(`[data-vehicle-id="${vehicle.id}"]`);
            selectedCard.classList.add('selected');
            
            // Update hidden field
            document.getElementById('selected_vehicle_type').value = vehicle.id;
            
            // Enable calculate fare button
            document.getElementById('calculateFare').disabled = false;
            
            // Show notification
            showNotification(`${vehicle.name} selected. Click 'Calculate Fare' to see pricing.`, 'success');
        }

        function resetVehicleSelection() {
            selectedVehicleType = null;
            document.getElementById('selected_vehicle_type').value = '';
            document.getElementById('calculateFare').disabled = true;
            
            // Hide fare estimate
            document.getElementById('fareEstimate').style.display = 'none';
            document.getElementById('submitBooking').disabled = true;
        }

        // Initialize map on page load
        document.addEventListener('DOMContentLoaded', function() {
            initMap();
            setupAddressSearch();
            initVehicleSelection();
            
            // Add calculate fare button event listener
            document.getElementById('calculateFare').addEventListener('click', function() {
                // Check if both locations are set and vehicle type is selected
                if (!pickupCoords || !dropoffCoords) {
                    showNotification('Please set both pickup and dropoff locations', 'warning');
                    return;
                }
                
                if (!selectedVehicleType) {
                    showNotification('Please select a vehicle type first', 'warning');
                    return;
                }
                
                // Calculate distance and fare
                const distance = calculateDistance(
                    pickupCoords.lat, pickupCoords.lng,
                    dropoffCoords.lat, dropoffCoords.lng
                );
                
                document.getElementById('distance_km').value = distance.toFixed(2);
                calculateFare(distance);
            });
            
            // Initialize enhanced GPS tracking
            if (window.GPSTracker) {
                window.gpsTracker = new GPSTracker();
                window.gpsTracker.init();
            }
            
            // Initialize booking status system
            initBookingStatusSystem();
        });
        
        // Booking Status Management System
        let bookingStatusInterval = null;
        let currentBookingId = null;
        let statusCheckCount = 0;
        let bookingAcceptedModalShown = false;
        const MAX_STATUS_CHECKS = 300; // 5 minutes at 1-second intervals
        
        function initBookingStatusSystem() {
            // Handle form submission with AJAX
            const bookingForm = document.getElementById('bookingForm');
            if (bookingForm) {
                bookingForm.addEventListener('submit', handleBookingSubmission);
            }
            
            // Setup modal event listeners
            setupModalEventListeners();
            
            // Check for active booking on page load/refresh
            checkActiveBookingOnLoad();
        }
        
        function checkActiveBookingOnLoad() {
            // Check if there's an active booking when page loads
            fetch('../api/get_active_booking.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.active && data.booking_id) {
                        // Set current booking ID
                        currentBookingId = data.booking_id;
                        
                        // Show modal with booking details
                        showBookingStatusModal({
                            booking_id: data.booking_id,
                            pickup_address: data.pickup_address || 'Pickup location',
                            dropoff_address: data.dropoff_address || 'Dropoff location',
                            estimated_fare: data.estimated_fare,
                            distance_km: data.distance_km
                        });
                        
                        // Handle the current status
                        handleStatusUpdate(data.status, data);
                        
                        // Start status polling if still pending
                        if (data.status === 'pending') {
                            startStatusPolling(data.booking_id);
                        }
                    }
                })
                .catch(error => {
                    console.error('Error checking active booking:', error);
                });
        }
        
        function handleBookingSubmission(e) {
            e.preventDefault();
            
            const submitBtn = document.getElementById('submitBooking');
            const originalText = submitBtn.innerHTML;
            
            // Validate form
            const pickupAddress = document.getElementById('pickup_address').value;
            const dropoffAddress = document.getElementById('dropoff_address').value;
            const pickupLat = document.getElementById('pickup_latitude').value;
            const pickupLng = document.getElementById('pickup_longitude').value;
            const dropoffLat = document.getElementById('dropoff_latitude').value;
            const dropoffLng = document.getElementById('dropoff_longitude').value;
            const fare = document.getElementById('estimated_fare').value;
            const distance = document.getElementById('distance_km').value;
            
            if (!pickupAddress || !dropoffAddress || !pickupLat || !pickupLng || !dropoffLat || !dropoffLng) {
                alert('Please complete all required fields and select locations on the map.');
                return;
            }
            
            // Show loading state
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating booking...';
            
            // Create AJAX request
            const formData = new FormData();
            formData.append('pickup_address', pickupAddress);
            formData.append('dropoff_address', dropoffAddress);
            formData.append('pickup_latitude', pickupLat);
            formData.append('pickup_longitude', pickupLng);
            formData.append('dropoff_latitude', dropoffLat);
            formData.append('dropoff_longitude', dropoffLng);
            formData.append('estimated_fare', fare);
            formData.append('distance_km', distance);
            formData.append('selected_vehicle_type', selectedVehicleType.id);
            
            fetch('booking.php', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    currentBookingId = data.booking_id;
                    
                    // Show booking status modal
                    showBookingStatusModal({
                        booking_id: data.booking_id,
                        pickup_address: pickupAddress,
                        dropoff_address: dropoffAddress,
                        estimated_fare: fare,
                        distance_km: distance
                    });
                    
                    // Start status polling
                    startStatusPolling(data.booking_id);
                    
                    // Reset form
                    bookingForm.reset();
                    clearAllMarkers();
                    document.getElementById('fareEstimate').style.display = 'none';
                    
                } else {
                    alert(data.error || 'Failed to create booking. Please try again.');
                }
            })
            .catch(error => {
                console.error('Booking error:', error);
                alert('An error occurred. Please try again.');
            })
            .finally(() => {
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
            });
        }
        
        function showBookingStatusModal(bookingData) {
            const modal = document.getElementById('bookingStatusModal');
            
            // Update trip details
            document.getElementById('tripPickup').textContent = bookingData.pickup_address;
            document.getElementById('tripDropoff').textContent = bookingData.dropoff_address;

            bookingAcceptedModalShown = false;
            hideBookingAcceptedModal();
            
            // Show modal
            modal.style.display = 'block';
            document.body.style.overflow = 'hidden';
            
            // Start progress animation
            animateProgress();
        }
        
        function animateProgress() {
            let progress = 0;
            const progressBar = document.getElementById('progressBar');
            const progressText = document.getElementById('progressText');
            
            const progressInterval = setInterval(() => {
                if (progress < 85) {
                    progress += Math.random() * 3;
                    progressBar.style.width = progress + '%';
                    
                    const messages = [
                        'Searching for nearby drivers...',
                        'Contacting available drivers...',
                        'Finding the best driver for you...',
                        'Almost there...'
                    ];
                    progressText.textContent = messages[Math.floor(Math.random() * messages.length)];
                } else {
                    clearInterval(progressInterval);
                }
            }, 1000);
        }
        
        function startStatusPolling(bookingId) {
            statusCheckCount = 0;
            
            if (bookingStatusInterval) {
                clearInterval(bookingStatusInterval);
            }
            
            // Try Server-Sent Events first (more efficient)
            if (typeof(EventSource) !== 'undefined') {
                try {
                    startSSEStatusPolling(bookingId);
                } catch (error) {
                    console.log('SSE not available, falling back to AJAX polling');
                    startAJAXStatusPolling(bookingId);
                }
            } else {
                // Fallback to AJAX polling
                startAJAXStatusPolling(bookingId);
            }
        }
        
        function startSSEStatusPolling(bookingId) {
            const eventSource = new EventSource(`../api/booking_status_stream.php?booking_id=${bookingId}`);
            
            eventSource.onmessage = function(event) {
                try {
                    const data = JSON.parse(event.data);
                    
                    if (data.error) {
                        console.error('SSE error:', data.error);
                        eventSource.close();
                        startAJAXStatusPolling(bookingId); // Fallback to AJAX
                        return;
                    }
                    
                    if (data.heartbeat) {
                        // Just a heartbeat, ignore
                        return;
                    }
                    
                    if (data.stream_end) {
                        console.log('SSE stream ended:', data.reason);
                        eventSource.close();
                        return;
                    }
                    
                    if (data.success) {
                        handleStatusUpdate(data.status, data);
                        
                        const finalStatuses = ['cancelled', 'completed', 'expired'];
                        if (finalStatuses.includes(data.status)) {
                            eventSource.close();
                        }
                    }
                } catch (error) {
                    console.error('SSE parse error:', error);
                    eventSource.close();
                    startAJAXStatusPolling(bookingId);
                }
            };
            
            eventSource.onerror = function(event) {
                console.error('SSE error:', event);
                eventSource.close();
                startAJAXStatusPolling(bookingId); // Fallback to AJAX
            };
            
            // Set timeout for SSE connection
            setTimeout(() => {
                if (eventSource.readyState !== EventSource.CLOSED) {
                    eventSource.close();
                    startAJAXStatusPolling(bookingId);
                }
            }, 300000); // 5 minutes
        }
        
        function startAJAXStatusPolling(bookingId) {
            bookingStatusInterval = setInterval(() => {
                checkBookingStatus(bookingId);
                statusCheckCount++;
                
                // Auto-stop after max checks
                if (statusCheckCount >= MAX_STATUS_CHECKS) {
                    clearInterval(bookingStatusInterval);
                    updateStatusDisplay('expired', 'Request Expired', 'Your ride request has expired. Please try booking again.');
                }
            }, 2000); // Check every 2 seconds
        }
        
        function checkBookingStatus(bookingId) {
            fetch(`../api/check_booking_status.php?booking_id=${bookingId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        handleStatusUpdate(data.status, data);
                    } else {
                        console.error('Status check failed:', data.error);
                    }
                })
                .catch(error => {
                    console.error('Status check error:', error);
                });
        }
        
        function handleStatusUpdate(status, data) {
            // Play notification sound based on status
            playStatusSound(status);
            
            switch(status) {
                case 'accepted':
                    // Build informative message with driver details
                    let acceptedMessage = 'Your ride request has been accepted!';
                    if (data.driver && data.driver.full_name) {
                        acceptedMessage += ` ${data.driver.full_name} will be your driver.`;
                    }
                    if (data.driver && data.driver.estimated_arrival) {
                        acceptedMessage += ` Estimated arrival: ${data.driver.estimated_arrival}.`;
                    }
                    updateStatusDisplay('accepted', 'Booking Accepted', acceptedMessage, data);
                    showDriverDetails(data.driver);
                    showBookingAcceptedModal(data);
                    break;
                case 'cancelled':
                    updateStatusDisplay('cancelled', 'Ride Cancelled', data.cancellation_reason || 'Your ride has been cancelled.');
                    if (bookingStatusInterval) {
                        clearInterval(bookingStatusInterval);
                    }
                    break;
                case 'expired':
                    updateStatusDisplay('expired', 'Request Expired', 'No drivers were available. Please try again.');
                    if (bookingStatusInterval) {
                        clearInterval(bookingStatusInterval);
                    }
                    break;
                case 'in_progress':
                    updateStatusDisplay('in_progress', 'Ride in Progress', 'Your driver is on the way to pickup location.');
                    if (data.driver) {
                        showDriverDetails(data.driver);
                    }
                    break;
                case 'completed':
                    updateStatusDisplay('completed', 'Ride Completed', 'Thank you for riding with TripGo!');
                    // Check if rating is requested and show rating modal
                    if (data.rating_requested) {
                        setTimeout(() => showRatingModal(data.booking_id), 1000);
                    }
                    if (bookingStatusInterval) {
                        clearInterval(bookingStatusInterval);
                    }
                    break;
            }
        }
        
        function playStatusSound(status) {
            try {
                const audio = new Audio();
                
                switch(status) {
                    case 'accepted':
                        audio.src = 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIG2m98OScTgwOUarm7blmFgU7k9n1unEiBC13yO/eizEIHWq+8+OWT';
                        break;
                    case 'cancelled':
                        audio.src = 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIG2m98OScTgwOUarm7blmFgU7k9n1unEiBC13yO/eizEIHWq+8+OWT';
                        break;
                    case 'in_progress':
                        audio.src = 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIG2m98OScTgwOUarm7blmFgU7k9n1unEiBC13yO/eizEIHWq+8+OWT';
                        break;
                    default:
                        return; // No sound for other statuses
                }
                
                audio.volume = 0.5;
                audio.play().catch(e => console.log('Audio play failed:', e));
            } catch (error) {
                console.log('Sound notification failed:', error);
            }
        }
        
        function updateStatusDisplay(status, title, message, data = null) {
            const statusIcon = document.getElementById('statusIcon');
            const statusTitle = document.getElementById('statusTitle');
            const statusMessage = document.getElementById('statusMessage');
            const actionButtons = document.getElementById('actionButtons');
            const acceptedActions = document.getElementById('acceptedActions');
            const driverDetails = document.getElementById('driverDetails');
            const progressBar = document.getElementById('progressBar');
            const progressText = document.getElementById('progressText');
            
            // Update icon and colors based on status
            switch(status) {
                case 'accepted':
                    statusIcon.innerHTML = '<i class="fas fa-check-circle" style="color: #28a745;"></i>';
                    actionButtons.style.display = 'none';
                    acceptedActions.style.display = 'block';
                    driverDetails.style.display = 'block';
                    progressBar.style.width = '100%';
                    progressBar.style.background = '#28a745';
                    progressText.textContent = 'Booking Accepted';
                    break;
                case 'cancelled':
                    statusIcon.innerHTML = '<i class="fas fa-times-circle" style="color: #dc3545;"></i>';
                    actionButtons.style.display = 'none';
                    progressBar.style.width = '100%';
                    progressBar.style.background = '#dc3545';
                    progressText.textContent = 'Ride cancelled';
                    break;
                case 'expired':
                    statusIcon.innerHTML = '<i class="fas fa-clock" style="color: #ffc107;"></i>';
                    actionButtons.style.display = 'none';
                    progressBar.style.width = '100%';
                    progressBar.style.background = '#ffc107';
                    progressText.textContent = 'Request expired';
                    break;
                case 'in_progress':
                    statusIcon.innerHTML = '<i class="fas fa-car" style="color: #007bff;"></i>';
                    actionButtons.style.display = 'none';
                    acceptedActions.style.display = 'block';
                    driverDetails.style.display = 'block';
                    progressBar.style.width = '100%';
                    progressText.textContent = 'Ride in progress';
                    break;
                case 'completed':
                    statusIcon.innerHTML = '<i class="fas fa-flag-checkered" style="color: #28a745;"></i>';
                    actionButtons.style.display = 'none';
                    acceptedActions.style.display = 'none';
                    progressBar.style.width = '100%';
                    progressText.textContent = 'Ride completed';
                    break;
            }
            
            statusTitle.textContent = title;
            // Handle message - it could be a string or an object
            if (typeof message === 'string') {
                statusMessage.textContent = message;
            } else if (message && typeof message === 'object') {
                // If message is actually data object, build message from it
                let msg = 'Your ride request has been accepted!';
                if (message.driver && message.driver.full_name) {
                    msg += ` ${message.driver.full_name} will be your driver.`;
                }
                if (message.driver && message.driver.estimated_arrival) {
                    msg += ` Estimated arrival: ${message.driver.estimated_arrival}.`;
                }
                statusMessage.textContent = msg;
            } else {
                statusMessage.textContent = message || '';
            }
            // Update minimized badge if present
            try {
                if (typeof window.updateBookingStatusBadge === 'function') {
                    // Short text for the badge
                    var badgeText = title || status;
                    window.updateBookingStatusBadge(badgeText, status);
                }
            } catch (e) {
                console.error('Failed to update booking status badge:', e);
            }
        }
        
        function showDriverDetails(driver) {
            if (!driver) {
                console.warn('No driver data provided to showDriverDetails');
                return;
            }
            
            // Update driver name
            const driverNameEl = document.getElementById('driverName');
            if (driverNameEl) {
                driverNameEl.textContent = driver.full_name || 'Driver';
            }
            
            // Update driver rating
            const driverRatingEl = document.getElementById('driverRating');
            if (driverRatingEl) {
                driverRatingEl.innerHTML = `<i class="fas fa-star"></i> ${driver.rating || '4.8'}`;
            }
            
            // Update vehicle information
            const vehicleTypeEl = document.getElementById('vehicleType');
            if (vehicleTypeEl) {
                vehicleTypeEl.textContent = driver.vehicle_type || 'Sedan';
            }
            
            const vehiclePlateEl = document.getElementById('vehiclePlate');
            if (vehiclePlateEl) {
                vehiclePlateEl.textContent = driver.license_plate || 'N/A';
            }
            
            // Update ETA and distance
            const driverETAEl = document.getElementById('driverETA');
            if (driverETAEl) {
                driverETAEl.textContent = driver.estimated_arrival || 'Calculating...';
            }
            
            const driverDistanceEl = document.getElementById('driverDistance');
            if (driverDistanceEl) {
                if (driver.distance !== null && driver.distance !== undefined) {
                    driverDistanceEl.textContent = `${driver.distance} km`;
                } else {
                    driverDistanceEl.textContent = 'Calculating...';
                }
            }
            
            // Update driver avatar with first letter of name
            const avatar = document.getElementById('driverAvatar');
            if (avatar && driver.full_name) {
                avatar.textContent = driver.full_name.charAt(0).toUpperCase();
                avatar.style.display = 'flex';
            }
            
            // Ensure driver details section is visible
            const driverDetailsSection = document.getElementById('driverDetails');
            if (driverDetailsSection) {
                driverDetailsSection.style.display = 'block';
            }
        }

        function showBookingAcceptedModal(data) {
            if (bookingAcceptedModalShown) {
                return;
            }
            const modal = document.getElementById('bookingAcceptedModal');
            if (!modal) {
                return;
            }

            const driverNameEl = modal.querySelector('[data-accepted-driver]');
            const vehicleInfoEl = modal.querySelector('[data-accepted-vehicle]');
            const etaEl = modal.querySelector('[data-accepted-eta]');

            if (data.driver && data.driver.full_name) {
                driverNameEl.textContent = `Driver: ${data.driver.full_name}`;
                driverNameEl.style.display = 'block';
            } else {
                driverNameEl.style.display = 'none';
            }

            if (data.driver && (data.driver.vehicle_type || data.driver.license_plate)) {
                const vehicleType = data.driver.vehicle_type ? data.driver.vehicle_type : 'Vehicle';
                const plate = data.driver.license_plate ? ` • Plate: ${data.driver.license_plate}` : '';
                vehicleInfoEl.textContent = `${vehicleType}${plate}`;
                vehicleInfoEl.style.display = 'block';
            } else {
                vehicleInfoEl.style.display = 'none';
            }

            if (data.driver && data.driver.estimated_arrival) {
                etaEl.textContent = `ETA: ${data.driver.estimated_arrival}`;
                etaEl.style.display = 'block';
            } else {
                etaEl.style.display = 'none';
            }

            modal.style.display = 'block';
            document.body.style.overflow = 'hidden';
            bookingAcceptedModalShown = true;
        }

        function hideBookingAcceptedModal() {
            const modal = document.getElementById('bookingAcceptedModal');
            if (!modal) {
                return;
            }
            modal.style.display = 'none';
            document.body.style.overflow = '';
        }

        document.addEventListener('DOMContentLoaded', function() {
            const closeBtn = document.getElementById('bookingAcceptedCloseBtn');
            const okBtn = document.getElementById('bookingAcceptedOkBtn');
            const acceptedModal = document.getElementById('bookingAcceptedModal');

            if (closeBtn) {
                closeBtn.addEventListener('click', function() {
                    hideBookingAcceptedModal();
                });
            }

            if (okBtn) {
                okBtn.addEventListener('click', function() {
                    hideBookingAcceptedModal();
                });
            }

            if (acceptedModal) {
                acceptedModal.addEventListener('click', function(event) {
                    if (event.target === acceptedModal) {
                        hideBookingAcceptedModal();
                    }
                });
            }
        });
        
        function setupModalEventListeners() {
            // Contact Driver Button
            document.getElementById('contactDriverBtn').addEventListener('click', function() {
                // Get driver phone from current status data
                fetch(`../api/check_booking_status.php?booking_id=${currentBookingId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success && data.driver && data.driver.phone) {
                            window.location.href = `tel:${data.driver.phone}`;
                        } else {
                            alert('Driver contact information not available.');
                        }
                    })
                    .catch(error => {
                        console.error('Error getting driver contact:', error);
                        alert('Failed to get driver contact information.');
                    });
            });
            
            // View Route Button
            document.getElementById('viewRouteBtn').addEventListener('click', function() {
                // Open Google Maps with route to driver
                fetch(`../api/check_booking_status.php?booking_id=${currentBookingId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success && data.driver) {
                            const pickupLat = document.getElementById('tripPickup').textContent;
                            // This would need to be enhanced with actual coordinates
                            alert('Route view feature would show map with driver location and route');
                        }
                    })
                    .catch(error => {
                        console.error('Error getting route data:', error);
                    });
            });
            
            // Cancel ride button
            document.getElementById('cancelRideBtn').addEventListener('click', showCancelReasonModal);
            
            // Cancel reason modal events
            document.getElementById('confirmCancelBtn').addEventListener('click', confirmCancellation);
            document.getElementById('backToStatusBtn').addEventListener('click', hideCancelReasonModal);
            
            // Handle "Other" reason selection
            const cancelReasons = document.querySelectorAll('input[name="cancelReason"]');
            cancelReasons.forEach(radio => {
                radio.addEventListener('change', function() {
                    const otherReasonDiv = document.getElementById('otherReasonDiv');
                    if (this.value === 'Other') {
                        otherReasonDiv.style.display = 'block';
                        document.getElementById('otherReasonText').required = true;
                    } else {
                        otherReasonDiv.style.display = 'none';
                        document.getElementById('otherReasonText').required = false;
                    }
                });
            });
            
            // Close modal when clicking outside (only for cancelled/expired status)
            document.getElementById('bookingStatusModal').addEventListener('click', function(e) {
                if (e.target === this) {
                    const statusTitle = document.getElementById('statusTitle').textContent;
                    if (statusTitle.includes('Cancelled') || statusTitle.includes('Expired') || statusTitle.includes('Completed')) {
                        hideBookingStatusModal();
                    }
                }
            });
        }
        
        function showCancelReasonModal() {
            document.getElementById('cancelReasonModal').style.display = 'block';
        }
        
        function hideCancelReasonModal() {
            document.getElementById('cancelReasonModal').style.display = 'none';
            // Reset form
            document.querySelectorAll('input[name="cancelReason"]').forEach(radio => radio.checked = false);
            document.getElementById('otherReasonDiv').style.display = 'none';
            document.getElementById('otherReasonText').value = '';
        }
        
        function confirmCancellation() {
            const selectedReason = document.querySelector('input[name="cancelReason"]:checked');
            
            if (!selectedReason) {
                alert('Please select a reason for cancellation.');
                return;
            }
            
            let reason = selectedReason.value;
            if (reason === 'Other') {
                const otherText = document.getElementById('otherReasonText').value.trim();
                if (!otherText) {
                    alert('Please specify the reason for cancellation.');
                    return;
                }
                reason = otherText;
            }
            
            // Disable button and show loading
            const confirmBtn = document.getElementById('confirmCancelBtn');
            const originalText = confirmBtn.innerHTML;
            confirmBtn.disabled = true;
            confirmBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Cancelling...';
            
            // Send cancellation request
            const formData = new FormData();
            formData.append('booking_id', currentBookingId);
            formData.append('reason', reason);
            
            fetch('../api/cancel_booking.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    hideCancelReasonModal();
                    updateStatusDisplay('cancelled', 'Ride Cancelled', 'Your ride has been cancelled successfully.');
                    
                    // Stop status polling
                    if (bookingStatusInterval) {
                        clearInterval(bookingStatusInterval);
                    }
                } else {
                    alert(data.error || 'Failed to cancel ride. Please try again.');
                }
            })
            .catch(error => {
                console.error('Cancellation error:', error);
                alert('An error occurred while cancelling. Please try again.');
            })
            .finally(() => {
                confirmBtn.disabled = false;
                confirmBtn.innerHTML = originalText;
            });
        }
        
        function hideBookingStatusModal() {
            document.getElementById('bookingStatusModal').style.display = 'none';
            document.body.style.overflow = 'auto';
            
            // Stop status polling
            if (bookingStatusInterval) {
                clearInterval(bookingStatusInterval);
            }
            
            // Reset for next booking
            currentBookingId = null;
            statusCheckCount = 0;
        }
    </script>
    
    <!-- Include enhanced GPS tracking -->
    <script src="../assets/js/gps-tracking.js"></script>
    
    <!-- Booking Status Modal -->

    <style>
    /* Modal controls styling */
    .modal-header {
        position: relative !important;
    }
    
    .modal-controls {
        position: absolute;
        top: 15px;
        right: 15px;
        display: flex;
        gap: 8px;
        z-index: 10001;
    }
    
    .modal-control-btn {
        width: 32px;
        height: 32px;
        border: none;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.2);
        color: white;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.2s ease;
        backdrop-filter: blur(10px);
    }
    
    .modal-control-btn:hover {
        background: rgba(255, 255, 255, 0.3);
        transform: scale(1.05);
    }
    
    .modal-control-btn svg {
        width: 16px;
        height: 16px;
    }

    /* Minimized badge styling */
    .booking-minimized-badge {
        position: fixed;
        right: 20px;
        bottom: 20px;
        z-index: 20000;
        display: none;
        align-items: center;
        gap: 12px;
        background: linear-gradient(135deg, #ffffff, #f8f9fa);
        color: #111;
        padding: 12px 16px;
        border-radius: 50px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.2);
        min-width: 160px;
        max-width: 300px;
        cursor: pointer;
        transition: all 0.3s ease;
        user-select: none;
        border: 1px solid rgba(0,0,0,0.1);
    }
    
    .booking-minimized-badge:hover {
        transform: translateY(-2px);
        box-shadow: 0 12px 40px rgba(0,0,0,0.25);
    }
    
    .booking-minimized-badge .badge-icon {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #007bff;
        color: #fff;
        font-size: 16px;
        flex-shrink: 0;
    }
    
    .booking-minimized-badge .badge-text {
        font-size: 14px;
        color: #222;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        font-weight: 500;
    }
    
    .booking-minimized-badge.state-pending .badge-icon { background: #ffc107; color: #000; }
    .booking-minimized-badge.state-searching .badge-icon { background: #007bff; }
    .booking-minimized-badge.state-accepted .badge-icon { background: #28a745; }
    .booking-minimized-badge.state-completed .badge-icon { background: #6c757d; }
    .booking-minimized-badge.state-cancelled .badge-icon { background: #dc3545; }
    
    @media (max-width: 480px) {
        .booking-minimized-badge {
            right: 15px;
            bottom: 15px;
            min-width: 140px;
            padding: 10px 14px;
        }
        
        .booking-minimized-badge .badge-icon {
            width: 28px;
            height: 28px;
            font-size: 14px;
        }
        
        .booking-minimized-badge .badge-text {
            font-size: 13px;
        }
    }
    </style>

    <div id="bookingStatusModal" class="modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999;">
        <div class="modal-content" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 0; border-radius: 15px; max-width: 500px; width: 90%; max-height: 80vh; overflow-y: auto; box-shadow: 0 10px 30px rgba(0,0,0,0.3);">
            
            <!-- Modal Header -->
            <div class="modal-header" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 15px 15px 0 0; text-align: center; position: relative;">
                <h3 style="margin: 0; font-size: 1.5rem;">
                    <i class="fas fa-car"></i> Ride Status
                </h3>
                <!-- Minimize and Close controls -->
                <div class="modal-controls">
                    <button id="bookingMinimizeBtn" class="modal-control-btn" aria-label="Minimize booking status" title="Minimize" type="button">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                            <path d="M6 12h12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                    </button>
                    <button id="bookingCloseBtn" class="modal-control-btn" aria-label="Close booking status" title="Close" type="button">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                            <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                    </button>
                </div>
            </div>
            
            <!-- Modal Body -->
            <div class="modal-body" style="padding: 30px 20px;">
                
                <!-- Status Display -->
                <div id="statusDisplay" style="text-align: center; margin-bottom: 30px;">
                    <div id="statusIcon" style="font-size: 3rem; margin-bottom: 15px;">
                        <i class="fas fa-search" style="color: #ffc107;"></i>
                    </div>
                    <h4 id="statusTitle" style="margin: 0 0 10px 0; color: #333;">Finding Your Driver</h4>
                    <p id="statusMessage" style="margin: 0; color: #666; font-size: 0.95rem;">
                        We're searching for available drivers nearby. This usually takes 2-5 minutes.
                    </p>
                </div>
                
                <!-- Progress Indicator -->
                <div id="progressContainer" style="margin: 20px 0;">
                    <div style="background: #f0f0f0; border-radius: 10px; height: 8px; overflow: hidden;">
                        <div id="progressBar" style="background: linear-gradient(90deg, #667eea, #764ba2); height: 100%; width: 0%; transition: width 0.3s ease; border-radius: 10px;"></div>
                    </div>
                    <p id="progressText" style="text-align: center; margin: 10px 0 0 0; font-size: 0.85rem; color: #666;">
                        Searching for drivers...
                    </p>
                </div>
                
                <!-- Driver Details (Hidden Initially) -->
                <div id="driverDetails" style="display: none; background: #f8f9fa; padding: 20px; border-radius: 10px; margin: 20px 0;">
                    <h5 style="margin: 0 0 15px 0; color: #333;">
                        <i class="fas fa-user-circle"></i> Your Driver
                    </h5>
                    <div style="display: flex; align-items: center; margin-bottom: 15px;">
                        <div id="driverAvatar" style="width: 60px; height: 60px; border-radius: 50%; background: #667eea; color: white; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; font-weight: bold; margin-right: 15px;">
                            <i class="fas fa-user"></i>
                        </div>
                        <div>
                            <div id="driverName" style="font-weight: 600; font-size: 1.1rem; color: #333;">Driver Name</div>
                            <div id="driverRating" style="color: #ffc107; font-size: 0.9rem;">
                                <i class="fas fa-star"></i> <span>4.8</span>
                            </div>
                        </div>
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; font-size: 0.9rem;">
                        <div>
                            <strong>Vehicle:</strong> <span id="vehicleType">Sedan</span>
                        </div>
                        <div>
                            <strong>Plate:</strong> <span id="vehiclePlate">ABC 123</span>
                        </div>
                        <div>
                            <strong>ETA:</strong> <span id="driverETA">5 mins</span>
                        </div>
                        <div>
                            <strong>Distance:</strong> <span id="driverDistance">2.3 km</span>
                        </div>
                    </div>
                </div>
                
                <!-- Trip Details -->
                <div id="tripDetails" style="background: #f0f8ff; padding: 15px; border-radius: 8px; margin: 15px 0; font-size: 0.85rem;">
                    <div style="margin-bottom: 8px;">
                        <i class="fas fa-map-marker-alt" style="color: #28a745;"></i>
                        <strong> From:</strong> <span id="tripPickup">Pickup location</span>
                    </div>
                    <div>
                        <i class="fas fa-flag-checkered" style="color: #dc3545;"></i>
                        <strong> To:</strong> <span id="tripDropoff">Dropoff location</span>
                    </div>
                </div>
                
                <!-- Action Buttons -->
                <div id="actionButtons" style="text-align: center; margin-top: 25px;">
                    <button id="cancelRideBtn" class="btn btn-danger" style="padding: 12px 30px; font-size: 1rem; border-radius: 25px;">
                        <i class="fas fa-times-circle"></i> Cancel Ride
                    </button>
                </div>
                
                <!-- Accepted State Actions -->
                <div id="acceptedActions" style="display: none; text-align: center; margin-top: 25px;">
                    <button id="contactDriverBtn" class="btn btn-primary" style="margin-right: 10px; padding: 12px 25px; border-radius: 25px;">
                        <i class="fas fa-phone"></i> Contact Driver
                    </button>
                    <button id="viewRouteBtn" class="btn btn-success" style="padding: 12px 25px; border-radius: 25px;">
                        <i class="fas fa-route"></i> View Route
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Cancellation Reason Modal -->
    <div id="cancelReasonModal" class="modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 10000;">
        <div class="modal-content" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 0; border-radius: 15px; max-width: 400px; width: 90%; box-shadow: 0 10px 30px rgba(0,0,0,0.3);">
            
            <div class="modal-header" style="background: #dc3545; color: white; padding: 20px; border-radius: 15px 15px 0 0; text-align: center;">
                <h4 style="margin: 0;">
                    <i class="fas fa-exclamation-triangle"></i> Cancel Ride
                </h4>
            </div>
            
            <div class="modal-body" style="padding: 25px;">
                <p style="margin-bottom: 20px; color: #666;">
                    Please let us know why you're cancelling this ride:
                </p>
                
                <div id="cancelReasons">
                    <label style="display: block; margin-bottom: 12px; cursor: pointer;">
                        <input type="radio" name="cancelReason" value="Found another ride" style="margin-right: 10px;">
                        Found another ride
                    </label>
                    <label style="display: block; margin-bottom: 12px; cursor: pointer;">
                        <input type="radio" name="cancelReason" value="Changed destination" style="margin-right: 10px;">
                        Changed destination
                    </label>
                    <label style="display: block; margin-bottom: 12px; cursor: pointer;">
                        <input type="radio" name="cancelReason" value="Wait is too long" style="margin-right: 10px;">
                        Wait is too long
                    </label>
                    <label style="display: block; margin-bottom: 12px; cursor: pointer;">
                        <input type="radio" name="cancelReason" value="Driver issues" style="margin-right: 10px;">
                        Driver issues
                    </label>
                    <label style="display: block; margin-bottom: 15px; cursor: pointer;">
                        <input type="radio" name="cancelReason" value="Other" style="margin-right: 10px;">
                        Other (please specify)
                    </label>
                </div>
                
                <div id="otherReasonDiv" style="display: none; margin-bottom: 20px;">
                    <textarea id="otherReasonText" placeholder="Please specify the reason..." style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; resize: vertical; min-height: 80px;"></textarea>
                </div>
                
                <div style="text-align: center;">
                    <button id="confirmCancelBtn" class="btn btn-danger" style="margin-right: 10px; padding: 10px 25px; border-radius: 20px;">
                        <i class="fas fa-check"></i> Confirm Cancellation
                    </button>
                    <button id="backToStatusBtn" class="btn btn-secondary" style="padding: 10px 25px; border-radius: 20px;">
                        <i class="fas fa-arrow-left"></i> Back
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Rating Modal -->
    <div id="ratingModal" class="modal" style="display: none;">
        <div class="modal-content" style="max-width: 500px;">
            <div class="modal-header">
                <h3><i class="fas fa-star"></i> Rate Your Trip</h3>
                <button class="close-btn" onclick="closeRatingModal()">&times;</button>
            </div>
            <div class="modal-body">
                <div class="rating-form">
                    <div class="form-group">
                        <label>How was your ride?</label>
                        <div class="star-rating" id="starRating">
                            <i class="fas fa-star" data-rating="1"></i>
                            <i class="fas fa-star" data-rating="2"></i>
                            <i class="fas fa-star" data-rating="3"></i>
                            <i class="fas fa-star" data-rating="4"></i>
                            <i class="fas fa-star" data-rating="5"></i>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="reviewText">Share your experience (optional)</label>
                        <textarea id="reviewText" rows="4" placeholder="Tell us about your ride..."></textarea>
                    </div>
                    <div class="rating-actions">
                        <button id="submitRatingBtn" class="btn btn-primary">
                            <i class="fas fa-check"></i> Submit Rating
                        </button>
                        <button id="skipRatingBtn" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Skip
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Rating Modal Functions
        let currentBookingId = null;
        let selectedRating = 0;

        function showRatingModal(bookingId) {
            currentBookingId = bookingId;
            selectedRating = 0;
            
            // Reset form
            document.getElementById('reviewText').value = '';
            updateStarDisplay(0);
            
            // Show modal
            document.getElementById('ratingModal').style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }

        function closeRatingModal() {
            document.getElementById('ratingModal').style.display = 'none';
            document.body.style.overflow = 'auto';
            currentBookingId = null;
            selectedRating = 0;
        }

        function updateStarDisplay(rating) {
            const stars = document.querySelectorAll('#starRating i');
            stars.forEach((star, index) => {
                if (index < rating) {
                    star.classList.add('selected');
                } else {
                    star.classList.remove('selected');
                }
            });
            selectedRating = rating;
        }

        // Star rating event listeners
        document.addEventListener('DOMContentLoaded', function() {
            const stars = document.querySelectorAll('#starRating i');
            stars.forEach((star, index) => {
                star.addEventListener('click', () => updateStarDisplay(index + 1));
                star.addEventListener('mouseenter', () => {
                    stars.forEach((s, i) => {
                        if (i <= index) {
                            s.style.color = '#ffc107';
                        } else {
                            s.style.color = '#ddd';
                        }
                    });
                });
            });

            document.getElementById('starRating').addEventListener('mouseleave', () => {
                updateStarDisplay(selectedRating);
            });

            // Submit rating
            document.getElementById('submitRatingBtn').addEventListener('click', submitRating);
            
            // Skip rating
            document.getElementById('skipRatingBtn').addEventListener('click', closeRatingModal);

            // Close modal on outside click
            document.getElementById('ratingModal').addEventListener('click', function(e) {
                if (e.target === this) {
                    closeRatingModal();
                }
            });
        });

        async function submitRating() {
            if (selectedRating === 0) {
                alert('Please select a star rating');
                return;
            }

            const reviewText = document.getElementById('reviewText').value.trim();
            const submitBtn = document.getElementById('submitRatingBtn');
            const originalText = submitBtn.innerHTML;

            try {
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';

                const response = await fetch('../api/submit_rating.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        booking_id: currentBookingId,
                        rating: selectedRating,
                        review: reviewText
                    })
                });

                const data = await response.json();

                if (data.success) {
                    alert('Thank you for your rating!');
                    closeRatingModal();
                } else {
                    alert('Error: ' + (data.error || 'Failed to submit rating'));
                }
            } catch (error) {
                console.error('Error submitting rating:', error);
                alert('Network error. Please try again.');
            } finally {
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
            }
        }
    </script>

    <style>
        /* Rating Modal Styles */
        .modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
        }

        .modal-content {
            background: white;
            border-radius: 12px;
            width: 90%;
            max-width: 500px;
            max-height: 90vh;
            overflow-y: auto;
            animation: modalSlideIn 0.3s ease-out;
        }

        @keyframes modalSlideIn {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .modal-header {
            padding: 20px;
            border-bottom: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-header h3 {
            margin: 0;
            color: #333;
        }

        .close-btn {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #666;
            padding: 0;
            width: 30px;
            height: 30px;
        }

        .close-btn:hover {
            color: #333;
        }

        .modal-body {
            padding: 20px;
        }

        .rating-form .form-group {
            margin-bottom: 20px;
        }

        .rating-form label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }

        .star-rating {
            display: flex;
            gap: 8px;
            font-size: 32px;
        }

        .star-rating i {
            color: #ddd;
            cursor: pointer;
            transition: color 0.2s ease;
        }

        .star-rating i.selected {
            color: #ffc107;
        }

        .star-rating i:hover {
            color: #ffc107;
        }

        .rating-form textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            resize: vertical;
        }

        .rating-actions {
            display: flex;
            gap: 12px;
            justify-content: flex-end;
        }

        .rating-actions .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.2s ease;
        }

        .btn-primary {
            background: #2563eb;
            color: white;
        }

        .btn-primary:hover {
            background: #1d4ed8;
        }

        .btn-secondary {
            background: #6b7280;
            color: white;
        }

        .btn-secondary:hover {
            background: #4b5563;
        }

        .btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
    </style>
</body>
</html>
