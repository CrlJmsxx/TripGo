<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modal Controls Test</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background: #f5f5f5;
        }
        
        .test-container {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .test-button {
            background: #007bff;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 6px;
            cursor: pointer;
            margin: 10px;
            font-size: 16px;
        }
        
        .test-button:hover {
            background: #0056b3;
        }
        
        .status-display {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 6px;
            margin: 20px 0;
            border-left: 4px solid #007bff;
        }
        
        /* Include the same styles from booking.php */
        .modal-header {
            position: relative !important;
        }
        
        .modal-controls {
            position: absolute;
            top: 15px;
            right: 15px;
            display: flex;
            gap: 8px;
            z-index: 10001;
        }
        
        .modal-control-btn {
            width: 32px;
            height: 32px;
            border: none;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
            backdrop-filter: blur(10px);
        }
        
        .modal-control-btn:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: scale(1.05);
        }
        
        .modal-control-btn svg {
            width: 16px;
            height: 16px;
        }

        .booking-minimized-badge {
            position: fixed;
            right: 20px;
            bottom: 20px;
            z-index: 20000;
            display: none;
            align-items: center;
            gap: 12px;
            background: linear-gradient(135deg, #ffffff, #f8f9fa);
            color: #111;
            padding: 12px 16px;
            border-radius: 50px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.2);
            min-width: 160px;
            max-width: 300px;
            cursor: pointer;
            transition: all 0.3s ease;
            user-select: none;
            border: 1px solid rgba(0,0,0,0.1);
        }
        
        .booking-minimized-badge:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 40px rgba(0,0,0,0.25);
        }
        
        .booking-minimized-badge .badge-icon {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #007bff;
            color: #fff;
            font-size: 16px;
            flex-shrink: 0;
        }
        
        .booking-minimized-badge .badge-text {
            font-size: 14px;
            color: #222;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            font-weight: 500;
        }
        
        .booking-minimized-badge.state-pending .badge-icon { background: #ffc107; color: #000; }
        .booking-minimized-badge.state-searching .badge-icon { background: #007bff; }
        .booking-minimized-badge.state-accepted .badge-icon { background: #28a745; }
        .booking-minimized-badge.state-completed .badge-icon { background: #6c757d; }
        .booking-minimized-badge.state-cancelled .badge-icon { background: #dc3545; }
    </style>
</head>
<body>
    <div class="test-container">
        <h1>Modal Controls Test</h1>
        <p>This page tests the modal minimize/restore functionality.</p>
        
        <div class="status-display">
            <h3>Current Status:</h3>
            <div id="currentStatus">No modal shown</div>
        </div>
        
        <h3>Test Controls:</h3>
        <button class="test-button" onclick="showModal()">Show Modal</button>
        <button class="test-button" onclick="simulateStatusUpdate('searching')">Simulate "Searching" Status</button>
        <button class="test-button" onclick="simulateStatusUpdate('accepted')">Simulate "Accepted" Status</button>
        <button class="test-button" onclick="simulateStatusUpdate('cancelled')">Simulate "Cancelled" Status</button>
        <button class="test-button" onclick="hideModal()">Hide Modal</button>
        
        <h3>Expected Behavior:</h3>
        <ul>
            <li>✅ Modal should show with minimize/close buttons in the top-right corner</li>
            <li>✅ Minimize button should hide modal and show badge</li>
            <li>✅ Badge should be clickable to restore modal</li>
            <li>✅ Status updates should update badge text when minimized</li>
            <li>✅ Auto-restore when status becomes "accepted"</li>
            <li>✅ Close button should hide modal and badge</li>
            <li>✅ Keyboard shortcut: Press 'M' to minimize when modal is visible</li>
        </ul>
    </div>

    <!-- Test Modal -->
    <div id="bookingStatusModal" class="modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999;">
        <div class="modal-content" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 0; border-radius: 15px; max-width: 500px; width: 90%; max-height: 80vh; overflow-y: auto; box-shadow: 0 10px 30px rgba(0,0,0,0.3);">
            
            <!-- Modal Header -->
            <div class="modal-header" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 15px 15px 0 0; text-align: center; position: relative;">
                <h3 style="margin: 0; font-size: 1.5rem;">
                    <i class="fas fa-car"></i> Ride Status
                </h3>
                <!-- Minimize and Close controls -->
                <div class="modal-controls">
                    <button id="bookingMinimizeBtn" class="modal-control-btn" aria-label="Minimize booking status" title="Minimize" type="button">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                            <path d="M6 12h12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                    </button>
                    <button id="bookingCloseBtn" class="modal-control-btn" aria-label="Close booking status" title="Close" type="button">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                            <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                    </button>
                </div>
            </div>
            
            <!-- Modal Body -->
            <div class="modal-body" style="padding: 30px 20px;">
                <div id="statusDisplay" style="text-align: center; margin-bottom: 30px;">
                    <div id="statusIcon" style="font-size: 3rem; margin-bottom: 15px;">
                        <i class="fas fa-clock" style="color: #ffc107;"></i>
                    </div>
                    <h2 id="statusTitle" style="margin: 0 0 10px 0; color: #333;">Finding Driver...</h2>
                    <p id="statusMessage" style="margin: 0; color: #666;">We're searching for available drivers near you.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Minimized Badge -->
    <div id="bookingMinimizedBadge" class="booking-minimized-badge" role="button" aria-label="Booking status minimized. Click to restore." tabindex="0" style="display:none;">
        <div class="badge-icon">⏳</div>
        <div class="badge-text">Finding driver…</div>
    </div>

    <script>
        (function() {
            const modal = document.getElementById('bookingStatusModal');
            const minimizeBtn = document.getElementById('bookingMinimizeBtn');
            const closeBtn = document.getElementById('bookingCloseBtn');
            const statusDisplay = document.getElementById('currentStatus');
            let badge = document.getElementById('bookingMinimizedBadge');
            
            // Create badge if it doesn't exist
            if (!badge) {
                badge = document.createElement('div');
                badge.id = 'bookingMinimizedBadge';
                badge.className = 'booking-minimized-badge';
                badge.setAttribute('role', 'button');
                badge.setAttribute('tabindex', '0');
                badge.setAttribute('aria-label', 'Click to restore booking status');
                badge.innerHTML = '<div class="badge-icon">⏳</div><div class="badge-text">Finding driver…</div>';
                document.body.appendChild(badge);
            }

            function updateStatusDisplay(text) {
                statusDisplay.innerHTML = text;
            }

            // Badge management functions
            function showBadge(text, state) {
                if (!badge) return;
                
                badge.style.display = 'flex';
                const badgeText = badge.querySelector('.badge-text');
                const badgeIcon = badge.querySelector('.badge-icon');
                
                if (badgeText) badgeText.textContent = text || 'Finding driver…';
                if (badgeIcon) {
                    const icons = {
                        'pending': '⏳',
                        'searching': '🔍',
                        'accepted': '✓',
                        'completed': '🏁',
                        'cancelled': '✕'
                    };
                    badgeIcon.textContent = icons[state] || '⏳';
                }
                
                badge.classList.remove('state-pending', 'state-searching', 'state-accepted', 'state-completed', 'state-cancelled');
                badge.classList.add('state-' + (state || 'pending'));
                
                updateStatusDisplay('Badge shown: ' + text + ' (state: ' + state + ')');
            }

            function hideBadge() {
                if (!badge) return;
                badge.style.display = 'none';
                updateStatusDisplay('Badge hidden');
            }

            function minimizeModal() {
                if (!modal) return;
                
                modal.style.display = 'none';
                document.body.style.overflow = 'auto';
                
                const currentStatus = document.getElementById('statusTitle')?.textContent || 'Finding driver…';
                const statusKey = getCurrentStatusKey();
                showBadge(currentStatus, statusKey);
                
                updateStatusDisplay('Modal minimized');
            }

            function restoreModal() {
                if (!modal) return;
                
                modal.style.display = 'block';
                document.body.style.overflow = 'hidden';
                hideBadge();
                
                updateStatusDisplay('Modal restored');
            }

            function getCurrentStatusKey() {
                const statusTitle = document.getElementById('statusTitle')?.textContent || '';
                
                if (statusTitle.includes('Accepted')) return 'accepted';
                if (statusTitle.includes('Completed')) return 'completed';
                if (statusTitle.includes('Cancelled')) return 'cancelled';
                if (statusTitle.includes('Searching')) return 'searching';
                return 'pending';
            }

            // Global function for updating badge from status updates
            window.updateBookingStatusBadge = function(text, stateKey) {
                try {
                    const key = stateKey || getCurrentStatusKey();
                    const txt = (typeof text === 'string') ? text : String(text || 'Finding driver…');
                    
                    if (modal && modal.style.display === 'none') {
                        showBadge(txt, key);
                    }
                    
                    if (key === 'accepted') {
                        setTimeout(() => {
                            restoreModal();
                        }, 2000);
                    }
                    
                    updateStatusDisplay('Badge updated: ' + txt + ' (state: ' + key + ')');
                } catch (e) {
                    console.error('Failed to update booking status badge:', e);
                }
            };

            // Event listeners for modal controls
            if (minimizeBtn) {
                minimizeBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    minimizeModal();
                });
            }

            if (closeBtn) {
                closeBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    hideBadge();
                    modal.style.display = 'none';
                    document.body.style.overflow = 'auto';
                    updateStatusDisplay('Modal closed');
                });
            }

            // Badge click to restore
            badge.addEventListener('click', (e) => {
                e.preventDefault();
                restoreModal();
            });

            badge.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    restoreModal();
                }
            });

            // Keyboard shortcut: press M to minimize when modal is visible
            document.addEventListener('keydown', (e) => {
                if ((e.key === 'm' || e.key === 'M') && modal && modal.style.display !== 'none') {
                    e.preventDefault();
                    minimizeModal();
                }
            });

            // Test functions
            window.showModal = function() {
                modal.style.display = 'block';
                document.body.style.overflow = 'hidden';
                updateStatusDisplay('Modal shown');
            };

            window.hideModal = function() {
                modal.style.display = 'none';
                document.body.style.overflow = 'auto';
                hideBadge();
                updateStatusDisplay('Modal hidden');
            };

            window.simulateStatusUpdate = function(status) {
                const statusData = {
                    'pending': { title: 'Finding Driver...', message: 'We\'re searching for available drivers near you.' },
                    'searching': { title: 'Searching for Driver...', message: 'Looking for the best driver for you.' },
                    'accepted': { title: 'Driver Found!', message: 'Your driver has been assigned and is on the way.' },
                    'cancelled': { title: 'Ride Cancelled', message: 'Your ride has been cancelled.' },
                    'completed': { title: 'Ride Completed', message: 'Thank you for riding with us!' }
                };

                const data = statusData[status] || statusData['pending'];
                
                document.getElementById('statusTitle').textContent = data.title;
                document.getElementById('statusMessage').textContent = data.message;
                
                // Update badge
                if (typeof window.updateBookingStatusBadge === 'function') {
                    window.updateBookingStatusBadge(data.title, status);
                }
                
                updateStatusDisplay('Status updated to: ' + status);
            };

            updateStatusDisplay('Test page loaded - ready for testing');
        })();
    </script>
</body>
</html>
