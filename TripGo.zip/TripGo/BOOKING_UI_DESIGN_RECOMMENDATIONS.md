# Booking Page UI/UX Design Recommendations

## Current State Analysis

### Identified Issues
1. **Layout Inconsistency**: Two maps displayed (duplicate content)
2. **Form Structure**: Mixed alignment and inconsistent grouping
3. **Container Sizing**: Bloated containers with excessive padding
4. **Visual Hierarchy**: Poor organization of related elements
5. **Mobile Responsiveness**: Grid layout creates awkward stacking
6. **Information Architecture**: Logical flow could be improved

## Design Blueprint & Recommendations

### 1. Layout and Sizing Optimization

#### **Page Container Structure**
```css
/* Recommended page layout */
.booking-page-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 40px 20px;
}

.booking-main-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 32px;
    align-items: start;
}

/* Mobile responsive */
@media (max-width: 968px) {
    .booking-main-grid {
        grid-template-columns: 1fr;
        gap: 24px;
    }
}
```

#### **Container Specifications**
- **Maximum Page Width**: 1200px (center-aligned)
- **Card Padding**: Reduce from 36px to 24px for cleaner appearance
- **Card Margins**: Standardize to 24px bottom margin
- **Grid Gap**: 32px between main columns for breathing room

### 2. Form Structure Reorganization

#### **Logical Grouping Strategy**
```html
<!-- Recommended form structure -->
<div class="booking-form-card">
    <!-- Section 1: Location Selection -->
    <div class="form-section">
        <div class="section-header">
            <h3><i class="fas fa-map-marker-alt"></i> Select Locations</h3>
        </div>
        
        <!-- Map as primary interface -->
        <div class="map-primary-container">
            <div id="bookingMap"></div>
            <div class="map-controls">
                <button class="btn btn-outline btn-sm">
                    <i class="fas fa-location-arrow"></i> Use Current Location
                </button>
                <button class="btn btn-outline btn-sm">
                    <i class="fas fa-times"></i> Clear All
                </button>
            </div>
        </div>
        
        <!-- Address inputs as secondary -->
        <div class="location-inputs-row">
            <div class="input-group">
                <label>Pickup Location</label>
                <div class="input-with-icon">
                    <i class="fas fa-map-marker-alt"></i>
                    <input type="text" placeholder="Enter pickup address">
                    <button type="button" class="input-action-btn">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </div>
            
            <div class="input-group">
                <label>Dropoff Location</label>
                <div class="input-with-icon">
                    <i class="fas fa-flag-checkered"></i>
                    <input type="text" placeholder="Enter dropoff address">
                    <button type="button" class="input-action-btn">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Section 2: Trip Details -->
    <div class="form-section">
        <div class="section-header">
            <h3><i class="fas fa-route"></i> Trip Details</h3>
        </div>
        
        <div class="trip-summary">
            <div class="route-info">
                <div class="route-point">
                    <i class="fas fa-circle"></i>
                    <span class="location-text">Pickup location</span>
                </div>
                <div class="route-line"></div>
                <div class="route-point">
                    <i class="fas fa-flag-checkered"></i>
                    <span class="location-text">Dropoff location</span>
                </div>
            </div>
            
            <div class="trip-stats">
                <div class="stat-item">
                    <span class="stat-label">Distance</span>
                    <span class="stat-value">-- km</span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">Est. Time</span>
                    <span class="stat-value">-- mins</span>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Section 3: Fare & Action -->
    <div class="form-section">
        <button class="btn btn-secondary btn-full" id="calculateFare">
            <i class="fas fa-calculator"></i> Calculate Fare
        </button>
        
        <div class="fare-estimate-container" id="fareEstimate" style="display: none;">
            <div class="fare-breakdown">
                <div class="fare-row">
                    <span>Base Fare</span>
                    <span>₱--</span>
                </div>
                <div class="fare-row">
                    <span>Distance (x km)</span>
                    <span>₱--</span>
                </div>
                <div class="fare-row">
                    <span>Time (x mins)</span>
                    <span>₱--</span>
                </div>
                <div class="fare-row total">
                    <span>Total Fare</span>
                    <span>₱--</span>
                </div>
            </div>
        </div>
        
        <button type="submit" class="btn btn-primary btn-full btn-large" id="submitBooking" disabled>
            <i class="fas fa-car"></i> Book Your Ride
        </button>
    </div>
</div>
```

#### **Form Layout Principles**
- **Top-aligned labels** for better scanning
- **Logical sections** with clear visual separation
- **Progressive disclosure** (map first, then details)
- **Consistent input styling** with icon integration

### 3. Modal Design Specifications

#### **Booking Status Modal**
```css
.booking-status-modal {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.6);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    padding: 20px;
}

.modal-content {
    background: var(--bg-secondary);
    border-radius: 16px;
    max-width: 500px;
    width: 100%;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
    border: 1px solid var(--border-color);
}

.modal-header {
    padding: 24px 24px 20px;
    border-bottom: 1px solid var(--border-light);
    background: linear-gradient(135deg, var(--bg-gradient-start), var(--bg-gradient-end));
    color: white;
    border-radius: 16px 16px 0 0;
}

.modal-body {
    padding: 24px;
}

.modal-footer {
    padding: 20px 24px;
    border-top: 1px solid var(--border-light);
    display: flex;
    gap: 12px;
    justify-content: flex-end;
}
```

#### **Modal Characteristics**
- **Fixed positioning** with center alignment
- **Maximum width**: 500px for optimal readability
- **Rounded corners**: 16px for modern feel
- **Subtle border**: Using existing theme border color
- **Backdrop blur**: For professional depth

### 4. Styling Principles & CSS Techniques

#### **Clean & Organic Aesthetic**
```css
/* Enhanced card styling */
.booking-card {
    background: var(--bg-secondary);
    border-radius: 16px;
    padding: 24px;
    margin-bottom: 24px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
    border: 1px solid var(--border-light);
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.booking-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.12);
}

/* Form section styling */
.form-section {
    margin-bottom: 32px;
}

.form-section:last-child {
    margin-bottom: 0;
}

.section-header {
    margin-bottom: 20px;
    padding-bottom: 12px;
    border-bottom: 2px solid var(--border-light);
}

.section-header h3 {
    font-size: 1.1rem;
    font-weight: 600;
    color: var(--text-primary);
    display: flex;
    align-items: center;
    gap: 10px;
}

/* Input group styling */
.input-group {
    margin-bottom: 20px;
}

.input-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: 500;
    color: var(--text-primary);
    font-size: 0.95rem;
}

.input-with-icon {
    position: relative;
    display: flex;
    align-items: center;
}

.input-with-icon i:first-child {
    position: absolute;
    left: 16px;
    color: var(--text-muted);
    z-index: 1;
}

.input-with-icon input {
    padding-left: 48px;
    padding-right: 48px;
}

.input-action-btn {
    position: absolute;
    right: 8px;
    background: none;
    border: none;
    color: var(--primary-color);
    padding: 8px;
    border-radius: 8px;
    cursor: pointer;
    transition: background-color 0.2s;
}

.input-action-btn:hover {
    background: var(--bg-primary);
}

/* Map container styling */
.map-primary-container {
    margin-bottom: 24px;
}

#bookingMap {
    height: 350px;
    border-radius: 12px;
    border: 2px solid var(--border-color);
    margin-bottom: 16px;
}

.map-controls {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
}

.btn-outline {
    background: transparent;
    border: 2px solid var(--border-color);
    color: var(--text-secondary);
    padding: 10px 20px;
    border-radius: 10px;
    font-size: 0.9rem;
    transition: all 0.2s;
}

.btn-outline:hover {
    border-color: var(--primary-color);
    color: var(--primary-color);
    background: rgba(37, 99, 235, 0.05);
}

/* Trip summary styling */
.trip-summary {
    background: var(--bg-primary);
    border-radius: 12px;
    padding: 20px;
    border-left: 4px solid var(--primary-color);
}

.route-info {
    margin-bottom: 16px;
}

.route-point {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 8px;
}

.route-point i:first-child {
    color: var(--primary-color);
    font-size: 0.8rem;
}

.route-line {
    height: 20px;
    border-left: 2px dashed var(--border-color);
    margin-left: 6px;
}

.trip-stats {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
    padding-top: 16px;
    border-top: 1px solid var(--border-light);
}

.stat-item {
    text-align: center;
}

.stat-label {
    display: block;
    font-size: 0.85rem;
    color: var(--text-muted);
    margin-bottom: 4px;
}

.stat-value {
    font-size: 1.1rem;
    font-weight: 600;
    color: var(--text-primary);
}

/* Fare estimate styling */
.fare-estimate-container {
    background: var(--bg-primary);
    border-radius: 12px;
    padding: 20px;
    margin: 20px 0;
}

.fare-breakdown {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.fare-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 0.95rem;
}

.fare-row.total {
    padding-top: 12px;
    border-top: 2px solid var(--border-color);
    font-weight: 600;
    font-size: 1.1rem;
    color: var(--primary-color);
}

/* Button enhancements */
.btn-large {
    padding: 16px 32px;
    font-size: 1.1rem;
    font-weight: 600;
}

.btn-full {
    width: 100%;
}

/* White space optimization */
.booking-form-card {
    line-height: 1.6;
}

.form-section > *:last-child {
    margin-bottom: 0;
}

/* Consistent spacing */
.spacing-xs { margin-bottom: 8px; }
.spacing-sm { margin-bottom: 12px; }
.spacing-md { margin-bottom: 16px; }
.spacing-lg { margin-bottom: 20px; }
.spacing-xl { margin-bottom: 24px; }
.spacing-xxl { margin-bottom: 32px; }
```

### 5. Responsive Design Strategy

#### **Mobile-First Approach**
```css
/* Base mobile styles */
.booking-main-grid {
    display: flex;
    flex-direction: column;
    gap: 24px;
}

/* Tablet and up */
@media (min-width: 768px) {
    .trip-stats {
        grid-template-columns: repeat(3, 1fr);
    }
    
    .map-controls {
        justify-content: center;
    }
}

/* Desktop and up */
@media (min-width: 1024px) {
    .booking-main-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 32px;
    }
    
    .trip-stats {
        grid-template-columns: 1fr 1fr;
    }
}

/* Large desktop */
@media (min-width: 1200px) {
    .booking-page-container {
        max-width: 1200px;
    }
}
```

### 6. Information Architecture Improvements

#### **Visual Hierarchy**
1. **Primary Action**: Map selection (largest, most prominent)
2. **Secondary**: Address inputs (medium prominence)
3. **Tertiary**: Trip details (smaller, supporting information)
4. **Final**: Fare calculation and booking (action-oriented)

#### **Content Organization**
- **Section-based grouping** with clear headers
- **Progressive disclosure** of information
- **Consistent visual language** throughout
- **Clear affordances** for interactive elements

### 7. Implementation Priority

#### **Phase 1: Core Layout**
1. Implement new grid structure
2. Standardize container sizing
3. Remove duplicate map
4. Optimize spacing

#### **Phase 2: Form Enhancement**
1. Reorganize form sections
2. Implement input grouping
3. Add icon integration
4. Improve visual hierarchy

#### **Phase 3: Polish & Refinement**
1. Add micro-interactions
2. Optimize responsive behavior
3. Enhance accessibility
4. Performance optimization

### 8. Success Metrics

#### **Usability Improvements**
- Reduced time to complete booking
- Lower form abandonment rate
- Higher user satisfaction scores
- Improved mobile conversion rates

#### **Technical Benefits**
- Cleaner, maintainable code
- Better performance scores
- Improved accessibility ratings
- Enhanced SEO friendliness

## Conclusion

These recommendations will transform your booking page from a functional interface to a professional, polished experience that maintains your existing brand identity while significantly improving usability and visual appeal. The focus on clean layouts, logical information architecture, and consistent spacing will create an interface that feels intentional and high-quality.

The modular CSS approach ensures easy maintenance and future enhancements while preserving the current color scheme and brand elements that users are familiar with.
