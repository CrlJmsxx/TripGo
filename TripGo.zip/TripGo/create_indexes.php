<?php
// Create performance indexes for the dashboard filtering feature
require_once __DIR__ . '/config/database.php';

echo "<h2>Creating Performance Indexes</h2>";

try {
    $pdo = getConnection();
    echo "<p style='color: green;'>✓ Database connection successful</p>";
    
    $indexes = [
        // Most important index for coordinate filtering
        "CREATE INDEX idx_bookings_status_coords ON bookings(status, pickup_latitude, pickup_longitude) WHERE status = 'pending' AND pickup_latitude IS NOT NULL AND pickup_longitude IS NOT NULL",
        
        // Supporting indexes
        "CREATE INDEX idx_bookings_coordinates ON bookings(pickup_latitude, pickup_longitude)",
        "CREATE INDEX idx_bookings_status_pending ON bookings(status) WHERE status = 'pending'",
        "CREATE INDEX idx_bookings_expires ON bookings(expires_at) WHERE expires_at IS NOT NULL",
        "CREATE INDEX idx_bookings_pending_expires ON bookings(status, expires_at) WHERE status = 'pending' AND expires_at IS NOT NULL",
        "CREATE INDEX idx_bookings_passenger ON bookings(passenger_id)",
        "CREATE INDEX idx_driver_profile_location ON driver_profiles(current_latitude, current_longitude) WHERE current_latitude IS NOT NULL AND current_longitude IS NOT NULL"
    ];
    
    foreach ($indexes as $index) {
        try {
            $pdo->exec($index);
            echo "<p style='color: green;'>✓ Index created successfully</p>";
        } catch (Exception $e) {
            if (strpos($e->getMessage(), 'Duplicate key name') !== false) {
                echo "<p style='color: orange;'>⚠ Index already exists</p>";
            } else {
                echo "<p style='color: red;'>✗ Index creation failed: " . htmlspecialchars($e->getMessage()) . "</p>";
            }
        }
    }
    
    // Analyze tables to update index statistics
    try {
        $pdo->exec("ANALYZE TABLE bookings");
        $pdo->exec("ANALYZE TABLE driver_profiles");
        $pdo->exec("ANALYZE TABLE users");
        echo "<p style='color: green;'>✓ Tables analyzed successfully</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠ Table analysis failed: " . htmlspecialchars($e->getMessage()) . "</p>";
    }
    
    echo "<br><h3>Index Creation Complete!</h3>";
    echo "<p><a href='create_test_requests.php'>Create Test Requests</a></p>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>✗ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}
?>
