<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/session.php';

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driver Requests Debug Tool</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background: #f5f5f5;
        }
        
        .debug-container {
            max-width: 1000px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .section {
            margin: 20px 0;
            padding: 20px;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            background: #f8f9fa;
        }
        
        .success { color: #28a745; font-weight: bold; }
        .error { color: #dc3545; font-weight: bold; }
        .warning { color: #ffc107; font-weight: bold; }
        .info { color: #007bff; font-weight: bold; }
        
        .debug-button {
            background: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            margin: 5px;
        }
        
        .debug-button:hover {
            background: #0056b3;
        }
        
        pre {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 4px;
            overflow-x: auto;
            font-size: 12px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 10px 0;
        }
        
        th, td {
            border: 1px solid #dee2e6;
            padding: 8px;
            text-align: left;
        }
        
        th {
            background: #f8f9fa;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="debug-container">
        <h1>🔍 Driver Requests Debug Tool</h1>
        <p>This tool helps diagnose why drivers can't see passenger requests.</p>
        
        <?php
        $pdo = getConnection();
        
        // Section 1: Database Overview
        echo '<div class="section">';
        echo '<h2>📊 Database Overview</h2>';
        
        try {
            // Count users
            $stmt = $pdo->query("SELECT COUNT(*) as total, SUM(CASE WHEN user_type = 'driver' THEN 1 ELSE 0 END) as drivers, SUM(CASE WHEN user_type = 'passenger' THEN 1 ELSE 0 END) as passengers FROM users");
            $userCounts = $stmt->fetch(PDO::FETCH_ASSOC);
            
            echo "<p><strong>Users:</strong> {$userCounts['total']} total, {$userCounts['drivers']} drivers, {$userCounts['passengers']} passengers</p>";
            
            // Count bookings by status
            $stmt = $pdo->query("SELECT status, COUNT(*) as count FROM bookings GROUP BY status");
            $bookingCounts = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo "<p><strong>Bookings by Status:</strong></p>";
            foreach ($bookingCounts as $count) {
                $color = $count['status'] === 'pending' ? 'success' : 'info';
                echo "<p class='{$color}'>• {$count['status']}: {$count['count']}</p>";
            }
            
        } catch (Exception $e) {
            echo "<p class='error'>Database error: " . htmlspecialchars($e->getMessage()) . "</p>";
        }
        
        echo '</div>';
        
        // Section 2: Driver Profile Check
        echo '<div class="section">';
        echo '<h2>👨‍✈️ Driver Profiles</h2>';
        
        try {
            $stmt = $pdo->query("
                SELECT u.full_name, u.email, dp.current_latitude, dp.current_longitude, dp.updated_at
                FROM users u
                JOIN driver_profiles dp ON u.id = dp.user_id
                WHERE u.user_type = 'driver'
                ORDER BY dp.updated_at DESC
            ");
            $drivers = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (empty($drivers)) {
                echo "<p class='error'>No driver profiles found!</p>";
            } else {
                echo "<table>";
                echo "<tr><th>Name</th><th>Email</th><th>Current Location</th><th>Last Updated</th><th>Status</th></tr>";
                
                foreach ($drivers as $driver) {
                    $hasLocation = $driver['current_latitude'] && $driver['current_longitude'];
                    $status = $hasLocation ? 'success' : 'warning';
                    $statusText = $hasLocation ? '✓ Has Location' : '⚠ No Location';
                    
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($driver['full_name']) . "</td>";
                    echo "<td>" . htmlspecialchars($driver['email']) . "</td>";
                    echo "<td>";
                    if ($hasLocation) {
                        echo "{$driver['current_latitude']}, {$driver['current_longitude']}";
                    } else {
                        echo "NULL";
                    }
                    echo "</td>";
                    echo "<td>" . ($driver['updated_at'] ? date('M j, Y H:i', strtotime($driver['updated_at'])) : 'Never') . "</td>";
                    echo "<td class='{$status}'>{$statusText}</td>";
                    echo "</tr>";
                }
                echo "</table>";
            }
            
        } catch (Exception $e) {
            echo "<p class='error'>Error checking driver profiles: " . htmlspecialchars($e->getMessage()) . "</p>";
        }
        
        echo '</div>';
        
        // Section 3: Pending Requests Analysis
        echo '<div class="section">';
        echo '<h2>🚗 Pending Requests Analysis</h2>';
        
        try {
            $stmt = $pdo->query("
                SELECT b.*, u.full_name as passenger_name, u.email as passenger_email
                FROM bookings b
                JOIN users u ON b.passenger_id = u.id
                WHERE b.status = 'pending'
                ORDER BY b.booking_time DESC
                LIMIT 10
            ");
            $pendingRequests = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (empty($pendingRequests)) {
                echo "<p class='warning'>No pending requests found!</p>";
                echo "<p class='info'>This is likely the main issue. Let's create some test requests...</p>";
                
                // Create test requests button
                echo '<button class="debug-button" onclick="createTestRequests()">Create Test Requests</button>';
                
            } else {
                echo "<p><strong>Found " . count($pendingRequests) . " pending requests:</strong></p>";
                echo "<table>";
                echo "<tr><th>ID</th><th>Passenger</th><th>Pickup</th><th>Coordinates</th><th>Time</th><th>Expires</th></tr>";
                
                foreach ($pendingRequests as $request) {
                    $hasCoords = $request['pickup_latitude'] && $request['pickup_longitude'];
                    $status = $hasCoords ? 'success' : 'error';
                    
                    echo "<tr>";
                    echo "<td>#{$request['id']}</td>";
                    echo "<td>" . htmlspecialchars($request['passenger_name']) . "</td>";
                    echo "<td>" . htmlspecialchars($request['pickup_address']) . "</td>";
                    echo "<td class='{$status}'>";
                    if ($hasCoords) {
                        echo "{$request['pickup_latitude']}, {$request['pickup_longitude']}";
                    } else {
                        echo "NO COORDINATES";
                    }
                    echo "</td>";
                    echo "<td>" . date('M j, H:i', strtotime($request['booking_time'])) . "</td>";
                    echo "<td>" . ($request['expires_at'] ? date('M j, H:i', strtotime($request['expires_at'])) : 'Never') . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            }
            
        } catch (Exception $e) {
            echo "<p class='error'>Error checking pending requests: " . htmlspecialchars($e->getMessage()) . "</p>";
        }
        
        echo '</div>';
        
        // Section 4: Distance Calculation Test
        echo '<div class="section">';
        echo '<h2>📏 Distance Calculation Test</h2>';
        
        try {
            // Get a sample driver location
            $stmt = $pdo->query("SELECT current_latitude, current_longitude FROM driver_profiles WHERE current_latitude IS NOT NULL LIMIT 1");
            $driver = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$driver) {
                echo "<p class='warning'>No driver with location found. Using Manila as test location.</p>";
                $driverLat = 14.5995;
                $driverLng = 120.9842;
            } else {
                $driverLat = $driver['current_latitude'];
                $driverLng = $driver['current_longitude'];
                echo "<p class='info'>Using driver location: {$driverLat}, {$driverLng}</p>";
            }
            
            // Test distance calculation on pending requests
            $stmt = $pdo->query("
                SELECT b.*, u.full_name as passenger_name,
                       (6371 * acos(
                           cos(radians(?)) * 
                           cos(radians(b.pickup_latitude)) * 
                           cos(radians(b.pickup_longitude) - radians(?)) + 
                           sin(radians(?)) * 
                           sin(radians(b.pickup_latitude))
                       )) as distance_km
                FROM bookings b
                JOIN users u ON b.passenger_id = u.id
                WHERE b.status = 'pending'
                AND b.pickup_latitude IS NOT NULL 
                AND b.pickup_longitude IS NOT NULL
                HAVING distance_km <= 50
                ORDER BY distance_km ASC
                LIMIT 10
            ");
            $stmt->execute([$driverLat, $driverLng, $driverLat]);
            $nearbyRequests = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo "<h3>Requests within 50km of driver:</h3>";
            
            if (empty($nearbyRequests)) {
                echo "<p class='warning'>No requests found within 50km!</p>";
                
                // Check all requests regardless of distance
                $stmt = $pdo->query("
                    SELECT b.*, u.full_name as passenger_name,
                           (6371 * acos(
                               cos(radians(?)) * 
                               cos(radians(b.pickup_latitude)) * 
                               cos(radians(b.pickup_longitude) - radians(?)) + 
                               sin(radians(?)) * 
                               sin(radians(b.pickup_latitude))
                           )) as distance_km
                    FROM bookings b
                    JOIN users u ON b.passenger_id = u.id
                    WHERE b.status = 'pending'
                    AND b.pickup_latitude IS NOT NULL 
                    AND b.pickup_longitude IS NOT NULL
                    ORDER BY distance_km ASC
                    LIMIT 5
                ");
                $stmt->execute([$driverLat, $driverLng, $driverLat]);
                $allRequests = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                if (!empty($allRequests)) {
                    echo "<p class='info'>Closest requests (all distances):</p>";
                    echo "<table>";
                    echo "<tr><th>Passenger</th><th>Distance</th><th>Pickup</th></tr>";
                    
                    foreach ($allRequests as $request) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($request['passenger_name']) . "</td>";
                        echo "<td>" . round($request['distance_km'], 2) . " km</td>";
                        echo "<td>" . htmlspecialchars($request['pickup_address']) . "</td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                }
                
            } else {
                echo "<p class='success'>Found " . count($nearbyRequests) . " requests within 50km:</p>";
                echo "<table>";
                echo "<tr><th>Passenger</th><th>Distance</th><th>Pickup</th><th>Should be visible</th></tr>";
                
                foreach ($nearbyRequests as $request) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($request['passenger_name']) . "</td>";
                    echo "<td>" . round($request['distance_km'], 2) . " km</td>";
                    echo "<td>" . htmlspecialchars($request['pickup_address']) . "</td>";
                    echo "<td class='success'>✓ Yes</td>";
                    echo "</tr>";
                }
                echo "</table>";
            }
            
        } catch (Exception $e) {
            echo "<p class='error'>Error testing distance calculation: " . htmlspecialchars($e->getMessage()) . "</p>";
        }
        
        echo '</div>';
        
        // Section 5: API Endpoint Test
        echo '<div class="section">';
        echo '<h2>🔌 API Endpoint Test</h2>';
        
        // Test the get_all_requests_optimized endpoint
        $apiUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/TripGo/api/get_all_requests_optimized.php?max_radius=50';
        
        echo "<p><strong>Testing API endpoint:</strong> {$apiUrl}</p>";
        
        $context = stream_context_create([
            'http' => [
                'method' => 'GET',
                'header' => 'Cookie: ' . $_SERVER['HTTP_COOKIE'] ?? ''
            ]
        ]);
        
        $response = file_get_contents($apiUrl, false, $context);
        
        if ($response === false) {
            echo "<p class='error'>Failed to call API endpoint</p>";
        } else {
            echo "<h3>API Response:</h3>";
            echo "<pre>" . htmlspecialchars($response) . "</pre>";
            
            $data = json_decode($response, true);
            if ($data) {
                if ($data['success']) {
                    echo "<p class='success'>API returned success with " . count($data['requests']) . " requests</p>";
                } else {
                    echo "<p class='error'>API returned error: " . htmlspecialchars($data['error'] ?? 'Unknown error') . "</p>";
                }
            } else {
                echo "<p class='error'>Invalid JSON response</p>";
            }
        }
        
        echo '</div>';
        ?>
        
        <div class="section">
            <h2>🔧 Quick Fixes</h2>
            
            <button class="debug-button" onclick="setDriverLocation()">Set Driver Location (Manila)</button>
            <button class="debug-button" onclick="createTestRequests()">Create Test Requests</button>
            <button class="debug-button" onclick="clearExpiredRequests()">Clear Expired Requests</button>
            <button class="debug-button" onclick="refreshPage()">Refresh Page</button>
            
            <div id="fixResults"></div>
        </div>
    </div>
    
    <script>
        function setDriverLocation() {
            fetch('set_driver_location.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('fixResults').innerHTML = '<div class="success">✓ Driver location set</div>' + data;
                    setTimeout(() => location.reload(), 2000);
                })
                .catch(error => {
                    document.getElementById('fixResults').innerHTML = '<div class="error">✗ Error: ' + error.message + '</div>';
                });
        }
        
        function createTestRequests() {
            fetch('create_test_booking.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('fixResults').innerHTML = '<div class="success">✓ Test requests created</div><pre>' + data + '</pre>';
                    setTimeout(() => location.reload(), 2000);
                })
                .catch(error => {
                    document.getElementById('fixResults').innerHTML = '<div class="error">✗ Error: ' + error.message + '</div>';
                });
        }
        
        function clearExpiredRequests() {
            fetch('clear_expired_requests.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('fixResults').innerHTML = '<div class="success">✓ Expired requests cleared</div>' + data;
                    setTimeout(() => location.reload(), 2000);
                })
                .catch(error => {
                    document.getElementById('fixResults').innerHTML = '<div class="error">✗ Error: ' + error.message + '</div>';
                });
        }
        
        function refreshPage() {
            location.reload();
        }
    </script>
</body>
</html>
