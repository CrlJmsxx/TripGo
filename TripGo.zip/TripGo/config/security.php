<?php
/**
 * TripGO Security Helper Functions
 * Provides input validation, sanitization, and security measures
 */

// Input validation functions
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function validatePhone($phone) {
    // Remove all non-digit characters
    $phone = preg_replace('/\D/', '', $phone);
    // Check if it's a valid length (7-15 digits)
    return strlen($phone) >= 7 && strlen($phone) <= 15;
}

function validatePassword($password) {
    // At least 6 characters, contains at least one letter and one number
    return strlen($password) >= 6 && 
           preg_match('/[A-Za-z]/', $password) && 
           preg_match('/[0-9]/', $password);
}

function validateUsername($username) {
    // 3-20 characters, alphanumeric and underscores only
    return preg_match('/^[a-zA-Z0-9_]{3,20}$/', $username);
}

function validateName($name) {
    // 2-50 characters, letters, spaces, hyphens, and apostrophes only
    return preg_match('/^[a-zA-Z\s\-\']{2,50}$/', $name);
}

// Input sanitization functions
function sanitizeString($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function sanitizeEmail($email) {
    return filter_var(trim($email), FILTER_SANITIZE_EMAIL);
}

function sanitizePhone($phone) {
    return preg_replace('/\D/', '', trim($phone));
}

function sanitizeAddress($address) {
    return htmlspecialchars(trim($address), ENT_QUOTES, 'UTF-8');
}

// CSRF Protection
function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function validateCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Rate limiting
function checkRateLimit($action, $limit = 5, $window = 300) {
    $key = $action . '_' . $_SERVER['REMOTE_ADDR'];
    $file = sys_get_temp_dir() . '/rate_limit_' . md5($key);
    
    $attempts = [];
    if (file_exists($file)) {
        $attempts = json_decode(file_get_contents($file), true) ?: [];
    }
    
    // Remove old attempts outside the window
    $now = time();
    $attempts = array_filter($attempts, function($timestamp) use ($now, $window) {
        return ($now - $timestamp) < $window;
    });
    
    if (count($attempts) >= $limit) {
        return false;
    }
    
    $attempts[] = $now;
    file_put_contents($file, json_encode($attempts));
    return true;
}

// SQL Injection Prevention
function escapeString($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

// XSS Prevention
function preventXSS($input) {
    return htmlspecialchars($input, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

// File upload security
function validateFileUpload($file, $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'], $maxSize = 2097152) {
    $errors = [];
    
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errors[] = 'File upload error';
        return $errors;
    }
    
    if ($file['size'] > $maxSize) {
        $errors[] = 'File too large';
    }
    
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($mimeType, $allowedTypes)) {
        $errors[] = 'Invalid file type';
    }
    
    return $errors;
}

// Session security
function secureSession() {
    // Regenerate session ID periodically
    if (!isset($_SESSION['last_regeneration'])) {
        $_SESSION['last_regeneration'] = time();
    } elseif (time() - $_SESSION['last_regeneration'] > 300) { // 5 minutes
        session_regenerate_id(true);
        $_SESSION['last_regeneration'] = time();
    }
    
    // Set secure session parameters
    ini_set('session.cookie_httponly', 1);
    ini_set('session.cookie_secure', isset($_SERVER['HTTPS']));
    ini_set('session.use_strict_mode', 1);
}

// Input validation for forms
function validateRegistrationInput($data) {
    $errors = [];
    
    if (empty($data['username']) || !validateUsername($data['username'])) {
        $errors[] = 'Invalid username';
    }
    
    if (empty($data['email']) || !validateEmail($data['email'])) {
        $errors[] = 'Invalid email';
    }
    
    if (empty($data['password']) || !validatePassword($data['password'])) {
        $errors[] = 'Password must be at least 6 characters with letters and numbers';
    }
    
    if (empty($data['full_name']) || !validateName($data['full_name'])) {
        $errors[] = 'Invalid full name';
    }
    
    if (empty($data['phone']) || !validatePhone($data['phone'])) {
        $errors[] = 'Invalid phone number';
    }
    
    if (isset($data['confirm_password']) && $data['password'] !== $data['confirm_password']) {
        $errors[] = 'Passwords do not match';
    }
    
    return $errors;
}

function validateLoginInput($data) {
    $errors = [];
    
    if (empty($data['username'])) {
        $errors[] = 'Username is required';
    }
    
    if (empty($data['password'])) {
        $errors[] = 'Password is required';
    }
    
    return $errors;
}

function validateBookingInput($data) {
    $errors = [];
    
    if (empty($data['pickup_address'])) {
        $errors[] = 'Pickup address is required';
    }
    
    if (empty($data['dropoff_address'])) {
        $errors[] = 'Dropoff address is required';
    }
    
    if (!isset($data['pickup_latitude']) || !is_numeric($data['pickup_latitude'])) {
        $errors[] = 'Invalid pickup coordinates';
    }
    
    if (!isset($data['pickup_longitude']) || !is_numeric($data['pickup_longitude'])) {
        $errors[] = 'Invalid pickup coordinates';
    }
    
    if (!isset($data['dropoff_latitude']) || !is_numeric($data['dropoff_latitude'])) {
        $errors[] = 'Invalid dropoff coordinates';
    }
    
    if (!isset($data['dropoff_longitude']) || !is_numeric($data['dropoff_longitude'])) {
        $errors[] = 'Invalid dropoff coordinates';
    }
    
    return $errors;
}

// Log security events
function logSecurityEvent($event, $details = '') {
    $logEntry = date('Y-m-d H:i:s') . " - " . $event . " - " . $details . " - IP: " . $_SERVER['REMOTE_ADDR'] . "\n";
    error_log($logEntry, 3, 'logs/security.log');
}

// Check for suspicious activity
function checkSuspiciousActivity() {
    $suspicious = false;
    $reasons = [];
    
    // Check for SQL injection attempts
    $sqlPatterns = ['union', 'select', 'insert', 'update', 'delete', 'drop', 'create', 'alter'];
    foreach ($_REQUEST as $key => $value) {
        if (is_string($value)) {
            foreach ($sqlPatterns as $pattern) {
                if (stripos($value, $pattern) !== false) {
                    $suspicious = true;
                    $reasons[] = 'SQL injection attempt detected';
                    break 2;
                }
            }
        }
    }
    
    // Check for XSS attempts
    $xssPatterns = ['<script', 'javascript:', 'onload=', 'onerror='];
    foreach ($_REQUEST as $key => $value) {
        if (is_string($value)) {
            foreach ($xssPatterns as $pattern) {
                if (stripos($value, $pattern) !== false) {
                    $suspicious = true;
                    $reasons[] = 'XSS attempt detected';
                    break 2;
                }
            }
        }
    }
    
    if ($suspicious) {
        logSecurityEvent('Suspicious Activity', implode(', ', $reasons));
        return true;
    }
    
    return false;
}
?>

