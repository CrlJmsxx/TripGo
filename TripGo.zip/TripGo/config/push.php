<?php
// Web Push (VAPID) configuration
// Replace the public_key and private_key values with your real VAPID keys.
// You can generate VAPID keys using a tool or the web-push CLI.
// Example generator: https://tools.reactpwa.com/vapid

return [
    'public_key'  => 'REPLACE_WITH_YOUR_VAPID_PUBLIC_KEY',
    'private_key' => 'REPLACE_WITH_YOUR_VAPID_PRIVATE_KEY',
    'subject'     => 'mailto:admin@example.com'
];
