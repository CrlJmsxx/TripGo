    <?php
    // Database configuration
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    define('DB_NAME', 'tripgo_booking');

    // API Keys (configure with real values)
    define('GOOGLE_MAPS_API_KEY', 'YOUR_GOOGLE_MAPS_API_KEY');
    define('STRIPE_SECRET_KEY', 'sk_test_your_stripe_secret_key');
    define('STRIPE_PUBLISHABLE_KEY', 'pk_test_your_stripe_publishable_key');
    define('PAYPAL_CLIENT_ID', 'your_paypal_client_id');
    define('PAYPAL_CLIENT_SECRET', 'your_paypal_client_secret');

    // Slow Query Logging
    if (!defined('SLOW_QUERY_LOG')) define('SLOW_QUERY_LOG', false);
    if (!defined('SLOW_QUERY_THRESHOLD_MS')) define('SLOW_QUERY_THRESHOLD_MS', 50);
    if (!defined('SLOW_QUERY_LOG_PATH')) define('SLOW_QUERY_LOG_PATH', __DIR__ . '/../logs/slow_queries.log');

    // Slow query logging class
    if (SLOW_QUERY_LOG && !class_exists('LoggedPDOStatement')) {
        class LoggedPDOStatement extends PDOStatement {
            protected function __construct() {}

            public function execute(?array $params = null): bool {
                $start = microtime(true);
                $result = parent::execute($params);
                $elapsed = (microtime(true) - $start) * 1000;

                if ($elapsed >= SLOW_QUERY_THRESHOLD_MS) {
                    $sql = $this->queryString;
                    $log = date('c') . " | {$elapsed}ms | {$sql} | params=" . json_encode($params) . PHP_EOL;

                    @mkdir(dirname(SLOW_QUERY_LOG_PATH), 0755, true);
                    @file_put_contents(SLOW_QUERY_LOG_PATH, $log, FILE_APPEND);
                }

                return $result;
            }
        }
    }

    // Create PDO connection
    function getConnection() {
        static $pdo = null;

        if ($pdo === null) {
            try {
                $pdoOptions = [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                    PDO::ATTR_PERSISTENT => true
                ];

                if (SLOW_QUERY_LOG) {
                    $pdoOptions[PDO::ATTR_STATEMENT_CLASS] = ['LoggedPDOStatement'];
                }

                $pdo = new PDO(
                    "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                    DB_USER,
                    DB_PASS,
                    $pdoOptions
                );

            } catch (PDOException $e) {
                error_log("DB Error: " . $e->getMessage());
                die("Database connection failed.");
            }
        }

        return $pdo;
    }

    // Initialize database tables
    function initializeDatabase() {
        try {
            $pdo = getConnection();

            // USERS TABLE
            $pdo->exec("CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) UNIQUE NOT NULL,
                email VARCHAR(100) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                full_name VARCHAR(100) NOT NULL,
                phone VARCHAR(20) NOT NULL,
                user_type ENUM('passenger','driver','admin') DEFAULT 'passenger',
                is_verified BOOLEAN DEFAULT FALSE,
                profile_image VARCHAR(255) DEFAULT NULL,
                average_rating DECIMAL(3,2) DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )");

            // DRIVER PROFILES
            $pdo->exec("CREATE TABLE IF NOT EXISTS driver_profiles (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                license_number VARCHAR(50) NOT NULL,
                vehicle_model VARCHAR(100) NOT NULL,
                vehicle_plate VARCHAR(20) NOT NULL,
                vehicle_color VARCHAR(30) NOT NULL,
                is_available BOOLEAN DEFAULT TRUE,
                current_latitude DECIMAL(10,8),
                current_longitude DECIMAL(11,8),
                rating DECIMAL(3,2) DEFAULT 0.00,
                total_rides INT DEFAULT 0,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )");

            // BOOKINGS TABLE
            $pdo->exec("CREATE TABLE IF NOT EXISTS bookings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                passenger_id INT NOT NULL,
                driver_id INT,
                pickup_address TEXT NOT NULL,
                dropoff_address TEXT NOT NULL,
                pickup_latitude DECIMAL(10,8),
                pickup_longitude DECIMAL(11,8),
                dropoff_latitude DECIMAL(10,8),
                dropoff_longitude DECIMAL(11,8),
                estimated_fare DECIMAL(10,2),
                actual_fare DECIMAL(10,2),
                distance_km DECIMAL(8,2),
                status ENUM('pending','accepted','in_progress','completed','cancelled','expired') DEFAULT 'pending',
                booking_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                pickup_time TIMESTAMP NULL,
                dropoff_time TIMESTAMP NULL,
                payment_method ENUM('cash','card','paypal') DEFAULT 'cash',
                payment_status ENUM('pending','paid','failed') DEFAULT 'pending',
                transaction_id VARCHAR(191) NULL,
                driver_latitude DECIMAL(10,8) NULL,
                driver_longitude DECIMAL(11,8) NULL,
                accepted_time TIMESTAMP NULL,
                rating_requested BOOLEAN DEFAULT FALSE,
                rating_submitted BOOLEAN DEFAULT FALSE,
                cancellation_reason TEXT NULL,
                cancelled_by ENUM('passenger','driver','system') NULL,
                cancelled_at TIMESTAMP NULL,
                expires_at TIMESTAMP NULL,
                FOREIGN KEY (passenger_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY (driver_id) REFERENCES users(id) ON DELETE SET NULL
            )");

            // RIDE TRACKING
            $pdo->exec("CREATE TABLE IF NOT EXISTS ride_tracking (
                id INT AUTO_INCREMENT PRIMARY KEY,
                booking_id INT NULL,
                driver_id INT NULL,
                driver_latitude DECIMAL(10,8),
                driver_longitude DECIMAL(11,8),
                status_update TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
                FOREIGN KEY (driver_id) REFERENCES users(id) ON DELETE SET NULL
            )");

            // REVIEWS
            $pdo->exec("CREATE TABLE IF NOT EXISTS reviews (
                id INT AUTO_INCREMENT PRIMARY KEY,
                booking_id INT NOT NULL UNIQUE,
                passenger_id INT NOT NULL,
                driver_id INT NOT NULL,
                rating INT CHECK (rating BETWEEN 1 AND 5),
                review TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
                FOREIGN KEY (passenger_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY (driver_id) REFERENCES users(id) ON DELETE CASCADE
            )");

            // SYSTEM SETTINGS
            $pdo->exec("CREATE TABLE IF NOT EXISTS system_settings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                setting_key VARCHAR(100) UNIQUE NOT NULL,
                setting_value VARCHAR(255) NOT NULL
            )");

            // DEFAULT SETTINGS
            $defaults = [
                ['base_fare', '2.50'],
                ['per_km_rate', '1.20'],
                ['per_minute_rate', '0.30'],
                ['minimum_fare', '5.00'],
                ['maximum_fare', '100.00']
            ];

            foreach ($defaults as $setting) {
                $stmt = $pdo->prepare("INSERT IGNORE INTO system_settings (setting_key, setting_value) VALUES (?,?)");
                $stmt->execute($setting);
            }

            // CREATE DEFAULT ADMIN
            $count = $pdo->query("SELECT COUNT(*) FROM users WHERE user_type='admin'")->fetchColumn();
            if ($count == 0) {
                $pass = password_hash('admin123', PASSWORD_DEFAULT);
                $pdo->prepare("INSERT INTO users (username, email, password, full_name, phone, user_type, is_verified) 
                            VALUES (?,?,?,?,?,?,?)")
                    ->execute(['admin', 'admin@tripgo.com', $pass, 'System Admin', '0000000000', 'admin', 1]);
            }

            return true;

        } catch (PDOException $e) {
            error_log("DB Init Error: " . $e->getMessage());
            return false;
        }
    }

    // Run only via CLI or explicit flag
    if (PHP_SAPI === 'cli' || (defined('RUN_INIT') && constant('RUN_INIT'))) {
        initializeDatabase();
    }
    ?>
