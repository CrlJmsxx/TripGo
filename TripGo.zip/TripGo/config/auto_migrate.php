<?php
// Auto-migration system - runs automatically when needed
function autoMigrateIfNeeded() {
    static $migrationRun = false;
    
    if ($migrationRun) {
        return; // Only run once per request
    }
    
    try {
        $pdo = getConnection();
        
        // Check if migration is needed by testing for new columns
        $testQuery = "SELECT expires_at FROM bookings LIMIT 1";
        $stmt = $pdo->query($testQuery);
        
        // If we get here, columns exist, no migration needed
        $migrationRun = true;
        return true;
        
    } catch (PDOException $e) {
        // Column doesn't exist, run migration
        if (strpos($e->getMessage(), 'expires_at') !== false) {
            try {
                // Add missing columns safely
                $pdo->exec("ALTER TABLE bookings ADD COLUMN expires_at TIMESTAMP NULL");
                
                // Add other missing columns
                try {
                    $pdo->exec("ALTER TABLE bookings ADD COLUMN cancellation_reason TEXT NULL");
                } catch (Exception $e2) {}
                
                try {
                    $pdo->exec("ALTER TABLE bookings ADD COLUMN cancelled_by ENUM('passenger', 'driver', 'system') NULL");
                } catch (Exception $e2) {}
                
                try {
                    $pdo->exec("ALTER TABLE bookings ADD COLUMN cancelled_at TIMESTAMP NULL");
                } catch (Exception $e2) {}
                
                try {
                    $pdo->exec("ALTER TABLE bookings ADD COLUMN accepted_time TIMESTAMP NULL");
                } catch (Exception $e2) {}
                
                try {
                    $pdo->exec("ALTER TABLE bookings ADD COLUMN rating_requested BOOLEAN DEFAULT FALSE");
                } catch (Exception $e2) {}
                
                try {
                    $pdo->exec("ALTER TABLE bookings ADD COLUMN rating_submitted BOOLEAN DEFAULT FALSE");
                } catch (Exception $e2) {}
                
                // Update status enum
                try {
                    $pdo->exec("ALTER TABLE bookings MODIFY COLUMN status ENUM('pending', 'accepted', 'in_progress', 'completed', 'cancelled', 'expired') DEFAULT 'pending'");
                } catch (Exception $e2) {}
                
                // Add users table columns
                try {
                    $pdo->exec("ALTER TABLE users ADD COLUMN average_rating DECIMAL(3, 2) DEFAULT NULL");
                } catch (Exception $e2) {}
                
                try {
                    $pdo->exec("ALTER TABLE users ADD COLUMN current_lat DECIMAL(10, 8) NULL");
                } catch (Exception $e2) {}
                
                try {
                    $pdo->exec("ALTER TABLE users ADD COLUMN current_lng DECIMAL(11, 8) NULL");
                } catch (Exception $e2) {}
                
                try {
                    $pdo->exec("ALTER TABLE users ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
                } catch (Exception $e2) {}
                
                // Create reviews table
                try {
                    $sql = "CREATE TABLE IF NOT EXISTS reviews (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        booking_id INT NOT NULL UNIQUE,
                        passenger_id INT NOT NULL,
                        driver_id INT NOT NULL,
                        rating INT CHECK (rating >= 1 AND rating <= 5),
                        review TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
                        FOREIGN KEY (passenger_id) REFERENCES users(id) ON DELETE CASCADE,
                        FOREIGN KEY (driver_id) REFERENCES users(id) ON DELETE CASCADE
                    )";
                    $pdo->exec($sql);
                } catch (Exception $e2) {}
                
                error_log("Auto-migration completed successfully");
                $migrationRun = true;
                return true;
                
            } catch (Exception $migrationError) {
                error_log("Auto-migration failed: " . $migrationError->getMessage());
                $migrationRun = true;
                return false;
            }
        }
        
        $migrationRun = true;
        return false;
    }
}

// Run auto-migration if needed
autoMigrateIfNeeded();
?>
