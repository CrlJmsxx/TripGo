<?php
// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Session management functions
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function getCurrentUser() {
    if (!isLoggedIn()) {
        return null;
    }
    
    // Capture the session user id and release the session lock early so
    // concurrent requests from the same user (AJAX, assets) are not blocked.
    $userId = $_SESSION['user_id'];
    // Close session write lock — safe here because we are only reading session data.
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }

    // Now fetch user information from database without holding the session lock.
    $pdo = getConnection();
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit();
    }
}

function requireAdmin() {
    requireLogin();
    $user = getCurrentUser();
    if ($user['user_type'] !== 'admin') {
        header('Location: index.php');
        exit();
    }
}

function requireDriver() {
    requireLogin();
    $user = getCurrentUser();
    if ($user['user_type'] !== 'driver') {
        header('Location: index.php');
        exit();
    }
}

function requirePassenger() {
    requireLogin();
    $user = getCurrentUser();
    if ($user['user_type'] !== 'passenger') {
        header('Location: index.php');
        exit();
    }
}

function logout() {
    // Clear all session variables
    $_SESSION = array();
    
    // Destroy the session cookie
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    
    // Destroy the session
    session_destroy();
}
?>
