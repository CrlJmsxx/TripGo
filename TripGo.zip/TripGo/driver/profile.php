<?php
require_once '../config/database.php';
require_once '../config/session.php';

requireDriver();

$currentUser = getCurrentUser();
$pdo = getConnection();

$success = '';
$error = '';

// Get driver profile
$stmt = $pdo->prepare("SELECT * FROM driver_profiles WHERE user_id = ?");
$stmt->execute([$currentUser['id']]);
$driverProfile = $stmt->fetch(PDO::FETCH_ASSOC);

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_profile'])) {
        $licenseNumber = trim($_POST['license_number']);
        $vehicleType = trim($_POST['vehicle_type']);
        $vehicleBrand = trim($_POST['vehicle_brand']);
        $vehicleModel = trim($_POST['vehicle_model']);
        $vehiclePlate = trim($_POST['vehicle_plate']);
        $vehicleColor = trim($_POST['vehicle_color']);
        $vehicleCapacity = trim($_POST['vehicle_capacity']);
        
        if (empty($licenseNumber) || empty($vehicleType) || empty($vehicleBrand) || empty($vehicleModel) || empty($vehiclePlate) || empty($vehicleColor) || empty($vehicleCapacity)) {
            $error = 'All fields are required.';
        } else {
            try {
                $stmt = $pdo->prepare("
                    UPDATE driver_profiles 
                    SET license_number = ?, vehicle_type = ?, vehicle_brand = ?, vehicle_model = ?, vehicle_plate = ?, vehicle_color = ?, vehicle_capacity = ?
                    WHERE user_id = ?
                ");
                $stmt->execute([$licenseNumber, $vehicleType, $vehicleBrand, $vehicleModel, $vehiclePlate, $vehicleColor, $vehicleCapacity, $currentUser['id']]);
                $success = 'Profile updated successfully!';
                
                // Refresh profile data
                $stmt = $pdo->prepare("SELECT * FROM driver_profiles WHERE user_id = ?");
                $stmt->execute([$currentUser['id']]);
                $driverProfile = $stmt->fetch(PDO::FETCH_ASSOC);
            } catch (Exception $e) {
                $error = 'Failed to update profile. Please try again.';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driver Profile - TripGO</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <a href="../index.php" class="logo">
                    <i class="fas fa-car"></i> TripGO
                </a>
                
                <nav class="nav">
                    <a href="../index.php">Home</a>
                    <a href="dashboard.php">Dashboard</a>
                    <a href="earnings.php">Earnings</a>
                    <a href="profile.php">Profile</a>
                </nav>
                
                <div class="user-menu">
                    <div class="user-info">
                        <div class="user-avatar">
                            <?php echo strtoupper(substr($currentUser['full_name'], 0, 1)); ?>
                        </div>
                        <span><?php echo htmlspecialchars($currentUser['full_name']); ?></span>
                    </div>
                    <a href="../auth/logout.php" class="btn btn-danger">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="container" style="padding: 40px 0;">
        <div class="dashboard-grid">
            <!-- Profile Information -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-user"></i> Driver Profile
                    </h2>
                </div>
                
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST">
                    <div class="form-group">
                        <label for="full_name">Full Name</label>
                        <input type="text" id="full_name" value="<?php echo htmlspecialchars($currentUser['full_name']); ?>" disabled>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" value="<?php echo htmlspecialchars($currentUser['email']); ?>" disabled>
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input type="tel" id="phone" value="<?php echo htmlspecialchars($currentUser['phone']); ?>" disabled>
                    </div>
                    
                    <div class="form-group">
                        <label for="license_number">License Number</label>
                        <input type="text" id="license_number" name="license_number" 
                               value="<?php echo htmlspecialchars($driverProfile['license_number'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="vehicle_type">Vehicle Type</label>
                        <select id="vehicle_type" name="vehicle_type" required>
                            <option value="">Select Vehicle Type</option>
                            <option value="motorcycle" <?php echo ($driverProfile['vehicle_type'] ?? '') === 'motorcycle' ? 'selected' : ''; ?>>
                                🏍️ Motorcycle
                            </option>
                            <option value="tricycle" <?php echo ($driverProfile['vehicle_type'] ?? '') === 'tricycle' ? 'selected' : ''; ?>>
                                🛺 Tricycle
                            </option>
                            <option value="car" <?php echo ($driverProfile['vehicle_type'] ?? '') === 'car' ? 'selected' : ''; ?>>
                                🚗 Car
                            </option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="vehicle_brand">Vehicle Brand</label>
                        <input type="text" id="vehicle_brand" name="vehicle_brand" 
                               value="<?php echo htmlspecialchars($driverProfile['vehicle_brand'] ?? ''); ?>" 
                               placeholder="e.g., Honda, Toyota, Ford" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="vehicle_capacity">Vehicle Capacity</label>
                        <select id="vehicle_capacity" name="vehicle_capacity" required>
                            <option value="">Select Capacity</option>
                            <option value="1" <?php echo ($driverProfile['vehicle_capacity'] ?? '') == '1' ? 'selected' : ''; ?>>
                                1 Passenger
                            </option>
                            <option value="2" <?php echo ($driverProfile['vehicle_capacity'] ?? '') == '2' ? 'selected' : ''; ?>>
                                2 Passengers
                            </option>
                            <option value="3" <?php echo ($driverProfile['vehicle_capacity'] ?? '') == '3' ? 'selected' : ''; ?>>
                                3 Passengers
                            </option>
                            <option value="4" <?php echo ($driverProfile['vehicle_capacity'] ?? '') == '4' ? 'selected' : ''; ?>>
                                4 Passengers
                            </option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="vehicle_model">Vehicle Model</label>
                        <input type="text" id="vehicle_model" name="vehicle_model" 
                               value="<?php echo htmlspecialchars($driverProfile['vehicle_model'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="vehicle_plate">License Plate</label>
                        <input type="text" id="vehicle_plate" name="vehicle_plate" 
                               value="<?php echo htmlspecialchars($driverProfile['vehicle_plate'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="vehicle_color">Vehicle Color</label>
                        <input type="text" id="vehicle_color" name="vehicle_color" 
                               value="<?php echo htmlspecialchars($driverProfile['vehicle_color'] ?? ''); ?>" required>
                    </div>
                    
                    <button type="submit" name="update_profile" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update Profile
                    </button>
                </form>
            </div>
            
            <!-- Driver Statistics -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-chart-bar"></i> Driver Statistics
                    </h3>
                </div>
                
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                            <i class="fas fa-route"></i>
                        </div>
                        <div class="stat-number"><?php echo $driverProfile['total_rides'] ?? 0; ?></div>
                        <div class="stat-label">Total Rides</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon" style="background: linear-gradient(135deg, #28a745 0%, #20c997 100%);">
                            <i class="fas fa-star"></i>
                        </div>
                        <div class="stat-number"><?php echo number_format($driverProfile['rating'] ?? 0.0, 1); ?></div>
                        <div class="stat-label">Rating</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon" style="background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%);">
                            <i class="fas fa-dollar-sign"></i>
                        </div>
                        <div class="stat-number">₱<?php echo number_format(($driverProfile['total_rides'] ?? 0) * 15, 2); ?></div>
                        <div class="stat-label">Estimated Earnings</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

