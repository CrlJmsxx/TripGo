<?php
require_once '../config/database.php';
require_once '../config/session.php';

requireDriver();

$currentUser = getCurrentUser();
$pdo = getConnection();

// Get driver's earnings data
$stmt = $pdo->prepare("
    SELECT 
        COUNT(*) as total_rides,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_rides,
        SUM(CASE WHEN status = 'completed' THEN actual_fare ELSE 0 END) as total_earnings,
        AVG(CASE WHEN status = 'completed' THEN actual_fare ELSE NULL END) as avg_fare
    FROM bookings 
    WHERE driver_id = ?
");
$stmt->execute([$currentUser['id']]);
$stats = $stmt->fetch(PDO::FETCH_ASSOC);

// Get recent completed rides
$stmt = $pdo->prepare("
    SELECT b.*, u.full_name as passenger_name 
    FROM bookings b 
    JOIN users u ON b.passenger_id = u.id 
    WHERE b.driver_id = ? AND b.status = 'completed'
    ORDER BY b.dropoff_time DESC 
    LIMIT 10
");
$stmt->execute([$currentUser['id']]);
$recentRides = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get earnings by month (last 6 months)
$stmt = $pdo->prepare("
    SELECT 
        DATE_FORMAT(dropoff_time, '%Y-%m') as month,
        COUNT(*) as rides,
        SUM(actual_fare) as earnings
    FROM bookings 
    WHERE driver_id = ? AND status = 'completed' 
    AND dropoff_time >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    GROUP BY DATE_FORMAT(dropoff_time, '%Y-%m')
    ORDER BY month DESC
");
$stmt->execute([$currentUser['id']]);
$monthlyEarnings = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driver Earnings - TripGO</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <a href="../index.php" class="logo">
                    <i class="fas fa-car"></i> TripGO
                </a>
                
                <nav class="nav">
                    <a href="../index.php">Home</a>
                    <a href="dashboard.php">Dashboard</a>
                    <a href="earnings.php">Earnings</a>
                    <a href="profile.php">Profile</a>
                </nav>
                
                <div class="user-menu">
                    <div class="user-info">
                        <div class="user-avatar">
                            <?php echo strtoupper(substr($currentUser['full_name'], 0, 1)); ?>
                        </div>
                        <span><?php echo htmlspecialchars($currentUser['full_name']); ?></span>
                    </div>
                    <a href="../auth/logout.php" class="btn btn-danger">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="container" style="padding: 40px 0;">
        <!-- Earnings Overview -->
        <div class="stats-grid" style="margin-bottom: 40px;">
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                    <i class="fas fa-route"></i>
                </div>
                <div class="stat-number"><?php echo $stats['total_rides']; ?></div>
                <div class="stat-label">Total Rides</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, #28a745 0%, #20c997 100%);">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="stat-number"><?php echo $stats['completed_rides']; ?></div>
                <div class="stat-label">Completed Rides</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%);">
                    <i class="fas fa-peso-sign"></i>
                </div>
                <div class="stat-number">₱<?php echo number_format($stats['total_earnings'], 2); ?></div>
                <div class="stat-label">Total Earnings</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, #dc3545 0%, #e83e8c 100%);">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="stat-number">₱<?php echo number_format($stats['avg_fare'], 2); ?></div>
                <div class="stat-label">Average per Ride</div>
            </div>
        </div>

        <div class="dashboard-grid">
            <!-- Recent Rides -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-clock" style="color: #667eea;"></i>
                        Recent Completed Rides
                    </h3>
                </div>
                
                <?php if (empty($recentRides)): ?>
                    <p style="text-align: center; color: #666; padding: 20px;">
                        <i class="fas fa-info-circle"></i> No completed rides yet
                    </p>
                <?php else: ?>
                    <div class="booking-list">
                        <?php foreach ($recentRides as $ride): ?>
                            <div class="booking-item">
                                <div class="booking-header">
                                    <span class="booking-id">#<?php echo $ride['id']; ?></span>
                                    <span class="booking-status status-completed">Completed</span>
                                </div>
                                <div class="booking-details">
                                    <div class="booking-detail">
                                        <i class="fas fa-user"></i>
                                        <span><?php echo htmlspecialchars($ride['passenger_name']); ?></span>
                                    </div>
                                    <div class="booking-detail">
                                        <i class="fas fa-dollar-sign"></i>
                                        <span>$<?php echo number_format($ride['actual_fare'], 2); ?></span>
                                    </div>
                                    <div class="booking-detail">
                                        <i class="fas fa-clock"></i>
                                        <span><?php echo date('M j, Y g:i A', strtotime($ride['dropoff_time'])); ?></span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Monthly Earnings -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-chart-bar" style="color: #28a745;"></i>
                        Monthly Earnings
                    </h3>
                </div>
                
                <?php if (empty($monthlyEarnings)): ?>
                    <p style="text-align: center; color: #666; padding: 20px;">
                        <i class="fas fa-info-circle"></i> No earnings data available
                    </p>
                <?php else: ?>
                    <div class="booking-list">
                        <?php foreach ($monthlyEarnings as $month): ?>
                            <div class="booking-item">
                                <div class="booking-header">
                                    <span class="booking-id"><?php echo date('F Y', strtotime($month['month'] . '-01')); ?></span>
                                    <span class="booking-status status-completed"><?php echo $month['rides']; ?> rides</span>
                                </div>
                                <div class="booking-details">
                                    <div class="booking-detail">
                                        <i class="fas fa-dollar-sign"></i>
                                        <span>$<?php echo number_format($month['earnings'], 2); ?></span>
                                    </div>
                                    <div class="booking-detail">
                                        <i class="fas fa-route"></i>
                                        <span><?php echo $month['rides']; ?> completed rides</span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>