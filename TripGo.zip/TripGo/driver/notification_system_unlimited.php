<?php
require_once '../config/database.php';
require_once '../config/session.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0);

// Set headers for Server-Sent Events
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
header('Connection: keep-alive');

// Enable CORS for EventSource
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Cache-Control');
header('Access-Control-Allow-Credentials: true');

// Prevent output buffering
if (ob_get_level()) {
    ob_end_clean();
}

// Start session if not already active
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check driver authentication
requireDriver();

$currentUser = getCurrentUser();
if (!$currentUser || $currentUser['user_type'] !== 'driver') {
    echo "data: " . json_encode([
        'type' => 'error',
        'message' => 'Unauthorized access',
        'timestamp' => time()
    ]) . "\n\n";
    exit();
}

$driverId = $currentUser['id'];

try {
    $pdo = getConnection();
    
    // Get driver's current location (for distance calculation, not filtering)
    $stmt = $pdo->prepare("SELECT current_latitude, current_longitude FROM driver_profiles WHERE user_id = ?");
    $stmt->execute([$driverId]);
    $driverProfile = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$driverProfile || $driverProfile['current_latitude'] === null || $driverProfile['current_longitude'] === null) {
        // Send error message and exit
        echo "data: " . json_encode([
            'type' => 'error',
            'message' => 'Driver location not set. Please update your location first.',
            'timestamp' => time()
        ]) . "\n\n";
        flush();
        exit();
    }
    
    $driverLat = (float) $driverProfile['current_latitude'];
    $driverLng = (float) $driverProfile['current_longitude'];
    
    // Track last known requests to avoid duplicates
    $lastKnownRequests = [];
    $lastCheckTime = time();
    $connectionStartTime = time();
    
    // Send initial connection message
    echo "data: " . json_encode([
        'type' => 'connected',
        'message' => 'Connected to ride request notifications (UNLIMITED RANGE)',
        'driver_location' => ['lat' => $driverLat, 'lng' => $driverLng],
        'driver_id' => $driverId,
        'timestamp' => time()
    ]) . "\n\n";
    
    flush();
    
    // Continuous monitoring loop
    while (connection_aborted() === false) {
        try {
            // FIXED: Get ALL new pending requests regardless of distance (from last 2 minutes)
            $stmt = $pdo->prepare("
                SELECT 
                    b.*,
                    u.full_name as passenger_name,
                    u.phone as passenger_phone,
                    (6371 * acos(
                        cos(radians(?)) * 
                        cos(radians(b.pickup_latitude)) * 
                        cos(radians(b.pickup_longitude) - radians(?)) + 
                        sin(radians(?)) * 
                        sin(radians(b.pickup_latitude))
                    )) as distance_km
                FROM bookings b
                JOIN users u ON b.passenger_id = u.id
                WHERE b.status = 'pending'
                AND (b.expires_at IS NULL OR b.expires_at > NOW())
                AND b.pickup_latitude IS NOT NULL
                AND b.pickup_longitude IS NOT NULL
                AND b.booking_time > DATE_SUB(NOW(), INTERVAL 2 MINUTE)
                ORDER BY b.booking_time DESC
            ");
            
            // FIXED: No bounding box filtering - get all requests
            $stmt->execute([$driverLat, $driverLng, $driverLat]);
            $newRequests = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Check for new requests
            foreach ($newRequests as $request) {
                $requestId = $request['id'];
                
                // If this is a new request we haven't seen
                if (!isset($lastKnownRequests[$requestId])) {
                    $lastKnownRequests[$requestId] = true;
                    
                    // Calculate distance category for UI
                    $distance = (float) $request['distance_km'];
                    $distanceCategory = 'nearby';
                    if ($distance > 50) {
                        $distanceCategory = 'far';
                    } elseif ($distance > 20) {
                        $distanceCategory = 'medium';
                    }
                    
                    // Send notification for new request (regardless of distance)
                    echo "data: " . json_encode([
                        'type' => 'new_request',
                        'request' => [
                            'id' => (int) $request['id'],
                            'passenger_name' => $request['passenger_name'],
                            'passenger_phone' => $request['passenger_phone'],
                            'pickup_address' => $request['pickup_address'],
                            'dropoff_address' => $request['dropoff_address'],
                            'pickup_latitude' => (float) $request['pickup_latitude'],
                            'pickup_longitude' => (float) $request['pickup_longitude'],
                            'dropoff_latitude' => $request['dropoff_latitude'] ? (float) $request['dropoff_latitude'] : null,
                            'dropoff_longitude' => $request['dropoff_longitude'] ? (float) $request['dropoff_longitude'] : null,
                            'estimated_fare' => (float) $request['estimated_fare'],
                            'distance_km' => round((float) $request['distance_km'], 2),
                            'distance_category' => $distanceCategory,
                            'booking_time' => $request['booking_time'],
                            'expires_at' => $request['expires_at']
                        ],
                        'timestamp' => time()
                    ]) . "\n\n";
                    
                    flush();
                }
            }
            
            // Clean up old requests from tracking (older than 5 minutes)
            $stmt = $pdo->prepare("
                SELECT id FROM bookings 
                WHERE status = 'pending' 
                AND booking_time < DATE_SUB(NOW(), INTERVAL 5 MINUTE)
            ");
            $stmt->execute();
            $oldRequests = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            foreach ($oldRequests as $oldRequestId) {
                if (isset($lastKnownRequests[$oldRequestId])) {
                    unset($lastKnownRequests[$oldRequestId]);
                    
                    // Send notification about expired request
                    echo "data: " . json_encode([
                        'type' => 'request_expired',
                        'request_id' => (int) $oldRequestId,
                        'timestamp' => time()
                    ]) . "\n\n";
                    
                    flush();
                }
            }
            
            // Send periodic heartbeat
            if (time() - $lastCheckTime > 30) {
                echo "data: " . json_encode([
                    'type' => 'heartbeat',
                    'message' => 'Still monitoring for ALL requests...',
                    'active_requests' => count($lastKnownRequests),
                    'uptime' => time() - $connectionStartTime,
                    'timestamp' => time()
                ]) . "\n\n";
                
                flush();
                $lastCheckTime = time();
            }
            
            // Sleep before next check
            sleep(3);
            
        } catch (PDOException $e) {
            // Send error but don't break the connection
            echo "data: " . json_encode([
                'type' => 'error',
                'message' => 'Database error: ' . $e->getMessage(),
                'timestamp' => time()
            ]) . "\n\n";
            
            flush();
            sleep(5);
        }
    }
    
} catch (Exception $e) {
    echo "data: " . json_encode([
        'type' => 'error',
        'message' => 'Connection error: ' . $e->getMessage(),
        'timestamp' => time()
    ]) . "\n\n";
    
    flush();
}
?>
