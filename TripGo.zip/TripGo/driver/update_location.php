<?php
require_once '../config/database.php';
require_once '../config/session.php';

requireDriver();

header('Content-Type: application/json');

// Get current user
$currentUser = getCurrentUser();
if (!$currentUser) {
    echo json_encode(['success' => false, 'error' => 'Not authenticated']);
    exit();
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['latitude']) || !isset($input['longitude'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid input']);
    exit();
}

$latitude = $input['latitude'];
$longitude = $input['longitude'];

// Validate coordinates
if (!is_numeric($latitude) || !is_numeric($longitude) ||
    $latitude < -90 || $latitude > 90 ||
    $longitude < -180 || $longitude > 180) {
    echo json_encode(['success' => false, 'error' => 'Invalid coordinates']);
    exit();
}

try {
    $pdo = getConnection();
    
    // Get driver's vehicle type for broadcasting
    $stmt = $pdo->prepare("SELECT vehicle_type, is_available FROM driver_profiles WHERE user_id = ?");
    $stmt->execute([$currentUser['id']]);
    $driverProfile = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Update driver profile with current location
    $stmt = $pdo->prepare("
        UPDATE driver_profiles 
        SET current_latitude = ?, current_longitude = ?, updated_at = NOW() 
        WHERE user_id = ?
    ");
    $stmt->execute([$latitude, $longitude, $currentUser['id']]);
    
    // Also update any active booking with driver location
    $stmt = $pdo->prepare("
        UPDATE bookings 
        SET driver_latitude = ?, driver_longitude = ? 
        WHERE driver_id = ? AND status IN ('accepted', 'in_progress')
    ");
    $stmt->execute([$latitude, $longitude, $currentUser['id']]);
    
    echo json_encode([
        'success' => true, 
        'message' => 'Location updated successfully',
        'timestamp' => date('Y-m-d H:i:s'),
        'driver_info' => [
            'driver_id' => $currentUser['id'],
            'current_location' => ['lat' => $latitude, 'lng' => $longitude],
            'vehicle_type' => $driverProfile['vehicle_type'] ?? null,
            'availability_status' => $driverProfile['is_available'] ? 'available' : 'unavailable'
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
}
?>
