<?php
require_once '../config/database.php';
require_once '../config/session.php';

requireDriver();

$currentUser = getCurrentUser();
$pdo = getConnection();

// Get driver profile
$stmt = $pdo->prepare("SELECT * FROM driver_profiles WHERE user_id = ?");
$stmt->execute([$currentUser['id']]);
$driverProfile = $stmt->fetch(PDO::FETCH_ASSOC);

// Get driver availability status
$isAvailable = $driverProfile['is_available'] ?? false;

// Get pending booking requests matching driver's vehicle type (exclude expired rides)
try {
    if ($driverProfile && $driverProfile['vehicle_type']) {
        $stmt = $pdo->prepare("
            SELECT b.*, u.full_name as passenger_name, u.phone as passenger_phone 
            FROM bookings b 
            JOIN users u ON b.passenger_id = u.id 
            WHERE b.status = 'pending' 
            AND b.vehicle_type = ?
            AND (b.expires_at IS NULL OR b.expires_at > NOW())
            ORDER BY b.booking_time DESC
        ");
        $stmt->execute([$driverProfile['vehicle_type']]);
    } else {
        // Fallback if no vehicle type set
        $stmt = $pdo->prepare("
            SELECT b.*, u.full_name as passenger_name, u.phone as passenger_phone 
            FROM bookings b 
            JOIN users u ON b.passenger_id = u.id 
            WHERE b.status = 'pending' 
            AND (b.expires_at IS NULL OR b.expires_at > NOW())
            ORDER BY b.booking_time DESC
        ");
        $stmt->execute();
    }
    $pendingBookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Fallback for databases without expires_at column
    if (strpos($e->getMessage(), 'expires_at') !== false) {
        if ($driverProfile && $driverProfile['vehicle_type']) {
            $stmt = $pdo->prepare("
                SELECT b.*, u.full_name as passenger_name, u.phone as passenger_phone 
                FROM bookings b 
                JOIN users u ON b.passenger_id = u.id 
                WHERE b.status = 'pending' 
                AND b.vehicle_type = ?
                ORDER BY b.booking_time DESC
            ");
            $stmt->execute([$driverProfile['vehicle_type']]);
        } else {
            $stmt = $pdo->prepare("
                SELECT b.*, u.full_name as passenger_name, u.phone as passenger_phone 
                FROM bookings b 
                JOIN users u ON b.passenger_id = u.id 
                WHERE b.status = 'pending' 
                ORDER BY b.booking_time DESC
            ");
            $stmt->execute();
        }
        $pendingBookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        throw $e; // Re-throw if it's a different error
    }
}

// Get driver's active bookings
$stmt = $pdo->prepare("
    SELECT b.*, u.full_name as passenger_name, u.phone as passenger_phone 
    FROM bookings b 
    JOIN users u ON b.passenger_id = u.id 
    WHERE b.driver_id = ? AND b.status IN ('accepted', 'in_progress')
    ORDER BY b.booking_time DESC
");
$stmt->execute([$currentUser['id']]);
$activeBookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get driver statistics
$stmt = $pdo->prepare("
    SELECT 
        COUNT(*) as total_rides,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_rides,
        SUM(CASE WHEN status = 'completed' THEN actual_fare ELSE 0 END) as total_earnings,
        AVG(CASE WHEN status = 'completed' THEN actual_fare ELSE NULL END) as avg_fare
    FROM bookings 
    WHERE driver_id = ?
");
$stmt->execute([$currentUser['id']]);
$stats = $stmt->fetch(PDO::FETCH_ASSOC);

// Handle status updates
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['toggle_availability'])) {
        $isAvailable = $_POST['is_available'] === '1';
        
        // First, check if driver profile exists
        $stmt = $pdo->prepare("SELECT id FROM driver_profiles WHERE user_id = ?");
        $stmt->execute([$currentUser['id']]);
        $profileExists = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($profileExists) {
            // Update existing profile
            $stmt = $pdo->prepare("UPDATE driver_profiles SET is_available = ? WHERE user_id = ?");
            $stmt->execute([$isAvailable, $currentUser['id']]);
        } else {
            // Create new profile with availability status
            $stmt = $pdo->prepare("
                INSERT INTO driver_profiles (user_id, is_available, license_number, vehicle_model, vehicle_plate, vehicle_color) 
                VALUES (?, ?, 'TEMP_LICENSE', 'TEMP_MODEL', 'TEMP_PLATE', 'TEMP_COLOR')
            ");
            $stmt->execute([$currentUser['id'], $isAvailable]);
        }
        
        header('Location: dashboard.php');
        exit();
    }
    
    if (isset($_POST['accept_booking'])) {
        $bookingId = $_POST['booking_id'];
        
        // Check if driver has any active rides (accepted or in_progress)
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as active_count 
            FROM bookings 
            WHERE driver_id = ? AND status IN ('accepted', 'in_progress')
        ");
        $stmt->execute([$currentUser['id']]);
        $activeCount = $stmt->fetch(PDO::FETCH_ASSOC)['active_count'];
        
        if ($activeCount > 0) {
            // Driver has active rides, cannot accept new ones
            $_SESSION['error'] = 'You cannot accept new rides while you have active rides. Please complete your current ride first.';
            header('Location: dashboard.php');
            exit();
        }
        
        // Check if driver is available
        $stmt = $pdo->prepare("SELECT is_available FROM driver_profiles WHERE user_id = ?");
        $stmt->execute([$currentUser['id']]);
        $isAvailable = $stmt->fetch(PDO::FETCH_ASSOC)['is_available'];
        
        if (!$isAvailable) {
            $_SESSION['error'] = 'You must be available to accept rides. Please set your status to available.';
            header('Location: dashboard.php');
            exit();
        }
        
        // Accept the booking (try with accepted_time, fallback without it)
        try {
            $stmt = $pdo->prepare("UPDATE bookings SET driver_id = ?, status = 'accepted', accepted_time = NOW() WHERE id = ? AND status = 'pending'");
            $stmt->execute([$currentUser['id'], $bookingId]);
        } catch (PDOException $e) {
            // Fallback for databases without accepted_time column
            if (strpos($e->getMessage(), 'accepted_time') !== false) {
                $stmt = $pdo->prepare("UPDATE bookings SET driver_id = ?, status = 'accepted' WHERE id = ? AND status = 'pending'");
                $stmt->execute([$currentUser['id'], $bookingId]);
            } else {
                throw $e; // Re-throw if it's a different error
            }
        }
        
        // Check if booking was actually updated
        if ($stmt->rowCount() > 0) {
            $_SESSION['success'] = 'Ride accepted successfully! Navigate to pickup location.';
        } else {
            $_SESSION['error'] = 'This ride is no longer available.';
        }
        
        header('Location: dashboard.php');
        exit();
    }
    
    if (isset($_POST['reject_booking'])) {
        $bookingId = $_POST['booking_id'];
        // In a real system, this would notify other drivers
        header('Location: dashboard.php');
        exit();
    }
    
    if (isset($_POST['update_ride_status'])) {
        $bookingId = $_POST['booking_id'];
        $newStatus = $_POST['status'];
        $stmt = $pdo->prepare("UPDATE bookings SET status = ? WHERE id = ? AND driver_id = ?");
        $stmt->execute([$newStatus, $bookingId, $currentUser['id']]);
        
        if ($newStatus === 'completed') {
            $stmt = $pdo->prepare("UPDATE bookings SET actual_fare = estimated_fare, dropoff_time = NOW() WHERE id = ?");
            $stmt->execute([$bookingId]);
            
            // Mark ride as ready for rating - this is the manual trigger
            try {
                $stmt = $pdo->prepare("UPDATE bookings SET rating_requested = 1 WHERE id = ?");
                $stmt->execute([$bookingId]);
                
                // Return JSON response for AJAX requests
                if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
                    header('Content-Type: application/json');
                    echo json_encode([
                        'success' => true,
                        'message' => 'Ride completed successfully! Passenger can now rate the ride.',
                        'booking_id' => $bookingId
                    ]);
                    exit();
                }
                
                $_SESSION['success'] = 'Ride completed successfully! Passenger can now rate the ride.';
                
            } catch (PDOException $e) {
                // Fallback for databases without rating columns
                if (strpos($e->getMessage(), 'rating_requested') !== false) {
                    // Rating system not available, just continue without it
                    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
                        header('Content-Type: application/json');
                        echo json_encode(['success' => true, 'message' => 'Ride completed successfully!']);
                        exit();
                    }
                    $_SESSION['success'] = 'Ride completed successfully!';
                } else {
                    throw $e; // Re-throw if it's a different error
                }
            }
        }
        
        header('Location: dashboard.php');
        exit();
    }
}

// Process expired rides (run on each dashboard load)
try {
    $stmt = $pdo->prepare("
        UPDATE bookings 
        SET status = 'expired', 
            cancelled_by = 'system', 
            cancellation_reason = 'Request expired - no driver available within time limit',
            cancelled_at = NOW()
        WHERE status IN ('pending', 'searching') 
        AND expires_at <= NOW()
    ");
    $stmt->execute();
} catch (PDOException $e) {
    // Fallback for databases without expiry columns
    if (strpos($e->getMessage(), 'expires_at') !== false || strpos($e->getMessage(), 'cancelled_by') !== false) {
        // Expiry system not available, just ignore
    } else {
        // Log other errors but continue
        error_log("Expiry processing error: " . $e->getMessage());
    }
}

// Update driver profile availability
$stmt = $pdo->prepare("SELECT is_available FROM driver_profiles WHERE user_id = ?");
$stmt->execute([$currentUser['id']]);
$isAvailable = $stmt->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driver Dashboard - TripGO</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/driver-dashboard-enhanced.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <!-- Leaflet CSS for OpenStreetMap -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <style>
        #driverMap { 
            height: 400px; 
            width: 100%; 
            border-radius: 12px; 
            margin: 20px 0;
            border: 2px solid var(--border-color);
        }
        .leaflet-control-custom {
            background: white;
            border: 2px solid var(--primary-color);
            border-radius: 8px;
            padding: 5px 10px;
            font-weight: bold;
            color: var(--primary-color);
        }
        .driver-marker {
            background: var(--primary-color);
            border: 3px solid white;
            border-radius: 50%;
            width: 12px;
            height: 12px;
        }
        .booking-card {
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }
        .booking-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-medium);
        }
        .status-indicator {
            display: inline-block;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 8px;
            animation: pulse 2s infinite;
        }
        .status-available { background: var(--success-color); }
        .status-busy { background: var(--creative-accent); }
        .status-offline { background: var(--text-muted); }
        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.5; }
            100% { opacity: 1; }
        }
        .real-time-info {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }
        
        /* Notification animations */
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <a href="../index.php" class="logo">
                    <i class="fas fa-car"></i> TripGO
                </a>
                
                <nav class="nav">
                    <a href="../index.php">Home</a>
                    <a href="dashboard.php">Dashboard</a>
                    <a href="earnings.php">Earnings</a>
                    <a href="profile.php">Profile</a>
                </nav>
                
                <div class="user-menu">
                    <div class="user-info">
                        <div class="user-avatar">
                            <?php echo strtoupper(substr($currentUser['full_name'], 0, 1)); ?>
                        </div>
                        <span><?php echo htmlspecialchars($currentUser['full_name']); ?></span>
                    </div>
                    <a href="../auth/logout.php" class="btn btn-danger">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="container" style="padding: 40px 0;">
        <!-- Session Messages -->
        <?php if (isset($_SESSION['success'])): ?>
            <div style="background: #d4edda; color: #155724; padding: 15px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #c3e6cb;">
                <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div style="background: #f8d7da; color: #721c24; padding: 15px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #f5c6cb;">
                <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <!-- Driver Status -->
        <div class="card" style="margin-bottom: 30px;">
            <div class="card-header">
                <h1 class="card-title">
                    <i class="fas fa-car"></i> Driver Dashboard
                </h1>
            </div>
            
            <div class="driver-status">
                <div style="display: flex; align-items: center; gap: 15px;">
                    <span style="font-weight: 600; font-size: 1.1rem;">Status:</span>
                    <span id="statusText" style="padding: 8px 16px; border-radius: 20px; font-weight: 600; 
                         background: <?php echo $isAvailable ? '#d4edda' : '#f8d7da'; ?>; 
                         color: <?php echo $isAvailable ? '#155724' : '#721c24'; ?>;">
                        <?php echo $isAvailable ? 'Available' : 'Offline'; ?>
                    </span>
                </div>
                
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="toggle_availability" value="1">
                    <input type="hidden" name="is_available" value="<?php echo $isAvailable ? '0' : '1'; ?>">
                    <button type="submit" class="btn <?php echo $isAvailable ? 'btn-danger' : 'btn-success'; ?>">
                        <i class="fas fa-<?php echo $isAvailable ? 'pause' : 'play'; ?>"></i>
                        <?php echo $isAvailable ? 'Go Offline' : 'Go Online'; ?>
                    </button>
                </form>
            </div>
        </div>

        <!-- Real-Time Map -->
        <div class="card" style="margin-bottom: 30px;">
            <div class="card-header">
                <h2 class="card-title">
                    <i class="fas fa-map"></i> Real-Time Location Tracking
                </h2>
            </div>
            
            <div class="real-time-info">
                <div style="display: flex; align-items: center; justify-content: center; gap: 10px;">
                    <span class="status-indicator <?php echo $isAvailable ? 'status-available' : 'status-offline'; ?>"></span>
                    <span style="font-weight: 600;">
                        <?php echo $isAvailable ? 'Online & Tracking Location' : 'Offline - Location Tracking Paused'; ?>
                    </span>
                </div>
                <div style="margin-top: 10px; font-size: 0.9rem; opacity: 0.9;">
                    <i class="fas fa-sync-alt"></i> Location updates every 5 seconds
                </div>
            </div>
            
            <div id="driverMap"></div>
            
            <div style="display: flex; gap: 15px; margin-top: 15px; flex-wrap: wrap;">
                <button type="button" id="centerOnDriver" class="btn btn-secondary" style="font-size: 14px;">
                    <i class="fas fa-crosshairs"></i> Center on My Location
                </button>
                <button type="button" id="showNearbyRequests" class="btn btn-primary" style="font-size: 14px;">
                    <i class="fas fa-search"></i> <span id="nearbyButtonText">Search Nearby Requests</span>
                </button>
            </div>
        </div>

        <!-- Advanced Filter Section -->
        <div class="card" style="margin-bottom: 30px;">
            <div class="card-header">
                <h3><i class="fas fa-filter"></i> Advanced Request Search</h3>
            </div>
            <div class="filter-section" style="padding: 20px;">
                <div class="filter-controls">
                    <button id="filterAllRequestsBtn" class="btn btn-primary">
                        <i class="fas fa-search"></i> Show All Requests
                    </button>
                    
                    <div class="filter-options" style="display: inline-block; margin-left: 15px;">
                        <label for="maxRadius" style="margin-right: 8px;">Optional Distance Filter (km):</label>
                        <input type="number" id="maxRadius" min="1" max="100" value="" 
                               placeholder="Show all"
                               style="width: 100px; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                        <button id="applyRadiusFilter" class="btn btn-secondary" style="margin-left: 8px;">
                            <i class="fas fa-filter"></i> Apply Filter
                        </button>
                        <button id="clearRadiusFilter" class="btn btn-outline-secondary" style="margin-left: 8px;">
                            <i class="fas fa-times"></i> Clear Filter
                        </button>
                    </div>
                    
                    <div class="filter-status" style="float: right;">
                        <span id="filterStatus" style="color: #666; font-size: 14px;"></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Enhanced Request List Container -->
        <div id="enhancedRequestList" class="request-list-container" style="margin-bottom: 30px;">
            <!-- Dynamic content will be inserted here -->
        </div>

        <!-- Statistics -->
        <div class="stats-grid" style="margin-bottom: 40px;">
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                    <i class="fas fa-route"></i>
                </div>
                <div class="stat-number"><?php echo $stats['total_rides']; ?></div>
                <div class="stat-label">Total Rides</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, #28a745 0%, #20c997 100%);">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="stat-number"><?php echo $stats['completed_rides']; ?></div>
                <div class="stat-label">Completed Rides</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%);">
                    <i class="fas fa-dollar-sign"></i>
                </div>
                <div class="stat-number">₱<?php echo number_format($stats['total_earnings'], 2); ?></div>
                <div class="stat-label">Total Earnings</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, #dc3545 0%, #e83e8c 100%);">
                    <i class="fas fa-star"></i>
                </div>
                <div class="stat-number"><?php echo number_format($driverProfile['rating'] ?? 0.0, 1); ?></div>
                <div class="stat-label">Average Rating</div>
            </div>
        </div>

        <div class="dashboard-grid">
            <!-- Pending Booking Requests -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-clock" style="color: #667eea;"></i>
                        Booking Requests
                    </h3>
                </div>
                
                <!-- Nearby Requests Display -->
                <div id="nearbyRequestsDisplay" style="padding: 15px; background: #f8f9fa; border-radius: 8px; margin-bottom: 20px;">
                    <div style="text-align: center; padding: 20px; color: var(--text-muted);">
                        <i class="fas fa-search" style="font-size: 2rem; margin-bottom: 10px;"></i>
                        <p>Click "Search Nearby Requests" to find available rides</p>
                        <small>Requests within 10km will appear here automatically</small>
                    </div>
                </div>
                
                <?php if (empty($pendingBookings)): ?>
                    <p style="text-align: center; color: #666; padding: 20px;">
                        <i class="fas fa-info-circle"></i> No pending booking requests
                    </p>
                <?php else: ?>
                    <div class="booking-list">
                        <?php foreach ($pendingBookings as $booking): ?>
                            <div class="booking-item">
                                <div class="booking-header">
                                    <span class="booking-id">#<?php echo $booking['id']; ?></span>
                                    <span class="booking-status status-pending">
                                        Pending
                                    </span>
                                </div>
                                <div class="booking-details">
                                    <div class="booking-detail">
                                        <i class="fas fa-map-marker-alt"></i>
                                        <span><?php echo htmlspecialchars($booking['pickup_address']); ?></span>
                                    </div>
                                    <div class="booking-detail">
                                        <i class="fas fa-flag-checkered"></i>
                                        <span><?php echo htmlspecialchars($booking['dropoff_address']); ?></span>
                                    </div>
                                    <div class="booking-detail">
                                        <i class="fas fa-dollar-sign"></i>
                                        <span>$<?php echo number_format($booking['estimated_fare'], 2); ?></span>
                                    </div>
                                    <div class="booking-detail">
                                        <i class="fas fa-user"></i>
                                        <span><?php echo htmlspecialchars($booking['passenger_name']); ?></span>
                                    </div>
                                    <div class="booking-detail">
                                        <i class="fas fa-car"></i>
                                        <span><?php echo htmlspecialchars($booking['vehicle_type'] ?? 'Not specified'); ?></span>
                                    </div>
                                </div>
                                <div style="margin-top: 15px; padding: 10px; background: #f8f9fa; border-radius: 8px;">
                                    <strong>Passenger:</strong> <?php echo htmlspecialchars($booking['passenger_name']); ?><br>
                                    <strong>Phone:</strong> <?php echo htmlspecialchars($booking['passenger_phone']); ?>
                                </div>
                                <div class="booking-actions">
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="accept_booking" value="1">
                                        <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                        <button type="submit" class="btn btn-success">
                                            <i class="fas fa-check"></i> Accept
                                        </button>
                                    </form>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="reject_booking" value="1">
                                        <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                        <button type="submit" class="btn btn-danger">
                                            <i class="fas fa-times"></i> Reject
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Active Bookings -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-car" style="color: #28a745;"></i>
                        Active Rides
                    </h3>
                </div>
                
                <?php if (empty($activeBookings)): ?>
                    <p style="text-align: center; color: #666; padding: 20px;">
                        <i class="fas fa-info-circle"></i> No active rides
                    </p>
                <?php else: ?>
                    <div class="booking-list">
                        <?php foreach ($activeBookings as $booking): ?>
                            <div class="booking-item" id="activeBooking_<?php echo $booking['id']; ?>">
                                <div class="booking-header">
                                    <span class="booking-id">#<?php echo $booking['id']; ?></span>
                                    <span class="booking-status status-<?php echo $booking['status']; ?>">
                                        <?php echo ucfirst($booking['status']); ?>
                                    </span>
                                </div>
                                <div class="booking-details">
                                    <div class="booking-detail">
                                        <i class="fas fa-map-marker-alt"></i>
                                        <span><?php echo htmlspecialchars($booking['pickup_address']); ?></span>
                                    </div>
                                    <div class="booking-detail">
                                        <i class="fas fa-flag-checkered"></i>
                                        <span><?php echo htmlspecialchars($booking['dropoff_address']); ?></span>
                                    </div>
                                    <div class="booking-detail">
                                        <i class="fas fa-dollar-sign"></i>
                                        <span>$<?php echo number_format($booking['estimated_fare'], 2); ?></span>
                                    </div>
                                    <div class="booking-detail">
                                        <i class="fas fa-user"></i>
                                        <span><?php echo htmlspecialchars($booking['passenger_name']); ?></span>
                                    </div>
                                </div>
                                
                                <!-- Passenger Location Tracking -->
                                <div class="passenger-tracking" style="margin-top: 15px; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                                    <h5 style="margin: 0 0 10px 0; color: #007bff;">
                                        <i class="fas fa-map"></i> Passenger Location & Route
                                    </h5>
                                    <div id="passengerMap_<?php echo $booking['id']; ?>" style="height: 250px; border-radius: 8px; margin-bottom: 10px;"></div>
                                    <div id="passengerETA_<?php echo $booking['id']; ?>" style="font-size: 0.9rem; color: #666;">
                                        <i class="fas fa-clock"></i> Calculating route...
                                    </div>
                                </div>
                                
                                <?php if ($booking['status'] === 'accepted'): ?>
                                    <div class="booking-actions">
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="update_ride_status" value="1">
                                            <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                            <input type="hidden" name="status" value="in_progress">
                                            <button type="submit" class="btn btn-primary">
                                                <i class="fas fa-play"></i> Start Ride
                                            </button>
                                        </form>
                                    </div>
                                <?php elseif ($booking['status'] === 'in_progress'): ?>
                                    <div class="booking-actions">
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="update_ride_status" value="1">
                                            <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                            <input type="hidden" name="status" value="completed">
                                            <button type="submit" class="btn btn-success">
                                                <i class="fas fa-check"></i> Complete Ride
                                            </button>
                                        </form>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Leaflet JS for OpenStreetMap -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
        let map;
        let driverMarker;
        let locationUpdateInterval;
        let bookingMarkers = [];
        let isAvailable = <?php echo $isAvailable ? 'true' : 'false'; ?>;
        let currentDriverLocation = null;

        // Initialize map
        function initDriverMap() {
            // Initialize map centered on Philippines
            map = L.map('driverMap').setView([12.8797, 121.7740], 13);

            // Add OpenStreetMap tiles (free)
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors',
                maxZoom: 18
            }).addTo(map);

            // Expose map globally so other scripts can reference it
            window.driverMap = map;

            // Custom driver icon
            const driverIcon = L.divIcon({
                html: '<div style="background: #007bff; color: white; border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; font-weight: bold; border: 3px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3);"><i class="fas fa-car" style="font-size: 16px;"></i></div>',
                iconSize: [40, 40],
                className: 'custom-div-icon'
            });

            // Get initial driver location
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                    const lat = position.coords.latitude;
                    const lng = position.coords.longitude;
                    
                    // Check accuracy
                    if (position.coords.accuracy > 100) {
                        console.warn('Low GPS accuracy:', position.coords.accuracy + 'm');
                        // Show warning but still use the location
                        showLocationWarning('GPS accuracy is low. Move to open area for better tracking.');
                    }
                    
                    currentDriverLocation = {lat: lat, lng: lng};
                    
                    // Set driver marker (add className so other managers can find it)
                    driverMarker = L.marker([lat, lng], {icon: driverIcon, className: 'driver-marker'}).addTo(map);
                    driverMarker.bindPopup('<b>Your Current Location</b><br>Accuracy: ' + Math.round(position.coords.accuracy) + 'm').openPopup();
                    
                    // Center map on driver
                    map.setView([lat, lng], 15);
                    
                    // Start location tracking
                    startLocationTracking();
                    
                    // Update database with initial location
                    updateDriverLocation(lat, lng);
                }, function(error) {
                    console.error('Error getting location:', error);
                    let errorMessage = 'Unable to get your GPS location. ';
                    switch(error.code) {
                        case error.PERMISSION_DENIED:
                            errorMessage += 'Location access was denied. Please enable GPS.';
                            break;
                        case error.POSITION_UNAVAILABLE:
                            errorMessage += 'GPS signal unavailable. Please check your device settings.';
                            break;
                        case error.TIMEOUT:
                            errorMessage += 'GPS request timed out. Please try again.';
                            break;
                        default:
                            errorMessage += 'Please check your GPS settings.';
                    }
                    showLocationError(errorMessage);
                    
                    // Fallback to default location (Manila)
                    const fallbackLat = 14.5995;
                    const fallbackLng = 120.9842;
                    currentDriverLocation = {lat: fallbackLat, lng: fallbackLng};
                    driverMarker = L.marker([fallbackLat, fallbackLng], {icon: driverIcon, className: 'driver-marker'}).addTo(map);
                    map.setView([fallbackLat, fallbackLng], 13);
                });
            }

            // Center on driver button
            document.getElementById('centerOnDriver').addEventListener('click', function() {
                if (currentDriverLocation) {
                    map.setView([currentDriverLocation.lat, currentDriverLocation.lng], 16);
                }
            });

            // Show nearby requests button
            document.getElementById('showNearbyRequests').addEventListener('click', function() {
                showNearbyBookingRequests();
            });
        }

        // Start real-time location tracking
        function startLocationTracking() {
            if (!isAvailable) return;
            
            locationUpdateInterval = setInterval(function() {
                if (navigator.geolocation && isAvailable) {
                    navigator.geolocation.getCurrentPosition(function(position) {
                        const lat = position.coords.latitude;
                        const lng = position.coords.longitude;
                        
                        // Skip if accuracy is too poor
                        if (position.coords.accuracy > 200) {
                            console.warn('Skipping low accuracy location:', position.coords.accuracy + 'm');
                            return;
                        }
                        
                        currentDriverLocation = {lat: lat, lng: lng};
                        
                        // Update marker position
                        if (driverMarker) {
                            driverMarker.setLatLng([lat, lng]);
                            driverMarker.setPopupContent('<b>Your Current Location</b><br>Accuracy: ' + Math.round(position.coords.accuracy) + 'm');
                        }
                        
                        // Update database
                        updateDriverLocation(lat, lng);
                        
                        // Check for nearby bookings
                        checkNearbyBookings(lat, lng);
                    }, function(error) {
                        console.error('Location update error:', error);
                    }, {
                        enableHighAccuracy: true,
                        timeout: 15000,
                        maximumAge: 10000 // Use recent data
                    });
                }
            }, 5000); // Update every 5 seconds
        }

        // Update driver location in database
        function updateDriverLocation(lat, lng) {
            fetch('update_location.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    latitude: lat,
                    longitude: lng
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    console.log('Location updated successfully');
                }
            })
            .catch(error => {
                console.error('Error updating location:', error);
            });
        }

        // Check for nearby bookings
        function checkNearbyBookings(driverLat, driverLng) {
            // Clear existing booking markers
            clearBookingMarkers();
            
            // Fetch nearby rides from API
            fetch('../api/get_nearby_rides.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `latitude=${driverLat}&longitude=${driverLng}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success && data.data) {
                    const nearbyBookings = data.data;
                    
                    // Update display
                    updateNearbyRequestsDisplay(nearbyBookings);
                    
                    // Add markers for each nearby booking
                    nearbyBookings.forEach(function(booking) {
                        const marker = L.marker([booking.pickup_latitude, booking.pickup_longitude], {
                            icon: L.divIcon({
                                className: 'custom-div-icon',
                                html: `<div style="background: #007bff; color: white; padding: 5px 8px; border-radius: 12px; font-size: 11px; font-weight: bold; white-space: nowrap; box-shadow: 0 2px 6px rgba(0,0,0,0.3);">
                                    <i class="fas fa-user"></i> ₱${booking.estimated_fare}
                                </div>`,
                                iconSize: [80, 30],
                                iconAnchor: [40, 15]
                            })
                        }).addTo(map);
                        
                        // Add popup
                        marker.bindPopup(`
                            <div style="min-width: 200px;">
                                <h4 style="margin: 0 0 10px 0; color: #333;">Ride Request #${booking.id}</h4>
                                <p style="margin: 5px 0;"><strong>Passenger:</strong> ${booking.passenger_name}</p>
                                <p style="margin: 5px 0;"><strong>Pickup:</strong> ${booking.pickup_address.substring(0, 50)}...</p>
                                <p style="margin: 5px 0;"><strong>Dropoff:</strong> ${booking.dropoff_address.substring(0, 50)}...</p>
                                <p style="margin: 5px 0;"><strong>Distance:</strong> ${booking.distance_km} km</p>
                                <p style="margin: 5px 0;"><strong>Fare:</strong> ₱${booking.estimated_fare}</p>
                                <button onclick="acceptBooking(${booking.id})" style="background: #28a745; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; margin-top: 10px;">
                                    <i class="fas fa-check"></i> Accept
                                </button>
                            </div>
                        `);
                        
                        // Store marker
                        window.bookingMarkers = window.bookingMarkers || [];
                        window.bookingMarkers.push(marker);
                    });
                    
                    // Update nearby requests display
                    updateNearbyRequestsDisplay(nearbyBookings);
                } else {
                    updateNearbyRequestsDisplay([]);
                    if (data.error) {
                        showNotification('Error loading nearby requests: ' + data.error, 'error');
                    }
                }
            })
            .catch(error => {
                console.error('Error fetching nearby rides:', error);
                updateNearbyRequestsDisplay([]);
                showNotification('Error loading nearby requests', 'error');
            });
        }

        // Get route using OSRM API
        async function getRoute(startLat, startLng, endLat, endLng) {
            try {
                const url = `https://router.project-osrm.org/route/v1/driving/${startLng},${startLat};${endLng},${endLat}?overview=full&geometries=geojson`;
                const response = await fetch(url);
                const data = await response.json();
                
                if (data.code === 'Ok' && data.routes.length > 0) {
                    return {
                        coordinates: data.routes[0].geometry.coordinates,
                        distance: data.routes[0].distance / 1000, // Convert to km
                        duration: data.routes[0].duration / 60 // Convert to minutes
                    };
                }
                return null;
            } catch (error) {
                console.error('Error getting route:', error);
                return null;
            }
        }

        // Show route for accepted ride
        async function showRouteForAcceptedRide(booking) {
            if (!currentDriverLocation || !booking.pickup_latitude || !booking.pickup_longitude) {
                return;
            }

            // Get route from driver to passenger
            const route = await getRoute(
                currentDriverLocation.lat, currentDriverLocation.lng,
                booking.pickup_latitude, booking.pickup_longitude
            );

            if (route) {
                // Clear existing route
                if (window.currentRoute) {
                    map.removeLayer(window.currentRoute);
                }

                // Convert coordinates for Leaflet
                const latLngs = route.coordinates.map(coord => [coord[1], coord[0]]);
                
                // Draw route line
                window.currentRoute = L.polyline(latLngs, {
                    color: '#007bff',
                    weight: 4,
                    opacity: 0.7
                }).addTo(map);

                // Fit map to show route
                const bounds = L.latLngBounds(latLngs);
                map.fitBounds(bounds, { padding: [50, 50] });

                // Update ETA display
                const etaElement = document.getElementById('etaDisplay');
                if (etaElement) {
                    etaElement.innerHTML = `
                        <i class="fas fa-route"></i> 
                        Distance: ${route.distance.toFixed(1)} km | 
                        Estimated time: ${Math.round(route.duration)} minutes
                    `;
                }
            }
        }

        // Clear booking markers
        function clearBookingMarkers() {
            if (window.bookingMarkers) {
                window.bookingMarkers.forEach(marker => {
                    map.removeLayer(marker);
                });
                window.bookingMarkers = [];
            }
        }

        // Update nearby requests display
        function updateNearbyRequestsDisplay(nearbyBookings) {
            const displayElement = document.getElementById('nearbyRequestsDisplay');
            if (!displayElement) return;
            
            if (nearbyBookings.length === 0) {
                displayElement.innerHTML = `
                    <div style="text-align: center; padding: 20px; color: var(--text-muted);">
                        <i class="fas fa-search-location" style="font-size: 2rem; margin-bottom: 10px;"></i>
                        <p>No nearby requests found within 10km</p>
                        <small>Try searching again or check back later</small>
                    </div>
                `;
            } else {
                let html = `
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                        <strong style="color: var(--primary-color);">
                            <i class="fas fa-map-marked-alt"></i> Nearby Requests (${nearbyBookings.length})
                        </strong>
                        <small style="color: var(--text-muted);">Within 10km radius</small>
                    </div>
                `;
                
                nearbyBookings.forEach(function(booking) {
                    const distanceClass = booking.distance <= 3 ? 'success' : booking.distance <= 6 ? 'warning' : 'info';
                    const distanceColor = booking.distance <= 3 ? '#28a745' : booking.distance <= 6 ? '#ffc107' : '#17a2b8';
                    
                    html += `
                        <div style="background: white; border: 1px solid var(--border-color); border-radius: 8px; padding: 15px; margin-bottom: 12px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); transition: all 0.2s ease; cursor: pointer;" 
                             onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 4px 8px rgba(0,0,0,0.1)';"
                             onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 2px 4px rgba(0,0,0,0.05)';"
                             onclick="centerOnBooking(${booking.pickup_latitude}, ${booking.pickup_longitude})">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <span style="background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); color: white; padding: 4px 8px; border-radius: 6px; font-weight: 600; font-size: 0.9rem;">
                                        #${booking.id}
                                    </span>
                                    <span style="background: ${distanceColor}; color: white; padding: 2px 8px; border-radius: 12px; font-size: 0.75rem; font-weight: 600;">
                                        ${booking.distance.toFixed(1)} km
                                    </span>
                                </div>
                                <button onclick="event.stopPropagation(); acceptBooking(${booking.id})" 
                                        style="background: #28a745; color: white; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-size: 0.8rem; font-weight: 600; transition: all 0.2s ease;"
                                        onmouseover="this.style.background='#218838'; this.style.transform='scale(1.05)';"
                                        onmouseout="this.style.background='#28a745'; this.style.transform='scale(1)';">
                                    <i class="fas fa-check"></i> Accept
                                </button>
                            </div>
                            <div style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 8px; line-height: 1.4;">
                                <i class="fas fa-map-marker-alt" style="color: var(--primary-color);"></i> 
                                ${booking.pickup_address.length > 50 ? booking.pickup_address.substring(0, 50) + '...' : booking.pickup_address}
                            </div>
                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <span style="font-size: 0.85rem; color: var(--primary-color); font-weight: 600;">
                                    <i class="fas fa-dollar-sign"></i> ${parseFloat(booking.estimated_fare).toFixed(2)}
                                </span>
                                <span style="font-size: 0.75rem; color: var(--text-muted);">
                                    <i class="fas fa-user"></i> ${booking.passenger_name}
                                </span>
                            </div>
                        </div>
                    `;
                });
                
                html += `
                    <div style="text-align: center; margin-top: 15px; padding-top: 15px; border-top: 1px solid var(--border-color);">
                        <small style="color: var(--text-muted);">
                            <i class="fas fa-info-circle"></i> Click on any request to center map, or use Accept button to book immediately
                        </small>
                    </div>
                `;
                
                displayElement.innerHTML = html;
            }
        }

        // Center map on specific booking
        function centerOnBooking(lat, lng) {
            if (map && lat && lng) {
                map.setView([lat, lng], 15);
                showNotification('Map centered on pickup location', 'info');
            }
        }

        // Show booking on map
        function showBookingOnMap(booking, distance) {
            const bookingIcon = L.divIcon({
                html: '<div style="background: #28a745; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; font-weight: bold; border: 3px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3);">₱</div>',
                iconSize: [30, 30],
                className: 'custom-div-icon'
            });

            const marker = L.marker([booking.pickup_latitude, booking.pickup_longitude], {icon: bookingIcon})
                .addTo(map)
                .bindPopup(`
                    <div style="padding: 10px;">
                        <h4 style="margin: 0 0 10px 0; color: #28a745;">New Booking Request</h4>
                        <p style="margin: 5px 0;"><strong>Passenger:</strong> ${booking.passenger_name}</p>
                        <p style="margin: 5px 0;"><strong>Fare:</strong> ₱${parseFloat(booking.estimated_fare).toFixed(2)}</p>
                        <p style="margin: 5px 0;"><strong>Distance:</strong> ${distance.toFixed(1)} km away</p>
                        <p style="margin: 5px 0;"><strong>Pickup:</strong> ${booking.pickup_address}</p>
                        <button onclick="acceptBooking(${booking.id})" style="background: #28a745; color: white; border: none; padding: 5px 10px; border-radius: 4px; cursor: pointer; margin-top: 10px;">
                            Accept Booking
                        </button>
                    </div>
                `);
            
            // Store marker globally
            if (!window.bookingMarkers) {
                window.bookingMarkers = [];
            }
            window.bookingMarkers.push(marker);
        }

        // Accept booking function
        function acceptBooking(bookingId) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.innerHTML = `
                <input type="hidden" name="accept_booking" value="1">
                <input type="hidden" name="booking_id" value="${bookingId}">
            `;
            document.body.appendChild(form);
            form.submit();
        }

        // Show nearby booking requests
        function showNearbyBookingRequests() {
            // Show loading state
            const button = document.getElementById('showNearbyRequests');
            const buttonText = document.getElementById('nearbyButtonText');
            const originalText = buttonText.textContent;
            const originalIcon = button.querySelector('i').className;
            
            button.disabled = true;
            button.querySelector('i').className = 'fas fa-spinner fa-spin';
            buttonText.textContent = 'Searching...';
            
            // Clear existing booking markers
            clearBookingMarkers();
            
            if (currentDriverLocation) {
                // Zoom map to show nearby requests area (12km zoom level)
                map.setView([currentDriverLocation.lat, currentDriverLocation.lng], 12);
                
                // Check for nearby bookings
                checkNearbyBookings(currentDriverLocation.lat, currentDriverLocation.lng);
                
                // Show success feedback
                setTimeout(() => {
                    const nearbyCount = window.bookingMarkers ? window.bookingMarkers.length : 0;
                    if (nearbyCount > 0) {
                        showNotification(`Found ${nearbyCount} nearby request${nearbyCount > 1 ? 's' : ''} within 10km!`, 'success');
                        button.querySelector('i').className = 'fas fa-check-circle';
                        buttonText.textContent = `${nearbyCount} Request${nearbyCount > 1 ? 's' : ''} Found`;
                    } else {
                        showNotification('No nearby requests found within 10km. Try again later!', 'info');
                        button.querySelector('i').className = 'fas fa-search';
                        buttonText.textContent = 'No Requests Found';
                    }
                    
                    // Reset button after delay
                    setTimeout(() => {
                        button.querySelector('i').className = originalIcon;
                        buttonText.textContent = originalText;
                        button.disabled = false;
                    }, 3000);
                }, 1500);
            } else {
                showNotification('Location not available. Please enable location services!', 'error');
                button.querySelector('i').className = originalIcon;
                buttonText.textContent = originalText;
                button.disabled = false;
            }
        }

        // Show notification function
        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 15px 20px;
                border-radius: 8px;
                color: white;
                font-weight: 600;
                z-index: 10000;
                max-width: 300px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                animation: slideInRight 0.3s ease-out;
            `;
            
            switch(type) {
                case 'success':
                    notification.style.background = 'linear-gradient(135deg, #28a745, #20c997)';
                    notification.innerHTML = `<i class="fas fa-check-circle"></i> ${message}`;
                    break;
                case 'error':
                    notification.style.background = 'linear-gradient(135deg, #dc3545, #c82333)';
                    notification.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${message}`;
                    break;
                case 'info':
                default:
                    notification.style.background = 'linear-gradient(135deg, #17a2b8, #138496)';
                    notification.innerHTML = `<i class="fas fa-info-circle"></i> ${message}`;
                    break;
            }
            
            document.body.appendChild(notification);
            
            // Auto-remove after 4 seconds
            setTimeout(() => {
                notification.style.animation = 'slideOutRight 0.3s ease-out';
                setTimeout(() => {
                    document.body.removeChild(notification);
                }, 300);
            }, 4000);
        }

        // Calculate distance between two points
        function calculateDistance(lat1, lon1, lat2, lon2) {
            const R = 6371; // Radius of the Earth in km
            const dLat = (lat2 - lat1) * Math.PI / 180;
            const dLon = (lon2 - lon1) * Math.PI / 180;
            const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                    Math.sin(dLon/2) * Math.sin(dLon/2);
            const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
            return R * c;
        }

        // Stop location tracking when going offline
        function stopLocationTracking() {
            if (locationUpdateInterval) {
                clearInterval(locationUpdateInterval);
                locationUpdateInterval = null;
            }
        }

        // Check availability status changes
        function checkAvailabilityStatus() {
            const statusText = document.getElementById('statusText');
            if (statusText) {
                const currentStatus = statusText.textContent.trim();
                const newAvailable = currentStatus === 'Available';
                
                if (newAvailable !== isAvailable) {
                    isAvailable = newAvailable;
                    if (isAvailable) {
                        startLocationTracking();
                    } else {
                        stopLocationTracking();
                    }
                }
            }
        }

        // Initialize passenger tracking maps for active bookings
        function initPassengerTrackingMaps() {
            <?php if (!empty($activeBookings)): ?>
            const activeBookings = <?php echo json_encode($activeBookings); ?>;
            
            activeBookings.forEach(function(booking) {
                const mapId = 'passengerMap_' + booking.id;
                const etaId = 'passengerETA_' + booking.id;
                
                if (document.getElementById(mapId)) {
                    initPassengerTrackingMap(booking, mapId, etaId);
                }
            });
            <?php endif; ?>
        }

        // Initialize individual passenger tracking map
        function initPassengerTrackingMap(booking, mapId, etaId) {
            // Create small map for this booking
            const bookingMap = L.map(mapId).setView([booking.pickup_latitude, booking.pickup_longitude], 15);

            // Add OpenStreetMap tiles
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors',
                maxZoom: 18
            }).addTo(bookingMap);

            // Custom icons
            const driverIcon = L.divIcon({
                html: '<div style="background: #007bff; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; font-weight: bold; border: 2px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3);"><i class="fas fa-car" style="font-size: 12px;"></i></div>',
                iconSize: [30, 30],
                className: 'custom-div-icon'
            });

            const pickupIcon = L.divIcon({
                html: '<div style="background: #28a745; color: white; border-radius: 50%; width: 25px; height: 25px; display: flex; align-items: center; justify-content: center; font-weight: bold; border: 2px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3);">P</div>',
                iconSize: [25, 25],
                className: 'custom-div-icon'
            });

            const dropoffIcon = L.divIcon({
                html: '<div style="background: #dc3545; color: white; border-radius: 50%; width: 25px; height: 25px; display: flex; align-items: center; justify-content: center; font-weight: bold; border: 2px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3);">D</div>',
                iconSize: [25, 25],
                className: 'custom-div-icon'
            });

            // Add markers
            const pickupMarker = L.marker([booking.pickup_latitude, booking.pickup_longitude], {icon: pickupIcon})
                .addTo(bookingMap)
                .bindPopup('<b>Pickup Location</b>');

            const dropoffMarker = L.marker([booking.dropoff_latitude, booking.dropoff_longitude], {icon: dropoffIcon})
                .addTo(bookingMap)
                .bindPopup('<b>Dropoff Location</b>');

            // Add driver marker
            let driverMarker;
            if (currentDriverLocation) {
                driverMarker = L.marker([currentDriverLocation.lat, currentDriverLocation.lng], {icon: driverIcon})
                    .addTo(bookingMap)
                    .bindPopup('<b>Your Location</b>');
            }

            // Draw route
            const routeLine = L.polyline([
                [booking.pickup_latitude, booking.pickup_longitude],
                [booking.dropoff_latitude, booking.dropoff_longitude]
            ], {
                color: '#007bff',
                weight: 3,
                opacity: 0.7,
                dashArray: '5, 5'
            }).addTo(bookingMap);

            // Fit map to show route
            const group = new L.featureGroup([pickupMarker, dropoffMarker]);
            if (driverMarker) {
                group.addLayer(driverMarker);
            }
            bookingMap.fitBounds(group.getBounds().pad(0.2));

            // Update driver location on main map updates
            updatePassengerMapDriverLocation(bookingMap, driverMarker, booking, etaId);

            // Store reference for updates
            window.passengerMaps = window.passengerMaps || {};
            window.passengerMaps[booking.id] = {
                map: bookingMap,
                driverMarker: driverMarker,
                pickupMarker: pickupMarker,
                dropoffMarker: dropoffMarker,
                routeLine: routeLine,
                booking: booking,
                etaId: etaId
            };
        }

        // Update passenger map driver location
        function updatePassengerMapDriverLocation(bookingMap, driverMarker, booking, etaId) {
            if (!currentDriverLocation) return;

            if (driverMarker) {
                driverMarker.setLatLng([currentDriverLocation.lat, currentDriverLocation.lng]);
            }

            // Update ETA
            if (booking.status === 'accepted') {
                const distance = calculateDistance(
                    currentDriverLocation.lat, currentDriverLocation.lng,
                    parseFloat(booking.pickup_latitude),
                    parseFloat(booking.pickup_longitude)
                );
                
                const avgSpeed = 30; // km/h
                const etaMinutes = Math.round((distance / avgSpeed) * 60);
                
                const etaElement = document.getElementById(etaId);
                if (etaElement) {
                    if (etaMinutes <= 1) {
                        etaElement.innerHTML = '<i class="fas fa-clock"></i> Arriving at pickup now!';
                    } else {
                        etaElement.innerHTML = `<i class="fas fa-clock"></i> ${etaMinutes} minutes to pickup (${distance.toFixed(1)} km)`;
                    }
                }
            } else if (booking.status === 'in_progress') {
                const distance = calculateDistance(
                    currentDriverLocation.lat, currentDriverLocation.lng,
                    parseFloat(booking.dropoff_latitude),
                    parseFloat(booking.dropoff_longitude)
                );
                
                const avgSpeed = 30; // km/h
                const etaMinutes = Math.round((distance / avgSpeed) * 60);
                
                const etaElement = document.getElementById(etaId);
                if (etaElement) {
                    if (etaMinutes <= 1) {
                        etaElement.innerHTML = '<i class="fas fa-flag-checkered"></i> Arriving at destination now!';
                    } else {
                        etaElement.innerHTML = `<i class="fas fa-flag-checkered"></i> ${etaMinutes} minutes to destination (${distance.toFixed(1)} km remaining)`;
                    }
                }
            }
        }

        // Update all passenger tracking maps
        function updateAllPassengerMaps() {
            if (!window.passengerMaps) return;

            Object.keys(window.passengerMaps).forEach(bookingId => {
                const mapData = window.passengerMaps[bookingId];
                updatePassengerMapDriverLocation(
                    mapData.map, 
                    mapData.driverMarker, 
                    mapData.booking, 
                    mapData.etaId
                );
            });
        }

        // Show location warning
        function showLocationWarning(message) {
            const warningDiv = document.createElement('div');
            warningDiv.className = 'alert alert-warning alert-dismissible fade show position-fixed';
            warningDiv.style.cssText = 'top: 70px; right: 20px; z-index: 9999; min-width: 300px;';
            warningDiv.innerHTML = `
                <i class="fas fa-exclamation-triangle"></i> ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            document.body.appendChild(warningDiv);
            
            // Auto-remove after 5 seconds
            setTimeout(() => {
                if (warningDiv.parentNode) {
                    warningDiv.parentNode.removeChild(warningDiv);
                }
            }, 5000);
        }

        // Show location error
        function showLocationError(message) {
            const errorDiv = document.createElement('div');
            errorDiv.className = 'alert alert-danger alert-dismissible fade show position-fixed';
            errorDiv.style.cssText = 'top: 70px; right: 20px; z-index: 9999; min-width: 300px;';
            errorDiv.innerHTML = `
                <i class="fas fa-exclamation-circle"></i> ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            document.body.appendChild(errorDiv);
            
            // Auto-remove after 10 seconds
            setTimeout(() => {
                if (errorDiv.parentNode) {
                    errorDiv.parentNode.removeChild(errorDiv);
                }
            }, 10000);
        }

        // Initialize map on page load
        document.addEventListener('DOMContentLoaded', function() {
            initDriverMap();
            initPassengerTrackingMaps();
            
            // Check availability status every 2 seconds
            setInterval(checkAvailabilityStatus, 2000);
            
            // Update passenger maps when driver location updates
            setInterval(updateAllPassengerMaps, 5000);
        });

        // Cleanup on page unload
        window.addEventListener('beforeunload', function() {
            stopLocationTracking();
        });
    </script>
    
    <!-- Include unlimited dashboard functionality -->
    <script src="../assets/js/driver-dashboard-unlimited.js"></script>
    
    <!-- Include unlimited real-time notification system -->
    <script src="notification_system_unlimited.php" defer></script>
    
    <!-- Include enhanced GPS tracking -->
    <script src="assets/js/gps-tracking.js"></script>
</body>
</html>
