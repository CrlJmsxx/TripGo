// TripGO GPS Tracking System
class GPSTracker {
    constructor() {
        this.watchId = null;
        this.currentPosition = null;
        this.isTracking = false;
        this.updateInterval = 5000; // 5 seconds
        this.accuracyThreshold = 100; // 100 meters
    }

    // Initialize GPS tracking
    init() {
        if (!navigator.geolocation) {
            console.error('Geolocation is not supported by this browser.');
            return false;
        }

        this.requestLocationPermission();
        return true;
    }

    // Request location permission
    requestLocationPermission() {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                console.log('Location permission granted');
                this.currentPosition = position;
                this.startTracking();
            },
            (error) => {
                console.error('Location permission denied:', error);
                this.showLocationError(error);
                // Try fallback method
                this.tryFallbackLocation();
            },
            {
                enableHighAccuracy: true,
                timeout: 20000,
                maximumAge: 0, // Don't use cached location
                desiredAccuracy: 10 // Target 10 meter accuracy
            }
        );
    }

    // Start GPS tracking
    startTracking() {
        if (this.isTracking) return;

        this.isTracking = true;
        this.watchId = navigator.geolocation.watchPosition(
            (position) => {
                this.updateLocation(position);
            },
            (error) => {
                console.error('GPS tracking error:', error);
                this.handleTrackingError(error);
            },
            {
                enableHighAccuracy: true,
                timeout: 20000,
                maximumAge: 5000, // Use only recent data
                desiredAccuracy: 10
            }
        );

        console.log('GPS tracking started');
    }

    // Stop GPS tracking
    stopTracking() {
        if (this.watchId) {
            navigator.geolocation.clearWatch(this.watchId);
            this.watchId = null;
        }
        this.isTracking = false;
        console.log('GPS tracking stopped');
    }

    // Update location
    updateLocation(position) {
        // Check accuracy before processing
        if (!this.checkAccuracy(position)) {
            return; // Skip low accuracy readings
        }

        const newPosition = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
            timestamp: new Date().toISOString(),
            speed: position.coords.speed || 0,
            heading: position.coords.heading || 0
        };

        // Check if position has changed significantly
        if (this.isSignificantChange(newPosition)) {
            this.currentPosition = newPosition;
            this.sendLocationUpdate(newPosition);
            this.updateUI(newPosition);
        }
    }

    // Check if position change is significant
    isSignificantChange(newPosition) {
        if (!this.currentPosition) return true;

        const distance = this.calculateDistance(
            this.currentPosition.latitude,
            this.currentPosition.longitude,
            newPosition.latitude,
            newPosition.longitude
        );

        return distance > 10; // 10 meters threshold
    }

    // Calculate distance between two points
    calculateDistance(lat1, lon1, lat2, lon2) {
        const R = 6371e3; // Earth's radius in meters
        const φ1 = lat1 * Math.PI / 180;
        const φ2 = lat2 * Math.PI / 180;
        const Δφ = (lat2 - lat1) * Math.PI / 180;
        const Δλ = (lon2 - lon1) * Math.PI / 180;

        const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
                Math.cos(φ1) * Math.cos(φ2) *
                Math.sin(Δλ/2) * Math.sin(Δλ/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

        return R * c;
    }

    // Send location update to server
    sendLocationUpdate(position) {
        // Send to server via AJAX
        fetch('api/update-location.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                latitude: position.latitude,
                longitude: position.longitude,
                accuracy: position.accuracy,
                timestamp: position.timestamp,
                speed: position.speed,
                heading: position.heading
            })
        })
        .then(response => response.json())
        .then(data => {
            console.log('Location updated:', data);
        })
        .catch(error => {
            console.error('Error updating location:', error);
        });
    }

    // Update UI with current location
    updateUI(position) {
        const locationElement = document.getElementById('current-location');
        if (locationElement) {
            locationElement.innerHTML = `
                <div class="location-info">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>Lat: ${position.latitude.toFixed(6)}</span>
                    <span>Lng: ${position.longitude.toFixed(6)}</span>
                    <span>Accuracy: ${Math.round(position.accuracy)}m</span>
                </div>
            `;
        }

        // Update map if available
        this.updateMap(position);
    }

    // Update map with current location
    updateMap(position) {
        if (window.map && window.marker) {
            const latLng = new google.maps.LatLng(position.latitude, position.longitude);
            window.marker.setPosition(latLng);
            window.map.setCenter(latLng);
        }
    }

    // Handle tracking errors
    handleTrackingError(error) {
        let message = 'GPS tracking error: ';
        switch(error.code) {
            case error.PERMISSION_DENIED:
                message += 'Location access denied by user.';
                break;
            case error.POSITION_UNAVAILABLE:
                message += 'Location information unavailable.';
                break;
            case error.TIMEOUT:
                message += 'Location request timed out.';
                break;
            default:
                message += 'Unknown error occurred.';
                break;
        }
        
        console.error(message);
        this.showNotification(message, 'error');
    }

    // Show location error
    showLocationError(error) {
        const message = 'Location access is required for ride tracking. Please enable location services.';
        this.showNotification(message, 'warning');
    }

    // Show notification
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <i class="fas fa-${type === 'error' ? 'exclamation-circle' : type === 'warning' ? 'exclamation-triangle' : 'info-circle'}"></i>
            <span>${message}</span>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 5000);
    }

    // Get current position
    getCurrentPosition() {
        return this.currentPosition;
    }

    // Check if tracking is active
    isActive() {
        return this.isTracking;
    }

    // Try fallback location methods
    tryFallbackLocation() {
        console.log('Trying fallback location methods...');
        
        // Try IP-based geolocation as fallback
        fetch('https://ipapi.co/json/')
            .then(response => response.json())
            .then(data => {
                if (data.latitude && data.longitude) {
                    const fallbackPosition = {
                        coords: {
                            latitude: parseFloat(data.latitude),
                            longitude: parseFloat(data.longitude),
                            accuracy: 1000, // IP location is less accurate
                            speed: null,
                            heading: null
                        },
                        timestamp: Date.now()
                    };
                    
                    console.log('Using IP-based location as fallback');
                    this.currentPosition = fallbackPosition;
                    this.updateLocation(fallbackPosition);
                    this.showNotification('Using approximate location. Enable GPS for better accuracy.', 'warning');
                }
            })
            .catch(error => {
                console.error('Fallback location failed:', error);
                this.showNotification('Unable to determine your location. Please check your device GPS settings.', 'error');
            });
    }

    // Force fresh location reading
    forceFreshLocation() {
        console.log('Forcing fresh location reading...');
        
        // Clear any cached position
        this.currentPosition = null;
        
        // Use aggressive settings for fresh reading
        navigator.geolocation.getCurrentPosition(
            (position) => {
                console.log('Fresh location obtained:', position);
                this.updateLocation(position);
                this.showNotification('Location updated successfully!', 'success');
            },
            (error) => {
                console.error('Failed to get fresh location:', error);
                this.handleTrackingError(error);
            },
            {
                enableHighAccuracy: true,
                timeout: 30000, // Longer timeout for better accuracy
                maximumAge: 0, // Force fresh reading
                desiredAccuracy: 5 // Target 5 meter accuracy
            }
        );
    }

    // Enhanced tracking with multiple attempts
    startEnhancedTracking() {
        if (this.isTracking) return;

        console.log('Starting enhanced GPS tracking...');
        this.isTracking = true;
        let attemptCount = 0;
        const maxAttempts = 3;

        const attemptLocation = () => {
            if (!this.isTracking || attemptCount >= maxAttempts) {
                if (attemptCount >= maxAttempts) {
                    console.log('Max attempts reached, switching to normal tracking');
                    this.startTracking();
                }
                return;
            }

            attemptCount++;
            console.log(`Location attempt ${attemptCount}/${maxAttempts}`);

            navigator.geolocation.getCurrentPosition(
                (position) => {
                    console.log(`Attempt ${attemptCount} successful:`, position);
                    this.updateLocation(position);
                    
                    // If accuracy is good enough, switch to normal tracking
                    if (position.coords.accuracy <= 20) {
                        console.log('Good accuracy achieved, switching to normal tracking');
                        this.startTracking();
                        return;
                    }
                    
                    // Try again for better accuracy
                    setTimeout(attemptLocation, 2000);
                },
                (error) => {
                    console.error(`Attempt ${attemptCount} failed:`, error);
                    
                    if (attemptCount < maxAttempts) {
                        setTimeout(attemptLocation, 2000);
                    } else {
                        console.log('All attempts failed, using fallback');
                        this.tryFallbackLocation();
                    }
                },
                {
                    enableHighAccuracy: true,
                    timeout: 15000,
                    maximumAge: 0
                }
            );
        };

        attemptLocation();
    }

    // Enhanced accuracy check
    checkAccuracy(position) {
        const accuracy = position.coords.accuracy;
        
        if (accuracy > 100) {
            console.warn('Low accuracy detected:', accuracy + 'm');
            this.showNotification(`Location accuracy is low (${Math.round(accuracy)}m). Move to an open area for better accuracy.`, 'warning');
            return false;
        }
        
        return true;
    }
}

// Initialize GPS tracking when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.gpsTracker = new GPSTracker();
    
    // Auto-start tracking if on driver dashboard
    if (window.location.pathname.includes('driver/dashboard.php')) {
        console.log('Driver dashboard detected, starting enhanced GPS tracking');
        window.gpsTracker.startEnhancedTracking();
    }
    
    // Auto-start on booking page
    if (window.location.pathname.includes('passenger/booking.php')) {
        console.log('Booking page detected, initializing GPS');
        window.gpsTracker.init();
    }
});

// Export for use in other scripts
window.GPSTracker = GPSTracker;
