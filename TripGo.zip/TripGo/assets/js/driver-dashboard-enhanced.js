/**
 * Driver Dashboard Enhancement - Advanced Filtering & Map Visualization
 * Handles advanced ride request filtering and spatial visualization
 */

class EnhancedRequestManager {
    constructor() {
        this.currentRequests = [];
        this.mapManager = null;
        this.listManager = null;
        this.performanceManager = new PerformanceManager();
        this.isLoading = false;
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.initializeComponents();
        console.log('Enhanced Request Manager initialized');
    }

    setupEventListeners() {
        // Filter button
        document.getElementById('filterAllRequestsBtn')?.addEventListener('click', () => {
            this.loadAllRequests();
        });

        // Radius filter
        document.getElementById('applyRadiusFilter')?.addEventListener('click', () => {
            const radius = document.getElementById('maxRadius')?.value || 50;
            this.loadAllRequests(radius);
        });

        // Enter key on radius input
        document.getElementById('maxRadius')?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const radius = e.target.value || 50;
                this.loadAllRequests(radius);
            }
        });
    }

    initializeComponents() {
        this.mapManager = new EnhancedRequestMap();
        this.listManager = new RequestListManager();
    }

    async loadAllRequests(maxRadius = 50) {
        if (this.isLoading) return;

        // Check cache first
        const cachedData = this.performanceManager.getCachedRequests(maxRadius);
        if (cachedData) {
            this.handleRequestData(cachedData);
            return;
        }

        this.isLoading = true;
        this.showLoadingState();

        try {
            console.log('Fetching requests with radius:', maxRadius);
            const response = await fetch(`../api/get_all_requests.php?max_radius=${maxRadius}`, {
                method: 'GET',
                credentials: 'same-origin', // Important for sessions
                headers: {
                    'Accept': 'application/json',
                    'Cache-Control': 'no-cache'
                }
            });
            
            console.log('Response status:', response.status);
            console.log('Response headers:', response.headers);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const data = await response.json();
            console.log('Response data:', data);

            if (data.success) {
                // Cache the results
                this.performanceManager.setCachedRequests(maxRadius, data);
                this.handleRequestData(data);
            } else {
                this.showError(data.error || 'Failed to load requests');
            }
        } catch (error) {
            console.error('Error loading requests:', error);
            this.showError(`Network error: ${error.message}. Please try again.`);
        } finally {
            this.isLoading = false;
            this.hideLoadingState();
        }
    }

    handleRequestData(data) {
        this.currentRequests = data.requests;
        
        // Update both list and map simultaneously
        Promise.all([
            this.listManager.updateRequestList(data.requests),
            this.mapManager.updateMapMarkers(data.requests, data.driver_location)
        ]).then(() => {
            this.updateFilterStatus(data);
        }).catch(error => {
            console.error('Error updating UI:', error);
        });
    }

    updateFilterStatus(data) {
        const statusElement = document.getElementById('filterStatus');
        if (statusElement) {
            statusElement.innerHTML = `
                <span style="color: #28a745;">
                    <i class="fas fa-check-circle"></i> 
                    Found ${data.total_found} requests within ${data.max_radius}km
                </span>
            `;
        }
    }

    showLoadingState() {
        const filterBtn = document.getElementById('filterAllRequestsBtn');
        const statusElement = document.getElementById('filterStatus');
        
        if (filterBtn) {
            filterBtn.disabled = true;
            filterBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
        }
        
        if (statusElement) {
            statusElement.textContent = 'Searching for requests...';
        }
    }

    hideLoadingState() {
        const filterBtn = document.getElementById('filterAllRequestsBtn');
        
        if (filterBtn) {
            filterBtn.disabled = false;
            filterBtn.innerHTML = '<i class="fas fa-search"></i> Filter All Requests';
        }
    }

    showError(message) {
        const statusElement = document.getElementById('filterStatus');
        if (statusElement) {
            statusElement.innerHTML = `
                <span style="color: #dc3545;">
                    <i class="fas fa-exclamation-circle"></i> ${message}
                </span>
            `;
        }
    }

    async acceptRequest(bookingId) {
        try {
            const response = await fetch('dashboard.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `update_ride_status=1&booking_id=${bookingId}&status=accepted`
            });

            const data = await response.json();
            
            if (data.success) {
                // Remove the accepted request from the list
                this.currentRequests = this.currentRequests.filter(req => req.id !== bookingId);
                this.listManager.updateRequestList(this.currentRequests);
                this.mapManager.removeRequestMarker(bookingId);
                
                // Show success message
                this.showSuccessMessage('Request accepted successfully!');
                
                // Reload page to update active bookings
                setTimeout(() => window.location.reload(), 1500);
            } else {
                alert('Error: ' + (data.error || 'Failed to accept request'));
            }
        } catch (error) {
            console.error('Error accepting request:', error);
            alert('Network error. Please try again.');
        }
    }

    showSuccessMessage(message) {
        const statusElement = document.getElementById('filterStatus');
        if (statusElement) {
            statusElement.innerHTML = `
                <span style="color: #28a745;">
                    <i class="fas fa-check-circle"></i> ${message}
                </span>
            `;
        }
    }
}

/**
 * Enhanced Map Manager for Request Visualization
 */
class EnhancedRequestMap {
    constructor() {
        this.map = null;
        this.driverMarker = null;
        this.requestMarkers = new Map();
        this.currentBounds = null;
        this.init();
    }

    init() {
        // Wait for map to be initialized by existing script
        if (window.driverMap) {
            this.map = window.driverMap;
            this.setupDriverMarker();
        } else {
            // Fallback: initialize map if not already done
            setTimeout(() => this.init(), 1000);
        }
    }

    setupDriverMarker() {
        if (!this.map) return;

        // Driver marker should already exist, just reference it
        const driverMarkers = this.map._layers;
        Object.values(driverMarkers).forEach(marker => {
            if (marker.options && marker.options.className === 'driver-marker') {
                this.driverMarker = marker;
            }
        });
    }

    async updateMapMarkers(requests, driverLocation) {
        if (!this.map) return;

        // Clear existing request markers
        this.clearRequestMarkers();

        if (requests.length === 0) return;

        // Add new request markers
        requests.forEach(request => {
            const marker = this.createRequestMarker(request);
            marker.addTo(this.map);
            this.requestMarkers.set(request.id, marker);
        });

        // Adjust map bounds to show all requests
        this.adjustMapBounds(requests, driverLocation);
    }

    createRequestMarker(request) {
        const color = this.getDistanceColor(request.distance_km);
        
        const customIcon = L.divIcon({
            className: 'custom-request-marker',
            html: `<div style="
                background: ${color}; 
                width: 12px; 
                height: 12px; 
                border-radius: 50%; 
                border: 2px solid white;
                box-shadow: 0 2px 4px rgba(0,0,0,0.3);
            "></div>`,
            iconSize: [16, 16],
            iconAnchor: [8, 8]
        });

        const marker = L.marker([request.pickup_latitude, request.pickup_longitude], {
            icon: customIcon,
            title: `Request #${request.id} - ${request.distance_km}km`
        });

        // Add popup with request details
        marker.bindPopup(this.createPopupContent(request));

        // Add click event for modal
        marker.on('click', () => {
            window.requestManager.showRequestModal(request);
        });

        return marker;
    }

    getDistanceColor(distance) {
        if (distance < 5) return '#28a745'; // Green - very close
        if (distance < 15) return '#ffc107'; // Yellow - close
        if (distance < 30) return '#fd7e14'; // Orange - moderate
        return '#dc3545'; // Red - far
    }

    createPopupContent(request) {
        return `
            <div style="min-width: 200px;">
                <h4 style="margin: 0 0 8px 0; color: #333;">
                    <i class="fas fa-map-marker-alt"></i> Request #${request.id}
                </h4>
                <div style="font-size: 14px; line-height: 1.4;">
                    <div><strong>Passenger:</strong> ${request.passenger_name}</div>
                    <div><strong>Distance:</strong> <span style="background: #007bff; color: white; padding: 2px 6px; border-radius: 10px; font-size: 12px;">${request.distance_km} km</span></div>
                    <div><strong>Fare:</strong> ₱${request.estimated_fare.toFixed(2)}</div>
                    <div><strong>Pickup:</strong> ${request.pickup_address}</div>
                </div>
                <button onclick="window.requestManager.acceptRequest(${request.id})" 
                        style="margin-top: 8px; padding: 4px 12px; background: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer;">
                    <i class="fas fa-check"></i> Accept
                </button>
            </div>
        `;
    }

    adjustMapBounds(requests, driverLocation) {
        if (!this.map || requests.length === 0) return;

        const bounds = L.latLngBounds();
        
        // Add driver location
        bounds.extend([driverLocation.latitude, driverLocation.longitude]);
        
        // Add all request locations
        requests.forEach(request => {
            bounds.extend([request.pickup_latitude, request.pickup_longitude]);
        });

        // Fit map to bounds with padding
        this.map.fitBounds(bounds, {
            padding: [50, 50],
            maxZoom: 15
        });
    }

    clearRequestMarkers() {
        this.requestMarkers.forEach(marker => {
            this.map.removeLayer(marker);
        });
        this.requestMarkers.clear();
    }

    removeRequestMarker(bookingId) {
        const marker = this.requestMarkers.get(bookingId);
        if (marker) {
            this.map.removeLayer(marker);
            this.requestMarkers.delete(bookingId);
        }
    }
}

/**
 * Request List Manager for Enhanced List View
 */
class RequestListManager {
    constructor() {
        this.container = document.getElementById('enhancedRequestList');
        this.createContainerIfNotExists();
    }

    createContainerIfNotExists() {
        if (!this.container) {
            const container = document.createElement('div');
            container.id = 'enhancedRequestList';
            container.className = 'request-list-container';
            
            // Insert after the existing pending bookings section
            const pendingSection = document.querySelector('.card:has("h3:contains(\'Pending Ride Requests\')")');
            if (pendingSection) {
                pendingSection.parentNode.insertBefore(container, pendingSection.nextSibling);
            } else {
                // Fallback: add to main container
                const mainContainer = document.querySelector('.container');
                if (mainContainer) {
                    mainContainer.appendChild(container);
                }
            }
            
            this.container = container;
        }
    }

    async updateRequestList(requests) {
        if (!this.container) return;

        if (requests.length === 0) {
            this.container.innerHTML = `
                <div class="no-requests" style="
                    text-align: center; 
                    padding: 40px; 
                    color: #666; 
                    background: #f8f9fa; 
                    border-radius: 8px; 
                    margin: 20px 0;
                ">
                    <i class="fas fa-search" style="font-size: 48px; margin-bottom: 16px; color: #ddd;"></i>
                    <p style="margin: 0;">No requests found within the specified radius.</p>
                </div>
            `;
            return;
        }

        const html = requests.map(request => this.createRequestItem(request)).join('');
        this.container.innerHTML = html;
        
        // Add event listeners
        this.attachEventListeners();
    }

    createRequestItem(request) {
        return `
            <div class="request-item-enhanced" data-request-id="${request.id}" style="
                background: white; 
                border: 1px solid #ddd; 
                border-radius: 8px; 
                padding: 15px; 
                margin-bottom: 12px; 
                display: flex; 
                justify-content: space-between; 
                align-items: center; 
                transition: all 0.2s ease;
            ">
                <div class="request-details" style="flex: 1;">
                    <div class="request-header" style="
                        display: flex; 
                        justify-content: space-between; 
                        align-items: center; 
                        margin-bottom: 8px;
                    ">
                        <strong style="font-size: 16px; color: #333;">${request.passenger_name}</strong>
                        <span class="distance-badge" style="
                            background: #007bff; 
                            color: white; 
                            padding: 4px 8px; 
                            border-radius: 12px; 
                            font-size: 12px; 
                            font-weight: bold;
                        ">${request.distance_km} km</span>
                    </div>
                    <div class="request-route" style="margin-bottom: 8px;">
                        <div class="route-point" style="display: flex; align-items: center; margin-bottom: 4px; font-size: 14px;">
                            <i class="fas fa-map-marker-alt" style="color: #28a745; margin-right: 8px;"></i>
                            ${request.pickup_address}
                        </div>
                        <div class="route-point" style="display: flex; align-items: center; font-size: 14px;">
                            <i class="fas fa-flag-checkered" style="color: #dc3545; margin-right: 8px;"></i>
                            ${request.dropoff_address}
                        </div>
                    </div>
                    <div class="request-meta" style="
                        display: flex; 
                        gap: 15px; 
                        font-size: 13px; 
                        color: #666;
                    ">
                        <span><i class="fas fa-dollar-sign"></i> ₱${request.estimated_fare.toFixed(2)}</span>
                        <span><i class="fas fa-clock"></i> ${this.formatTime(request.booking_time)}</span>
                    </div>
                </div>
                <div class="request-actions" style="
                    display: flex; 
                    gap: 8px; 
                    margin-left: 15px;
                ">
                    <button class="btn btn-primary btn-sm accept-btn" data-booking-id="${request.id}" style="
                        padding: 6px 12px; 
                        font-size: 13px;
                    ">
                        <i class="fas fa-check"></i> Accept
                    </button>
                    <button class="btn btn-outline btn-sm view-btn" data-request-id="${request.id}" style="
                        padding: 6px 12px; 
                        font-size: 13px;
                        background: white; 
                        border: 1px solid #ddd;
                    ">
                        <i class="fas fa-eye"></i> View
                    </button>
                </div>
            </div>
        `;
    }

    attachEventListeners() {
        // Accept buttons
        this.container.querySelectorAll('.accept-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const bookingId = e.target.dataset.bookingId;
                window.requestManager.acceptRequest(bookingId);
            });
        });

        // View buttons
        this.container.querySelectorAll('.view-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const requestId = e.target.dataset.requestId;
                const request = window.requestManager.currentRequests.find(r => r.id == requestId);
                if (request) {
                    window.requestManager.showRequestModal(request);
                }
            });
        });

        // Hover effects
        this.container.querySelectorAll('.request-item-enhanced').forEach(item => {
            item.addEventListener('mouseenter', () => {
                item.style.boxShadow = '0 4px 12px rgba(0,0,0,0.1)';
                item.style.transform = 'translateY(-2px)';
            });
            
            item.addEventListener('mouseleave', () => {
                item.style.boxShadow = '';
                item.style.transform = '';
            });
        });
    }

    formatTime(bookingTime) {
        const date = new Date(bookingTime);
        const now = new Date();
        const diff = now - date;
        
        if (diff < 60000) return 'Just now';
        if (diff < 3600000) return `${Math.floor(diff / 60000)} min ago`;
        if (diff < 86400000) return `${Math.floor(diff / 3600000)} hours ago`;
        return date.toLocaleDateString();
    }
}

/**
 * Performance Manager for Caching and Optimization
 */
class PerformanceManager {
    constructor() {
        this.requestCache = new Map();
        this.cacheTimeout = 30000; // 30 seconds
    }

    getCachedRequests(maxRadius) {
        const cacheKey = `requests_${maxRadius}`;
        const cached = this.requestCache.get(cacheKey);
        
        if (cached && (Date.now() - cached.timestamp) < this.cacheTimeout) {
            return cached.data;
        }
        
        return null;
    }

    setCachedRequests(maxRadius, data) {
        const cacheKey = `requests_${maxRadius}`;
        this.requestCache.set(cacheKey, {
            data: data,
            timestamp: Date.now()
        });
    }

    clearCache() {
        this.requestCache.clear();
    }
}

// Modal functionality for request details
EnhancedRequestManager.prototype.showRequestModal = function(request) {
    // Remove existing modal
    const existingModal = document.getElementById('requestModal');
    if (existingModal) {
        existingModal.remove();
    }
    
    // Create modal element
    const modal = document.createElement('div');
    modal.id = 'requestModal';
    modal.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: white;
        border-radius: 8px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.15);
        border: 1px solid #ddd;
        max-width: 400px;
        z-index: 1000;
        max-height: 80vh;
        overflow-y: auto;
    `;
    
    modal.innerHTML = `
        <div style="padding: 0;">
            <div style="
                background: #007bff; 
                color: white; 
                padding: 12px 16px; 
                border-radius: 8px 8px 0 0; 
                display: flex; 
                justify-content: space-between; 
                align-items: center;
            ">
                <h4 style="margin: 0; font-size: 16px;">
                    <i class="fas fa-map-marker-alt"></i> Ride Request #${request.id}
                </h4>
                <button class="close-modal" style="
                    background: none; 
                    border: none; 
                    color: white; 
                    font-size: 20px; 
                    cursor: pointer; 
                    padding: 0; 
                    width: 24px; 
                    height: 24px;
                ">&times;</button>
            </div>
            <div style="padding: 16px;">
                <div style="margin-bottom: 16px;">
                    <div style="margin-bottom: 8px; font-size: 14px;">
                        <strong>Passenger:</strong> ${request.passenger_name}
                    </div>
                    <div style="margin-bottom: 8px; font-size: 14px;">
                        <strong>Distance:</strong> <span style="background: #007bff; color: white; padding: 2px 6px; border-radius: 10px; font-size: 12px;">${request.distance_km} km</span>
                    </div>
                    <div style="margin-bottom: 8px; font-size: 14px;">
                        <strong>Pickup:</strong> ${request.pickup_address}
                    </div>
                    <div style="margin-bottom: 8px; font-size: 14px;">
                        <strong>Destination:</strong> ${request.dropoff_address}
                    </div>
                    <div style="margin-bottom: 8px; font-size: 14px;">
                        <strong>Estimated Fare:</strong> ₱${request.estimated_fare.toFixed(2)}
                    </div>
                    <div style="margin-bottom: 8px; font-size: 14px;">
                        <strong>Posted:</strong> ${this.formatTime(request.booking_time)}
                    </div>
                </div>
                <div style="display: flex; gap: 8px;">
                    <button class="accept-request-btn" data-booking-id="${request.id}" style="
                        flex: 1; 
                        padding: 8px 16px; 
                        background: #28a745; 
                        color: white; 
                        border: none; 
                        border-radius: 4px; 
                        cursor: pointer;
                    ">
                        <i class="fas fa-check"></i> Accept Request
                    </button>
                    <button class="close-modal" style="
                        padding: 8px 16px; 
                        background: #6c757d; 
                        color: white; 
                        border: none; 
                        border-radius: 4px; 
                        cursor: pointer;
                    ">
                        <i class="fas fa-times"></i> Close
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Add event listeners
    modal.querySelector('.accept-request-btn').addEventListener('click', () => {
        this.acceptRequest(request.id);
        modal.remove();
    });
    
    modal.querySelectorAll('.close-modal').forEach(btn => {
        btn.addEventListener('click', () => modal.remove());
    });
    
    // Close on outside click
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.remove();
        }
    });
};

// Helper method for time formatting
EnhancedRequestManager.prototype.formatTime = RequestListManager.prototype.formatTime;

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    // Wait a bit for existing scripts to load
    setTimeout(() => {
        window.requestManager = new EnhancedRequestManager();
        console.log('Driver Dashboard Enhanced loaded');
    }, 1000);
});
