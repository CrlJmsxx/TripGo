/**
 * Driver Dashboard Enhancement - UNLIMITED RANGE VERSION
 * Shows ALL ride requests regardless of distance with distance information
 */

class EnhancedRequestManagerUnlimited {
    constructor() {
        this.currentRequests = [];
        this.mapManager = null;
        this.listManager = null;
        this.isLoading = false;
        this.isInitialized = false;
        this.distanceFilter = null; // Optional distance filter
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.initializeComponents();
        this.isInitialized = true;
        console.log('Enhanced Request Manager (Unlimited) initialized');
    }

    setupEventListeners() {
        // Filter button - now shows ALL requests
        const filterBtn = document.getElementById('filterAllRequestsBtn');
        if (filterBtn) {
            filterBtn.addEventListener('click', () => {
                this.loadAllRequests();
            });
        }

        // Nearby button - now shows ALL requests with distance info
        const nearbyBtn = document.getElementById('showNearbyRequests');
        if (nearbyBtn) {
            nearbyBtn.addEventListener('click', () => {
                this.loadAllRequests();
            });
        }

        // Optional radius filter
        const applyBtn = document.getElementById('applyRadiusFilter');
        if (applyBtn) {
            applyBtn.addEventListener('click', () => {
                const radius = document.getElementById('maxRadius')?.value || null;
                this.distanceFilter = radius ? parseFloat(radius) : null;
                this.loadAllRequests();
            });
        }

        // Clear radius filter
        const clearBtn = document.getElementById('clearRadiusFilter');
        if (!clearBtn) {
            // Add clear button if it doesn't exist
            const filterOptions = document.querySelector('.filter-options');
            if (filterOptions) {
                const clearBtn = document.createElement('button');
                clearBtn.id = 'clearRadiusFilter';
                clearBtn.className = 'btn btn-secondary';
                clearBtn.style.marginLeft = '8px';
                clearBtn.innerHTML = '<i class="fas fa-times"></i> Clear Filter';
                clearBtn.addEventListener('click', () => {
                    this.distanceFilter = null;
                    document.getElementById('maxRadius').value = '';
                    this.loadAllRequests();
                });
                filterOptions.appendChild(clearBtn);
            }
        }

        // Enter key on radius input
        const radiusInput = document.getElementById('maxRadius');
        if (radiusInput) {
            radiusInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    const radius = e.target.value || null;
                    this.distanceFilter = radius ? parseFloat(radius) : null;
                    this.loadAllRequests();
                }
            });
        }
    }

    initializeComponents() {
        // Initialize components if they exist
        if (typeof EnhancedRequestMap !== 'undefined') {
            this.mapManager = new EnhancedRequestMap();
        }
        if (typeof RequestListManager !== 'undefined') {
            this.listManager = new RequestListManager();
        }
    }

    async loadAllRequests(maxRadius = null) {
        if (this.isLoading) return;
        
        this.isLoading = true;
        this.showLoadingState();

        try {
            // Use unlimited API endpoint
            const response = await fetch(`../api/get_all_requests_unlimited.php`);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            
            if (!data.success) {
                throw new Error(data.error || 'Unknown error occurred');
            }

            this.currentRequests = data.requests;
            this.handleRequestData(data);
            
            // Update filter status
            this.updateFilterStatus(data);
            
        } catch (error) {
            console.error('Error loading requests:', error);
            this.showError('Failed to load ride requests: ' + error.message);
        } finally {
            this.isLoading = false;
            this.hideLoadingState();
        }
    }

    handleRequestData(data) {
        // Apply optional distance filter if set
        let filteredRequests = data.requests;
        
        if (this.distanceFilter !== null) {
            filteredRequests = data.requests.filter(request => 
                request.distance_km <= this.distanceFilter
            );
        }

        // Update both list and map simultaneously
        Promise.all([
            this.updateRequestList(filteredRequests),
            this.updateMapMarkers(filteredRequests, data.driver_location)
        ]).then(() => {
            console.log(`Displayed ${filteredRequests.length} of ${data.requests.length} total requests`);
        }).catch(error => {
            console.error('Error updating UI:', error);
        });
    }

    updateRequestList(requests) {
        const listContainer = document.getElementById('requestList');
        if (!listContainer) return;

        if (requests.length === 0) {
            listContainer.innerHTML = `
                <div class="no-requests" style="text-align: center; padding: 40px; color: #666;">
                    <i class="fas fa-search" style="font-size: 48px; margin-bottom: 16px; opacity: 0.5;"></i>
                    <h3>No ride requests found</h3>
                    <p>No active ride requests at the moment. Check back soon!</p>
                </div>
            `;
            return;
        }

        // Group requests by distance category
        const grouped = {
            nearby: requests.filter(r => r.distance_km <= 20),
            medium: requests.filter(r => r.distance_km > 20 && r.distance_km <= 50),
            far: requests.filter(r => r.distance_km > 50 && r.distance_km <= 100),
            very_far: requests.filter(r => r.distance_km > 100)
        };

        let html = '';
        
        // Add distance category headers
        const categories = [
            { key: 'nearby', label: 'Nearby (≤ 20km)', color: '#28a745' },
            { key: 'medium', label: 'Medium Distance (20-50km)', color: '#ffc107' },
            { key: 'far', label: 'Far (50-100km)', color: '#fd7e14' },
            { key: 'very_far', label: 'Very Far (> 100km)', color: '#dc3545' }
        ];

        categories.forEach(category => {
            if (grouped[category.key].length > 0) {
                html += `
                    <div class="distance-category" style="margin-bottom: 20px;">
                        <h4 style="color: ${category.color}; border-bottom: 2px solid ${category.color}; padding-bottom: 8px;">
                            ${category.label} (${grouped[category.key].length})
                        </h4>
                        <div class="request-list">
                `;
                
                grouped[category.key].forEach(request => {
                    html += this.createRequestCard(request, category.key);
                });
                
                html += `
                        </div>
                    </div>
                `;
            }
        });

        listContainer.innerHTML = html;
        this.attachRequestEventListeners();
    }

    createRequestCard(request, distanceCategory) {
        const distanceColor = this.getDistanceColor(request.distance_km);
        const fareColor = '#28a745';
        
        return `
            <div class="request-card" data-request-id="${request.id}" style="
                border: 1px solid #ddd; 
                border-radius: 8px; 
                padding: 16px; 
                margin-bottom: 12px; 
                background: white;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                transition: transform 0.2s, box-shadow 0.2s;
            ">
                <div class="request-header" style="display: flex; justify-content: between; align-items: center; margin-bottom: 12px;">
                    <div style="flex: 1;">
                        <h5 style="margin: 0; color: #333;">${request.passenger_name}</h5>
                        <div style="display: flex; gap: 12px; align-items: center; margin-top: 4px;">
                            <span style="color: ${distanceColor}; font-weight: bold; font-size: 14px;">
                                <i class="fas fa-route"></i> ${request.distance_km} km
                            </span>
                            <span style="color: ${fareColor}; font-weight: bold; font-size: 14px;">
                                <i class="fas fa-peso-sign"></i> ${request.estimated_fare.toFixed(2)}
                            </span>
                        </div>
                    </div>
                    <div class="request-actions" style="display: flex; gap: 8px;">
                        <button class="btn btn-success btn-sm accept-request" data-request-id="${request.id}">
                            <i class="fas fa-check"></i> Accept
                        </button>
                        <button class="btn btn-outline-secondary btn-sm view-details" data-request-id="${request.id}">
                            <i class="fas fa-info-circle"></i> Details
                        </button>
                    </div>
                </div>
                
                <div class="request-details">
                    <div style="margin-bottom: 8px;">
                        <strong style="color: #666;">Pickup:</strong> 
                        <span style="color: #333;">${request.pickup_address}</span>
                    </div>
                    ${request.dropoff_address ? `
                        <div style="margin-bottom: 8px;">
                            <strong style="color: #666;">Dropoff:</strong> 
                            <span style="color: #333;">${request.dropoff_address}</span>
                        </div>
                    ` : ''}
                    <div style="font-size: 12px; color: #999;">
                        <i class="fas fa-clock"></i> ${new Date(request.booking_time).toLocaleString()}
                    </div>
                </div>
            </div>
        `;
    }

    getDistanceColor(distance) {
        if (distance <= 20) return '#28a745';      // Green - nearby
        if (distance <= 50) return '#ffc107';      // Yellow - medium
        if (distance <= 100) return '#fd7e14';     // Orange - far
        return '#dc3545';                          // Red - very far
    }

    updateMapMarkers(requests, driverLocation) {
        if (!this.mapManager) return;

        // Update map with all requests
        this.mapManager.updateMapMarkers(requests, driverLocation);
        
        // Update map bounds to show all requests
        if (requests.length > 0 && driverLocation) {
            const bounds = this.calculateBounds(requests, driverLocation);
            this.mapManager.map.fitBounds(bounds, { padding: [50, 50] });
        }
    }

    calculateBounds(requests, driverLocation) {
        if (typeof L === 'undefined') return null;
        
        const bounds = L.latLngBounds();
        
        // Add driver location
        if (driverLocation && driverLocation.latitude && driverLocation.longitude) {
            bounds.extend([driverLocation.latitude, driverLocation.longitude]);
        }
        
        // Add all request locations
        requests.forEach(request => {
            if (request.pickup_latitude && request.pickup_longitude) {
                bounds.extend([request.pickup_latitude, request.pickup_longitude]);
            }
        });
        
        return bounds;
    }

    updateFilterStatus(data) {
        const statusElement = document.getElementById('filterStatus');
        if (!statusElement) return;

        const total = data.stats.total_requests;
        const nearby = data.stats.nearby_requests;
        const medium = data.stats.medium_requests;
        const far = data.stats.far_requests;
        const veryFar = data.stats.very_far_requests;

        let statusText = `Found ${total} requests total`;
        
        if (this.distanceFilter !== null) {
            const filtered = data.requests.filter(r => r.distance_km <= this.distanceFilter).length;
            statusText += ` (${filtered} within ${this.distanceFilter}km)`;
        }
        
        statusText += ` - Nearby: ${nearby}, Medium: ${medium}, Far: ${far}, Very Far: ${veryFar}`;
        
        statusElement.innerHTML = statusText;
        statusElement.style.color = '#666';
        statusElement.style.fontSize = '14px';
    }

    attachRequestEventListeners() {
        // Accept request buttons
        document.querySelectorAll('.accept-request').forEach(button => {
            button.addEventListener('click', (e) => {
                const requestId = e.target.closest('.accept-request').dataset.requestId;
                this.acceptRequest(requestId);
            });
        });

        // View details buttons
        document.querySelectorAll('.view-details').forEach(button => {
            button.addEventListener('click', (e) => {
                const requestId = e.target.closest('.view-details').dataset.requestId;
                this.viewRequestDetails(requestId);
            });
        });

        // Add hover effects to request cards
        document.querySelectorAll('.request-card').forEach(card => {
            card.addEventListener('mouseenter', () => {
                card.style.transform = 'translateY(-2px)';
                card.style.boxShadow = '0 4px 8px rgba(0,0,0,0.15)';
            });
            
            card.addEventListener('mouseleave', () => {
                card.style.transform = 'translateY(0)';
                card.style.boxShadow = '0 2px 4px rgba(0,0,0,0.1)';
            });
        });
    }

    acceptRequest(requestId) {
        if (confirm('Are you sure you want to accept this ride request?')) {
            // Redirect to accept request page
            window.location.href = `accept_request.php?id=${requestId}`;
        }
    }

    viewRequestDetails(requestId) {
        const request = this.currentRequests.find(r => r.id == requestId);
        if (!request) return;

        // Show detailed modal or redirect
        const details = `
            Passenger: ${request.passenger_name}
            Phone: ${request.passenger_phone}
            Pickup: ${request.pickup_address}
            Dropoff: ${request.dropoff_address || 'Not specified'}
            Distance: ${request.distance_km} km
            Fare: ₱${request.estimated_fare.toFixed(2)}
            Time: ${new Date(request.booking_time).toLocaleString()}
        `;
        
        alert(details);
    }

    showLoadingState() {
        const statusElement = document.getElementById('filterStatus');
        if (statusElement) {
            statusElement.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading requests...';
            statusElement.style.color = '#007bff';
        }
    }

    hideLoadingState() {
        // Loading state is hidden when results are shown
    }

    showError(message) {
        const statusElement = document.getElementById('filterStatus');
        if (statusElement) {
            statusElement.innerHTML = `<i class="fas fa-exclamation-triangle"></i> ${message}`;
            statusElement.style.color = '#dc3545';
        }
    }
}

// Initialize the unlimited request manager when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    window.requestManagerUnlimited = new EnhancedRequestManagerUnlimited();
    console.log('Driver dashboard (unlimited) loaded');
});

// Make acceptRequest function globally available
function acceptRequest(requestId) {
    if (window.requestManagerUnlimited) {
        window.requestManagerUnlimited.acceptRequest(requestId);
    }
}
