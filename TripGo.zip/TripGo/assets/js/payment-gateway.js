// TripGO Payment Gateway Integration
class PaymentGateway {
    constructor() {
        this.stripePublicKey = 'pk_test_your_stripe_public_key'; // Replace with actual key
        this.paypalClientId = 'your_paypal_client_id'; // Replace with actual ID
        this.currentBooking = null;
        this.paymentMethods = ['cash', 'card', 'paypal'];
    }

    // Initialize payment gateway
    init() {
        this.loadStripe();
        this.loadPayPal();
        this.setupEventListeners();
    }

    // Load Stripe.js
    loadStripe() {
        if (typeof Stripe === 'undefined') {
            const script = document.createElement('script');
            script.src = 'https://js.stripe.com/v3/';
            script.onload = () => {
                this.stripe = Stripe(this.stripePublicKey);
                console.log('Stripe loaded');
            };
            document.head.appendChild(script);
        }
    }

    // Load PayPal SDK
    loadPayPal() {
        if (typeof paypal === 'undefined') {
            const script = document.createElement('script');
            script.src = 'https://www.paypal.com/sdk/js?client-id=' + this.paypalClientId + '&currency=USD';
            script.onload = () => {
                console.log('PayPal loaded');
            };
            document.head.appendChild(script);
        }
    }

    // Setup event listeners
    setupEventListeners() {
        // Payment method selection
        document.addEventListener('change', (e) => {
            if (e.target.name === 'payment_method') {
                this.handlePaymentMethodChange(e.target.value);
            }
        });

        // Payment form submission
        document.addEventListener('submit', (e) => {
            if (e.target.id === 'payment-form') {
                e.preventDefault();
                this.processPayment(e.target);
            }
        });
    }

    // Handle payment method change
    handlePaymentMethodChange(method) {
        const cardSection = document.getElementById('card-payment');
        const paypalSection = document.getElementById('paypal-payment');
        const cashSection = document.getElementById('cash-payment');

        // Hide all payment sections
        [cardSection, paypalSection, cashSection].forEach(section => {
            if (section) section.style.display = 'none';
        });

        // Show selected payment method
        switch (method) {
            case 'card':
                if (cardSection) cardSection.style.display = 'block';
                this.initializeCardPayment();
                break;
            case 'paypal':
                if (paypalSection) paypalSection.style.display = 'block';
                this.initializePayPalPayment();
                break;
            case 'cash':
                if (cashSection) cashSection.style.display = 'block';
                break;
        }
    }

    // Initialize card payment
    initializeCardPayment() {
        if (!this.stripe) {
            console.error('Stripe not loaded');
            return;
        }

        const elements = this.stripe.elements();
        const cardElement = elements.create('card', {
            style: {
                base: {
                    fontSize: '16px',
                    color: '#424770',
                    '::placeholder': {
                        color: '#aab7c4',
                    },
                },
            },
        });

        cardElement.mount('#card-element');

        // Handle real-time validation errors
        cardElement.on('change', (event) => {
            const displayError = document.getElementById('card-errors');
            if (event.error) {
                displayError.textContent = event.error.message;
            } else {
                displayError.textContent = '';
            }
        });

        this.cardElement = cardElement;
    }

    // Initialize PayPal payment
    initializePayPalPayment() {
        if (typeof paypal === 'undefined') {
            console.error('PayPal not loaded');
            return;
        }

        const paypalContainer = document.getElementById('paypal-button-container');
        if (!paypalContainer) return;

        paypal.Buttons({
            createOrder: (data, actions) => {
                return actions.order.create({
                    purchase_units: [{
                        amount: {
                            value: this.currentBooking?.estimated_fare || '0.00'
                        }
                    }]
                });
            },
            onApprove: (data, actions) => {
                return actions.order.capture().then((details) => {
                    this.handlePayPalSuccess(details);
                });
            },
            onError: (err) => {
                this.handlePaymentError('PayPal payment failed: ' + err.message);
            }
        }).render('#paypal-button-container');
    }

    // Process payment
    async processPayment(form) {
        const paymentMethod = form.payment_method.value;
        const bookingId = form.booking_id.value;
        const amount = form.amount.value;

        this.currentBooking = { id: bookingId, amount: amount };

        try {
            switch (paymentMethod) {
                case 'card':
                    await this.processCardPayment(amount);
                    break;
                case 'paypal':
                    // PayPal is handled by the button
                    break;
                case 'cash':
                    await this.processCashPayment(bookingId);
                    break;
                default:
                    throw new Error('Invalid payment method');
            }
        } catch (error) {
            this.handlePaymentError(error.message);
        }
    }

    // Process card payment
    async processCardPayment(amount) {
        if (!this.stripe || !this.cardElement) {
            throw new Error('Stripe not initialized');
        }

        const { token, error } = await this.stripe.createToken(this.cardElement);

        if (error) {
            throw new Error(error.message);
        }

        // Send token to server
        const response = await fetch('api/process-payment.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                payment_method: 'card',
                token: token.id,
                amount: amount,
                booking_id: this.currentBooking.id
            })
        });

        const result = await response.json();

        if (!result.success) {
            throw new Error(result.message);
        }

        this.handlePaymentSuccess(result);
    }

    // Process cash payment
    async processCashPayment(bookingId) {
        const response = await fetch('api/process-payment.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                payment_method: 'cash',
                booking_id: bookingId
            })
        });

        const result = await response.json();

        if (!result.success) {
            throw new Error(result.message);
        }

        this.handlePaymentSuccess(result);
    }

    // Handle PayPal success
    handlePayPalSuccess(details) {
        console.log('PayPal payment successful:', details);
        this.handlePaymentSuccess({
            transaction_id: details.id,
            payment_method: 'paypal',
            amount: this.currentBooking.amount
        });
    }

    // Handle payment success
    handlePaymentSuccess(result) {
        // Show success message
        this.showNotification('Payment successful!', 'success');
        
        // Update booking status
        this.updateBookingStatus(this.currentBooking.id, 'paid');
        
        // Redirect or update UI
        setTimeout(() => {
            window.location.href = 'dashboard.php';
        }, 2000);
    }

    // Handle payment error
    handlePaymentError(message) {
        console.error('Payment error:', message);
        this.showNotification('Payment failed: ' + message, 'error');
    }

    // Update booking status
    async updateBookingStatus(bookingId, status) {
        try {
            const response = await fetch('api/update-booking.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    booking_id: bookingId,
                    status: status
                })
            });

            const result = await response.json();
            return result.success;
        } catch (error) {
            console.error('Error updating booking:', error);
            return false;
        }
    }

    // Show notification
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
            <span>${message}</span>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 5000);
    }

    // Get payment methods
    getPaymentMethods() {
        return this.paymentMethods;
    }

    // Set booking data
    setBooking(booking) {
        this.currentBooking = booking;
    }
}

// Initialize payment gateway when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.paymentGateway = new PaymentGateway();
    window.paymentGateway.init();
});

// Export for use in other scripts
window.PaymentGateway = PaymentGateway;
