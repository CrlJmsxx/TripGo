// TripGO Push Notifications System
class PushNotificationManager {
    constructor() {
        this.isSupported = 'Notification' in window;
        this.permission = Notification.permission;
        this.registration = null;
        this.isSubscribed = false;
    }

    // Initialize push notifications
    async init() {
        if (!this.isSupported) {
            console.log('Push notifications not supported');
            return false;
        }

        // Register service worker
        try {
            this.registration = await navigator.serviceWorker.register('/sw.js');
            console.log('Service Worker registered');
        } catch (error) {
            console.error('Service Worker registration failed:', error);
            return false;
        }

        // Check if already subscribed
        const subscription = await this.registration.pushManager.getSubscription();
        this.isSubscribed = !!subscription;

        return true;
    }

    // Request notification permission
    async requestPermission() {
        if (!this.isSupported) {
            return false;
        }

        if (this.permission === 'granted') {
            return true;
        }

        if (this.permission === 'denied') {
            this.showPermissionDeniedMessage();
            return false;
        }

        try {
            this.permission = await Notification.requestPermission();
            return this.permission === 'granted';
        } catch (error) {
            console.error('Error requesting permission:', error);
            return false;
        }
    }

    // Subscribe to push notifications
    async subscribe() {
        if (!this.registration) {
            console.error('Service Worker not registered');
            return false;
        }

        try {
            const subscription = await this.registration.pushManager.subscribe({
                userVisibleOnly: true,
                applicationServerKey: this.urlBase64ToUint8Array(
                    'BEl62iUYgUivxIkv69yViEuiBIa40HI8Yy4gV1L2g2Lgv7YJmT3uugWxKqxNoGFTz4W0Kz3KJ1l8j2K4m5n6o7p8q9r0s1t2u3v4w5x6y7z8'
                )
            });

            // Send subscription to server
            await this.sendSubscriptionToServer(subscription);
            
            this.isSubscribed = true;
            console.log('Successfully subscribed to push notifications');
            return true;
        } catch (error) {
            console.error('Error subscribing to push notifications:', error);
            return false;
        }
    }

    // Unsubscribe from push notifications
    async unsubscribe() {
        if (!this.registration) {
            return false;
        }

        try {
            const subscription = await this.registration.pushManager.getSubscription();
            if (subscription) {
                await subscription.unsubscribe();
                await this.removeSubscriptionFromServer(subscription);
                this.isSubscribed = false;
                console.log('Successfully unsubscribed from push notifications');
                return true;
            }
        } catch (error) {
            console.error('Error unsubscribing from push notifications:', error);
        }
        return false;
    }

    // Send subscription to server
    async sendSubscriptionToServer(subscription) {
        try {
            const response = await fetch('api/save-subscription.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    subscription: subscription.toJSON()
                })
            });

            const result = await response.json();
            if (!result.success) {
                throw new Error(result.message);
            }
        } catch (error) {
            console.error('Error saving subscription:', error);
            throw error;
        }
    }

    // Remove subscription from server
    async removeSubscriptionFromServer(subscription) {
        try {
            const response = await fetch('api/remove-subscription.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    endpoint: subscription.endpoint
                })
            });

            const result = await response.json();
            return result.success;
        } catch (error) {
            console.error('Error removing subscription:', error);
            return false;
        }
    }

    // Show local notification
    showNotification(title, options = {}) {
        if (!this.isSupported || this.permission !== 'granted') {
            return false;
        }

        const notification = new Notification(title, {
            icon: '/assets/icons/icon-192x192.png',
            badge: '/assets/icons/icon-72x72.png',
            ...options
        });

        // Handle notification click
        notification.onclick = () => {
            window.focus();
            notification.close();
        };

        // Auto-close after 5 seconds
        setTimeout(() => {
            notification.close();
        }, 5000);

        return notification;
    }

    // Send push notification to user
    async sendPushNotification(userId, title, body, data = {}) {
        try {
            const response = await fetch('api/send-notification.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    user_id: userId,
                    title: title,
                    body: body,
                    data: data
                })
            });

            const result = await response.json();
            return result.success;
        } catch (error) {
            console.error('Error sending push notification:', error);
            return false;
        }
    }

    // Show permission denied message
    showPermissionDeniedMessage() {
        const message = document.createElement('div');
        message.className = 'notification notification-warning';
        message.innerHTML = `
            <i class="fas fa-exclamation-triangle"></i>
            <span>Push notifications are blocked. Please enable them in your browser settings.</span>
        `;
        document.body.appendChild(message);
        
        setTimeout(() => {
            message.remove();
        }, 5000);
    }

    // Convert VAPID key
    urlBase64ToUint8Array(base64String) {
        const padding = '='.repeat((4 - base64String.length % 4) % 4);
        const base64 = (base64String + padding)
            .replace(/\-/g, '+')
            .replace(/_/g, '/');

        const rawData = window.atob(base64);
        const outputArray = new Uint8Array(rawData.length);

        for (let i = 0; i < rawData.length; ++i) {
            outputArray[i] = rawData.charCodeAt(i);
        }
        return outputArray;
    }

    // Get subscription status
    getSubscriptionStatus() {
        return {
            isSupported: this.isSupported,
            permission: this.permission,
            isSubscribed: this.isSubscribed
        };
    }

    // Setup notification handlers
    setupNotificationHandlers() {
        // Handle booking notifications
        document.addEventListener('bookingCreated', (event) => {
            this.showNotification('Booking Created', {
                body: 'Your ride has been booked successfully!',
                tag: 'booking-created'
            });
        });

        // Handle driver notifications
        document.addEventListener('driverAssigned', (event) => {
            this.showNotification('Driver Assigned', {
                body: 'A driver has been assigned to your ride!',
                tag: 'driver-assigned'
            });
        });

        // Handle ride status updates
        document.addEventListener('rideStatusUpdate', (event) => {
            const status = event.detail.status;
            let message = '';
            
            switch (status) {
                case 'accepted':
                    message = 'Your ride has been accepted!';
                    break;
                case 'in_progress':
                    message = 'Your ride is in progress!';
                    break;
                case 'completed':
                    message = 'Your ride has been completed!';
                    break;
            }
            
            if (message) {
                this.showNotification('Ride Update', {
                    body: message,
                    tag: 'ride-status'
                });
            }
        });
    }
}

// Initialize push notifications when DOM is loaded
document.addEventListener('DOMContentLoaded', async function() {
    window.pushNotificationManager = new PushNotificationManager();
    
    if (await window.pushNotificationManager.init()) {
        window.pushNotificationManager.setupNotificationHandlers();
        
        // Auto-subscribe if permission is granted
        if (window.pushNotificationManager.permission === 'granted') {
            await window.pushNotificationManager.subscribe();
        }
    }
});

// Export for use in other scripts
window.PushNotificationManager = PushNotificationManager;
