// TripGO Multi-Language Support System
class MultiLanguageManager {
    constructor() {
        this.currentLanguage = 'en';
        this.translations = {};
        this.supportedLanguages = ['en', 'es', 'fr', 'de', 'it', 'pt', 'zh', 'ja', 'ko', 'ar'];
        this.defaultLanguage = 'en';
    }

    // Initialize multi-language support
    async init() {
        // Get saved language preference
        this.currentLanguage = localStorage.getItem('tripgo-language') || this.detectBrowserLanguage();
        
        // Load translations
        await this.loadTranslations(this.currentLanguage);
        
        // Apply translations
        this.applyTranslations();
        
        // Setup language switcher
        this.setupLanguageSwitcher();
        
        console.log(`Multi-language initialized: ${this.currentLanguage}`);
    }

    // Detect browser language
    detectBrowserLanguage() {
        const browserLang = navigator.language || navigator.userLanguage;
        const langCode = browserLang.split('-')[0];
        
        return this.supportedLanguages.includes(langCode) ? langCode : this.defaultLanguage;
    }

    // Load translations for a language
    async loadTranslations(language) {
        try {
            const response = await fetch(`assets/translations/${language}.json`);
            if (response.ok) {
                this.translations = await response.json();
            } else {
                // Fallback to default language
                if (language !== this.defaultLanguage) {
                    await this.loadTranslations(this.defaultLanguage);
                }
            }
        } catch (error) {
            console.error('Error loading translations:', error);
            // Load default translations
            this.translations = await this.getDefaultTranslations();
        }
    }

    // Get default translations (fallback)
    async getDefaultTranslations() {
        return {
            'app.name': 'TripGO',
            'app.tagline': 'Your Ride, Your Way',
            'nav.home': 'Home',
            'nav.dashboard': 'Dashboard',
            'nav.book_ride': 'Book Ride',
            'nav.history': 'History',
            'nav.earnings': 'Earnings',
            'nav.analytics': 'Analytics',
            'nav.settings': 'Settings',
            'auth.login': 'Login',
            'auth.register': 'Register',
            'auth.logout': 'Logout',
            'auth.username': 'Username',
            'auth.password': 'Password',
            'auth.email': 'Email',
            'auth.full_name': 'Full Name',
            'auth.phone': 'Phone Number',
            'auth.confirm_password': 'Confirm Password',
            'booking.pickup_location': 'Pickup Location',
            'booking.dropoff_location': 'Dropoff Location',
            'booking.calculate_fare': 'Calculate Fare',
            'booking.book_ride': 'Book Ride',
            'booking.estimated_fare': 'Estimated Fare',
            'booking.distance': 'Distance',
            'booking.duration': 'Duration',
            'driver.status': 'Status',
            'driver.available': 'Available',
            'driver.offline': 'Offline',
            'driver.go_online': 'Go Online',
            'driver.go_offline': 'Go Offline',
            'driver.accept': 'Accept',
            'driver.reject': 'Reject',
            'driver.start_ride': 'Start Ride',
            'driver.complete_ride': 'Complete Ride',
            'passenger.book_ride': 'Book a Ride',
            'passenger.ride_history': 'Ride History',
            'passenger.total_rides': 'Total Rides',
            'passenger.completed_rides': 'Completed Rides',
            'passenger.total_spent': 'Total Spent',
            'admin.manage_users': 'Manage Users',
            'admin.verify_drivers': 'Verify Drivers',
            'admin.system_settings': 'System Settings',
            'admin.total_users': 'Total Users',
            'admin.total_drivers': 'Total Drivers',
            'admin.total_bookings': 'Total Bookings',
            'admin.total_revenue': 'Total Revenue',
            'status.pending': 'Pending',
            'status.accepted': 'Accepted',
            'status.in_progress': 'In Progress',
            'status.completed': 'Completed',
            'status.cancelled': 'Cancelled',
            'payment.cash': 'Cash',
            'payment.card': 'Card',
            'payment.paypal': 'PayPal',
            'payment.process_payment': 'Process Payment',
            'notification.booking_created': 'Booking Created',
            'notification.driver_assigned': 'Driver Assigned',
            'notification.ride_started': 'Ride Started',
            'notification.ride_completed': 'Ride Completed',
            'error.generic': 'An error occurred. Please try again.',
            'error.network': 'Network error. Please check your connection.',
            'error.permission_denied': 'Permission denied.',
            'success.booking_created': 'Booking created successfully!',
            'success.payment_processed': 'Payment processed successfully!',
            'success.profile_updated': 'Profile updated successfully!'
        };
    }

    // Apply translations to the page
    applyTranslations() {
        // Translate elements with data-translate attribute
        document.querySelectorAll('[data-translate]').forEach(element => {
            const key = element.getAttribute('data-translate');
            const translation = this.getTranslation(key);
            if (translation) {
                element.textContent = translation;
            }
        });

        // Translate elements with data-translate-placeholder attribute
        document.querySelectorAll('[data-translate-placeholder]').forEach(element => {
            const key = element.getAttribute('data-translate-placeholder');
            const translation = this.getTranslation(key);
            if (translation) {
                element.placeholder = translation;
            }
        });

        // Translate page title
        const titleKey = document.querySelector('meta[name="title-key"]');
        if (titleKey) {
            const title = this.getTranslation(titleKey.content);
            if (title) {
                document.title = title;
            }
        }
    }

    // Get translation for a key
    getTranslation(key) {
        return this.translations[key] || key;
    }

    // Change language
    async changeLanguage(language) {
        if (!this.supportedLanguages.includes(language)) {
            console.error('Unsupported language:', language);
            return false;
        }

        this.currentLanguage = language;
        localStorage.setItem('tripgo-language', language);
        
        // Load new translations
        await this.loadTranslations(language);
        
        // Apply translations
        this.applyTranslations();
        
        // Update language switcher
        this.updateLanguageSwitcher();
        
        // Trigger language change event
        document.dispatchEvent(new CustomEvent('languageChanged', {
            detail: { language: language }
        }));
        
        console.log(`Language changed to: ${language}`);
        return true;
    }

    // Setup language switcher
    setupLanguageSwitcher() {
        // Create language switcher if it doesn't exist
        let switcher = document.getElementById('language-switcher');
        if (!switcher) {
            switcher = document.createElement('div');
            switcher.id = 'language-switcher';
            switcher.className = 'language-switcher';
            switcher.innerHTML = `
                <select id="language-select">
                    <option value="en">English</option>
                    <option value="es">Español</option>
                    <option value="fr">Français</option>
                    <option value="de">Deutsch</option>
                    <option value="it">Italiano</option>
                    <option value="pt">Português</option>
                    <option value="zh">中文</option>
                    <option value="ja">日本語</option>
                    <option value="ko">한국어</option>
                    <option value="ar">العربية</option>
                </select>
            `;
            
            // Add to header
            const header = document.querySelector('.header-content');
            if (header) {
                header.appendChild(switcher);
            }
        }
        
        // Setup event listener
        const select = document.getElementById('language-select');
        if (select) {
            select.value = this.currentLanguage;
            select.addEventListener('change', (e) => {
                this.changeLanguage(e.target.value);
            });
        }
    }

    // Update language switcher
    updateLanguageSwitcher() {
        const select = document.getElementById('language-select');
        if (select) {
            select.value = this.currentLanguage;
        }
    }

    // Get current language
    getCurrentLanguage() {
        return this.currentLanguage;
    }

    // Get supported languages
    getSupportedLanguages() {
        return this.supportedLanguages;
    }

    // Format currency based on language
    formatCurrency(amount, currency = 'USD') {
        const formatters = {
            'en': new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }),
            'es': new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR' }),
            'fr': new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }),
            'de': new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }),
            'it': new Intl.NumberFormat('it-IT', { style: 'currency', currency: 'EUR' }),
            'pt': new Intl.NumberFormat('pt-PT', { style: 'currency', currency: 'EUR' }),
            'zh': new Intl.NumberFormat('zh-CN', { style: 'currency', currency: 'CNY' }),
            'ja': new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }),
            'ko': new Intl.NumberFormat('ko-KR', { style: 'currency', currency: 'KRW' }),
            'ar': new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR' })
        };
        
        const formatter = formatters[this.currentLanguage] || formatters['en'];
        return formatter.format(amount);
    }

    // Format date based on language
    formatDate(date, options = {}) {
        const locales = {
            'en': 'en-US',
            'es': 'es-ES',
            'fr': 'fr-FR',
            'de': 'de-DE',
            'it': 'it-IT',
            'pt': 'pt-PT',
            'zh': 'zh-CN',
            'ja': 'ja-JP',
            'ko': 'ko-KR',
            'ar': 'ar-SA'
        };
        
        const locale = locales[this.currentLanguage] || 'en-US';
        return new Intl.DateTimeFormat(locale, options).format(new Date(date));
    }
}

// Initialize multi-language support when DOM is loaded
document.addEventListener('DOMContentLoaded', async function() {
    window.multiLanguageManager = new MultiLanguageManager();
    await window.multiLanguageManager.init();
});

// Export for use in other scripts
window.MultiLanguageManager = MultiLanguageManager;
