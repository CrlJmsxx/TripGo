/**
 * Driver Dashboard Enhancement - FIXED VERSION
 * Addresses performance, data integrity, and frontend reliability issues
 */

class EnhancedRequestManagerFixed {
    constructor() {
        this.currentRequests = [];
        this.mapManager = null;
        this.listManager = null;
        this.performanceManager = new PerformanceManager();
        this.isLoading = false;
        this.isInitialized = false;
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.initializeComponents();
        this.isInitialized = true;
        console.log('Enhanced Request Manager (Fixed) initialized');
    }

    setupEventListeners() {
        // Filter button
        const filterBtn = document.getElementById('filterAllRequestsBtn');
        if (filterBtn) {
            filterBtn.addEventListener('click', () => {
                this.loadAllRequests();
            });
        }

        // Radius filter
        const applyBtn = document.getElementById('applyRadiusFilter');
        if (applyBtn) {
            applyBtn.addEventListener('click', () => {
                const radius = document.getElementById('maxRadius')?.value || 50;
                this.loadAllRequests(radius);
            });
        }

        // Enter key on radius input
        const radiusInput = document.getElementById('maxRadius');
        if (radiusInput) {
            radiusInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    const radius = e.target.value || 50;
                    this.loadAllRequests(radius);
                }
            });
        }
    }

    initializeComponents() {
        try {
            console.log('Attempting to initialize components...');
            
            // Initialize map manager
            try {
                this.mapManager = new EnhancedRequestMapFixed();
                console.log('✓ Map manager initialized');
            } catch (error) {
                console.error('✗ Error initializing map manager:', error);
                this.mapManager = null;
                // Continue - map is optional
            }
            
            // Initialize list manager
            try {
                this.listManager = new RequestListManagerFixed();
                console.log('✓ List manager initialized');
            } catch (error) {
                console.error('✗ Error initializing list manager:', error);
                this.listManager = null;
                throw new Error('Critical: List manager failed to initialize - feature cannot work');
            }
            
            console.log('✓ All critical components initialized successfully');
        } catch (error) {
            console.error('Fatal error initializing components:', error);
            this.showError('Dashboard component initialization failed. Please refresh the page.');
            this.isInitialized = false;
            throw error;
        }
    }

    async loadAllRequests(maxRadius = 50) {
        if (this.isLoading || !this.isInitialized) {
            console.log('Loading in progress or not initialized');
            return;
        }

        // Validate critical components are ready (listManager is critical; mapManager is optional)
        if (!this.listManager) {
            console.error('List manager not properly initialized');
            this.showError('Dashboard components not ready. Please refresh the page.');
            return;
        }

        // Check cache first
        const cachedData = this.performanceManager.getCachedRequests(maxRadius);
        if (cachedData) {
            this.handleRequestData(cachedData);
            return;
        }

        this.isLoading = true;
        this.showLoadingState();

        try {
            console.log('Fetching requests with radius:', maxRadius);
            
            // Use optimized endpoint
            const response = await fetch(`../api/get_all_requests_optimized.php?max_radius=${maxRadius}`, {
                method: 'GET',
                credentials: 'same-origin',
                headers: {
                    'Accept': 'application/json',
                    'Cache-Control': 'no-cache'
                }
            });
            
            console.log('Response status:', response.status);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const responseText = await response.text();
            console.log('Raw response:', responseText);
            
            // Safe JSON parsing
            let data;
            try {
                data = JSON.parse(responseText);
            } catch (parseError) {
                console.error('JSON parse error:', parseError);
                throw new Error('Invalid JSON response from server');
            }

            console.log('Parsed data:', data);

            // Validate response structure
            if (!data || typeof data !== 'object') {
                throw new Error('Invalid response format');
            }

            if (data.success) {
                // Validate requests array
                if (!Array.isArray(data.requests)) {
                    console.warn('Requests is not an array, using empty array');
                    data.requests = [];
                }

                // Cache the results
                this.performanceManager.setCachedRequests(maxRadius, data);
                this.handleRequestData(data);
            } else {
                this.showError(data.error || 'Failed to load requests');
            }
        } catch (error) {
            console.error('Error loading requests:', error);
            this.showError(`Network error: ${error.message}. Please try again.`);
        } finally {
            this.isLoading = false;
            this.hideLoadingState();
        }
    }

    handleRequestData(data) {
        try {
            // Comprehensive validation
            if (!data || typeof data !== 'object') {
                console.error('Invalid data object:', data);
                this.showError('Invalid response format from server');
                return;
            }

            if (!data.success) {
                this.showError(data.error || 'Failed to load requests');
                console.warn('API returned success=false:', data.error);
                return;
            }

            // Ensure requests is an array
            const requests = Array.isArray(data.requests) ? data.requests : [];
            console.log(`Received ${requests.length} requests from API`);
            this.currentRequests = requests;

            // Validate components exist before proceeding
            if (!this.listManager) {
                console.error('List manager is null or undefined');
                this.showError('Dashboard list component not initialized. Please refresh the page.');
                return;
            }

            if (!this.mapManager) {
                console.warn('Map manager is null or undefined - map will not display');
                // Continue but only update list
            }

            // Update components with proper error handling
            const updatePromises = [];

            // Update list (critical)
            if (typeof this.listManager.updateRequestList === 'function') {
                try {
                    const listPromise = Promise.resolve(this.listManager.updateRequestList(requests));
                    updatePromises.push(
                        listPromise.catch(err => {
                            console.error('List update error:', err);
                            this.showError('Error updating request list');
                        })
                    );
                } catch (error) {
                    console.error('Error calling updateRequestList:', error);
                    this.showError('Error displaying requests');
                    return;
                }
            } else {
                console.error('listManager.updateRequestList is not a function');
                this.showError('List manager method not available');
                return;
            }

            // Update map (optional)
            if (this.mapManager && typeof this.mapManager.updateMapMarkers === 'function') {
                try {
                    const mapPromise = Promise.resolve(
                        this.mapManager.updateMapMarkers(requests, data.driver_location)
                    );
                    updatePromises.push(
                        mapPromise.catch(err => {
                            console.warn('Map update error (non-critical):', err);
                        })
                    );
                } catch (error) {
                    console.warn('Error calling updateMapMarkers (non-critical):', error);
                    // Continue without map update
                }
            }

            // Wait for all updates and then show status
            Promise.all(updatePromises)
                .then(() => {
                    this.updateFilterStatus(data);
                    console.log('✓ Request display updated successfully');
                })
                .catch(err => {
                    console.error('Unhandled error updating display:', err);
                });

        } catch (error) {
            console.error('Error in handleRequestData:', error);
            this.showError('Error processing server response: ' + error.message);
        }
    }

    updateFilterStatus(data) {
        try {
            const statusElement = document.getElementById('filterStatus');
            if (statusElement) {
                const performanceInfo = data.performance ? 
                    ` (pre-filtered: ${data.performance.pre_filtered_count})` : '';
                
                statusElement.innerHTML = `
                    <span style="color: #28a745;">
                        <i class="fas fa-check-circle"></i> 
                        Found ${data.total_found} requests within ${data.max_radius}km${performanceInfo}
                    </span>
                `;
            }
        } catch (error) {
            console.error('Error updating filter status:', error);
        }
    }

    showLoadingState() {
        try {
            const filterBtn = document.getElementById('filterAllRequestsBtn');
            const statusElement = document.getElementById('filterStatus');
            
            if (filterBtn) {
                filterBtn.disabled = true;
                filterBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
            }
            
            if (statusElement) {
                statusElement.textContent = 'Searching for requests...';
            }
        } catch (error) {
            console.error('Error showing loading state:', error);
        }
    }

    hideLoadingState() {
        try {
            const filterBtn = document.getElementById('filterAllRequestsBtn');
            
            if (filterBtn) {
                filterBtn.disabled = false;
                filterBtn.innerHTML = '<i class="fas fa-search"></i> Filter All Requests';
            }
        } catch (error) {
            console.error('Error hiding loading state:', error);
        }
    }

    showError(message) {
        try {
            const statusElement = document.getElementById('filterStatus');
            if (statusElement) {
                statusElement.innerHTML = `
                    <span style="color: #dc3545;">
                        <i class="fas fa-exclamation-circle"></i> ${message}
                    </span>
                `;
            }
        } catch (error) {
            console.error('Error showing error message:', error);
            alert(message); // Fallback
        }
    }

    async acceptRequest(bookingId) {
        try {
            const response = await fetch('dashboard.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `update_ride_status=1&booking_id=${bookingId}&status=accepted`
            });

            const data = await response.json();
            
            if (data.success) {
                // Remove the accepted request from the list
                this.currentRequests = this.currentRequests.filter(req => req.id !== bookingId);
                this.listManager.updateRequestList(this.currentRequests);
                this.mapManager.removeRequestMarker(bookingId);
                
                // Show success message
                this.showSuccessMessage('Request accepted successfully!');
                
                // Reload page to update active bookings
                setTimeout(() => window.location.reload(), 1500);
            } else {
                alert('Error: ' + (data.error || 'Failed to accept request'));
            }
        } catch (error) {
            console.error('Error accepting request:', error);
            alert('Network error. Please try again.');
        }
    }

    showSuccessMessage(message) {
        try {
            const statusElement = document.getElementById('filterStatus');
            if (statusElement) {
                statusElement.innerHTML = `
                    <span style="color: #28a745;">
                        <i class="fas fa-check-circle"></i> ${message}
                    </span>
                `;
            }
        } catch (error) {
            console.error('Error showing success message:', error);
        }
    }
}

/**
 * Enhanced Map Manager - FIXED VERSION
 */
class EnhancedRequestMapFixed {
    constructor() {
        this.map = null;
        this.driverMarker = null;
        this.requestMarkers = new Map();
        this.currentBounds = null;
        this.init();
    }

    init() {
        // Wait for map to be initialized by existing script
        if (window.driverMap) {
            this.map = window.driverMap;
            this.setupDriverMarker();
        } else {
            // Fallback: initialize map if not already done
            setTimeout(() => this.init(), 1000);
        }
    }

    setupDriverMarker() {
        if (!this.map) return;

        // Driver marker should already exist, just reference it
        const driverMarkers = this.map._layers;
        Object.values(driverMarkers).forEach(marker => {
            if (marker.options && marker.options.className === 'driver-marker') {
                this.driverMarker = marker;
            }
        });
    }

    async updateMapMarkers(requests, driverLocation) {
        if (!this.map) {
            console.warn('Map not available');
            return;
        }

        // Validate inputs
        if (!Array.isArray(requests)) {
            console.warn('Invalid requests data');
            requests = [];
        }

        if (!driverLocation || !driverLocation.latitude || !driverLocation.longitude) {
            console.warn('Invalid driver location');
            return;
        }

        // Clear existing request markers
        this.clearRequestMarkers();

        if (requests.length === 0) return;

        // Add new request markers with validation
        requests.forEach(request => {
            if (this.isValidRequest(request)) {
                const marker = this.createRequestMarker(request);
                marker.addTo(this.map);
                this.requestMarkers.set(request.id, marker);
            } else {
                console.warn('Invalid request data:', request);
            }
        });

        // Adjust map bounds to show all requests
        this.adjustMapBounds(requests, driverLocation);
    }

    isValidRequest(request) {
        return request && 
               typeof request.id === 'number' &&
               typeof request.pickup_latitude === 'number' &&
               typeof request.pickup_longitude === 'number' &&
               request.pickup_latitude >= -90 && request.pickup_latitude <= 90 &&
               request.pickup_longitude >= -180 && request.pickup_longitude <= 180;
    }

    createRequestMarker(request) {
        const color = this.getDistanceColor(request.distance_km || 0);
        
        const customIcon = L.divIcon({
            className: 'custom-request-marker',
            html: `<div style="
                background: ${color}; 
                width: 12px; 
                height: 12px; 
                border-radius: 50%; 
                border: 2px solid white;
                box-shadow: 0 2px 4px rgba(0,0,0,0.3);
            "></div>`,
            iconSize: [16, 16],
            iconAnchor: [8, 8]
        });

        const marker = L.marker([request.pickup_latitude, request.pickup_longitude], {
            icon: customIcon,
            title: `Request #${request.id} - ${(request.distance_km || 0).toFixed(1)}km`
        });

        // Add popup with request details
        marker.bindPopup(this.createPopupContent(request));

        // Add click event for modal
        marker.on('click', () => {
            if (window.requestManager) {
                window.requestManager.showRequestModal(request);
            }
        });

        return marker;
    }

    getDistanceColor(distance) {
        if (distance < 5) return '#28a745'; // Green - very close
        if (distance < 15) return '#ffc107'; // Yellow - close
        if (distance < 30) return '#fd7e14'; // Orange - moderate
        return '#dc3545'; // Red - far
    }

    createPopupContent(request) {
        const safeRequest = {
            id: request.id || 'Unknown',
            passenger_name: request.passenger_name || 'Unknown',
            distance_km: (request.distance_km || 0).toFixed(2),
            estimated_fare: (request.estimated_fare || 0).toFixed(2),
            pickup_address: request.pickup_address || 'Unknown location'
        };

        return `
            <div style="min-width: 200px;">
                <h4 style="margin: 0 0 8px 0; color: #333;">
                    <i class="fas fa-map-marker-alt"></i> Request #${safeRequest.id}
                </h4>
                <div style="font-size: 14px; line-height: 1.4;">
                    <div><strong>Passenger:</strong> ${safeRequest.passenger_name}</div>
                    <div><strong>Distance:</strong> <span style="background: #007bff; color: white; padding: 2px 6px; border-radius: 10px; font-size: 12px;">${safeRequest.distance_km} km</span></div>
                    <div><strong>Fare:</strong> ₱${safeRequest.estimated_fare}</div>
                    <div><strong>Pickup:</strong> ${safeRequest.pickup_address}</div>
                </div>
                <button onclick="window.requestManager.acceptRequest(${safeRequest.id})" 
                        style="margin-top: 8px; padding: 4px 12px; background: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer;">
                    <i class="fas fa-check"></i> Accept
                </button>
            </div>
        `;
    }

    adjustMapBounds(requests, driverLocation) {
        if (!this.map || requests.length === 0) return;

        try {
            const bounds = L.latLngBounds();
            
            // Add driver location
            bounds.extend([driverLocation.latitude, driverLocation.longitude]);
            
            // Add valid request locations
            requests.forEach(request => {
                if (this.isValidRequest(request)) {
                    bounds.extend([request.pickup_latitude, request.pickup_longitude]);
                }
            });

            // Fit map to bounds with padding
            this.map.fitBounds(bounds, {
                padding: [50, 50],
                maxZoom: 15
            });
        } catch (error) {
            console.error('Error adjusting map bounds:', error);
        }
    }

    clearRequestMarkers() {
        this.requestMarkers.forEach(marker => {
            try {
                this.map.removeLayer(marker);
            } catch (error) {
                console.warn('Error removing marker:', error);
            }
        });
        this.requestMarkers.clear();
    }

    removeRequestMarker(bookingId) {
        const marker = this.requestMarkers.get(bookingId);
        if (marker) {
            try {
                this.map.removeLayer(marker);
                this.requestMarkers.delete(bookingId);
            } catch (error) {
                console.warn('Error removing request marker:', error);
            }
        }
    }
}

/**
 * Request List Manager - FIXED VERSION
 */
class RequestListManagerFixed {
    constructor() {
        this.container = document.getElementById('enhancedRequestList');
        this.createContainerIfNotExists();
    }

    createContainerIfNotExists() {
        if (!this.container) {
            const container = document.createElement('div');
            container.id = 'enhancedRequestList';
            container.className = 'request-list-container';
            
            // Insert after the existing pending bookings section by searching headers safely
            let inserted = false;
            try {
                const headers = document.querySelectorAll('.card h3, .card .card-title, .card h2, .card h1');
                for (const header of headers) {
                    const text = (header.textContent || '').trim();
                    if (/pending ride requests/i.test(text) || /pending booking requests/i.test(text) || /pending requests/i.test(text)) {
                        const card = header.closest('.card');
                        if (card && card.parentNode) {
                            card.parentNode.insertBefore(container, card.nextSibling);
                            inserted = true;
                            break;
                        }
                    }
                }
            } catch (e) {
                console.warn('Safe header search failed:', e);
            }

            if (!inserted) {
                // Fallback: add to main container
                const mainContainer = document.querySelector('.container');
                if (mainContainer) {
                    mainContainer.appendChild(container);
                }
            }
            
            this.container = container;
        }
    }

    async updateRequestList(requests) {
        if (!this.container) {
            console.warn('Request list container not found');
            return;
        }

        // Validate requests
        if (!Array.isArray(requests)) {
            console.warn('Invalid requests data');
            requests = [];
        }

        if (requests.length === 0) {
            this.container.innerHTML = `
                <div class="no-requests" style="
                    text-align: center; 
                    padding: 40px; 
                    color: #666; 
                    background: #f8f9fa; 
                    border-radius: 8px; 
                    margin: 20px 0;
                    border: 2px dashed #ddd;
                ">
                    <i class="fas fa-search" style="font-size: 48px; margin-bottom: 16px; color: #ddd;"></i>
                    <p style="margin: 0;">No requests found within the specified radius.</p>
                </div>
            `;
            return;
        }

        const html = requests.map(request => this.createRequestItem(request)).join('');
        this.container.innerHTML = html;
        
        // Add event listeners
        this.attachEventListeners();
    }

    createRequestItem(request) {
        // Safe request data with defaults
        const safeRequest = {
            id: request.id || 0,
            passenger_name: request.passenger_name || 'Unknown',
            pickup_address: request.pickup_address || 'Unknown location',
            dropoff_address: request.dropoff_address || 'Unknown destination',
            estimated_fare: (request.estimated_fare || 0).toFixed(2),
            distance_km: (request.distance_km || 0).toFixed(2),
            booking_time: request.booking_time || ''
        };

        return `
            <div class="request-item-enhanced" data-request-id="${safeRequest.id}" style="
                background: white; 
                border: 1px solid #ddd; 
                border-radius: 8px; 
                padding: 15px; 
                margin-bottom: 12px; 
                display: flex; 
                justify-content: space-between; 
                align-items: center; 
                transition: all 0.2s ease;
            ">
                <div class="request-details" style="flex: 1;">
                    <div class="request-header" style="
                        display: flex; 
                        justify-content: space-between; 
                        align-items: center; 
                        margin-bottom: 8px;
                    ">
                        <strong style="font-size: 16px; color: #333;">${safeRequest.passenger_name}</strong>
                        <span class="distance-badge" style="
                            background: #007bff; 
                            color: white; 
                            padding: 4px 8px; 
                            border-radius: 12px; 
                            font-size: 12px; 
                            font-weight: bold;
                        ">${safeRequest.distance_km} km</span>
                    </div>
                    <div class="request-route" style="margin-bottom: 8px;">
                        <div class="route-point" style="display: flex; align-items: center; margin-bottom: 4px; font-size: 14px;">
                            <i class="fas fa-map-marker-alt" style="color: #28a745; margin-right: 8px;"></i>
                            ${safeRequest.pickup_address}
                        </div>
                        <div class="route-point" style="display: flex; align-items: center; font-size: 14px;">
                            <i class="fas fa-flag-checkered" style="color: #dc3545; margin-right: 8px;"></i>
                            ${safeRequest.dropoff_address}
                        </div>
                    </div>
                    <div class="request-meta" style="
                        display: flex; 
                        gap: 15px; 
                        font-size: 13px; 
                        color: #666;
                    ">
                        <span><i class="fas fa-dollar-sign"></i> ₱${safeRequest.estimated_fare}</span>
                        <span><i class="fas fa-clock"></i> ${this.formatTime(safeRequest.booking_time)}</span>
                    </div>
                </div>
                <div class="request-actions" style="
                    display: flex; 
                    gap: 8px; 
                    margin-left: 15px;
                ">
                    <button class="btn btn-primary btn-sm accept-btn" data-booking-id="${safeRequest.id}" style="
                        padding: 6px 12px; 
                        font-size: 13px;
                    ">
                        <i class="fas fa-check"></i> Accept
                    </button>
                    <button class="btn btn-outline btn-sm view-btn" data-request-id="${safeRequest.id}" style="
                        padding: 6px 12px; 
                        font-size: 13px;
                        background: white; 
                        border: 1px solid #ddd;
                    ">
                        <i class="fas fa-eye"></i> View
                    </button>
                </div>
            </div>
        `;
    }

    attachEventListeners() {
        try {
            // Accept buttons
            this.container.querySelectorAll('.accept-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const bookingId = e.target.dataset.bookingId;
                    if (window.requestManager) {
                        window.requestManager.acceptRequest(bookingId);
                    }
                });
            });

            // View buttons
            this.container.querySelectorAll('.view-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const requestId = e.target.dataset.requestId;
                    const request = window.requestManager?.currentRequests.find(r => r.id == requestId);
                    if (request && window.requestManager) {
                        window.requestManager.showRequestModal(request);
                    }
                });
            });

            // Hover effects
            this.container.querySelectorAll('.request-item-enhanced').forEach(item => {
                item.addEventListener('mouseenter', () => {
                    item.style.boxShadow = '0 4px 12px rgba(0,0,0,0.1)';
                    item.style.transform = 'translateY(-2px)';
                });
                
                item.addEventListener('mouseleave', () => {
                    item.style.boxShadow = '';
                    item.style.transform = '';
                });
            });
        } catch (error) {
            console.error('Error attaching event listeners:', error);
        }
    }

    formatTime(bookingTime) {
        try {
            const date = new Date(bookingTime);
            const now = new Date();
            const diff = now - date;
            
            if (diff < 60000) return 'Just now';
            if (diff < 3600000) return `${Math.floor(diff / 60000)} min ago`;
            if (diff < 86400000) return `${Math.floor(diff / 3600000)} hours ago`;
            return date.toLocaleDateString();
        } catch (error) {
            return 'Unknown time';
        }
    }
}

/**
 * Performance Manager - FIXED VERSION
 */
class PerformanceManager {
    constructor() {
        this.requestCache = new Map();
        this.cacheTimeout = 30000; // 30 seconds
    }

    getCachedRequests(maxRadius) {
        const cacheKey = `requests_${maxRadius}`;
        const cached = this.requestCache.get(cacheKey);
        
        if (cached && (Date.now() - cached.timestamp) < this.cacheTimeout) {
            return cached.data;
        }
        
        return null;
    }

    setCachedRequests(maxRadius, data) {
        const cacheKey = `requests_${maxRadius}`;
        this.requestCache.set(cacheKey, {
            data: data,
            timestamp: Date.now()
        });
    }

    clearCache() {
        this.requestCache.clear();
    }
}

// Modal functionality for request details
EnhancedRequestManagerFixed.prototype.showRequestModal = function(request) {
    try {
        // Remove existing modal
        const existingModal = document.getElementById('requestModal');
        if (existingModal) {
            existingModal.remove();
        }
        
        // Validate request data
        if (!request || !request.id) {
            console.warn('Invalid request data for modal');
            return;
        }
        
        // Create modal element
        const modal = document.createElement('div');
        modal.id = 'requestModal';
        modal.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.15);
            border: 1px solid #ddd;
            max-width: 400px;
            z-index: 1000;
            max-height: 80vh;
            overflow-y: auto;
        `;
        
        const safeRequest = {
            id: request.id || 'Unknown',
            passenger_name: request.passenger_name || 'Unknown',
            distance_km: (request.distance_km || 0).toFixed(2),
            estimated_fare: (request.estimated_fare || 0).toFixed(2),
            pickup_address: request.pickup_address || 'Unknown location',
            dropoff_address: request.dropoff_address || 'Unknown destination',
            booking_time: request.booking_time || ''
        };
        
        modal.innerHTML = `
            <div style="padding: 0;">
                <div style="
                    background: #007bff; 
                    color: white; 
                    padding: 16px 20px; 
                    border-radius: 12px 12px 0 0; 
                    display: flex; 
                    justify-content: space-between; 
                    align-items: center;
                ">
                    <h4 style="margin: 0; font-size: 18px;">
                        <i class="fas fa-map-marker-alt"></i> Ride Request #${safeRequest.id}
                    </h4>
                    <button class="close-modal" style="
                        background: none; 
                        border: none; 
                        color: white; 
                        font-size: 24px; 
                        cursor: pointer; 
                        padding: 0; 
                        width: 32px; 
                        height: 32px;
                    ">&times;</button>
                </div>
                <div style="padding: 20px;">
                    <div style="margin-bottom: 16px;">
                        <div style="margin-bottom: 8px; font-size: 14px;">
                            <strong>Passenger:</strong> ${safeRequest.passenger_name}
                        </div>
                        <div style="margin-bottom: 8px; font-size: 14px;">
                            <strong>Distance:</strong> <span style="background: #007bff; color: white; padding: 2px 6px; border-radius: 10px; font-size: 12px;">${safeRequest.distance_km} km</span>
                        </div>
                        <div style="margin-bottom: 8px; font-size: 14px;">
                            <strong>Pickup:</strong> ${safeRequest.pickup_address}
                        </div>
                        <div style="margin-bottom: 8px; font-size: 14px;">
                            <strong>Destination:</strong> ${safeRequest.dropoff_address}
                        </div>
                        <div style="margin-bottom: 8px; font-size: 14px;">
                            <strong>Estimated Fare:</strong> ₱${safeRequest.estimated_fare}
                        </div>
                        <div style="margin-bottom: 8px; font-size: 14px;">
                            <strong>Posted:</strong> ${this.formatTime(safeRequest.booking_time)}
                        </div>
                    </div>
                    <div style="display: flex; gap: 12px;">
                        <button class="accept-request-btn" data-booking-id="${safeRequest.id}" style="
                            flex: 1; 
                            padding: 8px 16px; 
                            background: #28a745; 
                            color: white; 
                            border: none; 
                            border-radius: 4px; 
                            cursor: pointer;
                        ">
                            <i class="fas fa-check"></i> Accept Request
                        </button>
                        <button class="close-modal" style="
                            padding: 8px 16px; 
                            background: #6c757d; 
                            color: white; 
                            border: none; 
                            border-radius: 4px; 
                            cursor: pointer;
                        ">
                            <i class="fas fa-times"></i> Close
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Add event listeners
        modal.querySelector('.accept-request-btn').addEventListener('click', () => {
            this.acceptRequest(safeRequest.id);
            modal.remove();
        });
        
        modal.querySelectorAll('.close-modal').forEach(btn => {
            btn.addEventListener('click', () => modal.remove());
        });
        
        // Close on outside click
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
    } catch (error) {
        console.error('Error showing request modal:', error);
    }
};

// Helper method for time formatting
EnhancedRequestManagerFixed.prototype.formatTime = RequestListManagerFixed.prototype.formatTime;

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOMContentLoaded event fired - initializing Enhanced Request Manager');
    
    // Wait a bit for existing scripts to load
    setTimeout(() => {
        try {
            console.log('Creating EnhancedRequestManagerFixed instance...');
            window.requestManager = new EnhancedRequestManagerFixed();
            console.log('✓ Driver Dashboard Enhanced (Fixed) loaded successfully');
            console.log('  - Request Manager available at window.requestManager');
            console.log('  - Click "Filter All Requests" button to test the feature');
        } catch (error) {
            console.error('✗ CRITICAL: Failed to initialize Enhanced Request Manager:', error);
            console.error('  Stack trace:', error.stack);
            // Attempt to show error to user
            const statusElement = document.getElementById('filterStatus');
            if (statusElement) {
                statusElement.innerHTML = '<span style="color: #dc3545;"><i class="fas fa-exclamation-circle"></i> Dashboard initialization failed. Please refresh the page.</span>';
            }
        }
    }, 1000);
});
