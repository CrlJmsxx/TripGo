<?php
// Performance test script
$start_time = microtime(true);
$memory_start = memory_get_usage();

echo "<h2>TripGO Performance Test</h2>";

// Test database connection
$db_start = microtime(true);
try {
    require_once 'config/database.php';
    $pdo = getConnection();
    $db_time = (microtime(true) - $db_start) * 1000;
    echo "✅ Database Connection: " . number_format($db_time, 2) . "ms<br>";
} catch (Exception $e) {
    echo "❌ Database Connection Failed: " . $e->getMessage() . "<br>";
}

// Test session
$session_start = microtime(true);
try {
    require_once 'config/session.php';
    $session_time = (microtime(true) - $session_start) * 1000;
    echo "✅ Session Load: " . number_format($session_time, 2) . "ms<br>";
} catch (Exception $e) {
    echo "❌ Session Load Failed: " . $e->getMessage() . "<br>";
}

// Total load time
$total_time = (microtime(true) - $start_time) * 1000;
$memory_used = (memory_get_usage() - $memory_start) / 1024;

echo "<hr>";
echo "<strong>Total Load Time:</strong> " . number_format($total_time, 2) . "ms<br>";
echo "<strong>Memory Used:</strong> " . number_format($memory_used, 2) . " KB<br>";

if ($total_time > 1000) {
    echo "<div style='color: red;'><strong>⚠️ Slow Performance Detected!</strong></div>";
} else {
    echo "<div style='color: green;'><strong>✅ Performance is Good</strong></div>";
}
?>
